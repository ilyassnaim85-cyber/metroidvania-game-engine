// Fast checks that need no browser: node tests/unit.js   (also run by npm test)
const assert = require('assert'),
  fs = require('fs'),
  path = require('path');
const V = require('../tools/validate.js'),
  MV = V.engine();
const wav = (hz, dur) => {
  const sr = 8000,
    n = Math.floor(sr * dur),
    b = Buffer.alloc(44 + n * 2);
  b.write('RIFF', 0);
  b.writeUInt32LE(36 + n * 2, 4);
  b.write('WAVEfmt ', 8);
  b.writeUInt32LE(16, 16);
  b.writeUInt16LE(1, 20);
  b.writeUInt16LE(1, 22);
  b.writeUInt32LE(sr, 24);
  b.writeUInt32LE(sr * 2, 28);
  b.writeUInt16LE(2, 32);
  b.writeUInt16LE(16, 34);
  b.write('data', 36);
  b.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) b.writeInt16LE(Math.round(Math.sin((i / sr) * hz * 6.2832) * 9000), 44 + i * 2);
  return 'data:audio/wav;base64,' + b.toString('base64');
};
let pass = 0,
  fail = 0;
const t = (name, fn) => {
  try {
    fn();
    pass++;
    console.log('  ok   ' + name);
  } catch (e) {
    fail++;
    console.log('  FAIL ' + name + '\n       ' + e.message);
  }
};

t('events: clean is stable and drops junk', () => {
  const a = MV.Events.clean([
    {
      id: 'x',
      name: 'N',
      trigger: { type: 'flag', flag: 'f' },
      actions: [{ type: 'setflag', flag: 'g' }, { type: 'nonsense' }]
    },
    null,
    5
  ]);
  assert.strictEqual(a.length, 1);
  assert.strictEqual(a[0].actions.length, 1);
  assert.deepStrictEqual(MV.Events.clean(a), a);
});
t('events: validate finds missing room, item and event', () => {
  const w = {
    areas: [{ id: 'a', rooms: [{ id: 'r', n: 'R', ent: [] }] }],
    items: [],
    bosses: [],
    events: MV.Events.clean([
      {
        id: 'e',
        name: 'E',
        trigger: { type: 'room', room: 'gone' },
        actions: [
          { type: 'giveitem', item: 'nope', n: 1 },
          { type: 'event', event: 'zz' }
        ]
      }
    ])
  };
  const bad = MV.Events.validate(w).filter(i => i.level === 'error');
  assert.ok(bad.length >= 3, 'errors: ' + bad.length);
});
t('events: a loop of events is reported', () => {
  const w = {
    areas: [],
    events: MV.Events.clean([
      { id: 'a', name: 'A', trigger: { type: 'called' }, actions: [{ type: 'event', event: 'b' }] },
      { id: 'b', name: 'B', trigger: { type: 'called' }, actions: [{ type: 'event', event: 'a' }] }
    ])
  };
  assert.ok(MV.Events.validate(w).some(i => /loop/.test(i.text)));
});
t('audio: only real audio data URLs are kept, ids are unique', () => {
  const u = wav(300, 0.1);
  const l = MV.Audio.cleanList([
    { id: 'a', src: 'data:text/html;base64,AAAA' },
    { id: 'a', src: u },
    { id: 'b c!', src: u }
  ]);
  assert.strictEqual(l[0].src, '');
  assert.strictEqual(l[1].id, 'ax');
  assert.ok(/^[\w-]+$/.test(l[2].id));
});
t('audio: validate finds missing sounds and music', () => {
  const w = {
    sounds: [],
    sfx: { jump: 'x' },
    areas: [{ rooms: [{ id: 'r', n: 'R', music: 'm' }] }],
    events: [{ name: 'E', actions: [{ type: 'sound', sound: 'q' }] }],
    moves: [{ id: 'd', effects: [{ do: 'sound', snd: 'z' }] }],
    attacks: []
  };
  assert.strictEqual(MV.Audio.validate(w).filter(i => i.level === 'error').length, 4);
});
t('camera: profiles are cleaned and built-ins cannot be reused', () => {
  const l = MV.Camera.cleanProfiles([
    { id: 'vlock', p: {} },
    { id: 'cave', name: 'Cave', p: { modeY: 'locked', camLookAhead: 99, junk: 1 } }
  ]);
  assert.strictEqual(l.length, 1);
  assert.strictEqual(l[0].p.camLookAhead, MV.data.playerSchema.camLookAhead.max);
  assert.strictEqual(l[0].p.junk, undefined);
});
t('background: up to 256 layers with blur and fog kept in range', () => {
  const b = MV.Background.clean({
    color: '#112233',
    layers: Array.from({ length: 300 }, () => ({ blur: 99, fog: 7, fogDir: 'bottom' }))
  });
  assert.strictEqual(b.layers.length, 256);
  assert.strictEqual(b.layers[0].blur, 40);
  assert.strictEqual(b.layers[0].fog, 1);
});
t('moves: every move type in the editor list is known to the engine', () => {
  const f = MV.data.moveFields;
  ['dash', 'sequence', 'impulse', 'hold', 'surface', 'ledge', 'swim', 'grapple', 'bash', 'throw'].forEach(x =>
    assert.ok(f.type.o.includes(x), x)
  );
  ['on', 'runs', 'sqw', 'nojump', 'state', 'fly', 'phase', 'how', 'grab', 'climb'].forEach(k =>
    assert.ok(f[k], 'field ' + k)
  );
});
t('config: new entities exist with skins', () => {
  ['rail', 'cannon', 'mount', 'airpocket', 'camzone', 'evzone'].forEach(k => assert.ok(MV.data.entities[k], k));
});
t('validate tool: the fixture has the errors we put in it', () => {
  const proj = V.read(fs.readFileSync(path.join(__dirname, 'fixture.json'), 'utf8')),
    rep = V.check(MV, proj);
  assert.ok(rep.some(i => /gone_room|does not exist/.test(i.text) && i.level === 'error'));
  assert.ok(rep.filter(i => i.level === 'error').length >= 3);
});
t('validate tool: a clean project passes', () => {
  const proj = V.read(fs.readFileSync(path.join(__dirname, 'clean.json'), 'utf8')),
    rep = V.check(MV, proj);
  assert.strictEqual(
    rep.filter(i => i.level === 'error').length,
    0,
    JSON.stringify(rep.filter(i => i.level === 'error'))
  );
});
t('packed grids read back the same', () => {
  const rows = ['....##....', '....##....', '##########'],
    pack = {
      z: 1,
      d: [
        ['....##....', 2],
        ['##########', 1]
      ]
    };
  assert.deepStrictEqual(V.read(JSON.stringify({ grid: pack })).grid, rows);
});
t('progression: tuning keeps the energy, charm and death settings in range', () => {
  const T = MV.Tuning.resolve({ energyMax: 999, respawnHp: 0, coinsLost: 500, charmSlots: -4 });
  assert.strictEqual(T.energyMax, 200);
  assert.strictEqual(T.respawnHp, 1);
  assert.strictEqual(T.coinsLost, 100);
  assert.strictEqual(T.charmSlots, 0);
  const D = MV.Tuning.resolve({});
  assert.strictEqual(D.energyMax, 0);
  assert.strictEqual(D.respawnHp, 100);
  assert.strictEqual(D.coinsLost, 0);
});
t('progression: costs, hold effects and the charged trigger are cleaned', () => {
  const m = MV.Moves.clean1({
    id: 'f',
    type: 'hold',
    cost: 999,
    drain: -1,
    recharge: 'yes',
    chargeLock: 'yes',
    windup: 1,
    effects: [
      { on: 'charged', do: 'heal', value: 1 },
      { on: 'x', do: 'y' }
    ]
  });
  assert.strictEqual(m.cost, 200);
  assert.strictEqual(m.drain, 0);
  assert.strictEqual(m.recharge, 'yes');
  assert.strictEqual(m.chargeLock, 'yes');
  assert.strictEqual(m.effects[0].on, 'charged');
  assert.strictEqual(m.effects[1].on, 'hit');
  assert.strictEqual(MV.Moves.clean1({ id: 'w', type: 'swim' }).effects.length, 0);
  assert.strictEqual(MV.Attacks.clean1({ id: 'a', cost: 12 }).cost, 12);
});
t('progression: charm items are cleaned', () => {
  const d = MV.Inventory.clean1({
    id: 'c',
    use: 'charm',
    notches: 99,
    mods: [
      { key: 'maxHp', add: 50 },
      { key: 'bogus', add: 1 },
      { key: 'run', add: -2 }
    ],
    grant: 'dash'
  });
  assert.strictEqual(d.notches, 10);
  assert.strictEqual(d.mods.length, 2);
  assert.strictEqual(d.mods[0].add, 10);
  assert.strictEqual(d.grant, 'dash');
});
t('progression: new events actions and conditions exist and clean', () => {
  const e = MV.Events.clean([
    {
      id: 'p',
      trigger: { type: 'room' },
      conds: [{ type: 'energy', n: 20 }],
      actions: [
        { type: 'energy', n: -5 },
        { type: 'upgrade', stat: 'bogus', n: 2 }
      ]
    }
  ]);
  assert.strictEqual(e[0].conds.length, 1);
  assert.strictEqual(e[0].actions[1].stat, 'maxHp');
  assert.strictEqual(e[0].actions[0].n, -5);
});
t('progression: the checker warns about energy costs with no energy, charms with no notches', () => {
  const room = {
    id: 'r',
    n: 'R',
    gw: 10,
    gh: 6,
    grid: ['..........', '..........', '..........', '..........', '##########', '##########'],
    ent: [{ id: 's', type: 'spawn', x: 2, y: 3, props: {} }],
    tr: []
  };
  const w = {
    areas: [{ id: 'a', n: 'A', rooms: [room], links: [] }],
    player: {},
    moves: [MV.Moves.clean1({ id: 'z', type: 'dash', cost: 10 })],
    attacks: [],
    items: [MV.Inventory.clean1({ id: 'c', use: 'charm' })],
    events: []
  };
  let codes = MV.World.validate(w).map(i => i.code);
  assert.ok(codes.includes('energy-none'));
  assert.ok(codes.includes('charm-no-slots'));
  w.player = { energyMax: 40, charmSlots: 2 };
  codes = MV.World.validate(w).map(i => i.code);
  assert.ok(!codes.includes('energy-none'));
  assert.ok(!codes.includes('charm-no-slots'));
  assert.ok(codes.includes('energy-no-refill'));
  w.player.energyRegen = 2;
  assert.ok(!MV.World.validate(w).some(i => i.code === 'energy-no-refill'));
});
t('enemies: types are cleaned and ranges kept', () => {
  const d = MV.Enemies.clean1({
    id: 'a b',
    move: 'teleport',
    hp: 99999,
    w: 0,
    attack: 'shoot',
    coins: -3,
    color: 'red',
    clips: { idle: 'x', bogus: 'y', walk: 'bad id!' },
    dropItem: 'po tion'
  });
  assert.ok(/^[\w-]{1,24}$/.test(d.id));
  assert.strictEqual(d.move, 'patrol');
  assert.strictEqual(d.hp, 999);
  assert.strictEqual(d.w, 0.3);
  assert.strictEqual(d.coins, 0);
  assert.strictEqual(d.color, '#c0504d');
  assert.strictEqual(JSON.stringify(d.clips), '{"idle":"x"}');
  assert.strictEqual(d.dropItem, 'potion');
  assert.strictEqual(JSON.stringify(MV.Enemies.clean1(d)), JSON.stringify(d));
  assert.strictEqual(MV.Enemies.resolve([{ id: 'z' }, { id: 'z' }, null]).length, 2);
});
t('enemies: the shared hit rule gives safe time, knockback and flinch', () => {
  const a = { hp: 3, inv: 0, cx: 5, vx: 0 };
  let r = MV.Actor.hit(a, { dmg: 1, fromX: 3, knock: 4, flinch: 0.5, invul: 0.4 });
  assert.ok(r.hit && !r.dead);
  assert.strictEqual(a.hp, 2);
  assert.strictEqual(a.vx, 4);
  assert.strictEqual(a.stun, 0.5);
  assert.ok(!MV.Actor.hit(a, { dmg: 1, fromX: 3 }).hit);
  a.inv = 0;
  assert.ok(MV.Actor.hit(a, { dmg: 5, fromX: 9 }).dead);
});
t('enemies: the checker finds missing types, drops, pictures and blind chasers', () => {
  const room = {
    id: 'r',
    n: 'R',
    gw: 10,
    gh: 6,
    grid: ['..........', '..........', '..........', '..........', '##########', '##########'],
    ent: [
      { id: 's', type: 'spawn', x: 2, y: 3, props: {} },
      { id: 'e', type: 'enemy', x: 5, y: 3, props: { kind: 'ghost' } }
    ],
    tr: []
  };
  const w = {
    areas: [{ id: 'a', n: 'A', rooms: [room], links: [] }],
    player: {},
    moves: [],
    attacks: [],
    items: [],
    anims: [],
    sounds: [],
    events: [],
    enemies: MV.Enemies.resolve([
      { id: 'bat', move: 'fly', sight: 0, dropItem: 'gem', energy: 5, clips: { idle: 'nope' } }
    ])
  };
  const codes = MV.World.validate(w).map(i => i.code);
  ['enemy-missing', 'enemy-unused', 'enemy-drop', 'enemy-energy', 'enemy-anim', 'enemy-blind'].forEach(c =>
    assert.ok(codes.includes(c), c)
  );
});
t('enemies: the "enemy defeated" event trigger exists and matches a type', () => {
  const e = MV.Events.clean([
    { id: 'k', trigger: { type: 'enemy', enemy: 'bat' }, actions: [{ type: 'message', text: 'x' }] }
  ]);
  assert.strictEqual(e[0].trigger.type, 'enemy');
  assert.strictEqual(e[0].trigger.enemy, 'bat');
  assert.ok(MV.Events.validate({ events: e, enemies: [], areas: [] }).some(i => i.level === 'error'));
  assert.ok(!MV.Events.validate({ events: e, enemies: [{ id: 'bat' }], areas: [] }).some(i => i.level === 'error'));
});
t('hitboxes: shapes touch only where they really overlap', () => {
  const A = MV.Attacks,
    sq = (cx, cy, w, h) => ({ sh: 'rect', cx, cy, w, h }),
    ci = (cx, cy, r) => ({ sh: 'circle', cx, cy, r, w: r * 2, h: r * 2 }),
    tr = (cx, cy) => ({
      sh: 'polygon',
      cx,
      cy,
      pts: [
        { x: cx - 1, y: cy + 1 },
        { x: cx, y: cy - 1 },
        { x: cx + 1, y: cy + 1 }
      ],
      w: 2,
      h: 2
    });
  assert.ok(A.shapeHit(ci(0, 0, 1), sq(0.5, 0, 1, 1)), 'circle meets box at its middle');
  assert.ok(
    !A.shapeHit(ci(0, 0, 1), sq(1.35, 1.35, 1, 1)),
    'a box in the corner of the circle bounding box misses the circle'
  );
  assert.ok(!A.shapeHit(tr(0, 0), sq(0.85, -0.85, 0.5, 0.5)), 'the empty top corner of a triangle misses');
  assert.ok(A.shapeHit(tr(0, 0), sq(0, 0.8, 0.5, 0.5)), 'the triangle base is solid');
  assert.ok(A.shapeHit(ci(0, 0, 1), ci(1.5, 0, 1)) && !A.shapeHit(ci(0, 0, 1), ci(2.2, 0, 1)), 'circle against circle');
  assert.ok(A.shapeHit(tr(0, 0), ci(0, 0.2, 0.3)) && !A.shapeHit(tr(0, 0), ci(3, 0, 0.3)), 'triangle against circle');
});
t('enemies: shapes, weak spots and strike hitboxes are cleaned and mirrored', () => {
  const d = MV.Enemies.clean1({
    id: 'x',
    shape: 'polygon',
    attack: 'strike',
    atkDur: 1,
    weak: [{ x: 99, y: 0, w: 0, h: 2, mult: 50 }],
    strike: [{ name: 'Slam', w: 2, h: 1, from: 0.2, to: 9, dmg: 3, kf: [{ t: 0, x: 1, y: 0 }] }]
  });
  assert.ok(
    d.pts.length >= 3 && d.weak[0].x === 8 && d.weak[0].w === 0.1 && d.weak[0].mult === 10,
    JSON.stringify(d.weak)
  );
  assert.strictEqual(d.strike[0].dmg, 3);
  assert.strictEqual(d.strike[0].to, 1);
  const e = { cx: 10, by: 5, w: 2, h: 2, dir: -1 },
    r = MV.Enemies.strikeWorld(e, d, 0.5)[0];
  assert.ok(r.cx < 10, 'a strike on the left when facing left');
  assert.strictEqual(MV.Enemies.weakWorld(e, d)[0].cx, 10 - 8);
  assert.strictEqual(MV.Enemies.clean1({ shape: 'blob' }).shape, 'rect');
});
t('enemies: the checker finds enemies that can never be killed or have empty strikes', () => {
  const room = {
    id: 'r',
    n: 'R',
    gw: 10,
    gh: 6,
    grid: ['..........', '..........', '..........', '..........', '##########', '##########'],
    ent: [
      { id: 's', type: 'spawn', x: 2, y: 3, props: {} },
      { id: 'e', type: 'enemy', x: 5, y: 3, props: { kind: 'a' } },
      { id: 'f', type: 'enemy', x: 6, y: 3, props: { kind: 'b' } }
    ],
    tr: []
  };
  const w = {
    areas: [{ id: 'a', n: 'A', rooms: [room], links: [] }],
    player: {},
    moves: [],
    attacks: [],
    items: [],
    anims: [],
    sounds: [],
    events: [],
    enemies: MV.Enemies.resolve([
      { id: 'a', weakOnly: 'yes' },
      { id: 'b', attack: 'strike' }
    ])
  };
  const codes = MV.World.validate(w).map(i => i.code);
  assert.ok(codes.includes('enemy-unhittable') && codes.includes('enemy-strike-empty'), codes.join());
});
t('bosses: warning before hitboxes, shaped per-hitbox damage, phase change, sounds and restart', () => {
  const def = MV.Boss.clean({
    id: 'b',
    hp: 10,
    wake: 20,
    touch: 'no',
    hurtSnd: 'ouch',
    phaseSnd: 'roar',
    dieSnd: 'boom',
    patterns: [
      {
        id: 'p',
        warn: 0.5,
        duration: 1,
        hitboxes: [
          { shape: 'circle', r: 0.5, dmg: 3, from: 0.1, to: 0.8, kf: [{ t: 0, x: 2, y: -0.5 }] },
          { w: 1, h: 1, dmg: 0, from: 0, to: 1, kf: [{ t: 0, x: -2, y: -0.5 }] }
        ]
      }
    ],
    phases: [
      { below: 100, idle: 0.2, patterns: ['p'] },
      { below: 50, idle: 0.2, enter: 0.8, patterns: ['p'] }
    ]
  });
  assert.strictEqual(def.patterns[0].hitboxes[0].shape, 'circle');
  assert.strictEqual(def.patterns[0].hitboxes[0].dmg, 3);
  assert.strictEqual(def.patterns[0].warn, 0.5);
  assert.strictEqual(def.phases[1].enter, 0.8);
  assert.strictEqual(def.hurtSnd, 'ouch');
  const e = { uid: 'u', hp: 10, cx: 10, by: 5, ox: 10, oy: 5, inv: 0, b: MV.Boss.init(def) },
    p = { x: 12, y: 5 },
    st = { opened: {}, flags: {}, abilities: {} },
    sounds = [],
    hurts = [];
  let dmg = 0;
  const env = {
    p,
    W: 0.7,
    H: 1.5,
    st,
    hit: () => dmg > 0,
    dmg: () => dmg,
    bodyS: r => MV.Attacks.shapeHit(r, { sh: 'rect', cx: p.x, cy: p.y - 0.75, w: 0.7, h: 1.5 }),
    msg() {},
    shake() {},
    save() {},
    snd: id => sounds.push(id),
    hurt: o => hurts.push({ d: o.d, t: e.b.t, st: e.b.state }),
    onHit() {}
  };
  let warned = false;
  for (let i = 0; i < 360; i++) {
    const n = hurts.length;
    MV.Boss.tick(e, 1 / 60, env);
    if (e.b.state === 'attack' && e.b.t < 0) {
      warned = true;
      assert.strictEqual(hurts.length, n, 'nothing hurts during the warning');
    }
  }
  assert.ok(warned, 'a warning was seen');
  assert.ok(
    hurts.length > 0 && hurts.every(h => h.d === 3 && h.t >= 0.1 - 1e-9),
    'only the 3 damage hitbox hurts, and not before its start: ' + JSON.stringify(hurts[0])
  );
  dmg = 6;
  e.inv = 0;
  for (let i = 0; i < 3; i++) MV.Boss.tick(e, 1 / 60, env);
  dmg = 0;
  assert.ok(
    e.hp === 4 && e.b.state === 'phase' && sounds.includes('ouch') && sounds.includes('roar'),
    e.hp + ' ' + e.b.state + ' ' + sounds
  );
  dmg = 6;
  const hp = e.hp;
  MV.Boss.tick(e, 1 / 60, env);
  assert.strictEqual(e.hp, hp, 'no damage during a phase change');
  dmg = 0;
  for (let i = 0; i < 60; i++) MV.Boss.tick(e, 1 / 60, env);
  assert.ok(e.b.state !== 'phase', 'the phase change ends');
  MV.Boss.reset(e);
  assert.ok(e.hp === 10 && e.b.state === 'passive' && !e.b.awake && e.cx === 10);
  dmg = 99;
  e.b.state = 'idle';
  e.b.awake = true;
  e.inv = 0;
  MV.Boss.tick(e, 1 / 60, env);
  assert.ok(e.dead && sounds.includes('boom') && st.flags.boss_b === 1);
});
t('bosses: the checker finds harmless, unhittable and silent-sound bosses', () => {
  const room = {
    id: 'r',
    n: 'R',
    gw: 10,
    gh: 6,
    grid: ['..........', '..........', '..........', '..........', '##########', '##########'],
    ent: [{ id: 's', type: 'spawn', x: 2, y: 3, props: {} }],
    tr: []
  };
  const w = {
    areas: [{ id: 'a', n: 'A', rooms: [room], links: [] }],
    player: {},
    moves: [],
    attacks: [],
    items: [],
    anims: [],
    sounds: [],
    events: [],
    enemies: [],
    bosses: MV.Boss.list([{ id: 'x', name: 'X', touch: 'no', weakOnly: 'yes', hurtSnd: 'gone', patterns: [] }])
  };
  const codes = MV.World.validate(w).map(i => i.code);
  ['boss-no-patterns', 'boss-unhittable', 'boss-sound'].forEach(c =>
    assert.ok(codes.includes(c), c + ' in ' + codes.join())
  );
});
t('tuning: air time works out gravity from jump height', () => {
  const a = MV.Tuning.resolve({ jumpHeight: 3, airTime: 1 });
  assert.ok(Math.abs(a.gravity - 24) < 1e-9, String(a.gravity));
  assert.strictEqual(MV.Tuning.resolve({ jumpHeight: 3, gravity: 70 }).gravity, 70);
  assert.ok(MV.Tuning.resolve({ w: 1.2, h: 2 }).w === 1.2);
});
t('animations: frames can be free rectangles of different sizes and draw at the same scale', () => {
  const A = MV.Anim,
    c = A.clean({
      id: 'w',
      pivot: { x: 0.5, y: 1 },
      frames: [
        { sheet: 's', col: 1, row: 0, dur: 100 },
        { sheet: 's', x: 40, y: 8, w: 10, h: 20, dur: 100 }
      ]
    });
  assert.ok(!A.customRect(c.frames[0]) && A.customRect(c.frames[1]));
  const calls = [],
    ctx = { save() {}, restore() {}, translate() {}, scale() {}, drawImage: (...a) => calls.push(a) },
    sheets = { s: { img: { complete: true, naturalWidth: 100 }, tw: 16, th: 16 } };
  A.draw(ctx, c, A.sample(c, 0), sheets, 0, 0, { scale: 2 });
  A.draw(ctx, c, A.sample(c, 0.15), sheets, 0, 0, { scale: 2 });
  assert.deepStrictEqual(calls[0].slice(1, 9), [16, 0, 16, 16, -16, -32, 32, 32], 'a grid cell is as before');
  assert.deepStrictEqual(
    calls[1].slice(1, 9),
    [40, 8, 10, 20, -10, -40, 20, 40],
    'a 10x20 frame keeps its own size, bottom-centre pivot'
  );
});
t('bosses: invincible moments, stagger stun after losing health, and the clip names', () => {
  const def = MV.Boss.clean({
    id: 'b',
    hp: 20,
    wake: 20,
    touch: 'no',
    stagger: 25,
    staggerTime: 1,
    staggerMult: 2,
    clips: { idle: 'c1', bad: 'x' },
    patterns: [
      {
        id: 'p',
        duration: 2,
        clip: 'c2',
        inv: [{ from: 1, to: 0.5 }],
        hitboxes: [{ w: 1, h: 1, dmg: 1, clip: 'c3', kf: [{ t: 0, x: 3, y: 0 }] }]
      }
    ],
    phases: [{ below: 100, idle: 0.1, patterns: ['p'] }]
  });
  assert.strictEqual(JSON.stringify(def.clips), '{"idle":"c1"}');
  assert.strictEqual(def.patterns[0].clip, 'c2');
  assert.strictEqual(JSON.stringify(def.patterns[0].inv), '[{"from":0.5,"to":1}]');
  assert.strictEqual(def.patterns[0].hitboxes[0].clip, 'c3');
  const e = { uid: 'u', hp: 20, cx: 10, by: 5, ox: 10, oy: 5, inv: 0, b: MV.Boss.init(def) },
    p = { x: 30, y: 5 },
    st = { opened: {}, flags: {}, abilities: {} };
  let dmg = 0;
  const env = {
    p,
    W: 0.7,
    H: 1.5,
    st,
    hit: () => dmg > 0,
    dmg: () => dmg,
    bodyS: () => false,
    msg() {},
    shake() {},
    save() {},
    snd() {},
    hurt() {},
    onHit() {}
  };
  e.b.state = 'idle';
  e.b.awake = true;
  dmg = 3;
  MV.Boss.tick(e, 1 / 60, env);
  dmg = 0;
  assert.ok(e.hp === 17 && e.b.state === 'idle', 'a small hit does not stun');
  e.inv = 0;
  dmg = 3;
  MV.Boss.tick(e, 1 / 60, env);
  dmg = 0;
  assert.ok(e.hp === 14 && e.b.state === 'stun', 'losing 25% of max health (5) stuns it: ' + e.hp + ' ' + e.b.state);
  e.inv = 0;
  dmg = 1;
  MV.Boss.tick(e, 1 / 60, env);
  dmg = 0;
  assert.strictEqual(e.hp, 12, 'it takes double damage while stunned');
  for (let i = 0; i < 70; i++) MV.Boss.tick(e, 1 / 60, env);
  assert.ok(e.b.state !== 'stun', 'the stun ends');
  e.b.state = 'attack';
  e.b.pat = def.patterns[0];
  e.b.t = 0.7;
  e.inv = 0;
  dmg = 5;
  const hp = e.hp;
  MV.Boss.tick(e, 1 / 60, env);
  assert.strictEqual(e.hp, hp, 'no damage in an invincible moment');
  assert.ok(e.shield);
});

// ---- camera rig ----
const rig = (dt, secs, tx, ty, o) => {
  o = o || {};
  const r = o.rig || new MV.CameraRig();
  const n = Math.round(secs / dt);
  for (let i = 0; i < n; i++)
    r.update(
      dt,
      typeof tx === 'function' ? tx(i * dt) : tx,
      ty,
      o.vw || 25,
      o.vh || 14,
      o.rw || 60,
      o.rh || 30,
      { p: o.p || {} },
      i === 0 && !o.rig,
      { vx: 0, vy: 0, face: 1, on: true },
      {}
    );
  return r;
};
t('camera: curves stay in range and hit 0 and 1', () => {
  for (const n of ['linear', 'easeIn', 'easeOut', 'easeInOut', 'smooth', 'smoother', 'sine']) {
    const f = MV.CameraRig.curve(n);
    assert.ok(Math.abs(f(0)) < 1e-6 && Math.abs(f(1) - 1) < 1e-6, n);
  }
  assert.ok(Math.abs(MV.CameraRig.curve([0.25, 0.1, 0.25, 1])(1) - 1) < 1e-3);
  assert.strictEqual(typeof MV.CameraRig.curve('nonsense'), 'function');
});
t('camera: follows a target and stays inside the room', () => {
  const r = rig(1 / 60, 3, 30, 15);
  assert.ok(r.x > 15 && r.x <= 60 - 25 + 1e-6 && r.y >= 0 && r.y <= 30 - 14 + 1e-6);
  const q = rig(1 / 60, 3, 1, 1);
  assert.ok(q.x >= -1e-6 && q.y >= -1e-6);
});
t('camera: the same result at 30, 60 and 144 fps', () => {
  const a = rig(1 / 30, 4, 40, 20),
    b = rig(1 / 60, 4, 40, 20),
    c = rig(1 / 144, 4, 40, 20);
  assert.ok(Math.abs(a.x - b.x) < 0.5 && Math.abs(c.x - b.x) < 0.5, a.x + ' ' + b.x + ' ' + c.x);
});
t('camera: a missing target falls back to the player', () => {
  const r = rig(1 / 60, 1, 30, 15);
  r.target({ cx: 5, by: 5, h: 1, dead: true });
  r.target(() => {
    throw new Error('gone');
  });
  r.target('no-such-uid');
  r.addTarget('no-such-uid');
  r.lockOn('no-such-uid');
  for (let i = 0; i < 60; i++) r.update(1 / 60, 30, 15, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.ok(isFinite(r.x) && isFinite(r.y));
  assert.ok(r.x > 15);
});
t('camera: bad numbers never break the view', () => {
  const r = new MV.CameraRig();
  r.update(NaN, NaN, undefined, 0, -3, 0, 0, null, true, null, null);
  r.zoomTo(NaN);
  r.shake({ amount: Infinity, time: -1 });
  r.update(1 / 60, 5, 5, 25, 14, 30, 20, {}, false, {}, {});
  const v = r.view();
  assert.ok(['cx', 'cy', 'vw', 'vh', 'zoom', 'rot'].every(k => isFinite(v[k])));
});
t('camera: overrides - the higher priority wins, ending restores', () => {
  const r = rig(1 / 60, 1, 30, 15, { p: { zoom: 1 } });
  r.override({ id: 'a', priority: 1, zoom: 1.5, blend: 0.1 });
  r.override({ id: 'b', priority: 5, zoom: 2, blend: 0.1 });
  for (let i = 0; i < 120; i++) r.update(1 / 60, 30, 15, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.ok(Math.abs(r.zeff - 2) < 0.05, 'b wins: ' + r.zeff);
  r.endOverride('b', 0.1);
  for (let i = 0; i < 180; i++) r.update(1 / 60, 30, 15, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.ok(Math.abs(r.zeff - 1.5) < 0.05, 'a is back: ' + r.zeff);
  r.endOverride('a', 0.1);
  for (let i = 0; i < 240; i++) r.update(1 / 60, 30, 15, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.ok(Math.abs(r.zeff - 1) < 0.05 && !r.overrides().length, 'all gone');
});
t('camera: a room-scoped override ends when the room changes, a global one stays', () => {
  const r = rig(1 / 60, 0.5, 30, 15);
  r.override({ id: 'r', scope: 'room', zoom: 1.4 });
  r.override({ id: 'g', scope: 'global', zoom: 1.2 });
  r.sceneChange();
  assert.strictEqual(
    r
      .overrides()
      .map(q => q.id)
      .join(),
    'g'
  );
});
t('camera: shake ends by itself, stopShake clears it, reduce motion silences it', () => {
  const r = rig(1 / 60, 0.5, 30, 15);
  r.shake({ amount: 0.5, time: 0.3, id: 's' });
  r.update(1 / 60, 30, 15, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.ok(Math.abs(r.view().cx - (r.x + r.vw / 2)) > 0 || r.shakes.length);
  for (let i = 0; i < 40; i++) r.update(1 / 60, 30, 15, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.strictEqual(r.shakes.length, 0);
  r.shake({ amount: 1, time: 5, id: 'x' });
  r.stopShake('x');
  assert.strictEqual(r.shakes.length, 0);
  r.settings({ reduceMotion: true, shake: 0 });
  r.shake({ amount: 1, time: 2, roll: 10 });
  r.update(1 / 60, 30, 15, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.ok(r.shx === 0 && r.shy === 0 && r.shr === 0);
});
t('camera: framing two targets zooms out to keep both in view', () => {
  const r = rig(1 / 60, 1, 20, 15, { rw: 100, rh: 40 });
  r.addTarget(() => ({ x: 55, y: 15 }));
  r.frame(true, { pad: 2, min: 0.3 });
  for (let i = 0; i < 300; i++) r.update(1 / 60, 20, 15, 25, 14, 100, 40, { p: {}, brk: true }, false, {}, {});
  assert.ok(r.zeff < 0.7, 'zoomed out: ' + r.zeff);
  assert.ok(r.x <= 20 && r.x + r.vw >= 55, 'both inside the view');
});
t('camera: zoom and rotation are limited, the room limits keep zoom-out inside the room', () => {
  const r = new MV.CameraRig();
  r.zoomTo(100);
  r.rotateTo(500);
  for (let i = 0; i < 200; i++) r.update(1 / 60, 10, 10, 25, 14, 30, 20, { p: {} }, i === 0, {}, {});
  assert.ok(r.zeff <= 4 && Math.abs(r.reff) <= 45);
  const q = new MV.CameraRig();
  q.zoomTo(0.01);
  for (let i = 0; i < 200; i++) q.update(1 / 60, 10, 10, 25, 14, 30, 20, { p: {} }, i === 0, {}, {});
  assert.ok(q.vw <= 30 + 1e-6 && q.vh <= 20 + 1e-6, 'the view never shows more than the room: ' + q.vw + 'x' + q.vh);
});
t('camera: toScreen and toWorld are inverses (zoom and rotation included)', () => {
  const r = new MV.CameraRig();
  r.rotateTo(20, { time: 0.01 });
  r.zoomTo(1.5, { time: 0.01 });
  for (let i = 0; i < 120; i++) r.update(1 / 60, 20, 12, 25, 14, 60, 30, { p: {} }, i === 0, {}, {});
  const s = r.toScreen(21, 13, 800, 448, 32),
    w = r.toWorld(s.x, s.y, 800, 448, 32);
  assert.ok(Math.abs(w.x - 21) < 1e-6 && Math.abs(w.y - 13) < 1e-6);
});
t('camera: free camera is steered by input and can be left', () => {
  const r = rig(1 / 60, 0.5, 30, 15);
  r.free_(true, { speed: 10 });
  const x0 = r.cx;
  for (let i = 0; i < 60; i++) {
    r.feed({ keys: c => c === 'KeyD' });
    r.update(1 / 60, 30, 15, 25, 14, 60, 30, { p: {} }, false, {}, {});
  }
  assert.ok(r.cx > x0 + 5, 'moved right: ' + (r.cx - x0));
  assert.ok(r.inputLocked());
  r.free_(false);
  assert.ok(!r.inputLocked());
});
t('camera: inversion and sensitivity are applied to input', () => {
  const a = rig(1 / 60, 0.2, 30, 15),
    b = rig(1 / 60, 0.2, 30, 15);
  a.manualPan(true);
  b.manualPan(true);
  b.settings({ invertX: true, sensitivity: 2 });
  for (let i = 0; i < 30; i++) {
    a.feed({ keys: c => c === 'KeyL' });
    b.feed({ keys: c => c === 'KeyL' });
    a.update(1 / 60, 30, 15, 25, 14, 60, 30, { p: { panRange: 10 } }, false, {}, {});
    b.update(1 / 60, 30, 15, 25, 14, 60, 30, { p: { panRange: 10 } }, false, {}, {});
  }
  assert.ok(a.pn.x > 0 && b.pn.x < 0 && Math.abs(b.pn.x) > a.pn.x * 1.5, a.pn.x + ' ' + b.pn.x);
});
t('camera: settings are clamped and listeners hear changes', () => {
  const r = new MV.CameraRig();
  let n = 0;
  r.onSettings(() => n++);
  const s = r.settings({ sensitivity: 99, smoothing: -4, invertX: 1, bogus: 3 });
  assert.ok(s.sensitivity <= 3 && s.smoothing >= 0 && s.invertX === true && s.bogus === undefined && n === 1);
  assert.strictEqual(r.resetSettings().sensitivity, 1);
});
t('camera: transition calls onMid once, fades come back to clear', () => {
  const r = new MV.CameraRig();
  let mid = 0;
  r.transition('iris', 0.4, () => mid++);
  for (let i = 0; i < 60; i++) r.update(1 / 60, 10, 10, 25, 14, 30, 20, { p: {} }, i === 0, {}, {});
  assert.strictEqual(mid, 1);
  assert.strictEqual(r.trans, null);
  r.fadeOut(0.2);
  for (let i = 0; i < 20; i++) r.update(1 / 60, 10, 10, 25, 14, 30, 20, { p: {} }, false, {}, {});
  assert.ok(r.fadeA > 0.95);
  r.fadeIn(0.2);
  for (let i = 0; i < 20; i++) r.update(1 / 60, 10, 10, 25, 14, 30, 20, { p: {} }, false, {}, {});
  assert.ok(r.fadeA < 0.05);
});
t('camera: a rail moves the view along its points, then hands back', () => {
  const r = rig(1 / 60, 0.5, 10, 10);
  let done = 0;
  r.rail(
    [
      { x: 10, y: 10 },
      { x: 40, y: 10 }
    ],
    { time: 1, onDone: () => done++, blend: 0.05 }
  );
  for (let i = 0; i < 40; i++) r.update(1 / 60, 10, 10, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.ok(r.cx > 20, 'on its way: ' + r.cx);
  for (let i = 0; i < 200; i++) r.update(1 / 60, 10, 10, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.strictEqual(done, 1);
  assert.ok(r.cx < 25, 'back on the player');
});
t('camera: a cutscene runs its steps in order and can be skipped', () => {
  const r = rig(1 / 60, 0.5, 10, 10);
  let log = [];
  r.cutscene(
    [{ pan: { x: 30, y: 10 }, dur: 0.3 }, { call: () => log.push('a') }, { wait: 0.2 }, { call: () => log.push('b') }],
    { onDone: () => log.push('done') }
  );
  for (let i = 0; i < 120; i++) r.update(1 / 60, 10, 10, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.strictEqual(log.join(), 'a,b,done');
  r.cutscene([{ wait: 10 }], { onDone: () => log.push('x') });
  r.skipCutscene();
  for (let i = 0; i < 10; i++) r.update(1 / 60, 10, 10, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.ok(log.includes('x') && !r.status().cutscene);
});
t('camera: isometric and first-person say they are not supported', () => {
  const r = new MV.CameraRig();
  assert.strictEqual(r.mode('isometric'), false);
  assert.ok(/renderer/i.test(r.unsupported));
  assert.strictEqual(r.mode('firstperson'), false);
  assert.strictEqual(r.mode('side'), true);
  assert.strictEqual(r.mode('fixed'), true);
});
t('camera: resize and scene changes snap instead of gliding', () => {
  const r = rig(1 / 60, 2, 50, 25);
  r.sceneChange();
  r.update(1 / 60, 5, 5, 25, 14, 60, 30, { p: {} }, false, {}, {});
  assert.ok(r.x < 1 && r.y < 1, 'jumped to the new place: ' + r.x);
  r.resize();
  r.update(1 / 60, 5, 5, 40, 22, 60, 30, { p: {} }, false, {}, {});
  assert.ok(isFinite(r.x) && Math.abs(r.vw - 40) < 1e-6);
});
t('camera: validator accepts the new profile fields and drops bad ones', () => {
  const p = MV.Camera.cleanP({
    zoom: 2,
    view: 'free',
    doorFx: 'iris',
    bossFrame: 'yes',
    rot: 999,
    view2: 3,
    manualPan: 'maybe'
  });
  assert.strictEqual(p.zoom, 2);
  assert.strictEqual(p.view, 'free');
  assert.strictEqual(p.rot, 30);
  assert.strictEqual(p.manualPan, undefined);
  assert.strictEqual(p.view2, undefined);
});
// ---- boss AI: containment, collision, targeting, rule-based selection ----
const bossRig = (def, over) => {
  const d = MV.Boss.clean(Object.assign({ id: 'b', hp: 10, wake: 50, touch: 'no' }, def)),
    e = { uid: 'u', hp: 10, cx: 10, by: 10, ox: 10, oy: 10, inv: 0, b: MV.Boss.init(d) },
    p = { x: 4, y: 10, on: true };
  const env = Object.assign(
    {
      p,
      W: 0.7,
      H: 1.5,
      st: { opened: {}, flags: {}, abilities: {} },
      hit: () => false,
      msg() {},
      shake() {},
      save() {},
      snd() {},
      hurt() {},
      onHit() {},
      room: { gw: 40, gh: 20 },
      blocked: (cx, by, w, h) =>
        cx - w / 2 < 0 || cx + w / 2 > 40 || by > 10 + 1e-6 || by - h < 0 || (cx + w / 2 > 14 && by > 5)
    },
    over
  );
  return {
    e,
    p,
    env,
    run: n => {
      for (let i = 0; i < n; i++) MV.Boss.tick(e, 1 / 60, env);
    }
  };
};
t('boss AI: a body path cannot push the boss through a wall, out of the room or past its leash', () => {
  const R = bossRig({
    w: 2,
    h: 2,
    patterns: [
      {
        id: 'l',
        duration: 1,
        body: [
          { t: 0, x: 0, y: 0 },
          { t: 1, x: 30, y: 0 }
        ]
      }
    ],
    phases: [{ below: 100, idle: 0.1, patterns: ['l'] }]
  });
  R.p.x = 20;
  R.run(300);
  assert.ok(R.e.cx <= 14 - 1 + 1e-6, 'stopped at the wall: ' + R.e.cx);
  const L = bossRig({
    w: 2,
    h: 2,
    leash: 3,
    patterns: [
      {
        id: 'l',
        duration: 1,
        body: [
          { t: 0, x: 0, y: 0 },
          { t: 1, x: -30, y: 0 }
        ]
      }
    ],
    phases: [{ below: 100, idle: 0.1, patterns: ['l'] }]
  });
  L.env.blocked = null;
  L.p.x = -20;
  L.run(300);
  assert.ok(L.e.cx >= 10 - 3 - 1e-6, 'leash: ' + L.e.cx);
  const O = bossRig({
    w: 2,
    h: 2,
    patterns: [
      {
        id: 'l',
        duration: 1,
        body: [
          { t: 0, x: 0, y: 0 },
          { t: 1, x: 0, y: -80 }
        ]
      }
    ],
    phases: [{ below: 100, idle: 0.1, patterns: ['l'] }]
  });
  O.env.blocked = null;
  O.run(300);
  assert.ok(O.e.by >= 2 - 1e-6, 'room top: ' + O.e.by);
});
t('boss AI: a standing boss falls to the floor, a floating one stays', () => {
  const S = bossRig({ w: 2, h: 2, fly: 'no', patterns: [], phases: [] });
  S.e.by = 4;
  S.e.b.sy = 4;
  S.run(120);
  assert.ok(Math.abs(S.e.by - 10) < 0.15, 'landed: ' + S.e.by);
  const F = bossRig({ w: 2, h: 2, fly: 'yes', patterns: [], phases: [] });
  F.e.by = 4;
  F.run(120);
  assert.strictEqual(F.e.by, 4);
});
t('boss AI: it walks toward you but keeps its distance and never walks into walls', () => {
  const W = bossRig({ w: 2, h: 2, speed: 4, keep: 3, patterns: [], phases: [] });
  W.e.b.state = 'idle';
  W.e.b.awake = true;
  W.p.x = 4;
  W.run(300);
  assert.ok(Math.abs(W.e.cx - 7) < 0.3, 'stopped 3 away: ' + W.e.cx);
  W.p.x = 30;
  W.run(600);
  assert.ok(W.e.cx <= 13 + 1e-6, 'wall: ' + W.e.cx);
});
t('boss AI: rules choose by distance, ground or air, health and cooldown', () => {
  const pats = [
    { id: 'near', max: 4, duration: 0.2, hitboxes: [] },
    { id: 'far', min: 6, duration: 0.2, hitboxes: [], cd: 5 },
    { id: 'air', at: 'player in air', duration: 0.2, hitboxes: [] },
    { id: 'low', hpBelow: 30, duration: 0.2, hitboxes: [] }
  ];
  const seen = (pl, n) => {
    const R = bossRig(
      { w: 2, h: 2, select: 'rules', patterns: pats, phases: [{ below: 100, idle: 0.05, patterns: [] }] },
      { rand: () => 0.5 }
    );
    R.e.b.state = 'idle';
    R.e.b.awake = true;
    Object.assign(R.p, pl);
    const ids = [];
    let last = '';
    for (let i = 0; i < n; i++) {
      R.run(1);
      if (R.e.b.pat && R.e.b.pat.id !== last) {
        last = R.e.b.pat.id;
        ids.push(last);
      } else if (!R.e.b.pat) last = '';
    }
    return ids;
  };
  assert.ok(
    seen({ x: 8, on: true }, 150).every(i => i === 'near'),
    'close: only near'
  );
  const far = seen({ x: -10, on: true }, 150);
  assert.ok(far.includes('far') && !far.includes('air') && !far.includes('low'), 'far on the ground: ' + far);
  assert.ok(seen({ x: -10, on: false }, 150).includes('air'), 'in the air');
});
t('boss AI: a pattern that tracks you turns during the warning, and a lunge ends where you stand', () => {
  const R = bossRig({
    w: 2,
    h: 2,
    select: 'rules',
    patterns: [
      {
        id: 'a',
        warn: 1,
        track: 'yes',
        reach: 'to player',
        duration: 2,
        hitboxes: [],
        body: [
          { t: 0, x: 0, y: 0 },
          { t: 1, x: 10, y: 0 }
        ]
      }
    ],
    phases: [{ below: 100, idle: 0.05, patterns: [] }]
  });
  R.env.blocked = null;
  R.e.b.state = 'idle';
  R.e.b.awake = true;
  R.p.x = 14;
  R.run(10);
  assert.strictEqual(R.e.b.face, 1);
  R.p.x = 2;
  R.run(20);
  assert.strictEqual(R.e.b.face, -1, 'turned during the warning');
  R.run(150);
  assert.ok(Math.abs(R.e.cx - 2) < 1.5, 'ended near the player: ' + R.e.cx);
});
t('boss AI: the checker finds rules that can never be met', () => {
  const room = { id: 'r', n: 'R', gw: 20, gh: 14, grid: Array(14).fill('.'.repeat(20)), ent: [], tr: [] },
    w = {
      areas: [{ id: 'a', n: 'A', rooms: [room], links: [] }],
      player: {},
      moves: [],
      attacks: [],
      items: [],
      anims: [],
      sounds: [],
      events: [],
      enemies: [],
      bosses: [
        MV.Boss.clean({
          id: 'b',
          name: 'B',
          select: 'rules',
          patterns: [{ id: 'p', min: 9, max: 3, hitboxes: [{ dmg: 1 }] }]
        })
      ]
    };
  const v = MV.World.validate(w);
  assert.ok(v.some(i => i.code === 'boss-rule'));
});
t('boss AI: vertical rules and repeat limits', () => {
  const mk = (pats, pl) => {
    const R = bossRig(
      { w: 2, h: 2, select: 'rules', patterns: pats, phases: [{ below: 100, idle: 0.05, patterns: [] }] },
      { rand: () => 0.5 }
    );
    R.e.b.state = 'idle';
    R.e.b.awake = true;
    Object.assign(R.p, pl);
    const ids = [];
    let last = '';
    for (let i = 0; i < 900; i++) {
      R.run(1);
      if (R.e.b.pat && R.e.b.pat.id !== last) {
        last = R.e.b.pat.id;
        ids.push(last);
      } else if (!R.e.b.pat) last = '';
    }
    return ids;
  };
  const up = mk([{ id: 'a', vert: 'player above', duration: 0.1, hitboxes: [] }], { x: 8, y: 4, on: false });
  assert.ok(up.length > 3, 'above works');
  const dn = mk(
    [
      { id: 'a', vert: 'player above', duration: 0.1, hitboxes: [] },
      { id: 'b', duration: 0.1, hitboxes: [] }
    ],
    { x: 8, y: 10, on: true }
  );
  assert.ok(!dn.includes('a') || (dn.indexOf('a') >= 0 && false), 'not above: ' + dn.slice(0, 5));
  const r2 = mk(
    [
      { id: 'a', repeat: 2, duration: 0.1, hitboxes: [] },
      { id: 'b', repeat: 1, duration: 0.1, hitboxes: [] }
    ],
    { x: 8, y: 10, on: true }
  );
  let run = 0,
    mx = 0;
  r2.forEach((v, i) => {
    run = i && v === r2[i - 1] ? run + 1 : 1;
    mx = Math.max(mx, run);
  });
  assert.ok(mx <= 2, 'streak ' + mx);
});
t('boss AI: the arena is stamped on placement, or worked out from the spawn for older placements', () => {
  const def = MV.Boss.clean({ id: 'b', arena: { gw: 20, gh: 10, bx: 14, by: 7 } }),
    room = { gw: 60, gh: 30 };
  assert.strictEqual(MV.Boss.arenaOf('10,5,30,15', 99, 99, def, room).join(), '10,5,30,15');
  assert.strictEqual(MV.Boss.arenaOf('', 24, 12, def, room).join(), '10,5,30,15');
  assert.strictEqual(MV.Boss.arenaOf('junk', 24, 12, def, room).join(), '10,5,30,15');
  const R = bossRig({
    w: 2,
    h: 2,
    patterns: [
      {
        id: 'l',
        duration: 1,
        body: [
          { t: 0, x: 0, y: 0 },
          { t: 1, x: 30, y: 0 }
        ]
      }
    ],
    phases: [{ below: 100, idle: 0.1, patterns: ['l'] }]
  });
  R.env.blocked = null;
  R.e.arena = [5, 0, 20, 12];
  R.p.x = 40;
  R.run(300);
  assert.ok(R.e.cx <= 19 + 1e-6 && R.e.cx >= 6, 'inside the arena: ' + R.e.cx);
});
t('boss AI: aimed patterns turn toward the player on either side, fixed ones only mirror', () => {
  const go = (aim, px, py) => {
    const R = bossRig({
      w: 2,
      h: 2,
      patterns: [
        {
          id: 'a',
          aim,
          aimMax: 90,
          warn: 0.2,
          duration: 1,
          body: [
            { t: 0, x: 0, y: 0 },
            { t: 1, x: 6, y: 0 }
          ],
          hitboxes: [
            {
              w: 1,
              h: 1,
              dmg: 1,
              from: 0,
              to: 1,
              kf: [
                { t: 0, x: 2, y: -1 },
                { t: 1, x: 12, y: -1 }
              ]
            }
          ]
        }
      ],
      phases: [{ below: 100, idle: 0.1, patterns: ['a'] }]
    });
    R.env.blocked = null;
    R.e.b.state = 'idle';
    R.e.b.awake = true;
    R.p.x = px;
    R.p.y = py;
    for (let i = 0; i < 400 && !(R.e.b.pat && R.e.b.t > 0.5); i++) R.run(1);
    const hb = R.e.b.pat.hitboxes[0],
      r = MV.Boss.hbRect(R.e.b, R.e, hb, 1);
    return { r, cx: R.e.cx, by: R.e.by, face: R.e.b.face };
  };
  const l = go('at player', 0, 14);
  assert.ok(l.face === -1 && l.r.cx < 10, 'left: ' + JSON.stringify(l));
  const dn = go('at player', 20, 16);
  assert.ok(dn.r.cy > 12, 'aims down toward a player below: ' + JSON.stringify(dn));
  const fx = go('fixed', 0, 16);
  assert.ok(fx.r.cx < 10 && Math.abs(fx.r.cy - 9) < 0.01, 'fixed only mirrors: ' + JSON.stringify(fx));
});
t('structure: engine/game.js matches its pieces and every script in index.html exists', () => {
  const cp = require('child_process'); cp.execFileSync('node', [path.join(__dirname, '..', 'tools', 'build.js'), '--check']);
  const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8'), miss = [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]).filter(f => !fs.existsSync(path.join(__dirname, '..', f)));
  assert.deepStrictEqual(miss.slice(), []); });
t('structure: no two top-level functions share a name inside the editor scripts or inside game.js (the later one silently wins)', () => {
  const root = path.join(__dirname, '..'), names = {};
  const scan = (files, group) => files.forEach(f => { fs.readFileSync(path.join(root, f), 'utf8').split('\n').forEach(l => { const m = /^(?:async )?function (\w+)/.exec(l); if (m) (names[group + m[1]] = names[group + m[1]] || []).push(f); }); });
  scan(['editor/events_ui.js', 'editor/audio_ui.js', 'editor/enemies_ui.js', 'editor/app-01.js', 'editor/app-02.js', 'editor/app-03.js', 'editor/app-04.js'], 'editor:');
  const dup = Object.keys(names).filter(k => names[k].length > 1); assert.deepStrictEqual(dup.slice(), []); });
// ---- scripting ----
const mkRt = (code, api, extra) => { const out = [], rt = new MV.Script.Runtime([Object.assign({ id: 'a', name: 'A', code }, extra)], Object.assign({ say: t => out.push(t) }, api), t => out.push('ERR ' + t)); return { rt, out }; };
t('scripts: clean keeps good scripts, caps size and count, drops junk', () => {
  const l = MV.Script.clean([{ id: 'a', name: ' Hi ', code: 'x' }, null, 5, { id: 'a', code: 'dup' }, { name: 'B', code: 'y'.repeat(70000), on: false }]);
  assert.strictEqual(l.length, 2); assert.strictEqual(l[0].name, 'Hi'); assert.ok(l[1].code.length <= 60000 && l[1].on === false);
  assert.strictEqual(MV.Script.clean(new Array(100).fill({ code: 'a' })).length, 40); assert.strictEqual(MV.Script.clean(MV.Script.clean(l)).length, 2); });
t('scripts: hooks run with their data, friendly names work, filters match', () => {
  const { rt, out } = mkRt("on('roomEnter', ({ room }) => game.say('in ' + room)); on('room', () => game.say('two'), { room: 'r2' }); on('bossDefeat', () => game.say('boss')); on('update', dt => game.say('dt' + dt.toFixed(2)));");
  rt.emit('room', { room: 'r1' }); rt.emit('room', { room: 'r2' }); rt.emit('boss', { flag: 'f' }); rt.tick(0.5);
  assert.deepStrictEqual(out.slice(), ['in r1', 'in r2', 'two', 'boss', 'dt0.10']); });
t('scripts: the page is hidden from a script, strict mode catches typos, fn() can be called', () => {
  const { rt, out } = mkRt("fn('go', a => game.say([typeof window, typeof document, typeof MV, typeof localStorage, typeof fetch, a].join())); fn('bad', () => { undeclared = 1; });");
  rt.call('go', 'arg'); assert.strictEqual(out[0], 'undefined,undefined,undefined,undefined,undefined,arg');
  rt.call('bad'); assert.ok(out.some(x => /ERR .*undeclared/.test(x)), out.join('|')); rt.call('nope'); assert.ok(out.some(x => /no script function/.test(x))); });
t('scripts: errors are reported once, three-strikes handlers switch off, one bad script does not stop the others', () => {
  const out = [], rt = new MV.Script.Runtime([{ id: 'a', name: 'Bad', code: "on('update', () => { throw new Error('boom'); });" }, { id: 'b', name: 'Syntax', code: 'let = ;' }, { id: 'c', name: 'Good', code: "on('update', () => game.say('ok'));" }], { say: t => out.push(t) }, t => out.push('ERR ' + t));
  for (let i = 0; i < 20; i++) rt.tick(1 / 60);
  assert.strictEqual(out.filter(x => /boom/.test(x)).length, 1, 'reported once'); assert.ok(out.some(x => /does not compile|reserved|Unexpected/.test(x)));
  assert.strictEqual(out.filter(x => x === 'ok').length, 20, 'the good script kept running'); assert.ok(rt.errors.some(e => /switched off/.test(e.message))); });
t('scripts: timers run once or repeat, can be cancelled, and room timers end on a scene change', () => {
  const { rt, out } = mkRt("game.after(0.5, () => game.say('once')); const id = game.every(0.2, () => game.say('tick')); game.after(0.7, () => game.cancel(id)); game.after(5, () => game.say('room'), { room: true });");
  for (let i = 0; i < 90; i++) rt.tick(1 / 60); rt.sceneChange(); for (let i = 0; i < 400; i++) rt.tick(1 / 60);
  assert.strictEqual(out.filter(x => x === 'once').length, 1); assert.ok(out.filter(x => x === 'tick').length >= 2 && out.filter(x => x === 'tick').length <= 4, out.join()); assert.ok(!out.includes('room')); });
t('scripts: the checker finds compile errors, bad hooks, loops and missing functions', () => {
  const w = { scripts: [{ id: 'a', name: 'A', code: 'let = ;' }, { id: 'b', name: 'B', code: "on('typo', () => 1); while (true) {} fn('real', () => 1);" }], events: MV.Events.clean([{ id: 'e', name: 'E', trigger: { type: 'called' }, actions: [{ type: 'script', name: 'real' }, { type: 'script', name: 'gone' }] }]) };
  const v = MV.Script.validate(w); assert.ok(v.some(i => i.level === 'error' && /does not compile/.test(i.text))); assert.ok(v.some(i => /not a hook/.test(i.text))); assert.ok(v.some(i => /while\(true\)/.test(i.text)));
  assert.strictEqual(v.filter(i => /gone/.test(i.text)).length, 1); assert.ok(!v.some(i => /"real"/.test(i.text))); });
t('scripts: scripted AI and moves are checked and cleaned', () => {
  const w = { scripts: [{ id: 'a', name: 'A', on: true, code: "fn('hunt', me => 1); fn('zip', me => 1);" }],
    enemies: MV.Enemies.resolve([{ id: 'x', name: 'X', move: 'script', brain: 'hunt' }, { id: 'y', name: 'Y', move: 'script', brain: 'gone' }, { id: 'z', name: 'Z', move: 'script', brain: '' }]),
    bosses: MV.Boss.list([{ id: 'b1', name: 'B1', ai: 'script', brain: 'nope' }, { id: 'b2', name: 'B2', ai: 'script', brain: 'hunt' }]),
    moves: MV.Moves.resolve([{ id: 'm1', type: 'scripted', script: 'zip' }, { id: 'm2', type: 'scripted', script: 'lost' }]) };
  const v = MV.Script.validate(w).map(i => i.text);
  assert.strictEqual(v.filter(x => /"gone"/.test(x)).length, 1); assert.strictEqual(v.filter(x => /"nope"/.test(x)).length, 1); assert.strictEqual(v.filter(x => /"lost"/.test(x)).length, 1);
  assert.ok(v.some(x => /names no function/.test(x))); assert.ok(!v.some(x => /"hunt"|"zip"/.test(x)));
  assert.strictEqual(w.moves[0].type, 'scripted'); assert.strictEqual(w.moves[0].script, 'zip');
  assert.strictEqual(w.enemies[0].move, 'script'); assert.strictEqual(w.bosses[0].ai, 'script');
  assert.strictEqual(MV.Boss.clean({ ai: 'nonsense' }).ai, 'built-in'); });
console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail ? 1 : 0);
