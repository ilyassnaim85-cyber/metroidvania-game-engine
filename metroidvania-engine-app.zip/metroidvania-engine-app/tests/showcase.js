// Plays the Tidebound example for real (keys in a browser): node tests/showcase.js
// Checks that each obstacle needs its ability and can be beaten with it, and that the boss can be defeated.
const fs = require('fs'),
  os = require('os'),
  path = require('path');
const { chromium } = require(fs.existsSync('/opt/npm-tools/node_modules/playwright') ? '/opt/npm-tools/node_modules/playwright' : 'playwright');
const root = path.join(__dirname, '..');
const { buildGame } = require('../tools/export.js');
const file = path.join(os.tmpdir(), 'tidebound-test.html');
fs.writeFileSync(file, buildGame(root, fs.readFileSync(path.join(root, 'examples', 'tidebound.json'), 'utf8')));
const sleep = (pg, s) => pg.waitForTimeout(s * 1000);
let pass = 0,
  fail = 0;
const ok = (n, c, i) => {
  c ? pass++ : fail++;
  console.log((c ? '  ok   ' : '  FAIL ') + n + (c ? '' : '  ' + JSON.stringify(i)));
};
let browser;
async function boot(abil) {
  const pg = await browser.newPage({ viewport: { width: 960, height: 540 } });
  pg.errs = [];
  pg.on('pageerror', e => pg.errs.push(e.message));
  await pg.goto('file://' + file);
  await sleep(pg, 1);
  await pg.keyboard.press('Enter');
  await sleep(pg, 1);
  await pg.evaluate(a => a.forEach(k => (MV.Game.state().abilities[k] = true)), abil || []);
  return pg;
}
const P = pg =>
  pg.evaluate(() => {
    const p = MV.Game.player();
    return [p.x, p.y, MV.Game.room().id];
  });
const tp = (pg, x, y) =>
  pg.evaluate(
    ([x, y]) => {
      const p = MV.Game.player();
      p.x = x;
      p.y = y;
      p.vx = 0;
      p.vy = 0;
    },
    [x, y]
  );
async function runJump(pg, edge, hold, dashAt) {
  await pg.keyboard.down('ArrowRight');
  for (let i = 0; i < 80 && (await P(pg))[0] < edge - 0.6; i++) await sleep(pg, 0.03);
  await pg.keyboard.down('Space');
  await sleep(pg, hold);
  await pg.keyboard.up('Space');
  if (dashAt) {
    await sleep(pg, Math.max(0, dashAt - hold));
    await pg.keyboard.press('Shift');
  }
  await sleep(pg, 1.3);
  await pg.keyboard.up('ArrowRight');
}
(async () => {
  browser = await chromium.launch();
  // pictures: the hero's animation clips reach the player, and every sheet and clip the project names exists
  let pg = await boot(['dash']);
  const pic = await pg.evaluate(() => {
    const w = MV.Game.world ? MV.Game.world() : null;
    return { clips: MV.PlayerSprite.clips().length, sheets: document.querySelectorAll('canvas').length };
  });
  ok('the hero animation clips are available to the game', pic.clips > 20, pic);
  // level 1: the 8 wide gap needs the dash
  await tp(pg, 68, 20);
  await sleep(pg, 0.4);
  await runJump(pg, 72, 0.5, 0.3);
  let p = await P(pg);
  ok('level 1: with the dash the gap can be crossed', p[0] > 80 && p[1] === 20, p);
  await pg.close();
  pg = await boot([]);
  await tp(pg, 68, 20);
  await sleep(pg, 0.4);
  await runJump(pg, 72, 0.5, 0.3);
  p = await P(pg);
  ok('level 1: without it you fall in', !(p[0] > 80 && p[1] === 20), p);
  await pg.close();
  // level 2: the 4 high wall needs the double jump
  for (const dj of [false, true]) {
    pg = await boot(dj ? ['doublejump'] : []);
    await tp(pg, 89.5, 20);
    await sleep(pg, 3);
    await tp(pg, 20, 22);
    await sleep(pg, 0.4);
    await pg.keyboard.down('ArrowRight');
    for (let i = 0; i < 80 && (await P(pg))[0] < 22.8; i++) await sleep(pg, 0.02);
    await pg.keyboard.down('Space');
    await sleep(pg, 0.45);
    await pg.keyboard.up('Space');
    await pg.keyboard.press('Space');
    await sleep(pg, 0.9);
    await pg.keyboard.up('ArrowRight');
    p = await P(pg);
    ok('level 2: the wall ' + (dj ? 'is cleared with the double jump' : 'stops you without it'), dj ? p[0] > 26 : p[0] < 24.5, p);
    await pg.close();
  }
  // level 3: the shaft is climbed by wall jumping, then the ride, then the boss
  pg = await boot(['dash', 'doublejump', 'wallJump']);
  await tp(pg, 89.5, 20);
  await sleep(pg, 3);
  await tp(pg, 109.5, 22);
  await sleep(pg, 0.5);
  await pg.keyboard.down('ArrowUp');
  await sleep(pg, 2.5);
  await pg.keyboard.up('ArrowUp');
  p = await P(pg);
  ok('level 2: a press door takes you to the shaft', p[2] === 'shaft', p);
  await tp(pg, 16.5, 35);
  await sleep(pg, 0.4);
  let dir = 'ArrowRight';
  await pg.keyboard.down(dir);
  await pg.keyboard.down('Space');
  await sleep(pg, 0.4);
  await pg.keyboard.up('Space');
  const t0 = Date.now();
  let top = false;
  while (Date.now() - t0 < 40000) {
    const s = await pg.evaluate(() => {
      const q = MV.Game.player();
      MV.Game.hp(99);
      return { x: q.x, y: q.y, w: q.wall, on: q.on };
    });
    if (s.y < 8.2 && s.x > 19) {
      top = true;
      break;
    }
    if (s.w) {
      await pg.keyboard.up(dir);
      dir = s.w > 0 ? 'ArrowLeft' : 'ArrowRight';
      await pg.keyboard.down(dir);
      await pg.keyboard.press('Space');
      await sleep(pg, 0.12);
    } else if (s.on) await pg.keyboard.press('Space');
    await sleep(pg, 0.04);
  }
  await pg.keyboard.up(dir);
  ok('level 3: wall jumping climbs the shaft', top);
  await tp(pg, 43.5, 8);
  for (let i = 0; i < 200 && (await P(pg))[2] !== 'arena'; i++) await sleep(pg, 0.1);
  p = await P(pg);
  ok('level 3: the lift carries you to the boss room', p[2] === 'arena', p);
  await sleep(pg, 1);
  let dead = false;
  for (let i = 0; i < 2500 && !dead; i++) {
    const s = await pg.evaluate(() => {
      MV.Game.hp(99);
      const q = MV.Game.player(),
        e = MV.Game.entities().find(z => z.type === 'boss');
      return { px: q.x, bx: e.cx, dead: e.dead };
    });
    dead = s.dead;
    const dx = s.bx - s.px;
    await pg.keyboard.up('ArrowLeft');
    await pg.keyboard.up('ArrowRight');
    if (Math.abs(dx) > 3.2) await pg.keyboard.down(dx > 0 ? 'ArrowRight' : 'ArrowLeft');
    else await pg.keyboard.press(dx > 0 ? 'ArrowRight' : 'ArrowLeft');
    if (Math.abs(dx) < 4.2) await pg.keyboard.press('KeyX');
    await sleep(pg, 0.12);
  }
  await sleep(pg, 1);
  const f = await pg.evaluate(() => MV.Game.state().flags);
  ok('the boss can be defeated and the ending event runs', dead && f['ev:win'], f);
  ok('no page errors', pg.errs.length === 0, pg.errs);
  await browser.close();
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail ? 1 : 0);
})();
