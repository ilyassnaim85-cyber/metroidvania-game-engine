// Playtest scenarios in a real browser: node tests/browser.js   (needs:  npm i -D playwright  and  npx playwright install chromium)
// Each scenario builds a small room, plays it with the keyboard and checks what happened. Prints ok / FAIL for each and exits 1 if any failed.
let pw;
try {
  pw = require('playwright');
} catch (e) {
  try {
    pw = require(process.env.PLAYWRIGHT || '/opt/npm-tools/node_modules/playwright');
  } catch (e2) {
    console.log('Playwright is not installed: npm i -D playwright && npx playwright install chromium');
    process.exit(2);
  }
}
const path = require('path'),
  APP = 'file://' + path.join(__dirname, '..', 'index.html');
const sleep = (pg, s) => pg.waitForTimeout(s * 1000);
let pass = 0,
  fail = 0,
  errs = [];
const ok = (name, cond, info) => {
  if (cond) {
    pass++;
    console.log('  ok   ' + name);
  } else {
    fail++;
    console.log('  FAIL ' + name + (info !== undefined ? '   (' + JSON.stringify(info) + ')' : ''));
  }
};
const room = (w, h, floor) => {
  floor = floor || 2;
  const g = [];
  for (let y = 0; y < h; y++) g.push((y >= h - floor ? '#' : '.').repeat(w));
  return g;
};
const put = (g, x, y, c) => {
  g[y] = g[y].slice(0, x) + c + g[y].slice(x + 1);
};
const box = (g, x0, y0, x1, y1, c) => {
  for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) put(g, x, y, c || '#');
};
async function start(pg, o) {
  // o: grid, ents, moves, tune, abil, spawn, cam, profiles, events, items, room2, atk, st (extra progress state)
  await pg.evaluate(
    ([grid, ents, moves, tune, abil, spawn, cam, profiles, events, items, room2, atk, xst, enm, scripts, vcams]) => {
      const gh = grid.length,
        gw = grid[0].length;
      const room = {
        id: 't1',
        n: 'T',
        gw,
        gh,
        grid: grid.slice(),
        ent: (ents || []).map((e, i) => Object.assign({ id: 'e' + i, props: {} }, e)),
        tr: window.__tr || [],
        bg: null,
        art: [],
        cam: cam || null
      };
      if (spawn) room.ent.push({ id: 'sp', type: 'spawn', x: spawn[0], y: spawn[1] - 1, props: {} });
      const rooms = [room];
      if (room2)
        rooms.push({
          id: 't2',
          n: 'Second',
          gw: room2[0].length,
          gh: room2.length,
          grid: room2.slice(),
          ent: [{ id: 'sp2', type: 'spawn', x: 3, y: room2.length - 3, props: {} }],
          tr: [],
          bg: null,
          art: []
        });
      const area = { id: 'a1', n: 'A', s: '', c: '#378add', x: 0, y: 0, w: 50, h: 50, rooms, links: [] };
      const world = Object.assign({}, S, {
        areas: [area],
        camProfiles: profiles || [],
        events: events || [],
        scripts: scripts || [],
        vcams: vcams || [],
        items: items || S.items,
        bosses: S.bosses || []
      });
      const st = MV.Progress.fresh();
      (abil || []).forEach(a => (st.abilities[a] = true));
      window.__atk = atk;
      window.__enm = enm || [];
      Object.assign(st, xst || {});
      window.__mv = moves || [];
      window.__tune = Object.assign({ maxHp: 99 }, tune || {});
      document.getElementById('mtp').hidden = false;
      MV.Game.debug = false;
      MV.Game.boxes = false;
      MV.Game.start({
        enemies: () => window.__enm,
        bosses: () => world.bosses,
        canvas: document.getElementById('mtc'),
        world,
        room,
        state: st,
        persist: false,
        art: () => {},
        tuning: () => window.__tune,
        image: () => null,
        attacks: () => window.__atk || [],
        moves: () => window.__mv,
        items: () => world.items,
        body: () => S.body,
        controls: () => S.controls,
        sprite: () => S.sprite,
        sheet: () => null
      });
    },
    [
      o.grid,
      o.ents,
      o.moves,
      o.tune,
      o.abil,
      o.spawn,
      o.cam,
      o.profiles,
      o.events,
      o.items,
      o.room2,
      o.atk,
      o.st,
      o.enm,
      o.scripts,
      o.vcams
    ]
  );
  await sleep(pg, 0.4);
}
const P = pg =>
  pg.evaluate(() => {
    const p = MV.Game.player();
    return {
      x: p.x,
      y: p.y,
      vx: p.vx,
      vy: p.vy,
      on: p.on,
      sq: p.sq,
      hst: p.hst || '',
      xst: p.xst || '',
      lg: p.lg ? p.lg.ph : null,
      hp: MV.Game.hp(),
      ride: !!p.ride,
      air: p.air
    };
  });
const CAM = pg =>
  pg.evaluate(() => {
    const g = MV.Game.camera.get(),
      d = g.debug;
    return { cx: d.x, cy: d.y, look: d.look, b: d.bounds, zone: g.zone, prof: g.profile, ledge: d.ledge };
  });
const dn = (pg, k) => pg.keyboard.down(k),
  up = (pg, k) => pg.keyboard.up(k);
const tap = async (pg, k, t) => {
  await dn(pg, k);
  await sleep(pg, t || 0.08);
  await up(pg, k);
};

const scenarios = {
  async 'export: the exported game is one file that starts, plays, saves and has no network'(pg) {
    const fs = require('fs'),
      os = require('os');
    const text = await pg.evaluate(() => {
      const g = [];
      for (let y = 0; y < 14; y++) g.push((y >= 12 ? '#' : '.').repeat(40));
      const w = fresh();
      w.name = 'Export <test>';
      w.areas = [
        {
          id: 'a1',
          n: 'A',
          s: '',
          c: 't',
          x: 40,
          y: 40,
          w: 170,
          h: 56,
          rooms: [
            {
              id: 'r1',
              n: 'R',
              s: '',
              x: 10,
              y: 10,
              w: 130,
              h: 44,
              note: '',
              grid: g,
              gw: 40,
              gh: 14,
              art: [],
              table: [],
              tr: [],
              ent: [
                { id: 'sp', type: 'spawn', x: 5, y: 11, props: {} },
                { id: 'ck', type: 'checkpoint', x: 12, y: 11, props: {} }
              ],
              cam: null
            }
          ],
          links: []
        }
      ];
      w.scripts = MV.Script.clean([
        { id: 's', name: 'S', on: true, code: "on('start', () => game.flag('hello', true));" }
      ]);
      return ser(w);
    });
    const html = require('../tools/export.js').buildGame(path.join(__dirname, '..'), text);
    const file = path.join(os.tmpdir(), 'mv-export-test.html');
    fs.writeFileSync(file, html);
    ok(
      'the exported file is self-contained and has no editor code',
      !/editor\/app-0/.test(html) && !/<script src=/.test(html) && html.includes('mv-project'),
      html.length
    );
    const br2 = await pw.chromium.launch({ args: ['--no-sandbox'] }),
      g = await br2.newPage(),
      errs = [],
      reqs = [];
    g.on('pageerror', x => errs.push(String(x)));
    g.on('console', m => m.type() === 'error' && errs.push(m.text()));
    g.on('request', r => !/^(file|data|blob):/.test(r.url()) && reqs.push(r.url()));
    await g.goto('file://' + file);
    await g.waitForTimeout(800);
    const title = await g.evaluate(() => ({ t: document.title, m: window.__mvPlayer.title() }));
    ok(
      'it opens on a title screen drawn on the canvas, with New game, Full screen and a page title that is the project name',
      title.t === 'Export <test>' && title.m && title.m.items.includes('new') && title.m.items.includes('full'),
      title
    );
    await g.keyboard.press('Enter');
    await g.waitForTimeout(1200);
    const a = await g.evaluate(() => ({
      room: MV.Game.room() && MV.Game.room().id,
      x: MV.Game.player().x,
      hello: !!MV.Game.state().flags.hello,
      menu: !window.__mvPlayer.title()
    }));
    await g.keyboard.down('ArrowRight');
    await g.waitForTimeout(700);
    await g.keyboard.up('ArrowRight');
    const b = await g.evaluate(() => MV.Game.player().x);
    ok(
      'New game starts in the spawn room, runs the project scripts and the player moves with the keys',
      a.room === 'r1' && a.menu && a.hello && b > a.x + 1,
      [a, b]
    );
    await g.evaluate(() => {
      const p = MV.Game.player();
      p.x = 12;
      p.y = 12;
    });
    await g.waitForTimeout(600);
    const saved = await g.evaluate(() => Object.keys(localStorage).filter(k => /^mv_game_/.test(k)));
    ok('progress is saved under its own key', saved.length === 1, saved);
    await g.keyboard.press('Escape');
    await g.waitForTimeout(200);
    const pm = await g.evaluate(() => MV.Game.pauseOpen());
    await g.keyboard.press('ArrowDown');
    await g.keyboard.press('ArrowDown');
    await g.keyboard.press('ArrowDown');
    await g.keyboard.press('ArrowDown');
    await g.keyboard.press('Enter');
    await g.waitForTimeout(300);
    const again = await g.evaluate(() => window.__mvPlayer.title());
    ok(
      'Esc opens the pause menu and Quit to title returns to the title screen, which now offers Continue',
      pm && again && again.items[0] === 'continue',
      [pm, again]
    );
    ok('no network requests and no errors', reqs.length === 0 && errs.length === 0, [reqs, errs]);
    await br2.close();
  },
  async 'security: names from an opened project file are shown as text, never as HTML'(pg) {
    const r = await pg.evaluate(async () => {
      const P = '<img src=x onerror="window.__pwn=1"><svg onload="window.__pwn=2">"\'`';
      const w = fresh();
      w.name = P;
      w.areas = [
        {
          id: 'a1',
          n: P,
          s: P,
          c: 't',
          x: 40,
          y: 40,
          w: 170,
          h: 56,
          rooms: [
            {
              id: 'r1',
              n: P,
              s: '',
              x: 10,
              y: 10,
              w: 130,
              h: 44,
              note: P,
              grid: ['.'.repeat(20)].concat(Array(11).fill('.'.repeat(20))),
              gw: 20,
              gh: 12,
              art: [],
              table: [],
              tr: [{ id: 't', x: 1, y: 1, to: 'ghost|' + P }],
              ent: [],
              cam: null
            }
          ],
          links: []
        }
      ];
      w.events = MV.Events.clean([
        { id: 'e', name: P, trigger: { type: 'room', room: 'r1' }, actions: [{ type: 'message', text: P }] }
      ]);
      w.bosses = MV.Boss.list([{ id: 'b', name: P, patterns: [{ id: 'p', name: P, hitboxes: [] }] }]);
      w.enemies = MV.Enemies.resolve([{ id: 'en', name: P }]);
      w.scripts = MV.Script.clean([{ id: 's', name: P, on: false, code: '// ' + P }]);
      w.moves = MV.Moves.resolve([{ id: 'm', label: P }]);
      w.items = MV.Inventory.resolve([{ id: 'i', name: P }]);
      const text = ser(w);
      window.confirm = () => true;
      projectFromJson(text, 'evil.json');
      wValRun();
      if (typeof wValToggle === 'function') wValToggle();
      ['world', 'player', 'enemies', 'boss', 'anim', 'events', 'audio', 'scripts'].forEach(t => {
        TAB = '';
        tab(t);
      });
      tab('world');
      await new Promise(x => setTimeout(x, 400));
      return {
        pwn: window.__pwn,
        imgs: document.querySelectorAll('img[src="x"]').length,
        svgs: document.querySelectorAll('svg[onload]').length,
        panel: !!document.querySelector('.vpi')
      };
    });
    ok(
      'hostile names and notes create no elements and run no code',
      r.panel && !r.pwn && r.imgs === 0 && r.svgs === 0,
      r
    );
  },
  async 'camera: the preview window plays the camera and follows the setting you change'(pg) {
    await pg.evaluate(() => {
      tab('player');
      psSub('cam');
    });
    await sleep(pg, 1.5);
    const r1 = await pg.evaluate(() => ({
      shown: !document.getElementById('cpv').hidden,
      room: MV.Game.room() && MV.Game.room().id,
      moving: MV.Game.player().x
    }));
    await sleep(pg, 1);
    const r2 = await pg.evaluate(() => ({
      x: MV.Game.player().x,
      info: document.querySelector('#cpv .cpi').textContent
    }));
    ok(
      'the preview starts in the Camera tab with its own room and the player runs by itself',
      r1.shown && r1.room === '__cpv' && Math.abs(r2.x - r1.moving) > 1,
      [r1, r2]
    );
    ok('it shows the live camera numbers', /camera .*zoom/.test(r2.info), r2);
    await pg.evaluate(() => {
      S.player.camLookAhead = 3;
      buildCam();
    });
    await sleep(pg, 0.6);
    const n = await pg.evaluate(() => document.querySelector('#cpv .cpn').textContent);
    ok('changing a setting says what changed', /Look ahead/.test(n) && /3/.test(n), n);
    await pg.evaluate(() => {
      S.vcams = MV.CameraVcams.clean([{ id: 'v1', name: 'Tight', zoom: 2 }]);
      buildCam();
    });
    await sleep(pg, 0.8);
    const opts = await pg.evaluate(() => [...document.querySelectorAll('#cpv .cpw option')].map(o => o.textContent));
    ok(
      'the preview can look through a virtual camera or profile',
      opts.some(o => /Tight/.test(o)),
      opts
    );
    await pg.evaluate(() => psSub('mv'));
    await sleep(pg, 0.3);
    const off = await pg.evaluate(() => ({ room: MV.Game.room(), hid: document.getElementById('cpv').hidden }));
    ok('leaving the Camera tab stops the preview', !off.room && off.hid, off);
  },
  async 'camera: virtual cameras pick by priority, blend, freeze and draw the debug view'(pg) {
    await start(pg, {
      grid: room(60, 24),
      spawn: [10, 22],
      ents: [{ type: 'camzone', x: 40, y: 10, props: { width: 6, height: 5 } }],
      vcams: [
        { id: 'lo', name: 'Low', priority: 1, zoom: 1.5, blend: { time: 0.3, ease: 'linear' } },
        {
          id: 'big',
          name: 'Big',
          priority: 20,
          zoom: 2.2,
          follow: { kind: 'point', x: 30, y: 12 },
          bounds: [20, 0, 60, 24],
          blend: { time: 0.4, ease: [0.4, 0, 0.2, 1] }
        },
        { id: 'far', name: 'Far room', priority: 99, room: 'nowhere', zoom: 3 }
      ]
    });
    const st = () =>
      pg.evaluate(() => ({
        a: MV.Game.camera.vcamActive(),
        z: MV.Game.camera.status().zoom,
        v: MV.Game.camera.rig().view()
      }));
    await sleep(pg, 1.6);
    const a = await st();
    ok(
      'the highest-priority virtual camera of this room is live and sets the zoom',
      a.a === 'big' && Math.abs(a.z - 2.2) < 0.1,
      a
    );
    ok('a virtual camera for another room is ignored', a.a !== 'far', a);
    await pg.evaluate(() => MV.Game.camera.vcam('big', false));
    await sleep(pg, 1.2);
    const b = await st();
    ok('switching a camera off by script blends to the next one', b.a === 'lo' && Math.abs(b.z - 1.5) < 0.1, b);
    await pg.evaluate(() => MV.Game.camera.vcamPriority('lo', -5));
    await sleep(pg, 0.2);
    await pg.evaluate(() => MV.Game.camera.vcam('big', true));
    await pg.evaluate(() => MV.Game.camera.vcamSolo('lo'));
    await sleep(pg, 0.5);
    ok('solo makes one camera live whatever the priorities', (await st()).a === 'lo');
    await pg.evaluate(() => MV.Game.camera.vcamSolo(null));
    await pg.evaluate(() => MV.Game.camera.vcam('lo', false));
    await sleep(pg, 0.8);
    ok('letting go of solo returns to the highest priority', (await st()).a === 'big');
    const f0 = (await st()).v.cx;
    await pg.evaluate(() => {
      MV.Game.camera.vcamSolo(null);
      MV.Game.camera.vcam('big', false);
      MV.Game.camera.vcam('lo', false);
    });
    await sleep(pg, 1.4);
    await pg.evaluate(() => {
      MV.Game.camera.freeze(1);
      MV.Game.player().x = 30;
    });
    const c0 = (await st()).v.cx;
    await sleep(pg, 0.5);
    const c1 = (await st()).v.cx;
    ok('freeze stops the camera following for a moment', Math.abs(c1 - c0) < 0.6, [c0, c1]);
    await pg.evaluate(() => MV.Game.camera.debug(true));
    await sleep(pg, 0.4);
    ok('the camera debug view draws without errors', true);
  },
  async 'camera: the virtual camera editor builds, edits and round-trips'(pg) {
    const r = await pg.evaluate(() => {
      const o = {};
      S.vcams = [];
      const room = {
        id: 'vr1',
        n: 'V',
        gw: 30,
        gh: 20,
        grid: Array(20).fill('.'.repeat(30)),
        ent: [{ id: 'cz1', type: 'camzone', x: 4, y: 9, props: { width: 6, height: 4 } }],
        tr: [],
        bg: null,
        art: []
      };
      S.areas = [{ id: 'a1', n: 'A', s: '', c: '#378add', x: 0, y: 0, w: 50, h: 50, rooms: [room], links: [] }];
      rc = room;
      tab('player');
      psSub('cam');
      buildCam();
      o.host = !!$('vcg') && $('vcg').textContent.includes('Virtual cameras');
      [...$('vcg').querySelectorAll('button')].find(b => b.textContent === '+ New camera').click();
      o.made = S.vcams.length === 1 && S.vcams[0].room === room.id;
      const c = S.vcams[0];
      const f = lab => [...$('vcg').querySelectorAll('label')].find(l => l.textContent.trim().startsWith(lab));
      const setIn = (lab, v) => {
        const i = f(lab).querySelector('input');
        i.value = v;
        i.onchange();
      };
      setIn('Priority', 33);
      setIn('Zoom', 1.8);
      setIn('Dead zone X', 2);
      setIn('Soft zone X', 3);
      o.vals =
        S.vcams[0].priority === 33 &&
        S.vcams[0].zoom === 1.8 &&
        S.vcams[0].p.camDeadX === 2 &&
        S.vcams[0].p.camSoftX === 3;
      const sel = [...$('vcg').querySelectorAll('select')].find(s =>
        [...s.options].some(x => /pick a zone/.test(x.textContent))
      );
      sel.value = 'cz1';
      sel.onchange();
      o.bounds = JSON.stringify(S.vcams[0].bounds);
      const back = des(ser(S));
      o.round = back.vcams.length === 1 && back.vcams[0].priority === 33 && back.vcams[0].bounds[2] === 10;
      o.snap = snap().core.includes('"vcams"');
      drawT();
      S.vcams[0].bounds = [9, 9, 1, 1];
      o.warn = MV.CameraVcams.validate(S).length;
      S.vcams[0].bounds = null;
      tab('world');
      return o;
    });
    ok('Player > Camera shows the virtual camera list and makes a camera', r.host && r.made, r);
    ok('a virtual camera keeps priority, zoom, dead zone and soft zone', r.vals, r);
    ok('bounds can be taken from a Camera zone drawn in the room', r.bounds === '[4,6,10,10]', r.bounds);
    ok('virtual cameras are saved with the project and in undo', r.round && r.snap, r);
  },
  async 'scripts: the Boss AI panel offers Script and creates the starter script'(pg) {
    const r = await pg.evaluate(() => {
      const o = {};
      S.bosses = MV.Boss.list([{ id: 'bb', name: 'Big', patterns: [{ id: 'sl', name: 'Slam', hitboxes: [] }] }]);
      S.scripts = [];
      BI = 0;
      BSUB = 'patterns';
      tab('boss');
      bossUI();
      const txt = () => document.getElementById('bpc').textContent;
      o.offered = txt().includes('Script: a JavaScript');
      const sel = [...document.querySelectorAll('#bpc select')].find(q =>
        [...q.options].some(x => x.value === 'script')
      );
      sel.value = 'script';
      sel.onchange();
      o.ai = S.bosses[0].ai;
      o.rulesHidden = !txt().includes('Pick attacks by rules');
      [...document.querySelectorAll('#bpc button')].find(b => b.textContent === 'Create the script').click();
      o.brain = S.bosses[0].brain;
      o.code = !MV.Script.syntax(S.scripts[0].code) && S.scripts[0].code.includes("me.attack('sl')");
      o.clean = MV.Script.validate(S).length === 0;
      o.tab = TAB;
      tab('world');
      return o;
    });
    ok('the Boss AI panel offers Script next to the built-in AI', r.offered && r.ai === 'script' && r.rulesHidden, r);
    ok(
      'Create the script makes a working starter script that starts the boss patterns',
      r.brain === 'bbBrain' && r.code && r.clean && r.tab === 'scripts',
      r
    );
  },
  async 'scripts: scripted enemy AI, boss AI and a scripted move'(pg) {
    await pg.evaluate(() => {
      S.bosses = MV.Boss.list([
        {
          id: 'sb',
          name: 'Scripted boss',
          hp: 10,
          w: 2,
          h: 3,
          wake: 14,
          touch: 'no',
          wakeTime: 0.2,
          ai: 'script',
          brain: 'bossBrain',
          patterns: [{ id: 'sl', name: 'Slam', warn: 0.3, duration: 0.6, hitboxes: [] }]
        }
      ]);
    });
    const code =
      "fn('hunter', me => { me.dir = me.dx >= 0 ? 1 : -1; me.vx = me.sees ? me.dir * 4 : 0; });\n" +
      "fn('bossBrain', me => { me.mem.n = (me.mem.n || 0) + 1; if (me.dist > 3) me.walk(me.dx, 3); else me.attack('sl'); });\n" +
      "on('update', () => { if (game.player.tune('jumpHeight', 6) === 6) game.flag('tuned', true); const en = game.entities('enemy')[0], bo = game.entities('boss')[0]; if (en && en.set('sight', 17) && en.get('sight') === 17) game.flag('eset', true); if (bo && bo.set('keep', 5) && bo.get('keep') === 5) game.flag('bset', true); if (en && !en.set('nonsense', 1) && !en.set('hp', 'x')) game.flag('rejected', true); });\n" +
      "fn('zip', me => { me.vx = me.facing * 18; me.vy = 0; me.hitbox(1, 0, 1.5, 1.5, 2); });\n";
    await start(pg, {
      grid: room(60, 20),
      spawn: [3, 18],
      tune: { maxHp: 20 },
      enm: [{ id: 'hunter', move: 'script', brain: 'hunter', sight: 20, hp: 3, damage: 1, knock: 3 }],
      moves: [{ id: 'zip', type: 'scripted', key: 'KeyZ', script: 'zip', duration: 0.25, keep: 0, cooldown: 0.2 }],
      ents: [
        { type: 'enemy', x: 40, y: 17, props: { kind: 'hunter' } },
        { type: 'boss', x: 20, y: 17, props: { boss: 'sb' } }
      ],
      scripts: [{ id: 's', name: 'AI', on: true, code }]
    });
    const snap = () =>
      pg.evaluate(() => {
        const en = MV.Game.entities().find(q => q.kd === 'hunter'),
          b = MV.Game.entities().find(q => q.type === 'boss');
        return { ex: en.cx, bx: b.cx, bst: b.b.state, px: MV.Game.player().x, errs: MV.Game.script.errors() };
      });
    const a = await snap();
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 28;
      p.y = 18;
      p.inv = 99;
    });
    await sleep(pg, 1.2);
    const b = await snap();
    ok('an enemy with Moves = Script is steered by its function (it walks toward you)', b.ex < a.ex - 2, [a.ex, b.ex]);
    ok(
      'a boss with AI = Script walks and starts its own pattern by script',
      b.bx > a.bx + 1 || b.bx < a.bx - 1 || b.bst === 'attack',
      [a.bx, b.bx, b.bst]
    );
    let seen = false;
    for (let i = 0; i < 40 && !seen; i++) {
      await sleep(pg, 0.1);
      seen = (await snap()).bst === 'attack';
    }
    ok('the boss brain started a pattern with me.attack()', seen);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 5;
      p.y = 18;
      p.face = 1;
    });
    await sleep(pg, 0.3);
    const x0 = (await snap()).px;
    await dn(pg, 'KeyZ');
    await sleep(pg, 0.1);
    await up(pg, 'KeyZ');
    await sleep(pg, 0.35);
    const x1 = (await snap()).px;
    ok('a Scripted move moves the player the way its function says', x1 > x0 + 2.5, [x0, x1]);
    const d = await snap();
    const fl = await pg.evaluate(() => MV.Game.state().flags);
    ok(
      'a script can change the player settings, an enemy and a boss, and bad names or values are refused',
      fl.tuned && fl.eset && fl.bset && fl.rejected,
      fl
    );
    ok('script errors from these functions: none', d.errs.length === 0, d.errs);
  },
  async 'scripts: hooks, the Events action, the game API and error handling'(pg) {
    await start(pg, {
      grid: room(30, 14),
      spawn: [3, 12],
      ents: [{ type: 'loot', x: 20, y: 11, props: {} }],
      events: [
        {
          id: 'r',
          name: 'Run',
          trigger: { type: 'flag', flag: 'go' },
          actions: [{ type: 'script', name: 'bump', arg: '5' }]
        }
      ],
      scripts: [
        {
          id: 's1',
          name: 'A',
          on: true,
          code:
            "on('start', () => game.flag('started', true));\n" +
            "fn('bump', n => game.variable('n', (game.variable('n') || 0) + Number(n)));\n" +
            "let t = 0; on('update', dt => { t += dt; if (t > 0.5) game.flag('ticked', true); });\n" +
            "log('hello');"
        },
        { id: 's2', name: 'Bad', on: true, code: "on('update', () => { throw new Error('boom'); });" },
        {
          id: 's3',
          name: 'Sandbox',
          on: true,
          code: "on('start', () => game.flag('sandbox', typeof window === 'undefined' && typeof document === 'undefined'));"
        }
      ]
    });
    await sleep(pg, 1);
    const r = await pg.evaluate(() => {
      const f = MV.Game.state().flags;
      return {
        started: !!f.started,
        ticked: !!f.ticked,
        sandbox: !!f.sandbox,
        errs: MV.Game.script.errors(),
        logs: MV.Game.script.logs()
      };
    });
    ok('a script hears start and update', r.started && r.ticked, r);
    ok('script code cannot see window or document', r.sandbox, r);
    ok(
      'a script error is recorded with the script name and does not stop the game',
      r.errs.some(e => e.script === 'Bad' && /boom/.test(e.message)),
      r.errs
    );
    ok(
      'log() reaches the console',
      r.logs.some(l => l.text === 'hello'),
      r.logs
    );
    const n = await pg.evaluate(async () => {
      MV.Game.state().flags.go = true;
      await new Promise(x => setTimeout(x, 600));
      return MV.Game.state().vars ? MV.Game.state().vars.n : MV.Game.script.call('bump', 0);
    });
    ok('the Events action "Run a script function" calls the function with its argument', n === 5, n);
  },
  async 'scripts: the Scripts tab builds, edits and round-trips'(pg) {
    const r = await pg.evaluate(() => {
      const out = {};
      tab('scripts');
      out.shown = !$('scg').hidden;
      S.scripts = MV.Script.clean([MV.Script.blank('One')]);
      scUI();
      out.items = $('scg').querySelectorAll('.scl .item').length;
      out.status = $('scg').textContent.includes('Syntax OK');
      const ta = $('scg').querySelector('textarea.code');
      ta.value = 'on(';
      ta.dispatchEvent(new Event('input'));
      out.bad = $('scg').textContent.includes('Syntax error');
      const back = des(ser(S));
      out.kept = back.scripts.length === 1 && back.scripts[0].name === 'One';
      tab('world');
      return out;
    });
    ok('the Scripts tab opens and lists the scripts', r.shown && r.items === 1, r);
    ok('the code box checks the syntax as you type', r.status && r.bad, r);
    ok('scripts are saved with the project', r.kept, r);
  },
  async 'moves: sprint, crouch and morph ball hold on the ground'(pg) {
    const mv = [
      { id: 'sprint', type: 'hold', key: 'Shift', on: 'ground', runs: 14, state: 'sprint' },
      { id: 'crouch', type: 'hold', key: 'Down', on: 'ground', runs: 3, squash: 0.5, state: 'crouch' },
      {
        id: 'ball',
        type: 'hold',
        key: 'KeyC',
        on: 'ground',
        runs: 9,
        squash: 0.4,
        sqw: 0.5,
        nojump: 'yes',
        state: 'morph'
      }
    ];
    await start(pg, { grid: room(60, 20), moves: mv, spawn: [3, 18] });
    let x0 = (await P(pg)).x;
    await dn(pg, 'ArrowRight');
    await sleep(pg, 1);
    const run = (await P(pg)).x - x0;
    await up(pg, 'ArrowRight');
    await sleep(pg, 0.4);
    x0 = (await P(pg)).x;
    await dn(pg, 'ArrowRight');
    await dn(pg, 'Shift');
    await sleep(pg, 1);
    const spr = (await P(pg)).x - x0;
    await up(pg, 'Shift');
    await up(pg, 'ArrowRight');
    await sleep(pg, 0.4);
    ok('sprint is faster than run', spr > run * 1.4, { run, spr });
    x0 = (await P(pg)).x;
    await dn(pg, 'ArrowRight');
    await dn(pg, 'ArrowDown');
    await sleep(pg, 1.2);
    const cr = await P(pg);
    await up(pg, 'ArrowDown');
    await up(pg, 'ArrowRight');
    await sleep(pg, 0.3);
    ok('crouch is low and slow and lasts past 3 s rules', cr.sq === 0.5 && cr.x - x0 < 5, cr);
    ok('standing again after release', (await P(pg)).sq === 1);
    await dn(pg, 'KeyC');
    await sleep(pg, 0.3);
    await tap(pg, 'Space');
    await sleep(pg, 0.2);
    const b = await P(pg);
    await up(pg, 'KeyC');
    ok('morph ball cannot jump', b.on && b.sq < 0.5, b);
  },
  async 'moves: ledge grab, hang, climb and leap off'(pg) {
    const g = room(40, 20);
    box(g, 10, 14, 13, 17);
    await start(pg, {
      grid: g,
      moves: [{ id: 'ledge', type: 'ledge', key: 'None', grab: 0.5, climb: 0.35, kick: 8 }],
      spawn: [9.3, 18]
    });
    await dn(pg, 'ArrowRight');
    await tap(pg, 'Space', 0.25);
    let hang = false;
    for (let i = 0; i < 14 && !hang; i++) {
      await sleep(pg, 0.1);
      hang = (await P(pg)).lg === 'hang';
    }
    ok('catches the ledge', hang);
    await sleep(pg, 0.4);
    ok('keeps hanging', (await P(pg)).lg === 'hang');
    await up(pg, 'ArrowRight');
    await tap(pg, 'ArrowUp', 0.1);
    await sleep(pg, 1);
    const a = await P(pg);
    ok('climbs up on top of the block', a.y < 14.6 && a.x > 10 && a.on, a);
  },
  async 'moves: rope swing, zipline, cannon, portal fling'(pg) {
    await start(pg, {
      grid: room(40, 24),
      ents: [{ type: 'grapplepoint', x: 15, y: 6 }],
      moves: [
        {
          id: 'rope',
          type: 'grapple',
          key: 'KeyQ',
          how: 'swing',
          anchor: 'grapple points only',
          reach: 12,
          hook: 60,
          pull: 24,
          accel: 30,
          gravity: 1,
          duration: 3,
          dir: 'fixed',
          angle: 64
        }
      ],
      spawn: [12, 22]
    });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 11.4;
      p.y = 15;
      p.vx = p.vy = 0;
      p.on = false;
    });
    await dn(pg, 'KeyQ');
    let xs = [];
    for (let i = 0; i < 12; i++) {
      await sleep(pg, 0.15);
      xs.push((await P(pg)).x);
    }
    await up(pg, 'KeyQ');
    ok(
      'the rope swings like a pendulum (x goes right then back)',
      Math.max(...xs) > 18 && xs[xs.length - 1] < Math.max(...xs) - 1,
      xs.map(v => +v.toFixed(1))
    );
    await start(pg, {
      grid: room(40, 24),
      ents: [
        {
          type: 'rail',
          x: 4,
          y: 10,
          props: {
            dx: 14,
            dy: 4,
            speed: 9,
            accel: 14,
            mode: 'ride to the end',
            hang: 'hang below',
            grab: 'touch it',
            key: 'E'
          }
        }
      ],
      spawn: [4, 22]
    });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 4.3;
      p.y = 11.5;
      p.vy = 0;
      p.on = false;
    });
    await sleep(pg, 1.5);
    ok('the zipline carries you along', (await P(pg)).x > 11);
    await start(pg, {
      grid: room(40, 24),
      ents: [
        {
          type: 'cannon',
          x: 5,
          y: 19,
          props: { angle: 45, aim: 'fixed', power: 24, fire: 'after a delay', delay: 0.6, flight: 0.5, reload: 1 }
        }
      ],
      spawn: [5, 22]
    });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 5.7;
      p.y = 20.4;
    });
    await sleep(pg, 2);
    ok('the cannon fires you across the room', (await P(pg)).x > 14);
    await start(pg, {
      grid: room(40, 24),
      ents: [
        { type: 'teleporter', x: 4, y: 20, props: { channel: 'A', launch: 0 } },
        { type: 'teleporter', x: 30, y: 20, props: { channel: 'A', launch: 20, angle: 90, keep: 'no' } }
      ],
      spawn: [4.5, 22]
    });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 4.5;
      p.y = 22;
    });
    await sleep(pg, 1.1);
    const q = await P(pg);
    ok('the portal moves and flings you up', q.x > 29 && q.y < 21, q);
  },
  async 'world: oxygen, phase, burrow, mount'(pg) {
    const g = room(40, 24);
    for (let y = 8; y < 22; y++) for (let x = 10; x < 30; x++) put(g, x, y, '~');
    await start(pg, { grid: g, tune: { oxygen: 3, drownEvery: 1, drownDmg: 1 }, spawn: [15, 21] });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 15;
      p.y = 20;
    });
    await sleep(pg, 5.3);
    const d = await P(pg);
    ok('air runs out and drowning hurts', d.air === 0 && d.hp < 30, d);
    await start(pg, { grid: g, tune: { oxygen: 2, drownEvery: 1 }, abil: ['waterBreath'], spawn: [15, 21] });
    const hp0 = (await P(pg)).hp;
    await sleep(pg, 3.5);
    ok('underwater breathing ability stops drowning', (await P(pg)).hp === hp0);
    const w = room(40, 24);
    box(w, 15, 10, 17, 21);
    const ghost = [{ id: 'ghost', type: 'hold', key: 'KeyG', on: 'air and ground', phase: 'walls', runs: 8 }];
    await start(pg, { grid: w, moves: ghost, spawn: [10, 22] });
    await dn(pg, 'ArrowRight');
    await sleep(pg, 1);
    const blocked = (await P(pg)).x;
    await up(pg, 'ArrowRight');
    await start(pg, { grid: w, moves: ghost, spawn: [10, 22] });
    await dn(pg, 'KeyG');
    await dn(pg, 'ArrowRight');
    await sleep(pg, 1.2);
    const thru = (await P(pg)).x;
    await up(pg, 'ArrowRight');
    await up(pg, 'KeyG');
    ok('walls block you, ghost goes through', blocked < 15 && thru > 18, { blocked, thru });
    const s = room(40, 24);
    box(s, 15, 20, 24, 21, 's');
    const dig = [{ id: 'dig', type: 'hold', key: 'KeyD', on: 'air and ground', phase: 'soil', runs: 6, fly: 6 }];
    await start(pg, { grid: s, moves: dig, spawn: [10, 20] });
    await dn(pg, 'ArrowRight');
    await sleep(pg, 0.8);
    const solid = (await P(pg)).x;
    await up(pg, 'ArrowRight');
    await start(pg, { grid: s, moves: dig, spawn: [10, 20] });
    await dn(pg, 'KeyD');
    await dn(pg, 'ArrowRight');
    await sleep(pg, 1.4);
    const inside = await P(pg);
    await up(pg, 'ArrowRight');
    await up(pg, 'KeyD');
    ok(
      'soft ground blocks without the move and can be dug through with it',
      solid < 15 && inside.x > 17 && inside.hst === 'burrow',
      { solid, inside }
    );
    await start(pg, {
      grid: room(40, 24),
      ents: [
        {
          type: 'mount',
          x: 8,
          y: 19,
          props: {
            name: 'Turtle',
            kind: 'walks',
            key: 'E',
            speed: 12,
            jump: 5,
            gravity: 1,
            width: 1.6,
            height: 1.2,
            seat: 0.5
          }
        }
      ],
      spawn: [5, 22]
    });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 8.8;
      p.y = 22;
    });
    await tap(pg, 'KeyE', 0.1);
    await sleep(pg, 0.3);
    const m = await P(pg);
    ok('press E to ride a mount', m.ride, m);
    await dn(pg, 'ArrowRight');
    await sleep(pg, 1);
    const mx = (await P(pg)).x;
    await up(pg, 'ArrowRight');
    ok('the mount is faster than walking', mx - 8.5 > 9, mx);
    await tap(pg, 'KeyE', 0.1);
    await sleep(pg, 0.3);
    ok('press E again to get off', !(await P(pg)).ride);
  },
  async 'camera: direction bias, velocity look, bounds, ledge hint, swapping'(pg) {
    const g = room(120, 60, 3);
    await start(pg, { grid: g, tune: { camLookAhead: 4, camLookDelay: 0.25, camLookSpeed: 0.1 }, spawn: [60, 57] });
    await sleep(pg, 0.5);
    await dn(pg, 'ArrowRight');
    await sleep(pg, 1.2);
    const r = (await CAM(pg)).look[0];
    await up(pg, 'ArrowRight');
    await dn(pg, 'ArrowLeft');
    await sleep(pg, 0.12);
    const early = (await CAM(pg)).look[0];
    await sleep(pg, 1.2);
    const left = (await CAM(pg)).look[0];
    await up(pg, 'ArrowLeft');
    ok('the view leans the way you face, after the delay', r > 3.5 && early > 3 && left < -3.5, { r, early, left });
    await start(pg, { grid: g, tune: { camFallLook: 4, camVelStart: 10, camVelMax: 25 }, spawn: [60, 57] });
    await sleep(pg, 0.4);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.y = 10;
      p.vy = 0;
    });
    let mx = 0;
    for (let i = 0; i < 14; i++) {
      await sleep(pg, 0.1);
      mx = Math.max(mx, (await CAM(pg)).look[1]);
    }
    ok('the view leans down while you fall fast', mx > 3, mx);
    await start(pg, { grid: g, spawn: [2, 57] });
    await sleep(pg, 0.8);
    ok('the room limits hold the view', (await CAM(pg)).cx >= 0);
    const z = b => [
      { type: 'camzone', x: 0, y: 59, props: { width: 12, height: 20, profile: '', bounds: b, blend: 0.3 } }
    ];
    await start(pg, { grid: g, ents: z('break room limits'), spawn: [2, 57] });
    await sleep(pg, 1.5);
    ok('a zone can break the room limits', (await CAM(pg)).cx < -3);
    const g2 = room(120, 60, 3);
    for (let y = 57; y < 60; y++) for (let x = 60; x < 70; x++) put(g2, x, y, '.');
    await start(pg, { grid: g2, tune: { camLedgeLook: 3, camLedgeDelay: 0.3, camLedgeDepth: 3 }, spawn: [58, 57] });
    await sleep(pg, 0.5);
    await dn(pg, 'ArrowRight');
    await sleep(pg, 0.9);
    await up(pg, 'ArrowRight');
    await sleep(pg, 1.2);
    const L = await CAM(pg);
    ok('at the edge of a drop the view slides down', L.ledge && L.look[1] > 2, L);
    await start(pg, { grid: g, spawn: [60, 57] });
    await sleep(pg, 0.4);
    await pg.evaluate(() => {
      MV.Game.camera.set('locked', 0.3);
    });
    await sleep(pg, 1.2);
    const a = await CAM(pg);
    await dn(pg, 'ArrowRight');
    await sleep(pg, 0.8);
    const b = await CAM(pg);
    await up(pg, 'ArrowRight');
    ok('swapping to the fully locked profile freezes the view', a.prof === 'locked' && Math.abs(a.cx - b.cx) < 0.05, {
      a: a.cx,
      b: b.cx
    });
  },
  async 'events: switch, room entry, zone, dialogue, go to room'(pg) {
    const EVS = [
      {
        id: 'e1',
        name: 'Switch opens door',
        trigger: { type: 'flag', flag: 'sw1' },
        actions: [
          { type: 'message', text: 'Click!' },
          { type: 'setflag', flag: 'door_open' },
          { type: 'giveitem', item: 'key1', n: 2 }
        ]
      },
      {
        id: 'e2',
        name: 'Welcome',
        trigger: { type: 'room', room: 't1' },
        actions: [
          { type: 'wait', secs: 0.3 },
          { type: 'event', event: 'e3' }
        ]
      },
      {
        id: 'e3',
        name: 'Helper',
        trigger: { type: 'called' },
        conds: [{ type: 'flagnot', flag: 'nope' }],
        actions: [{ type: 'setflag', flag: 'helper_ran' }]
      },
      {
        id: 'e4',
        name: 'Zone',
        trigger: { type: 'zone', tag: 'z1' },
        once: 'no',
        actions: [{ type: 'setflag', flag: 'zone_hit' }]
      },
      {
        id: 'e5',
        name: 'Needs 5 keys',
        trigger: { type: 'flag', flag: 'zone_hit' },
        conds: [{ type: 'hasitem', item: 'key1', n: 5 }],
        actions: [{ type: 'setflag', flag: 'should_not' }]
      },
      {
        id: 'e7',
        name: 'Talk',
        trigger: { type: 'flag', flag: 'talk_me' },
        actions: [
          { type: 'dialogue', text: 'Hi there\n>Hello', speaker: 'Sage' },
          { type: 'setflag', flag: 'after_dialog' }
        ]
      },
      { id: 'e8', name: 'Go', trigger: { type: 'flag', flag: 'go_now' }, actions: [{ type: 'goroom', room: 't2' }] }
    ];
    const items = [
      { id: 'key1', name: 'Bronze key', desc: '', max: 9, use: 'none', amount: 1, tab: 'items', icon: '' }
    ];
    await start(pg, {
      grid: room(40, 20),
      ents: [{ type: 'evzone', x: 14, y: 17, props: { width: 3, height: 4, tag: 'z1' } }],
      spawn: [3, 18],
      events: EVS,
      items,
      room2: room(30, 16)
    });
    await sleep(pg, 1);
    const F = () => pg.evaluate(() => MV.Game.state().flags);
    let f = await F();
    ok('room entry runs an event that calls another', f.helper_ran === 1 && f['ev:e2'] === 1, f);
    await pg.evaluate(() => {
      MV.Game.state().flags.sw1 = 1;
    });
    await sleep(pg, 0.3);
    f = await F();
    const it = await pg.evaluate(() => MV.Game.state().items);
    ok('a switch flag starts an event that sets a flag and gives items', f.door_open === 1 && it.key1 === 2, { f, it });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 15;
      p.y = 18;
    });
    await sleep(pg, 0.4);
    f = await F();
    ok('walking into an event zone starts its event', f.zone_hit === 1);
    ok('a condition that is not met blocks an event', !f.should_not);
    await pg.evaluate(() => {
      MV.Game.state().flags.talk_me = 1;
    });
    await sleep(pg, 0.3);
    ok('a dialogue step opens the conversation', await pg.evaluate(() => !!MV.Game.dialog()));
    for (let i = 0; i < 6; i++) {
      await tap(pg, 'KeyE', 0.05);
      await sleep(pg, 0.7);
    }
    f = await F();
    ok('the steps after the dialogue run when it ends', f.after_dialog === 1);
    await pg.evaluate(() => {
      MV.Game.state().flags.go_now = 1;
    });
    await sleep(pg, 0.5);
    ok('an event can move the player to another room', (await pg.evaluate(() => MV.Game.room().id)) === 't2');
  },
  async 'audio: player sounds, effects, events and music fire'(pg) {
    await pg.evaluate(() => {
      const A = MV.Audio,
        u = o => __wav(o);
      S.sounds = A.cleanList([
        { id: 'jump1', name: 'J', src: u({ wave: 'square', f0: 280, f1: 700, dur: 0.1 }) },
        { id: 'hit1', name: 'H', src: u({ wave: 'saw', f0: 300, f1: 60, dur: 0.1 }) },
        { id: 'step1', name: 'S', src: u({ wave: 'noise', f0: 150, f1: 100, dur: 0.05 }) },
        { id: 'song', name: 'Song', music: true, src: u({ wave: 'sine', f0: 220, f1: 330, dur: 1 }) }
      ]);
      S.sfx = A.cleanSfx({ jump: 'jump1', step: 'step1', land: 'hit1' });
    });
    const EV = [
      {
        id: 's',
        name: 'Ping',
        trigger: { type: 'flag', flag: 'go' },
        actions: [
          { type: 'sound', sound: 'hit1' },
          { type: 'music', sound: 'song' }
        ]
      }
    ];
    await start(pg, {
      grid: room(40, 20),
      spawn: [3, 18],
      events: EV,
      moves: [
        {
          id: 'dash',
          type: 'dash',
          key: 'Shift',
          speed: 20,
          duration: 0.1,
          effects: [{ on: 'start', do: 'sound', snd: 'hit1', value: 1 }]
        }
      ]
    });
    const LOG = () => pg.evaluate(() => MV.Audio.log.map(l => l.id + ':' + l.what).join(' '));
    await tap(pg, 'Space', 0.1);
    await sleep(pg, 0.9);
    let l = await LOG();
    ok('jump and landing sounds play', /jump1:played/.test(l) && /hit1:played/.test(l), l);
    await dn(pg, 'ArrowRight');
    await sleep(pg, 1);
    await up(pg, 'ArrowRight');
    l = await LOG();
    ok('footsteps play while running', (l.match(/step1/g) || []).length >= 2, l);
    await pg.evaluate(() => {
      MV.Audio.log.length = 0;
    });
    await tap(pg, 'ShiftLeft', 0.05);
    await sleep(pg, 0.3);
    ok('a move effect can play a sound', /hit1:played/.test(await LOG()));
    await pg.evaluate(() => {
      MV.Audio.log.length = 0;
      MV.Game.state().flags.go = 1;
    });
    await sleep(pg, 0.3);
    l = await LOG();
    ok(
      'an event can play a sound and change the music',
      /hit1:played/.test(l) && (await pg.evaluate(() => MV.Audio.music_id())) === 'song',
      l
    );
  },
  async 'energy: costs block moves, regrowth, hits give energy, effects spend and give'(pg) {
    await start(pg, {
      grid: room(40, 20),
      spawn: [3, 18],
      tune: { energyMax: 50, energyRegen: 10, energyDelay: 0.3, energyPerHit: 7 },
      moves: [{ id: 'dash', type: 'dash', key: 'Shift', speed: 20, duration: 0.1, cooldown: 0.2, cost: 30 }],
      atk: [
        {
          id: 'zap',
          label: 'Zap',
          key: 'KeyX',
          duration: 0.2,
          cooldown: 0.1,
          cost: 20,
          hitboxes: [{ name: 'b', w: 1, h: 1, from: 0, to: 0.2, kf: [{ t: 0, x: 1, y: -0.7 }] }]
        }
      ]
    });
    const E = () => pg.evaluate(() => MV.Game.energy());
    ok('energy starts full', (await E()) === 50, await E());
    await tap(pg, 'ShiftLeft', 0.05);
    await sleep(pg, 0.15);
    const e1 = await E();
    ok('a move with a cost spends energy', e1 < 25 && e1 >= 15, e1);
    await sleep(pg, 0.35);
    await tap(pg, 'ShiftLeft', 0.05);
    await sleep(pg, 0.1);
    ok('a move you cannot afford does not start', (await E()) > 10, await E());
    await sleep(pg, 0.1);
    const e2 = await E();
    await sleep(pg, 0.6);
    const e3 = await E();
    ok('energy regrows by itself after a pause', e3 > e2 + 2, [e2, e3]);
    await pg.evaluate(() => MV.Game.energy(10));
    await tap(pg, 'KeyX', 0.05);
    await sleep(pg, 0.1);
    ok('an attack you cannot afford does not swing', (await pg.evaluate(() => MV.Game.player().atk)) === 0);
    await pg.evaluate(() => MV.Game.energy(40));
    await sleep(pg, 0.3);
    await tap(pg, 'KeyX', 0.05);
    await sleep(pg, 0.05);
    ok(
      'an attack with a cost spends energy and swings',
      (await E()) < 25 && (await pg.evaluate(() => MV.Game.player().atk)) > 0,
      await E()
    );
    await start(pg, {
      grid: room(40, 20),
      spawn: [3, 18],
      tune: { energyMax: 30 },
      moves: [{ id: 'dash', type: 'dash', key: 'Shift', cost: 5 }]
    });
    ok('with no regrowth the bar stays', (await E()) === 30 && (await sleep(pg, 0.5), await E()) === 30);
    await start(pg, {
      grid: room(40, 20),
      spawn: [3, 18],
      moves: [{ id: 'dash', type: 'dash', key: 'Shift', cost: 5 }]
    });
    await tap(pg, 'ShiftLeft', 0.05);
    await sleep(pg, 0.2);
    ok('a costed move cannot be used with no energy bar', Math.abs((await P(pg)).x - 3) < 1.5, await P(pg));
  },
  async 'energy: focus heal loop (hold, charge, heal, repeat) and being hurt breaks it'(pg) {
    const FOCUS = {
      id: 'focus',
      label: 'Focus',
      type: 'hold',
      key: 'KeyF',
      on: 'ground',
      windup: 0.5,
      cost: 20,
      recharge: 'yes',
      chargeLock: 'yes',
      effects: [{ on: 'charged', do: 'heal', value: 1 }]
    };
    await start(pg, { grid: room(40, 20), spawn: [3, 18], tune: { energyMax: 60, energyRegen: 0 }, moves: [FOCUS] });
    await pg.evaluate(() => MV.Game.hp(2));
    await dn(pg, 'KeyF');
    await sleep(pg, 0.35);
    const mid = await pg.evaluate(() => ({ hp: MV.Game.hp(), e: MV.Game.energy() }));
    ok('nothing happens before the charge is complete', mid.hp === 2 && mid.e === 60, mid);
    await dn(pg, 'ArrowRight');
    const x0 = (await P(pg)).x;
    await sleep(pg, 0.25);
    const x1 = (await P(pg)).x;
    ok('you are held still while charging', Math.abs(x1 - x0) < 0.3, [x0, x1]);
    await up(pg, 'ArrowRight');
    await sleep(pg, 0.2);
    let r = await pg.evaluate(() => ({ hp: MV.Game.hp(), e: MV.Game.energy() }));
    ok('a complete charge heals and spends the cost', r.hp === 3 && r.e === 40, r);
    await sleep(pg, 1.1);
    r = await pg.evaluate(() => ({ hp: MV.Game.hp(), e: MV.Game.energy() }));
    ok('holding on repeats the loop until the energy is gone', r.hp === 5 && r.e === 0, r);
    await sleep(pg, 0.8);
    r = await pg.evaluate(() => MV.Game.hp());
    ok('no energy: no more healing', r === 5, r);
    await up(pg, 'KeyF');
    await pg.evaluate(() => MV.Game.energy(60));
    await dn(pg, 'KeyF');
    await sleep(pg, 0.3);
    await pg.evaluate(() => MV.Game.hurt && 0);
    await pg.evaluate(() => {
      MV.Game.player().inv = 0;
      MV.Game.hurt(1);
    });
    await sleep(pg, 0.35);
    r = await pg.evaluate(() => ({ hp: MV.Game.hp(), e: MV.Game.energy() }));
    ok('being hurt breaks the charge', r.hp === 4 && r.e === 60, r);
    await up(pg, 'KeyF');
  },
  async 'progression: upgrades, charms, events and saving'(pg) {
    const items = [
      {
        id: 'heart',
        name: 'Heart charm',
        desc: '',
        max: 1,
        use: 'charm',
        amount: 1,
        notches: 2,
        grant: '',
        mods: [
          { key: 'maxHp', add: 2 },
          { key: 'run', add: 2 }
        ],
        tab: 'items',
        icon: null
      },
      {
        id: 'ghost',
        name: 'Ghost charm',
        desc: '',
        max: 1,
        use: 'charm',
        amount: 1,
        notches: 2,
        grant: 'dash',
        mods: [],
        tab: 'items',
        icon: null
      }
    ];
    await start(pg, {
      grid: room(40, 20),
      spawn: [3, 18],
      tune: { maxHp: 5, charmSlots: 3 },
      items,
      ents: [
        { type: 'pickup', x: 5, y: 17, props: { kind: 'upgrade', give: 'maxHp', amount: 2 } },
        { type: 'pickup', x: 7, y: 17, props: { kind: 'upgrade', give: 'charmSlots', amount: 1 } }
      ],
      st: { items: { heart: 1, ghost: 1 } },
      moves: [{ id: 'dash', type: 'dash', key: 'Shift', requires: 'dash', speed: 20, duration: 0.1 }]
    });
    ok('base health', (await pg.evaluate(() => MV.Game.maxHp())) === 5);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 5.3;
      p.y = 18;
    });
    await sleep(pg, 0.3);
    let r = await pg.evaluate(() => ({ m: MV.Game.maxHp(), hp: MV.Game.hp(), s: MV.Game.state().stats }));
    ok('an upgrade pickup raises max health and fills it', r.m === 7 && r.hp === 7 && r.s.maxHp === 2, r);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 7.3;
      p.y = 18;
    });
    await sleep(pg, 0.3);
    ok('an upgrade pickup can give charm notches', (await pg.evaluate(() => MV.Game.state().stats.charmSlots)) === 1);
    const eq = async () => pg.evaluate(() => Object.keys(MV.Game.state().equipped || {}).join(','));
    await tap(pg, 'KeyI', 0.05);
    await sleep(pg, 0.2);
    await tap(pg, 'Enter', 0.05);
    await sleep(pg, 0.1);
    ok('equip a charm in the inventory', (await eq()) === 'heart', await eq());
    await tap(pg, 'ArrowRight', 0.05);
    await tap(pg, 'ArrowDown', 0.05);
    await sleep(pg, 0.1);
    r = await pg.evaluate(() => ({ m: MV.Game.maxHp(), ch: MV.Game.charms() }));
    ok('an equipped charm changes the stats', r.m === 9 && r.ch.used === 2, r);
    await tap(pg, 'KeyI', 0.05);
    await pg.evaluate(() => {
      const st = MV.Game.state();
      st.equipped.ghost = 1;
    });
    await sleep(pg, 0.2);
    ok('a charm can grant an ability while equipped', await pg.evaluate(() => !!MV.Game.charms().grants.dash));
    await pg.evaluate(() => {
      const st = MV.Game.state();
      delete st.equipped.ghost;
      delete st.equipped.heart;
    });
    await sleep(pg, 0.2);
    ok('taking charms off removes the bonus', (await pg.evaluate(() => MV.Game.maxHp())) === 7);
  },
  async 'death rules: respawn health and energy, dropped coins, you died screen'(pg) {
    await start(pg, {
      grid: room(40, 20),
      spawn: [3, 18],
      tune: {
        maxHp: 10,
        energyMax: 40,
        respawnHp: 50,
        respawnEnergy: 25,
        coinsLost: 50,
        coinsRecover: 1,
        deathScreen: 0.8
      }
    });
    await pg.evaluate(() => {
      MV.Game.coins(100);
      const p = MV.Game.player();
      p.x = 20;
      p.y = 18;
      p.inv = 0;
      MV.Game.hurt(99);
    });
    await sleep(pg, 0.4);
    ok('the death screen holds the game', await pg.evaluate(() => MV.Game.dying()));
    await sleep(pg, 1.2);
    let r = await pg.evaluate(() => ({
      hp: MV.Game.hp(),
      e: MV.Game.energy(),
      c: MV.Game.coins(),
      lc: MV.Game.state().lostCoins,
      x: MV.Game.player().x,
      d: MV.Game.dying()
    }));
    ok('you come back with the set health and energy', r.hp === 5 && r.e === 10 && !r.d, r);
    ok(
      'half the coins are dropped where you died',
      r.c === 50 && r.lc && r.lc.n === 50 && Math.abs(r.lc.x - 20) < 1,
      r
    );
    await pg.evaluate(() => {
      const p = MV.Game.player(),
        l = MV.Game.state().lostCoins;
      p.x = l.x;
      p.y = l.y;
    });
    await sleep(pg, 0.3);
    r = await pg.evaluate(() => ({ c: MV.Game.coins(), lc: MV.Game.state().lostCoins }));
    ok('touching the bag gives the coins back', r.c === 100 && !r.lc, r);
  },
  async 'energy: hits fill the bar; events give energy and upgrades'(pg) {
    const EV = [
      {
        id: 'g',
        name: 'Give',
        trigger: { type: 'flag', flag: 'go' },
        conds: [{ type: 'energy', n: 1 }],
        actions: [
          { type: 'energy', n: 15 },
          { type: 'upgrade', stat: 'energyMax', n: 10 }
        ]
      }
    ];
    await start(pg, {
      grid: room(40, 20),
      spawn: [3, 18],
      tune: { energyMax: 40, energyRegen: 0, energyPerHit: 6 },
      ents: [{ type: 'enemy', x: 6, y: 17, props: { hp: 9, speed: 0, range: 0 } }],
      events: EV,
      atk: [
        {
          id: 'slash',
          label: 'Slash',
          key: 'KeyX',
          duration: 0.2,
          cooldown: 0.1,
          hitboxes: [{ name: 'Blade', w: 1.3, h: 1.5, from: 0, to: 0.2, kf: [{ t: 0, x: 1, y: -0.75 }] }]
        }
      ]
    });
    await pg.evaluate(() => {
      MV.Game.energy(10);
      const p = MV.Game.player();
      p.x = 4.8;
      p.y = 18;
      p.face = 1;
    });
    await sleep(pg, 0.1);
    for (let i = 0; i < 3; i++) {
      await tap(pg, 'KeyX', 0.05);
      await sleep(pg, 0.4);
    }
    const e = await pg.evaluate(() => MV.Game.energy());
    ok('hitting an enemy gives energy per hit', e >= 16, e);
    await pg.evaluate(() => {
      MV.Game.energy(5);
      MV.Game.state().flags.go = 1;
    });
    await sleep(pg, 0.4);
    const r = await pg.evaluate(() => ({ e: MV.Game.energy(), m: MV.Game.energyMax() }));
    ok('an event can give energy and raise the maximum', r.m === 50 && r.e >= 30, r);
  },
  async 'editor: templates, costs and charm fields build and edit'(pg) {
    const r = await pg.evaluate(() => {
      const o = {};
      S.moves = [];
      S.player = {};
      S.items = [MV.Inventory.clean1({ id: 'c1', name: 'Charm', use: 'charm', mods: [{ key: 'run', add: 1 }] })];
      II = 0;
      tab('player');
      MI = -1;
      buildMoves();
      const btns = [...document.querySelectorAll('#mvb button')].map(b => b.textContent);
      o.hasTpl =
        btns.includes('Add move: Focus heal (needs energy)') &&
        btns.includes('Feel: Floaty') &&
        btns.includes('Add move: Dash');
      [...document.querySelectorAll('#mvb button')]
        .find(b => b.textContent === 'Add move: Focus heal (needs energy)')
        .click();
      o.moves = S.moves.length;
      const m = S.moves[0];
      o.focus = [m.type, m.cost, m.windup, m.recharge, m.chargeLock, m.effects.length].join();
      MSEC = 'hfx';
      buildMoves();
      o.hfx = !!document.querySelector('#mvb')?.textContent.includes('Effects (1)');
      MI = -1;
      buildMoves();
      [...document.querySelectorAll('#mvb button')].find(b => b.textContent === 'Feel: Floaty').click();
      o.floaty = S.player.gravity;
      [...document.querySelectorAll('#mvb button')].find(b => b.textContent === 'Feel: Back to the engine defaults');
      MI = -1;
      buildMoves();
      [...document.querySelectorAll('#mvb button')]
        .find(b => b.textContent === 'Feel: Back to the engine defaults')
        .click();
      o.reset = Object.keys(S.player).length;
      tab('items');
      buildItems();
      o.charm = !!document.querySelector('#ivb')?.textContent.includes('What the charm changes');
      tab('player');
      buildAtk();
      o.done = 1;
      return o;
    });
    ok(
      'templates are offered, add editable moves and feel presets load and reset',
      r.hasTpl && r.moves === 1 && r.focus === 'hold,33,1.1,yes,yes,1' && r.floaty === 30 && r.reset === 0,
      r
    );
    ok('hold moves get a charge effects section and charm items show their changes', r.hfx && r.charm, r);
  },
  async 'enemies: types walk, chase, fly, hop, shoot, charge and drop things'(pg) {
    const SL = {
      id: 'slash',
      label: 'Slash',
      key: 'KeyX',
      duration: 0.2,
      cooldown: 0.1,
      hitboxes: [{ name: 'Blade', w: 1.4, h: 1.5, from: 0, to: 0.2, kf: [{ t: 0, x: 1, y: -0.75 }] }]
    };
    const T = o => (MV.Enemies ? 0 : 0);
    const mk = o => Object.assign({ move: 'stand still', hp: 2, damage: 2, knock: 5 }, o);
    const EN = [
      mk({ id: 'walker', move: 'patrol', speed: 3, range: 3, edge: 'yes' }),
      mk({ id: 'chaser', move: 'chase', speed: 3, sight: 8, range: 0 }),
      mk({ id: 'bat', move: 'fly', speed: 3, sight: 10 }),
      mk({ id: 'hopper', move: 'hop', speed: 3, sight: 10, hopEvery: 0.4 }),
      mk({
        id: 'turret',
        move: 'stand still',
        attack: 'shoot',
        atkRange: 9,
        atkWind: 0.3,
        atkCool: 1.5,
        atkSpeed: 12,
        atkDmg: 3,
        atkAim: 'forward'
      }),
      mk({
        id: 'rusher',
        move: 'stand still',
        attack: 'charge',
        atkRange: 9,
        atkWind: 0.3,
        atkCool: 3,
        atkSpeed: 14,
        atkDur: 0.5
      }),
      mk({ id: 'loot', move: 'stand still', hp: 2, coins: 7, energy: 9, hurtKnock: 0, flinch: 0 }),
      mk({ id: 'rock', move: 'stand still', hp: 50, damage: 0, hurtKnock: 0 })
    ];
    const ent = (kind, x) => ({ type: 'enemy', x, y: 17, props: { kind } }),
      E = id =>
        pg.evaluate(i => {
          const e = MV.Game.entities().find(q => q.kd === i);
          return e ? { x: e.cx, y: e.by, dead: e.dead, hp: e.hp, as: e.as, vx: e.vx, on: e.on } : null;
        }, id);
    await start(pg, {
      grid: room(60, 20),
      spawn: [3, 18],
      tune: { maxHp: 20, energyMax: 40, energyRegen: 0 },
      enm: EN,
      atk: [SL],
      ents: [
        ent('walker', 30),
        ent('chaser', 20),
        ent('bat', 40),
        ent('hopper', 50),
        ent('turret', 56),
        ent('rusher', 10),
        ent('loot', 6),
        ent('rock', 58)
      ],
      events: [
        {
          id: 'k',
          name: 'Kill',
          trigger: { type: 'enemy', enemy: 'loot' },
          actions: [{ type: 'setflag', flag: 'loot_dead' }]
        }
      ]
    });
    const w0 = (await E('walker')).x;
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 45;
      p.y = 18;
      p.inv = 5;
    });
    await sleep(pg, 1.6);
    const w1 = (await E('walker')).x;
    ok('a walking enemy patrols and stays within its distance', Math.abs(w1 - w0) > 0.5 && Math.abs(w1 - 30.5) <= 3.4, [
      w0,
      w1
    ]);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 22;
      p.y = 18;
      p.inv = 5;
    });
    const c0 = (await E('chaser')).x;
    await sleep(pg, 1.6);
    const c1 = (await E('chaser')).x;
    ok('a chaser walks toward you when it sees you', c1 > c0 + 0.5, [c0, c1]);
    const b0 = await E('bat');
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 36;
      p.y = 18;
      p.inv = 5;
    });
    await sleep(pg, 1);
    const b1 = await E('bat');
    ok('a flyer moves toward you and does not fall', b1.x < b0.x - 1 && b1.y > 0, [b0, b1]);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 46;
      p.y = 18;
      p.inv = 5;
    });
    const h0 = (await E('hopper')).x;
    let ups = 0;
    for (let i = 0; i < 12; i++) {
      await sleep(pg, 0.1);
      if (!(await E('hopper')).on) ups++;
    }
    const h1 = (await E('hopper')).x;
    ok('a hopper jumps toward you', ups >= 2 && h1 < h0 - 0.5, [ups, h0, h1]);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 50;
      p.y = 18;
      p.inv = 0;
      MV.Game.hp(20);
    });
    await sleep(pg, 0.45);
    const t1 = await pg.evaluate(() => MV.Game.enemyShots().length);
    await sleep(pg, 0.5);
    const hpT = await pg.evaluate(() => MV.Game.hp());
    ok('a shooter warns, then fires a shot', t1 >= 1, t1);
    ok('the shot damage is taken from your health', hpT <= 17, hpT);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 5;
      p.y = 18;
      p.inv = 0;
      MV.Game.hp(20);
    });
    await sleep(pg, 0.2);
    const r0 = await E('rusher');
    await sleep(pg, 0.45);
    const r1 = await E('rusher');
    ok('a charger stops and warns, then rushes', r0.as === 'wind' && r1.as === 'dash', [r0.as, r1.as]);
    await sleep(pg, 0.8);
    const hp2 = await pg.evaluate(() => MV.Game.hp());
    ok('a charge that connects hurts for the enemy damage', hp2 <= 18, hp2);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 4.6;
      p.y = 18;
      p.face = 1;
      p.inv = 5;
      MV.Game.energy(0);
      MV.Game.coins(0);
    });
    await sleep(pg, 0.1);
    for (let i = 0; i < 3; i++) {
      await tap(pg, 'KeyX', 0.05);
      await sleep(pg, 0.35);
    }
    const l = await E('loot');
    const st = await pg.evaluate(() => ({
      c: MV.Game.coins(),
      e: MV.Game.energy(),
      f: MV.Game.state().flags.loot_dead
    }));
    ok(
      'your attacks kill it, it drops coins and energy and an event runs',
      l.dead && st.c === 7 && st.e === 9 && st.f === 1,
      { l, st }
    );
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 56.6;
      p.y = 18;
      p.face = 1;
      p.inv = 5;
    });
    await sleep(pg, 0.1);
    ok('a harmless heavy enemy takes hits and stays', (await E('rock')).hp <= 50);
  },
  async 'enemies: a brain notices, chases and attacks by pattern, goes home; a hazard stays'(pg) {
    const SL = {
      id: 'slash',
      label: 'Slash',
      key: 'KeyX',
      duration: 0.2,
      cooldown: 0.1,
      hitboxes: [{ name: 'Blade', w: 1.4, h: 1.5, from: 0, to: 0.2, kf: [{ t: 0, x: 1, y: -0.75 }] }]
    };
    const EN = [
      {
        id: 'guard',
        ai: 'brain',
        move: 'patrol',
        speed: 3,
        range: 2,
        sight: 8,
        pattern: 'charge, shoot',
        meleeRange: 5,
        atkRange: 9,
        atkWind: 0.3,
        atkCool: 0.8,
        atkSpeed: 12,
        atkDur: 0.4,
        atkAim: 'forward',
        alertTime: 0.3,
        loseTime: 1,
        leash: 14,
        hp: 5,
        damage: 1
      },
      { id: 'loopy', ai: 'loop', move: 'patrol', speed: 2, range: 2, sight: 8, attack: 'none', damage: 1 },
      { id: 'spike', ai: 'hazard', immune: 'yes', move: 'patrol', attack: 'shoot', damage: 2, hp: 3 }
    ];
    const ent = (kind, x) => ({ type: 'enemy', x, y: 17, props: { kind } }),
      E = id =>
        pg.evaluate(i => {
          const e = MV.Game.entities().find(q => q.kd === i);
          return e ? { x: e.cx, ox: e.ox, st: e.st, as: e.as, cur: e.cur, hp: e.hp, vx: e.vx } : null;
        }, id);
    await start(pg, {
      grid: room(70, 20),
      spawn: [3, 18],
      tune: { maxHp: 30, energyMax: 0, energyRegen: 0 },
      enm: EN,
      atk: [SL],
      ents: [ent('guard', 40), ent('loopy', 60), ent('spike', 20)]
    });
    const types = await pg.evaluate(
      en =>
        MV.Enemies.resolve(en)
          .map(d => [d.id, d.ai, d.move, d.attack, d.pattern].join(':'))
          .join('|'),
      EN
    );
    ok('the hazard type is made static and attackless', /spike:hazard:stand still:none:/.test(types), types);
    await sleep(pg, 0.8);
    ok('far from you the brain just patrols', ['idle', undefined].includes((await E('guard')).st));
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 34;
      p.y = 18;
      p.inv = 99;
      MV.Game.hp(30);
    });
    const seen = [],
      sts = new Set();
    for (let i = 0; i < 50; i++) {
      await sleep(pg, 0.1);
      const g = await E('guard');
      sts.add(g.st);
      if (g.as === 'wind' && g.cur && seen[seen.length - 1] !== g.cur) seen.push(g.cur);
    }
    ok('it notices you (alert), then chases', sts.has('alert') && sts.has('chase'), [...sts]);
    ok('it uses its pattern: charge first, then shoot', seen[0] === 'charge' && seen.includes('shoot'), seen);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 3;
      p.y = 18;
    });
    await sleep(pg, 9);
    const g2 = await E('guard');
    ok('after losing you it walks home and rests', g2.st === 'idle' && Math.abs(g2.x - g2.ox) < 3.2, g2);
    const l0 = await E('loopy');
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 56;
      p.y = 18;
      p.inv = 99;
    });
    await sleep(pg, 1);
    const l1 = await E('loopy');
    ok(
      'a loop enemy never gets a brain: it stays within its patrol',
      l1.st === undefined && Math.abs(l1.x - l1.ox) <= 2.6,
      l1
    );
    const s0 = await E('spike');
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 20.4;
      p.y = 18;
      p.inv = 0;
      MV.Game.hp(30);
    });
    await sleep(pg, 0.6);
    const s1 = await E('spike'),
      hpS = await pg.evaluate(() => MV.Game.hp());
    ok('a hazard stays where it is and hurts when touched', Math.abs(s1.x - s0.x) < 0.05 && hpS < 30, [
      s0.x,
      s1.x,
      hpS
    ]);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 18.6;
      p.y = 18;
      p.face = -1;
      p.inv = 99;
    });
    for (let i = 0; i < 3; i++) {
      await tap(pg, 'KeyX', 0.05);
      await sleep(pg, 0.35);
    }
    ok('a hazard that cannot be hurt takes no damage', (await E('spike')).hp === 3, await E('spike'));
  },
  async 'enemies: Play runs the strike timeline and strike hitboxes can be dragged in the picture'(pg) {
    await pg.goto(APP);
    await pg.waitForTimeout(800);
    await pg.evaluate(() => {
      document.getElementById('splash') && document.getElementById('splash').remove();
      document.getElementById('app').hidden = false;
      S.enemies = [];
      tab('enemies');
      [...document.querySelectorAll('#eng button')].find(b => b.textContent === 'New enemy type').click();
      window.confirm = () => true;
      const t = [...document.querySelectorAll('#eng select')].find(q => [...q.options].some(o => o.value === 'brute'));
      t.value = 'brute';
      t.dispatchEvent(new Event('change', { bubbles: true }));
    });
    const rng = () => pg.evaluate(() => +[...document.querySelectorAll('#eng input[type=range]')][0].value);
    const before = await rng();
    await pg.evaluate(() => [...document.querySelectorAll('#eng button')].find(b => /^(Play|Pause)$/.test(b.textContent)).click());
    await pg.waitForTimeout(700);
    const mid = await pg.evaluate(() => {
      const l = [...document.querySelectorAll('#eng span.hint')].find(x => /^\d+\.\d\d s$/.test(x.textContent));
      return l ? l.textContent : null;
    });
    const btn = await pg.evaluate(() => [...document.querySelectorAll('#eng button')].some(b => b.textContent === 'Pause'));
    ok('Play starts and the button turns into Pause', btn, btn);
    await pg.evaluate(() => [...document.querySelectorAll('#eng button')].find(b => b.textContent === 'Pause').click());
    const after = await rng();
    ok('the timeline moves while playing', after !== before, before + ' -> ' + after + ' ' + mid);
    const moved = await pg.evaluate(() => {
      const d = S.enemies[0],
        cv = document.querySelector('#eng canvas'),
        h = d.strike[0],
        r = cv.getBoundingClientRect(),
        Z = 36,
        cx = cv.width / 2,
        mid = cv.height - 40 - (d.h * Z) / 2,
        k = h.kf[0],
        px = cx + k.x * Z,
        py = mid + k.y * Z,
        ev = (t, x, y) =>
          cv.dispatchEvent(
            new PointerEvent(t, {
              clientX: r.left + (x / cv.width) * r.width,
              clientY: r.top + (y / cv.height) * r.height,
              pointerId: 1,
              bubbles: true
            })
          );
      const x0 = k.x;
      cv.setPointerCapture = () => {};
      ev('pointerdown', px, py);
      ev('pointermove', px + Z * 1.5, py);
      ev('pointerup', px + Z * 1.5, py);
      return [x0, S.enemies[0].strike[0].kf[0].x];
    });
    ok('dragging a strike hitbox in the picture moves it', moved[1] !== moved[0], moved);
  },
  async 'level editor: the Enemies sub-tab places enemy types and hazards'(pg) {
    await pg.goto(APP);
    await pg.waitForTimeout(800);
    const o = await pg.evaluate(() => {
      document.getElementById('splash') && document.getElementById('splash').remove();
      document.getElementById('app').hidden = false;
      S.enemies = [{ id: 'crab', name: 'Crab' }];
      rc = {
        id: 'r1',
        n: 'R',
        gw: 20,
        gh: 12,
        grid: Array.from({ length: 12 }, () => '.'.repeat(20)),
        art: [],
        ent: [],
        tr: [],
        table: []
      };
      S.areas = [{ id: 'a1', n: 'A', s: '', c: '#378add', x: 0, y: 0, w: 50, h: 50, rooms: [rc], links: [] }];
      cur = S.areas[0];
      openRoom(rc);
      $('enmt').click();
      const chips = [...document.querySelectorAll('#enmg .echip')].map(b => b.textContent);
      [...document.querySelectorAll('#enmg .echip')].find(b => b.textContent === 'Crab').click();
      const cv = $('cv'),
        r = cv.getBoundingClientRect(),
        ev = (t, x, y) =>
          cv.dispatchEvent(new PointerEvent(t, { clientX: x, clientY: y, pointerId: 1, bubbles: true, button: 0, buttons: 1 }));
      ev('pointerdown', r.left + r.width * 0.3, r.top + r.height * 0.5);
      ev('pointerup', r.left + r.width * 0.3, r.top + r.height * 0.5);
      [...document.querySelectorAll('#enmg .echip')].find(b => /Hazard/.test(b.textContent)).click();
      ev('pointerdown', r.left + r.width * 0.6, r.top + r.height * 0.5);
      ev('pointerup', r.left + r.width * 0.6, r.top + r.height * 0.5);
      return { chips, ent: rc.ent.map(e => e.type + ':' + (e.props.kind || '')) };
    });
    ok('the Enemies sub-tab lists simple enemy, types and hazard', o.chips.length === 3, o.chips);
    ok('clicking the room places the picked enemy type and a hazard', o.ent.join() === 'enemy:crab,hazard:', o.ent);
  },
  async 'showcase: the Tidebound example opens in the editor with nothing lost and no world problems'(pg) {
    const text = require('fs').readFileSync(require('path').join(__dirname, '..', 'examples', 'tidebound.json'), 'utf8');
    await pg.goto(APP);
    await pg.waitForTimeout(800);
    const o = await pg.evaluate(t => {
      document.getElementById('splash') && document.getElementById('splash').remove();
      window.confirm = () => true;
      const r = {};
      r.opened = projectFromJson(t, 'tidebound.json', null);
      r.areas = S.areas.length;
      r.rooms = S.areas.reduce((n, a) => n + a.rooms.length, 0);
      r.moves = S.moves.map(m => m.id).join();
      r.enemies = S.enemies.map(e => e.id).join();
      r.bosses = S.bosses.length;
      r.events = S.events.length;
      r.fx = S.areas[0].rooms[0].tr.map(q => q.fx || '').join() + '|' + S.areas[1].rooms[0].tr.map(q => (q.mode || '') + (q.fx || '')).join();
      r.ride = S.areas[2].rooms[0].tr.some(q => q.ride === 2.5);
      r.errors = MW.validate(S).filter(i => i.sev === 'error').map(i => i.msg || i.text);
      return r;
    }, text);
    ok('the example opens', o.opened === true && o.areas === 3 && o.rooms === 4, o);
    ok('it keeps its moves, enemies, boss and events', o.moves === 'dash,doublejump' && o.enemies === 'crab,eel,puffer,urchin' && o.bosses === 1 && o.events === 4, o);
    ok('it keeps its doorway effects, press doors and ride', /iris/.test(o.fx) && /pressfade/.test(o.fx) && o.ride, o.fx);
    ok('the world check finds no errors', o.errors.length === 0, o.errors);
  },
  async 'enemies: the Brain group and its templates in the tab'(pg) {
    await pg.goto(APP);
    await pg.waitForTimeout(800);
    const o = await pg.evaluate(async () => {
      document.getElementById('splash') && document.getElementById('splash').remove();
      S = MV.Project ? S : S;
      S.enemies = [];
      tab('enemies');
      [...document.querySelectorAll('#eng button')].find(b => b.textContent === 'New enemy type').click();
      const r = {};
      const heads = () => [...document.querySelectorAll('#eng h3')].map(h => h.textContent);
      r.loopHeads = heads().join(',');
      const sel = () =>
        [...document.querySelectorAll('#eng select')].find(q => [...q.options].some(o => o.value === 'archer'));
      r.hasTemplates = !!sel();
      window.confirm = () => true;
      const t = sel();
      t.value = 'archer';
      t.dispatchEvent(new Event('change', { bubbles: true }));
      const d = S.enemies[0];
      r.archer = [d.ai, d.move, d.pattern, d.keepAway, d.atkRange].join('/');
      r.labels = [...document.querySelectorAll('#eng label > span')].map(x => x.textContent).join('|');
      const t2 = sel();
      t2.value = 'hazard';
      t2.dispatchEvent(new Event('change', { bubbles: true }));
      const h = S.enemies[0];
      r.hazard = [h.ai, h.move, h.attack, h.immune].join('/');
      r.hazHeads = heads().join(',');
      const t3 = sel();
      t3.value = 'brute';
      t3.dispatchEvent(new Event('change', { bubbles: true }));
      r.brute = S.enemies[0].pattern + '/' + S.enemies[0].strike.length;
      r.strikeCard = heads().includes('Strike hitboxes');
      return r;
    });
    ok('a new type has a Brain group with templates', /Brain/.test(o.loopHeads) && o.hasTemplates, o);
    ok(
      'the Archer template sets a brain that shoots and keeps away',
      o.archer === 'brain/stand still/shoot/4/9',
      o.archer
    );
    ok(
      'a brain shows its own settings (pattern, notice time, leash)',
      /Attack pattern/.test(o.labels) && /Notice time/.test(o.labels) && /Leash/.test(o.labels),
      o.labels
    );
    ok(
      'the Hazard template is static, attackless and cannot be hurt',
      o.hazard === 'hazard/stand still/none/yes',
      o.hazard
    );
    ok(
      'a hazard hides the Movement and Attack groups',
      !/Movement/.test(o.hazHeads) && !/Attack/.test(o.hazHeads),
      o.hazHeads
    );
    ok(
      'the Brute template has a pattern and a strike hitbox to edit',
      o.brute === 'strike, strike, charge/1' && o.strikeCard,
      o
    );
  },
  async 'tiles: pictures with auto-tiling, border, stamps and room templates'(pg) {
    await pg.click('#ncr');
    await sleep(pg, 1);
    const r = await pg.evaluate(async () => {
      const o = {};
      const c = document.createElement('canvas');
      c.width = 64;
      c.height = 64;
      const x = c.getContext('2d');
      for (let i = 0; i < 16; i++) {
        x.fillStyle = 'rgb(' + (i * 16 + 8) + ',100,50)';
        x.fillRect((i % 4) * 16, Math.floor(i / 4) * 16, 16, 16);
      }
      S.sheets = [{ id: 't1', name: 'tiles.png', url: c.toDataURL('image/png'), tw: 16, th: 16 }];
      S.tileSkins = MV.Tiles.cleanSkins({
        '#': { sheet: 't1', mode: 'auto16', col: 0, row: 0, join: 'same' },
        '=': { sheet: 'zz' }
      });
      o.skinKeys = Object.keys(S.tileSkins).join('');
      rc = {
        id: 'r1',
        n: 'R',
        gw: 20,
        gh: 12,
        grid: Array.from({ length: 12 }, () => '.'.repeat(20)),
        art: [],
        ent: [],
        tr: [],
        table: []
      };
      for (const y of [4, 5]) rc.grid[y] = rc.grid[y].slice(0, 6) + '##' + rc.grid[y].slice(8);
      S.areas = [{ id: 'a1', n: 'A', s: '', c: '#378add', x: 0, y: 0, w: 50, h: 50, rooms: [rc], links: [] }];
      cur = S.areas[0];
      openRoom(rc);
      await new Promise(r => {
        const im = sheetOf('t1').img;
        if (im.complete && im.naturalWidth) r();
        else im.onload = r;
      });
      drawT();
      const cw = parseFloat($('cvs').style.width) / rc.gw,
        px = (tx, ty) => {
          const d = ctx.getImageData(
            Math.round(tx * cw + cw / 2 - VO.x),
            Math.round(ty * cw + cw / 2 - VO.y),
            1,
            1
          ).data;
          return Math.round((d[0] - 8) / 16);
        };
      o.cells = [px(6, 4), px(7, 4), px(6, 5), px(7, 5)].join(',');
      o.dbg = [
        cw,
        VO.x,
        VO.y,
        ctx.canvas.width,
        ctx.canvas.height,
        [...ctx.getImageData(Math.round(6 * cw + cw / 2 - VO.x), Math.round(4 * cw + cw / 2 - VO.y), 1, 1).data].join(
          '/'
        )
      ].join(' ');
      const bg = ctx.getImageData(Math.round(1 * cw + cw / 2 - VO.x), Math.round(1 * cw + cw / 2 - VO.y), 1, 1).data;
      o.emptyIsPlain = bg[0] !== 8 + 16 * 6;
      // the panels exist
      o.panel = !!document.getElementById('tart') && /Tile pictures/.test(document.getElementById('tart').textContent);
      // fill the border
      tool = '#';
      document.getElementById('tart').querySelector('input[type=number]').value = 2;
      [...document.querySelectorAll('#tart button')].find(b => b.textContent === 'Fill the room border').click();
      o.border = [
        rc.grid[0],
        rc.grid[1],
        rc.grid[2].slice(0, 3),
        rc.grid[11],
        rc.grid[6].slice(0, 3),
        rc.grid[6].slice(-3)
      ].join('|').length;
      o.borderOk =
        rc.grid[0] === '#'.repeat(20) &&
        rc.grid[1] === '#'.repeat(20) &&
        rc.grid[6].startsWith('##.') &&
        rc.grid[6].endsWith('.##') &&
        rc.grid[11] === '#'.repeat(20);
      // stamp: select a block, save, list, delete
      SEL = { x0: 6, y0: 4, x1: 7, y1: 5 };
      const nm = document.querySelector('#tart input[type=text]');
      nm.value = 'Block';
      [...document.querySelectorAll('#tart button')]
        .find(b => b.textContent === 'Save the selection as a stamp')
        .click();
      o.stamp = S.stamps.map(s => s.name + ':' + s.w + 'x' + s.h + ':' + s.rows.join('/')).join();
      o.stampBack = des(snap().core).stamps.length + ':' + Object.keys(des(snap().core).tileSkins).join('');
      [...document.querySelectorAll('#tart button')].find(b => b.textContent === 'Place').click();
      o.pasting = typeof PASTE !== 'undefined' && PASTE === true && CLIP.w === 2;
      PASTE = false;
      // templates
      const tsel = document.querySelector('#tart select');
      window.confirm = () => true;
      const out = {};
      for (const k of ['boss', 'save', 'shop', 'corridor', 'shaft', 'water', 'pit']) {
        const sel = [...document.querySelectorAll('#tart select')].find(q => [...q.options].some(op => op.value === k));
        sel.value = k;
        [...document.querySelectorAll('#tart button')].find(b => b.textContent === 'Apply to this room').click();
        out[k] =
          rc.grid.length +
          'x' +
          rc.grid[0].length +
          ':' +
          rc.ent.map(e => e.type).join('+') +
          ':' +
          rc.grid.every(rw => rw.length === rc.gw && /^[#.=~gD]*$/.test(rw));
      }
      o.templates = out;
      return o;
    });
    ok(
      'a skin for an unknown sheet is kept only if its tile is valid; a bad one is cleaned',
      r.skinKeys === '#=',
      r.skinKeys
    );
    ok('auto-tile picks the cell by neighbours (2x2 block: 6, 12, 3, 9)', r.cells === '6,12,3,9', [r.cells, r.dbg]);
    ok('tiles without a picture still draw plainly', r.emptyIsPlain);
    ok('the Quick room tools and Tile pictures panels are in the room settings', r.panel);
    ok('Fill the room border draws a wall of the chosen thickness', r.borderOk, r.border);
    ok(
      'a selection saves as a stamp, is stored in the project and can be placed',
      /^Block:2x2:/.test(r.stamp) && r.stampBack === '1:#=' && r.pasting,
      [r.stamp, r.stampBack, r.pasting]
    );
    const T = r.templates || {};
    ok(
      'every room template builds a valid room',
      ['boss', 'save', 'shop', 'corridor', 'shaft', 'water', 'pit'].every(k => /:true$/.test(T[k] || '')),
      T
    );
    ok(
      'the save room has a rest point, the shop a character, the pit spikes',
      /checkpointkey/.test(T.save) && /npc/.test(T.shop) && /hazard/.test(T.pit) && /current/.test(T.water),
      T
    );
  },
  async 'map: the full-screen map opens with M, pauses the world and closes again'(pg) {
    await start(pg, {
      grid: room(30, 14),
      spawn: [3, 12],
      ents: [
        { type: 'checkpointkey', x: 8, y: 11, props: {} },
        { type: 'pickup', x: 12, y: 11, props: { kind: 'item', give: 'coin' } }
      ]
    });
    const px = () => pg.evaluate(() => MV.Game.player().x);
    await sleep(pg, 0.3);
    await tap(pg, 'KeyM', 0.05);
    await sleep(pg, 0.2);
    const open = await pg.evaluate(() => MV.Game.mapOpen());
    const px0 = await px();
    await pg.keyboard.down('KeyD');
    await sleep(pg, 0.5);
    await pg.keyboard.up('KeyD');
    const px1 = await px();
    const pix = await pg.evaluate(() => {
      const c = document.getElementById('mtc'),
        d = c.getContext('2d').getImageData(4, 4, 1, 1).data;
      return [d[0], d[1], d[2]].join(',');
    });
    ok('M opens the map and the world stands still', open && Math.abs(px1 - px0) < 0.01, [open, px0, px1]);
    ok('the map is drawn over the game in the map colour', pix === '10,22,32', pix);
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.2);
    ok(
      'Esc closes the map (and does not open the pause menu)',
      !(await pg.evaluate(() => MV.Game.mapOpen() || MV.Game.pauseOpen()))
    );
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.2);
    const list = await pg.evaluate(() => MV.Game.pauseOpen());
    ok('the pause menu opens with Esc and has a Map button', list);
  },
  async 'status: poison, burn and slow, damage types, weak/resist/immune, inflicting and resting'(pg) {
    const SL = (id, ty, inf) => ({
      id,
      label: id,
      key: id === 'fire' ? 'KeyZ' : 'KeyX',
      duration: 0.2,
      cooldown: 0.1,
      dtype: ty,
      inflict: inf || 'none',
      inflictTime: 3,
      hitboxes: [{ name: 'Blade', w: 1.4, h: 1.5, from: 0, to: 0.2, kf: [{ t: 0, x: 1, y: -0.75 }] }]
    });
    const EN = [
      { id: 'weak', move: 'stand still', hp: 8, weakTo: 'fire', attack: 'none', damage: 0, touch: 'no' },
      { id: 'tough', move: 'stand still', hp: 8, resistTo: 'fire', attack: 'none', damage: 0, touch: 'no' },
      { id: 'immune', move: 'stand still', hp: 8, immuneTo: 'fire', attack: 'none', damage: 0, touch: 'no' },
      { id: 'plain', move: 'stand still', hp: 8, attack: 'none', damage: 0, touch: 'no' },
      {
        id: 'spitter',
        move: 'stand still',
        hp: 8,
        attack: 'none',
        damage: 1,
        inflict: 'burn',
        inflictTime: 2,
        touch: 'yes'
      }
    ];
    const ent = (kind, x) => ({ type: 'enemy', x, y: 17, props: { kind } }),
      E = id =>
        pg.evaluate(i => {
          const e = MV.Game.entities().find(q => q.kd === i);
          return e ? { hp: e.hp, sts: e.sts ? Object.keys(e.sts).join() : '', dead: !!e.dead } : null;
        }, id);
    await start(pg, {
      grid: room(70, 20),
      spawn: [3, 18],
      tune: { maxHp: 20, energyMax: 0, energyRegen: 0, invTime: 0.1 },
      enm: EN,
      atk: [SL('slash', 'physical'), SL('fire', 'fire', 'poison')],
      ents: [
        ent('weak', 10),
        ent('tough', 20),
        ent('immune', 30),
        ent('plain', 40),
        ent('spitter', 52),
        { type: 'hazard', x: 60, y: 17.5, props: { width: 2, height: 1, inflict: 'slow', inflictTime: 2 } }
      ]
    });
    // the player: poison hurts over time, then ends; burn is faster
    await pg.evaluate(() => {
      MV.Game.hp(20);
      MV.Game.addStatus('poison', 3);
    });
    const tag = await pg.evaluate(() =>
      MV.Game.status()
        .map(s => s.id + ':' + Math.ceil(s.t))
        .join()
    );
    ok('a poisoned player carries the status', tag === 'poison:3', tag);
    await sleep(pg, 3.6);
    const hp1 = await pg.evaluate(() => [MV.Game.hp(), MV.Game.status().length]);
    ok('poison took one health every second, then wore off', hp1[0] === 17 && hp1[1] === 0, hp1);
    await pg.evaluate(() => {
      MV.Game.hp(20);
      MV.Game.addStatus('burn', 1.3);
    });
    await sleep(pg, 1.6);
    ok(
      'burn ticks faster (every 0.6 s)',
      (await pg.evaluate(() => MV.Game.hp())) === 18,
      await pg.evaluate(() => MV.Game.hp())
    );
    // slow halves the run speed, and ending it restores it
    const run0 = await pg.evaluate(() => MV.Game.tune().run);
    await pg.evaluate(() => MV.Game.addStatus('slow', 1));
    await sleep(pg, 0.2);
    const run1 = await pg.evaluate(() => MV.Game.tune().run);
    await sleep(pg, 1.2);
    const run2 = await pg.evaluate(() => MV.Game.tune().run);
    ok('slow halves the run speed and then ends', Math.abs(run1 - run0 / 2) < 0.01 && Math.abs(run2 - run0) < 0.01, [
      run0,
      run1,
      run2
    ]);
    // damage types against the fighters
    const strike = async (x, key) => {
      await pg.evaluate(x2 => {
        const p = MV.Game.player();
        p.x = x2 - 1.2;
        p.y = 18;
        p.face = 1;
        p.inv = 99;
      }, x);
      await tap(pg, key, 0.05);
      await sleep(pg, 0.5);
    };
    await strike(10.4, 'KeyX');
    const wPhys = (await E('weak')).hp;
    await strike(10.4, 'KeyZ');
    const wFire = (await E('weak')).hp;
    ok('physical does 1, fire does double to a fire-weak enemy', wPhys === 7 && wFire === 5, [wPhys, wFire]);
    await strike(20.4, 'KeyZ');
    ok('a fire resistant enemy takes half', (await E('tough')).hp === 7.5, await E('tough'));
    await strike(30.4, 'KeyZ');
    ok(
      'an immune enemy takes nothing and is not poisoned',
      (await E('immune')).hp === 8 && (await E('immune')).sts === '',
      await E('immune')
    );
    await strike(40.4, 'KeyZ');
    const pl = await E('plain');
    ok('an attack that inflicts poison poisons the enemy', pl.hp === 7 && /poison/.test(pl.sts), pl);
    await sleep(pg, 2.4);
    ok('the poison keeps hurting the enemy over time', (await E('plain')).hp <= 5, await E('plain'));
    // enemies and hazards inflict on the player
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 52.3;
      p.y = 18;
      p.inv = 0;
      MV.Game.hp(20);
    });
    await sleep(pg, 0.5);
    const st1 = await pg.evaluate(() =>
      MV.Game.status()
        .map(s => s.id)
        .join()
    );
    ok('an enemy that inflicts burn sets you on fire when it hurts you', /burn/.test(st1), st1);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 60.5;
      p.y = 18;
      p.inv = 0;
    });
    await sleep(pg, 0.5);
    const st2 = await pg.evaluate(() =>
      MV.Game.status()
        .map(s => s.id)
        .join()
    );
    ok('a hazard can inflict slow', /slow/.test(st2), st2);
    // the last health point is safe when poison cannot kill
    await start(pg, { grid: room(30, 14), spawn: [3, 12], tune: { maxHp: 5, statusKills: 0 } });
    await pg.evaluate(() => {
      MV.Game.hp(2);
      MV.Game.addStatus('poison', 6);
    });
    await sleep(pg, 4);
    ok(
      'with Poison can kill you off it stops at 1 health',
      (await pg.evaluate(() => MV.Game.hp())) === 1,
      await pg.evaluate(() => MV.Game.hp())
    );
    const cfg = await pg.evaluate(() => [
      Object.keys(MV.Tuning.schema())
        .filter(k => MV.Tuning.schema()[k].group === 'Status effects')
        .join(),
      MV.Boss.list([{ id: 'b1', weakTo: 'ice', inflict: 'poison', dtype: 'nope' }])[0].weakTo +
        '/' +
        MV.Boss.list([{ id: 'b1', inflict: 'poison' }])[0].inflict +
        '/' +
        MV.Boss.list([{ id: 'b1', dtype: 'nope' }])[0].dtype
    ]);
    ok(
      'the settings, and the boss fields, are known and cleaned',
      /poisonTick/.test(cfg[0]) && cfg[1] === 'ice/poison/physical',
      cfg
    );
  },
  async 'transitions: press-to-enter doors, screen effects and rides'(pg) {
    const g = room(40, 20);
    put(g, 10, 17, 'D');
    put(g, 20, 17, 'D');
    put(g, 30, 17, 'D');
    await pg.evaluate(() => {
      window.__tr = [
        { x: 10, y: 17, a: 'a1', r: 't2', mode: 'press', fx: 'slide', fxTime: 0.4 },
        { x: 20, y: 17, a: 'a1', r: 't2', fx: 'dissolve', fxTime: 0.4 },
        { x: 30, y: 17, a: 'a1', r: 't2', mode: 'press', ride: 1.5, fx: 'iris', fxTime: 0.4 }
      ];
    });
    const sb = () => start(pg, { grid: g, spawn: [3, 18], room2: room(20, 12) });
    const at = x =>
      pg.evaluate(x2 => {
        const p = MV.Game.player();
        p.x = x2;
        p.y = 18;
        p.vx = 0;
        p.inD = false;
      }, x);
    const rid = () => pg.evaluate(() => MV.Game.room().id);
    await sb();
    await at(10.5);
    await sleep(pg, 1.2);
    ok('a press door does not open by walking in', (await rid()) === 't1', await rid());
    await dn(pg, 'ArrowUp');
    await sleep(pg, 0.2);
    const mid = await pg.evaluate(() => !!MV.Game.player());
    await sleep(pg, 1.2);
    await up(pg, 'ArrowUp');
    ok('pressing Up opens it and goes through', (await rid()) === 't2' && mid, await rid());
    await sb();
    await at(20.5);
    await sleep(pg, 0.1);
    const tr1 = await pg.evaluate(() => !!(MV.Game.room() && MV.Game.camera && true));
    await sleep(pg, 1.2);
    ok('a walk-in doorway with a dissolve effect still changes room', (await rid()) === 't2' && tr1, await rid());
    await sb();
    await at(30.5);
    await sleep(pg, 0.15);
    await dn(pg, 'ArrowUp');
    await sleep(pg, 1.0);
    const still = await rid();
    for (let i = 0; i < 24 && (await rid()) === 't1'; i++) await sleep(pg, 0.5);
    await up(pg, 'ArrowUp');
    ok('a ride keeps you in the room for its time, then arrives', still === 't1' && (await rid()) === 't2', still + ' ' + (await rid()));
    await pg.evaluate(() => (window.__tr = null));
  },
  async 'world: key doors use up the key, levers toggle or stay on, rest points cure and refill, shops sell'(pg) {
    const items = [
      { id: 'key1', name: 'Brass key', use: 'none' },
      { id: 'pearl', name: 'Pearl', use: 'none' }
    ];
    await start(pg, {
      grid: room(60, 20),
      spawn: [3, 18],
      tune: { maxHp: 10, energyMax: 0, energyRegen: 0 },
      items,
      st: { items: { key1: 2 } },
      atk: [
        {
          id: 'slash',
          label: 'Slash',
          key: 'KeyX',
          duration: 0.2,
          cooldown: 0.1,
          hitboxes: [{ name: 'Blade', w: 1.4, h: 1.5, from: 0, to: 0.2, kf: [{ t: 0, x: 1, y: -0.75 }] }]
        }
      ],
      enm: [{ id: 'crab', move: 'stand still', hp: 3, attack: 'none', damage: 0, touch: 'no' }],
      ents: [
        { type: 'door', x: 8, y: 16, props: { requires: 'key1', consume: 'yes' } },
        { type: 'door', x: 14, y: 16, props: { requires: 'pearl', needMsg: 'The door wants a pearl.' } },
        { type: 'switch', x: 20, y: 17, props: { flag: 'lev', mode: 'turn on once' } },
        { type: 'switch', x: 24, y: 17, props: { flag: 'tog' } },
        { type: 'checkpointkey', x: 30, y: 17, props: { rest: 'yes', key: 'E' } },
        { type: 'enemy', x: 34, y: 17, props: { kind: 'crab' } },
        {
          type: 'npc',
          x: 42,
          y: 17,
          props: { name: 'Shopkeeper', dialogue: '', shop: 'pearl: 5\nkey1: 3', key: 'E' }
        }
      ]
    });
    const at = x =>
      pg.evaluate(x2 => {
        const p = MV.Game.player();
        p.x = x2;
        p.y = 18;
        p.inv = 99;
      }, x);
    const bag = () => pg.evaluate(() => JSON.stringify(MV.Game.state().items || {}));
    await at(8.2);
    await sleep(pg, 0.4);
    ok('a key door opens with the key and takes it', (await bag()) === '{"key1":1}', await bag());
    await at(14.2);
    await sleep(pg, 0.3);
    const m1 = await pg.evaluate(() =>
      MV.Game.messages()
        .map(m => m.t)
        .join('|')
    );
    ok('a locked door tells you what it needs', /The door wants a pearl/.test(m1), m1);
    const fl = () => pg.evaluate(() => JSON.stringify(MV.Game.state().flags || {}));
    const hit = async x => {
      await at(x - 1.1);
      await pg.evaluate(() => (MV.Game.player().face = 1));
      await tap(pg, 'KeyX', 0.05);
      await sleep(pg, 0.6);
    };
    await hit(20.3);
    await hit(20.3);
    const f1 = await fl();
    ok('a "turn on once" lever stays on when hit again', /"lev":1/.test(f1), f1);
    await hit(24.3);
    const f2 = await fl();
    await hit(24.3);
    const f3 = await fl();
    ok('a toggle lever flips on, then off', /"tog":1/.test(f2) && !/"tog"/.test(f3), [f2, f3]);
    ok(
      'doors, switches and rest points exist as entities',
      (await pg.evaluate(
        () => MV.Game.entities().filter(e => ['door', 'switch', 'checkpoint', 'checkpointkey'].includes(e.type)).length
      )) >= 5
    );
    // rest point: heals, cures status, brings back a dead enemy
    await pg.evaluate(() => {
      MV.Game.hp(3);
      MV.Game.addStatus('poison', 20);
      const e = MV.Game.entities().find(q => q.kd === 'crab');
      e.dead = true;
    });
    await at(30.2);
    await tap(pg, 'KeyE', 0.1);
    await sleep(pg, 0.4);
    const rest = await pg.evaluate(() => [
      MV.Game.status().length,
      !!MV.Game.entities().find(q => q.kd === 'crab' && !q.dead)
    ]);
    ok('resting cures status effects and brings the room enemies back', rest[0] === 0 && rest[1] === true, rest);
    // shop
    await pg.evaluate(() => MV.Game.coins(7));
    await at(42.3);
    await sleep(pg, 0.2);
    await tap(pg, 'KeyE', 0.1);
    await sleep(pg, 0.3);
    const op1 = await pg.evaluate(() => MV.Game.shopOpen());
    ok('talking to a character with a Shop opens the shop', op1 === true);
    await tap(pg, 'Enter', 0.1);
    await sleep(pg, 0.2);
    const sh1 = await pg.evaluate(() => [MV.Game.coins(), JSON.stringify(MV.Game.state().items || {})]);
    ok('buying takes the price and gives the item', sh1[0] === 2 && /"pearl":1/.test(sh1[1]), sh1);
    await tap(pg, 'Enter', 0.1);
    await sleep(pg, 0.2);
    ok('not enough coins buys nothing', (await pg.evaluate(() => MV.Game.coins())) === 2);
    await tap(pg, 'Escape', 0.1);
    await sleep(pg, 0.2);
    ok('Esc leaves the shop', (await pg.evaluate(() => MV.Game.shopOpen())) === false);
  },
  async 'enemies: the tab builds, edits and renames a type'(pg) {
    const r = await pg.evaluate(() => {
      const o = {};
      S.enemies = [];
      tab('enemies');
      const nb = [...document.querySelectorAll('#eng button')].find(b => b.textContent === 'New enemy type');
      nb.click();
      o.n = S.enemies.length;
      const d = S.enemies[0];
      d.move = 'chase';
      d.attack = 'shoot';
      enUI();
      o.fields = document.querySelectorAll('#eng .enr label').length;
      const room = okRoom({
        id: 'r1',
        n: 'R',
        x: 0,
        y: 0,
        w: 30,
        h: 20,
        gw: 30,
        gh: 20,
        grid: Array.from({ length: 20 }, () => '.'.repeat(30)),
        ent: [{ id: 'e1', type: 'enemy', x: 3, y: 3, props: { kind: d.id } }],
        tr: []
      });
      S.areas = [{ id: 'a1', n: 'A', s: '', c: '#378add', x: 0, y: 0, w: 50, h: 50, rooms: [room], links: [] }];
      enUI();
      const ii = [...document.querySelectorAll('#eng input[type=text]')][0];
      ii.value = 'ghoul';
      ii.onchange();
      o.id = S.enemies[0].id;
      o.ent = room.ent[0].props.kind;
      const back = des(snap().core);
      o.saved = back.enemies.length + ':' + back.enemies[0].move;
      return o;
    });
    ok(
      'a new type is made, its form shows the fields for what it does, renaming updates rooms, and it is saved',
      r.n === 1 && r.fields > 10 && r.id === 'ghoul' && r.ent === 'ghoul' && r.saved === '1:chase',
      r
    );
  },
  async 'enemies: weak spots, strike hitboxes and touch'(pg) {
    const SL = {
      id: 'slash',
      label: 'Slash',
      key: 'KeyX',
      duration: 0.2,
      cooldown: 0.1,
      hitboxes: [{ name: 'Blade', w: 1.4, h: 1.5, from: 0, to: 0.2, kf: [{ t: 0, x: 1, y: -0.75 }] }]
    };
    const mk = o =>
      Object.assign({ move: 'stand still', hp: 30, damage: 2, knock: 0, hurtKnock: 0, flinch: 0, invul: 0.1 }, o);
    const EN = [
      mk({ id: 'plain' }),
      mk({ id: 'weak', h: 2, weak: [{ name: 'Belly', x: 0, y: 0.6, w: 0.6, h: 0.4, mult: 3 }] }),
      mk({ id: 'armor', h: 2, weakOnly: 'yes', weak: [{ name: 'Head', x: 0, y: -0.9, w: 0.6, h: 0.3, mult: 3 }] }),
      mk({
        id: 'slam',
        attack: 'strike',
        atkRange: 6,
        atkWind: 0.3,
        atkDur: 0.6,
        atkCool: 5,
        touch: 'no',
        strike: [{ name: 'Slam', w: 1.5, h: 0.6, from: 0.1, to: 0.5, dmg: 4, kf: [{ t: 0, x: 1.2, y: 0.3 }] }]
      }),
      mk({ id: 'ghost', touch: 'no', damage: 5 })
    ];
    const ent = (kind, x) => ({ type: 'enemy', x, y: 17, props: { kind } }),
      E = id =>
        pg.evaluate(i => {
          const e = MV.Game.entities().find(q => q.kd === i);
          return e ? { hp: e.hp, as: e.as, dead: e.dead } : null;
        }, id);
    await start(pg, {
      grid: room(60, 20),
      spawn: [3, 18],
      tune: { maxHp: 20 },
      enm: EN,
      atk: [SL],
      ents: [ent('plain', 10), ent('weak', 14), ent('armor', 18), ent('slam', 30), ent('ghost', 40)]
    });
    const hitAt = async x => {
      await pg.evaluate(x2 => {
        const p = MV.Game.player();
        p.x = x2;
        p.y = 18;
        p.face = 1;
        p.inv = 9;
        p.vx = 0;
      }, x - 1.0);
      await sleep(pg, 0.1);
      await tap(pg, 'KeyX', 0.05);
      await sleep(pg, 0.4);
    };
    await hitAt(10.5);
    await hitAt(14.5);
    await hitAt(18.5);
    const a = await E('plain'),
      b = await E('weak'),
      c = await E('armor'),
      la = 30 - a.hp,
      lb = 30 - b.hp;
    ok(
      'a hit on a weak spot does its damage multiplier, a hit elsewhere does the normal damage',
      la > 0 && lb === 3 * la,
      [a.hp, b.hp]
    );
    ok('an armoured enemy ignores hits outside its weak spots', c.hp === 30, c);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 31.7;
      p.y = 18;
      p.inv = 0;
      p.vx = 0;
      MV.Game.hp(20);
    });
    await sleep(pg, 0.15);
    const s0 = await E('slam');
    const h0 = await pg.evaluate(() => MV.Game.hp());
    await sleep(pg, 0.35);
    const s1 = await E('slam');
    const h1 = await pg.evaluate(() => MV.Game.hp());
    await sleep(pg, 0.5);
    const h2 = await pg.evaluate(() => MV.Game.hp());
    ok(
      'a striker warns first without hurting you, then its hitbox hurts for its own damage',
      s0.as === 'wind' && h0 === 20 && s1.as === 'strike' && h2 === 16,
      [s0.as, h0, s1.as, h1, h2]
    );
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 40.5;
      p.y = 18;
      p.inv = 0;
      p.vx = 0;
      MV.Game.hp(20);
    });
    await sleep(pg, 1);
    const g = await pg.evaluate(() => MV.Game.hp());
    ok('an enemy that does not hurt by touching lets you stand inside it', g === 20, g);
  },
  async 'enemies: the tab edits shape, weak spots and strike hitboxes'(pg) {
    const r = await pg.evaluate(() => {
      const o = {};
      S.enemies = [];
      tab('enemies');
      [...document.querySelectorAll('#eng button')].find(b => b.textContent === 'New enemy type').click();
      const d = S.enemies[0];
      d.shape = 'polygon';
      d.attack = 'strike';
      Object.assign(d, MV.Enemies.clean1(d));
      enUI();
      const click = t => [...document.querySelectorAll('#eng button')].find(b => b.textContent === t).click();
      click('Add weak spot');
      click('Add hitbox');
      click('Add corner');
      const q = S.enemies[0];
      o.pts = q.pts.length;
      o.weak = q.weak.length;
      o.strike = q.strike.length;
      o.cards = [...document.querySelectorAll('#eng h3')].map(h => h.textContent).join('|');
      const back = des(snap().core).enemies[0];
      o.saved = back.strike.length + ':' + back.weak.length + ':' + back.shape;
      return o;
    });
    ok(
      'the tab shows polygon corners, weak spots and strike hitboxes, adds them and saves them',
      r.pts === 6 &&
        r.weak === 1 &&
        r.strike === 1 &&
        /Polygon corners/.test(r.cards) &&
        /Weak spots/.test(r.cards) &&
        /Strike hitboxes/.test(r.cards) &&
        r.saved === '1:1:polygon',
      r
    );
  },
  async 'bosses: warning, hitbox damage, phase change, restart and the editor'(pg) {
    const SL = {
      id: 'slash',
      label: 'Slash',
      key: 'KeyX',
      duration: 0.2,
      cooldown: 0.1,
      hitboxes: [{ name: 'Blade', w: 1.4, h: 1.5, from: 0, to: 0.2, kf: [{ t: 0, x: 1, y: -0.75 }] }]
    };
    await pg.evaluate(() => {
      S.bosses = MV.Boss.list([
        {
          id: 'bb',
          name: 'Big',
          hp: 10,
          w: 2,
          h: 3,
          wake: 8,
          touch: 'no',
          invul: 0.2,
          wakeTime: 0.3,
          patterns: [
            {
              id: 'sl',
              name: 'Slam',
              warn: 0.5,
              duration: 1,
              hitboxes: [{ name: 'Fist', w: 2, h: 1, dmg: 3, from: 0.1, to: 0.8, kf: [{ t: 0, x: 2.5, y: -0.5 }] }]
            }
          ],
          phases: [
            { below: 100, idle: 0.3, speed: 1, patterns: ['sl'] },
            { below: 50, idle: 0.3, speed: 1, enter: 0.8, patterns: ['sl'] }
          ]
        }
      ]);
    });
    await start(pg, {
      grid: room(60, 20),
      spawn: [3, 18],
      tune: { maxHp: 20 },
      atk: [SL],
      ents: [{ type: 'boss', x: 30, y: 17, props: { boss: 'bb' } }]
    });
    const B = () =>
      pg.evaluate(() => {
        const e = MV.Game.entities().find(q => q.type === 'boss');
        return { hp: e.hp, st: e.b.state, t: e.b.t, awake: e.b.awake, dead: e.dead };
      });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 28;
      p.y = 18;
      p.face = 1;
      p.inv = 0;
      MV.Game.hp(20);
    });
    let warn = false,
      hpWarn = true,
      dropAt = null;
    for (let i = 0; i < 70; i++) {
      await sleep(pg, 0.05);
      const q = await pg.evaluate(() => {
          const e = MV.Game.entities().find(z => z.type === 'boss');
          return { b: { st: e.b.state, t: e.b.t }, hp: MV.Game.hp() };
        }),
        b = q.b,
        hp = q.hp;
      if (b.st === 'attack' && b.t < 0 && dropAt === null) {
        warn = true;
        if (hp < 20) hpWarn = false;
      }
      if (hp < 20 && dropAt === null) dropAt = { b, hp };
    }
    ok(
      'a boss wakes, warns before an attack without hurting, then the hitbox hurts for its own damage',
      warn && hpWarn && dropAt && dropAt.b.st === 'attack' && dropAt.b.t >= 0.09 && dropAt.hp === 17,
      { warn, hpWarn, dropAt }
    );
    await pg.evaluate(() => {
      const e = MV.Game.entities().find(q => q.type === 'boss');
      e.hp = 4;
      e.inv = 0;
    });
    let ph = false;
    for (let i = 0; i < 20 && !ph; i++) {
      await sleep(pg, 0.05);
      ph = (await B()).st === 'phase';
    }
    const hpIn = (await B()).hp;
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 28.8;
      p.y = 18;
      p.face = 1;
      p.inv = 9;
    });
    await tap(pg, 'KeyX', 0.05);
    await sleep(pg, 0.3);
    const hpAfter = (await B()).hp;
    ok('crossing a phase threshold starts a phase change in which the boss cannot be hurt', ph && hpAfter === hpIn, {
      ph,
      hpIn,
      hpAfter
    });
    await sleep(pg, 1);
    await pg.evaluate(() => {
      MV.Game.player().inv = 0;
      MV.Game.hurt(99);
    });
    await sleep(pg, 1.5);
    const rb = await B();
    ok(
      'when you die an undefeated boss starts over: full health and asleep',
      rb.hp === 10 && rb.st === 'passive' && !rb.awake,
      rb
    );
    const r = await pg.evaluate(() => {
      const o = {};
      tab('boss');
      const b = S.bosses[0];
      BI = 0;
      BSUB = 'patterns';
      HI = 0;
      PI = 0;
      b.shape = 'polygon';
      S.bosses[0] = MV.Boss.clean(b);
      bossUI();
      const click = t => [...document.querySelectorAll('#bform button')].find(x => x.textContent === t).click();
      click('Add weak spot');
      o.weak = S.bosses[0].weak.length;
      o.polys = S.bosses[0].pts.length;
      o.labels = [...document.querySelectorAll('#bform label,#bpc label')].map(l => l.textContent).join('|');
      const back = des(snap().core).bosses[0];
      o.saved =
        back.patterns[0].warn + ':' + back.patterns[0].hitboxes[0].dmg + ':' + back.shape + ':' + back.phases[1].enter;
      return o;
    });
    ok(
      'the boss editor shows warning, damage, phase change and weak spots and saves them',
      r.weak === 1 &&
        r.polys >= 3 &&
        /Warning before it starts/.test(r.labels) &&
        /Phase change time/.test(r.labels) &&
        /Damage \(hits\)/.test(r.labels) &&
        /Sound: defeated/.test(r.labels) &&
        r.saved === '0.5:3:polygon:0.8',
      r
    );
  },
  async 'report: walls need damage, erase works with shapes, player size, no sound maker'(pg) {
    await start(pg, {
      grid: room(40, 20),
      spawn: [3, 18],
      moves: [{ id: 'dash', type: 'dash', key: 'ShiftLeft', speed: 12, duration: 0.3 }],
      ents: [{ type: 'breakable', x: 8, y: 16, props: { width: 1, height: 2, hp: 3 } }]
    });
    const W = () =>
      pg.evaluate(() => {
        const e = MV.Game.entities().find(q => q.type === 'breakable');
        return { hp: e.hp, dead: e.dead };
      });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 5;
      p.y = 18;
      p.face = 1;
      p.inv = 9;
    });
    await tap(pg, 'ShiftLeft', 0.05);
    await sleep(pg, 0.7);
    const w = await W();
    ok('a move with no attack box and no damage does not hurt a breakable wall', w.hp === 3 && !w.dead, w);
    const r = await pg.evaluate(() => {
      const o = {};
      rc = {
        gw: 20,
        gh: 10,
        grid: Array.from({ length: 10 }, () => '.'.repeat(20)),
        art: [],
        ent: [],
        tr: [],
        table: []
      };
      [
        [1, 1],
        [2, 2],
        [5, 5],
        [9, 9]
      ].forEach(q => rc.art.push({ x: q[0], y: q[1], s: 's', c: 0, r: 0, w: 1, h: 1 }));
      tool = 'X';
      MIR = false;
      SH = null;
      applyCells(shapeCells({ x: 0, y: 0 }, { x: 3, y: 3 }, 'rect'));
      o.left = rc.art.length;
      o.size = !!MV.data.playerSchema.w && !!MV.data.playerSchema.h;
      tab('audio');
      o.maker = /Sound maker/.test(document.getElementById('aug').textContent);
      return o;
    });
    ok(
      'Erase removes sprites in a whole rectangle, the player has width and height settings, and the sound maker is gone',
      r.left === 2 && r.size && !r.maker,
      r
    );
  },
  async 'report: moving platforms carry the player and never let them sink'(pg) {
    const mkp = (x, y, dx, dy, sp) => ({ type: 'platform', x, y, props: { dx, dy, speed: sp } });
    await start(pg, {
      grid: room(60, 24),
      spawn: [3, 22],
      ents: [mkp(10, 20, 0, -8, 3), mkp(20, 12, 0, 8, 5), mkp(30, 20, 10, 0, 4), mkp(45, 20, 0, -10, 12)]
    });
    const probe = async (i, x, secs) => {
      const out = { sunk: 0, off: 0, n: 0, maxGap: 0, log: [] };
      await pg.evaluate(
        ([i2, x2]) => {
          const pl = MV.Game.entities().filter(q => q.type === 'platform')[i2];
          const p = MV.Game.player();
          p.x = pl.cx + (x2 || 0);
          p.y = pl.by - pl.h;
          p.vx = p.vy = 0;
          p.inv = 9;
          p.on = true;
          p.plat = pl;
        },
        [i, x]
      );
      for (let k = 0; k < secs * 20; k++) {
        await sleep(pg, 0.05);
        const r = await pg.evaluate(i2 => {
          const pl = MV.Game.entities().filter(q => q.type === 'platform')[i2],
            p = MV.Game.player();
          return { gap: p.y - (pl.by - pl.h), on: p.on, vy: p.vy, pdy: pl.pdy, py: pl.by };
        }, i);
        if (!r.on && out.log.length < 8)
          out.log.push([k, +r.gap.toFixed(2), +r.vy.toFixed(1), +r.pdy.toFixed(2), +r.py.toFixed(1)]);
        out.n++;
        if (r.gap > 0.35) out.sunk++;
        if (!r.on) out.off++;
        out.maxGap = Math.max(out.maxGap, r.gap);
      }
      return out;
    };
    const up = await probe(0, 0, 4),
      down = await probe(1, 0, 4),
      side = await probe(2, 0, 4),
      fast = await probe(3, 0, 1.5);
    ok('a platform moving up carries the player', up.sunk === 0 && up.off < 3, up);
    ok('a platform moving down carries the player', down.sunk === 0 && down.off < 3, down);
    ok('a platform moving sideways carries the player', side.sunk === 0 && side.off < 3, side);
    ok('a fast platform does not drop the player', fast.sunk === 0 && fast.off < 3, fast);
  },
  async 'report: a solid moving platform blocks the sides and the head'(pg) {
    const mk = (x, y, solid) => ({ type: 'platform', x, y, props: { dx: 0, dy: 0, speed: 0, solid } });
    await start(pg, {
      grid: room(60, 20),
      spawn: [3, 18],
      ents: [mk(9, 17, 'yes'), mk(30, 17, 'no'), mk(45, 14, 'yes'), mk(52, 14, 'no')]
    });
    const run = async (x0, x1) => {
      await pg.evaluate(a => {
        const p = MV.Game.player();
        p.x = a;
        p.y = 18;
        p.vx = 0;
        p.vy = 0;
        p.inv = 9;
      }, x0);
      await dn(pg, 'ArrowRight');
      await sleep(pg, 1.2);
      await up(pg, 'ArrowRight');
      return (await P(pg)).x;
    };
    const xs = await run(5, 0),
      xn = await run(26, 0);
    ok('a solid platform stops you walking through its side, a normal one does not', xs < 8.8 && xn > 33, [xs, xn]);
    const jump = async x0 => {
      await pg.evaluate(a => {
        const p = MV.Game.player();
        p.x = a;
        p.y = 18;
        p.vx = 0;
        p.vy = 0;
        p.inv = 9;
      }, x0);
      await sleep(pg, 0.2);
      let mn = 99;
      await dn(pg, 'Space');
      for (let i = 0; i < 14; i++) {
        await sleep(pg, 0.05);
        mn = Math.min(mn, (await P(pg)).y);
      }
      await up(pg, 'Space');
      return mn;
    };
    const ys = await jump(45.5),
      yn = await jump(52.5);
    ok(
      'a solid platform stops your head when you jump into it from below, a normal one lets you through',
      ys >= 16.45 && yn < 16.2,
      [ys, yn]
    );
  },
  async 'camera rig: zoom, rotation, fades, free camera, overrides and the player API'(pg) {
    const g = room(120, 60, 3);
    for (let x = 40; x < 80; x++) put(g, x, 31, '#');
    await start(pg, { grid: g, spawn: [60, 31] });
    await sleep(pg, 1);
    const px = () =>
      pg.evaluate(() => {
        const c = document.getElementById('mtc'),
          d = c.getContext('2d').getImageData(c.width / 2 - 20, c.height / 2 - 20, 40, 40).data;
        let s = 0;
        for (let i = 0; i < d.length; i += 4) s += d[i] + d[i + 1] + d[i + 2];
        return s;
      });
    ok(
      'the camera is the rig and exposes the API',
      await pg.evaluate(
        () =>
          typeof MV.Game.camera.zoomTo === 'function' &&
          MV.Game.camera.rig() instanceof MV.CameraRig &&
          MV.Game.camera.status().mode === 'follow'
      ),
      await pg.evaluate(() => MV.Game.camera.status())
    );
    const v0 = await pg.evaluate(() => MV.Game.camera.rig().view().vw);
    await pg.evaluate(() => MV.Game.camera.zoomTo(1.6, { time: 0.2 }));
    await sleep(pg, 1.2);
    const v1 = await pg.evaluate(() => MV.Game.camera.rig().view().vw);
    ok('zooming in shows fewer tiles', v1 < v0 * 0.7, [v0, v1]);
    await pg.evaluate(() => {
      MV.Game.camera.rotateTo(12, { time: 0.2 });
    });
    await sleep(pg, 1.5);
    ok(
      'rotation tilts the view and the game keeps drawing',
      await pg.evaluate(() => Math.abs(MV.Game.camera.status().rotation) > 8)
    );
    await pg.evaluate(() => {
      MV.Game.camera.rotateTo(0, { time: 0.2 });
      MV.Game.camera.zoomReset(0.2);
    });
    await sleep(pg, 1.5);
    ok(
      'zoom and rotation return to normal',
      await pg.evaluate(() => {
        const s = MV.Game.camera.status();
        return Math.abs(s.zoom - 1) < 0.02 && Math.abs(s.rotation) < 0.3;
      })
    );
    const base = await px();
    await pg.evaluate(() => MV.Game.camera.fade('#000', 1, 0.1));
    await sleep(pg, 0.6);
    const dark = await px();
    ok('a fade to black covers the picture', dark < base * 0.2 || dark === 0, [base, dark]);
    await pg.evaluate(() => MV.Game.camera.fadeIn(0.1));
    await sleep(pg, 0.5);
    await pg.evaluate(() => MV.Game.camera.free(true, { speed: 12 }));
    await sleep(pg, 0.3);
    const p0 = await P(pg);
    await dn(pg, 'ArrowRight');
    await sleep(pg, 0.8);
    await up(pg, 'ArrowRight');
    const p1 = await P(pg),
      c1 = await pg.evaluate(() => MV.Game.camera.rig().cx);
    ok('the free camera moves the view, not the player', Math.abs(p1.x - p0.x) < 0.3 && c1 > p0.x + 3, [
      p0.x,
      p1.x,
      c1
    ]);
    await pg.evaluate(() => MV.Game.camera.free(false));
    await sleep(pg, 0.3);
    await dn(pg, 'ArrowRight');
    await sleep(pg, 0.5);
    await up(pg, 'ArrowRight');
    const p2 = await P(pg);
    ok('leaving the free camera gives the player their controls back', p2.x > p1.x + 0.5, [p1.x, p2.x]);
    await pg.evaluate(() => {
      MV.Game.camera.override({ id: 't', priority: 5, zoom: 1.5, lockInput: true, blend: 0.1 });
    });
    await sleep(pg, 0.6);
    const p3 = await P(pg);
    await dn(pg, 'ArrowRight');
    await sleep(pg, 0.5);
    await up(pg, 'ArrowRight');
    const p4 = await P(pg);
    ok('an override can lock the controls', Math.abs(p4.x - p3.x) < 0.3, [p3.x, p4.x]);
    await pg.evaluate(() => MV.Game.camera.endOverride('t', 0.1));
    await sleep(pg, 1);
    ok(
      'ending it restores the controls and the zoom',
      await pg.evaluate(
        () => MV.Game.camera.overrides().length === 0 && Math.abs(MV.Game.camera.status().zoom - 1) < 0.03
      )
    );
    await pg.evaluate(() => {
      MV.Game.camera.shake({ amount: 0.4, time: 0.3 });
      MV.Game.camera.recoil(1, 0, 1);
      MV.Game.camera.flash('#fff', 0.1);
    });
    await sleep(pg, 0.8);
    ok(
      'shake, recoil and flash finish by themselves',
      await pg.evaluate(() => {
        const r = MV.Game.camera.rig();
        return r.shakes.length === 0 && Math.abs(r.rec.x) < 0.01;
      })
    );
    ok(
      'isometric is reported as unsupported, not faked',
      await pg.evaluate(() => MV.Game.camera.mode('isometric') === false)
    );
    await pg.evaluate(() => MV.Game.camera.settings({ reduceMotion: true }));
    await pg.evaluate(() => MV.Game.camera.shake({ amount: 1, time: 1, roll: 10 }));
    await sleep(pg, 0.3);
    ok(
      'reduce motion removes tilt and cuts shake to a quarter',
      await pg.evaluate(() => {
        const r = MV.Game.camera.rig();
        return r.shr === 0 && Math.abs(r.shx) <= 0.15 && Math.abs(r.shy) <= 0.15;
      })
    );
    await pg.evaluate(() => MV.Game.camera.resetSettings());
  },
  async 'boss AI: it walks, stays inside a walled arena and picks attacks by distance'(pg) {
    const g = room(60, 20);
    for (let y = 0; y < 18; y++) {
      put(g, 36, y, '#');
      put(g, 24, y, '#');
    }
    await pg.evaluate(() => {
      S.bosses = MV.Boss.list([
        {
          id: 'bb',
          name: 'Big',
          hp: 10,
          w: 2,
          h: 3,
          wake: 30,
          touch: 'no',
          select: 'rules',
          speed: 4,
          keep: 2,
          fly: 'no',
          patterns: [
            {
              id: 'dash',
              name: 'Dash',
              duration: 1,
              warn: 0.2,
              reach: 'to player',
              max: 50,
              body: [
                { t: 0, x: 0, y: 0 },
                { t: 1, x: 40, y: 0 }
              ],
              hitboxes: []
            }
          ],
          phases: [{ below: 100, idle: 0.3, patterns: [] }]
        }
      ]);
    });
    await start(pg, { grid: g, spawn: [30, 18], ents: [{ type: 'boss', x: 30, y: 17, props: { boss: 'bb' } }] });
    await sleep(pg, 0.5);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 40;
      p.y = 18;
    });
    await sleep(pg, 5);
    const b = await pg.evaluate(() => {
      const e = MV.Game.entities().find(q => q.type === 'boss');
      return { x: e.cx, y: e.by, st: e.b.state };
    });
    ok(
      'a boss cannot leave its walled arena (between x 25 and 36)',
      b.x >= 25 - 1e-6 && b.x <= 35.05 && b.y <= 18 + 1e-6,
      b
    );
  },
  async 'boss AI: patterns mirror toward the player on either side'(pg) {
    await pg.evaluate(() => {
      S.bosses = MV.Boss.list([
        {
          id: 'bb',
          name: 'Big',
          hp: 10,
          w: 2,
          h: 3,
          wake: 40,
          touch: 'no',
          patterns: [
            {
              id: 'dash',
              name: 'Dash',
              duration: 1,
              warn: 0.2,
              body: [
                { t: 0, x: 0, y: 0 },
                { t: 1, x: 8, y: 0 }
              ],
              hitboxes: []
            }
          ],
          phases: [{ below: 100, idle: 0.3, patterns: [] }]
        }
      ]);
    });
    await start(pg, {
      grid: room(60, 20),
      spawn: [10, 18],
      ents: [{ type: 'boss', x: 40, y: 17, props: { boss: 'bb' } }]
    });
    await sleep(pg, 0.5);
    const xs = [];
    for (let i = 0; i < 6; i++) {
      await sleep(pg, 0.5);
      xs.push(
        await pg.evaluate(() => {
          const e = MV.Game.entities().find(q => q.type === 'boss');
          return +e.cx.toFixed(1);
        })
      );
    }
    ok('with the player on the left the boss moves left', Math.min(...xs) < 36, xs);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 55;
      p.y = 18;
    });
    await sleep(pg, 3);
    const e2 = await pg.evaluate(() => {
      const e = MV.Game.entities().find(q => q.type === 'boss');
      return { x: e.cx, f: e.b.face, st: e.b.state };
    });
    ok('with the player on the right it faces and moves right', e2.f === 1, e2);
  },
  async 'camera events: zoom, tilt, fade and look-at actions drive the rig'(pg) {
    const EVS = [
      {
        id: 'cz',
        name: 'Zoom',
        trigger: { type: 'flag', flag: 'go' },
        actions: [
          { type: 'camzoom', zoom: 1.5, secs: 0.2, hold: 0 },
          { type: 'camtilt', deg: 8, secs: 0.2 },
          { type: 'camfade', to: 'to black', secs: 0.2 },
          { type: 'camfocus', x: 30, y: 20, secs: 3, zoom: 1, lock: 'stay on' }
        ]
      }
    ];
    await start(pg, { grid: room(120, 60, 3), spawn: [60, 31], events: EVS });
    await sleep(pg, 0.8);
    await pg.evaluate(() => {
      MV.Game.state().flags.go = 1;
    });
    await sleep(pg, 1.2);
    const r = await pg.evaluate(() => {
      const s = MV.Game.camera.status();
      return { z: s.zoom, rot: s.rotation, fade: s.fade, ov: s.overrides.map(o => o.id) };
    });
    ok('the event actions reach the camera', r.z > 1.2 && r.rot > 3 && r.fade > 0.5 && r.ov.includes('event-focus'), r);
  },
  async 'report: camera screen position, grounded mode and zone defaults'(pg) {
    const g = room(120, 60, 3);
    for (let x = 40; x < 80; x++) put(g, x, 31, '#');
    await start(pg, { grid: g, tune: { camPosY: 25 }, spawn: [60, 31] });
    await sleep(pg, 1.5);
    const a = await CAM(pg),
      p = await P(pg),
      want = p.y - 0.75 - 7 - 3.5;
    ok('the player stands below the middle of the screen when you ask for it', Math.abs(a.cy - want) < 0.35, {
      cy: a.cy,
      want
    });
    await start(pg, { grid: g, tune: { camPosX: 20, camLookAhead: 0, camPosY: 0 }, spawn: [60, 31] });
    await sleep(pg, 1.5);
    const b = await CAM(pg),
      p2 = await P(pg);
    ok('and to the side', Math.abs(b.cx - (p2.x - 12.5 - 5)) < 0.35, { cx: b.cx, want: p2.x - 17.5 });
    await start(pg, {
      grid: g,
      profiles: [{ id: 'k', name: 'K', p: { modeY: 'grounded', groundBand: 4 } }],
      cam: { profile: 'k' },
      spawn: [60, 31]
    });
    await sleep(pg, 1.5);
    const y0 = (await CAM(pg)).cy;
    let lo = 99,
      hi = -99;
    await dn(pg, 'Space');
    for (let i = 0; i < 12; i++) {
      await sleep(pg, 0.05);
      const c = (await CAM(pg)).cy;
      lo = Math.min(lo, c);
      hi = Math.max(hi, c);
    }
    await up(pg, 'Space');
    await sleep(pg, 1.2);
    ok('a grounded camera stays put while you jump a little', hi - lo < 0.2, { lo, hi, y0 });
    const z = { type: 'camzone', x: 10, y: 20, props: {} };
    await start(pg, { grid: g, ents: [z], spawn: [11, 31] });
    const dflt = await pg.evaluate(() => MV.data.entities.camzone.props.bounds.d);
    ok(
      'a new camera zone limits the view to its box by default, so it visibly does something',
      dflt === 'limit view to this box',
      dflt
    );
  },
  async 'transitions: ceiling doorways drop you, floor doorways hop you up, wide doorways keep your place'(pg) {
    const wire = (tiles1, tiles2) =>
      pg.evaluate(
        ([a, b]) => {
          const r1 = MV.Game.room(),
            r2 = MV.Game.area().rooms[1];
          r1.tr = a.map(q => ({ x: q[0], y: q[1], a: 'a1', r: 't2' }));
          r2.tr = b.map(q => ({ x: q[0], y: q[1], a: 'a1', r: 't1' }));
        },
        [tiles1, tiles2]
      );
    const grids = door2 => {
      const g1 = room(40, 20),
        g2 = room(40, 20),
        t1 = [],
        t2 = [];
      for (let y = 8; y < 14; y++) {
        put(g1, 39, y, 'D');
        t1.push([39, y]);
      }
      door2(g2, t2);
      return [g1, g2, t1, t2];
    };
    // 1. a doorway in the ceiling
    let [g1, g2, t1, t2] = grids((g, t) => {
      for (let x = 10; x < 14; x++) {
        put(g, x, 0, 'D');
        t.push([x, 0]);
      }
    });
    await start(pg, { grid: g1, spawn: [3, 18], room2: g2 });
    await wire(t1, t2);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 39.5;
      p.y = 8.95;
      p.vy = 0;
      p.inD = false;
    });
    await sleep(pg, 0.2);
    const a0 = await pg.evaluate(() => ({ room: MV.Game.room().id, y: MV.Game.player().y, x: MV.Game.player().x }));
    await sleep(pg, 0.4);
    const a1 = await pg.evaluate(() => ({ y: MV.Game.player().y, x: MV.Game.player().x }));
    ok(
      'arriving through a doorway in the ceiling: you fall out of it and keep your place along it',
      a0.room === 't2' && a0.y <= 2.5 && a1.y > a0.y + 0.5 && Math.abs(a1.x - a0.x) < 0.3 && a0.x < 11.5,
      [a0, a1]
    );
    // 2. a hole in the floor
    [g1, g2, t1, t2] = grids((g, t) => {
      for (let x = 20; x < 22; x++)
        for (let y = 18; y < 20; y++) {
          put(g, x, y, 'D');
          t.push([x, y]);
        }
    });
    await start(pg, { grid: g1, spawn: [3, 18], room2: g2 });
    await wire(t1, t2);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 39.5;
      p.y = 13.9;
      p.vy = 0;
      p.inD = false;
    });
    await sleep(pg, 0.15);
    let rose = false,
      minY = 99;
    for (let i = 0; i < 20; i++) {
      const q = await pg.evaluate(() => ({ y: MV.Game.player().y, vy: MV.Game.player().vy }));
      minY = Math.min(minY, q.y);
      if (q.vy < -2) rose = true;
      await sleep(pg, 0.05);
    }
    await sleep(pg, 1);
    const b = await pg.evaluate(() => ({
      room: MV.Game.room().id,
      y: MV.Game.player().y,
      x: MV.Game.player().x,
      on: MV.Game.player().on
    }));
    ok(
      'arriving through a hole in the floor: you hop up and land on the nearest ledge beside it',
      rose && b.room === 't2' && b.on && b.y <= 18.05 && (b.x < 20 || b.x > 22),
      [rose, minY, b]
    );
  },
  async 'moves: same-key order and combo specificity'(pg) {
    const mkMv = o => Object.assign({ cooldown: 0.1 }, o);
    const dj = pr =>
        mkMv({
          id: 'dj',
          label: 'Double jump',
          type: 'impulse',
          key: 'Jump',
          where: 'air',
          dir: 'up',
          speed: 16,
          uses: 1,
          priority: pr
        }),
      gl = pr =>
        mkMv({
          id: 'gl',
          label: 'Glide',
          type: 'hold',
          key: 'Jump',
          on: 'air',
          where: 'air',
          speed: 2,
          gravity: 1,
          priority: pr
        });
    const run = async mvs => {
      await start(pg, { grid: room(30, 80), spawn: [5, 3], moves: mvs });
      await pg.evaluate(() => {
        const p = MV.Game.player();
        p.x = 5;
        p.y = 30;
        p.vy = 0;
        p.on = false;
      });
      await dn(pg, 'Space');
      let minV = 0;
      for (let i = 0; i < 14; i++) {
        await sleep(pg, 0.05);
        const q = await pg.evaluate(() => MV.Game.player().vy);
        minV = Math.min(minV, q);
      }
      const vEnd = await pg.evaluate(() => MV.Game.player().vy);
      await up(pg, 'Space');
      return { minV, vEnd };
    };
    const A = await run([dj(1), gl(0)]);
    ok(
      'the double jump with the higher order number takes the press and the glide waits',
      A.minV < -8 && A.vEnd > 3,
      A
    );
    const B = await run([dj(0), gl(1)]);
    ok(
      'the glide with the higher order number takes the press, so there is no double jump',
      B.minV > -8 && B.vEnd <= 2.6 && B.vEnd > 0,
      B
    );
    const comboHold = {
        id: 'c1',
        label: 'Fast fall hold',
        type: 'hold',
        key: 'KeyC',
        with: 'Down',
        on: 'air',
        where: 'air',
        speed: 9,
        gravity: 1
      },
      plainHold = {
        id: 'c2',
        label: 'Slow hold',
        type: 'hold',
        key: 'KeyC',
        on: 'air',
        where: 'air',
        speed: 2,
        gravity: 1
      };
    await start(pg, { grid: room(30, 80), spawn: [5, 3], moves: [comboHold, plainHold] });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 5;
      p.y = 8;
      p.vy = 0;
      p.on = false;
    });
    await dn(pg, 'KeyC');
    await sleep(pg, 1);
    const plainV = await pg.evaluate(() => MV.Game.player().vy);
    await dn(pg, 'ArrowDown');
    await sleep(pg, 0.8);
    const comboV = await pg.evaluate(() => MV.Game.player().vy);
    await up(pg, 'ArrowDown');
    await up(pg, 'KeyC');
    ok(
      'with Down held only the Down + key move works, the plain one does not also apply',
      plainV <= 2.6 && comboV > 6,
      [plainV, comboV]
    );
  },
  async 'report: body shape only while a move plays, held and swim animations, phase walls, new animation slots, doorway size'(
    pg
  ) {
    const g = room(60, 20);
    for (let y = 12; y < 19; y++) put(g, 14, y, 'w');
    const SH = { sheet: 'zz', col: 0, row: 0, frames: 2, fps: 6, loop: true };
    await start(pg, {
      grid: g,
      spawn: [3, 18],
      moves: [
        {
          id: 'ball',
          type: 'hold',
          key: 'KeyC',
          on: 'ground',
          runs: 9,
          squash: 0.5,
          sqw: 0.6,
          state: 'morph',
          body: { shape: 'circle' },
          sprite: SH
        },
        { id: 'ghost', type: 'hold', key: 'KeyG', on: 'air and ground', runs: 8, phase: 'ghost' }
      ]
    });
    const S0 = () =>
      pg.evaluate(() => {
        const p = MV.Game.player();
        return { sh: p.bshape && p.bshape.sh, hsp: !!p.hsp, x: p.x };
      });
    const a = await S0();
    await dn(pg, 'KeyC');
    await sleep(pg, 0.3);
    const b = await S0();
    await up(pg, 'KeyC');
    await sleep(pg, 0.4);
    const c = await S0();
    ok(
      'a move can make the hitbox a circle only while it is active',
      a.sh === 'rect' && b.sh === 'circle' && c.sh === 'rect',
      [a, b, c]
    );
    ok('a held move plays its own animation while it is held', !a.hsp && b.hsp && !c.hsp, [a, b, c]);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 10;
      p.y = 18;
      p.vx = 0;
    });
    await dn(pg, 'ArrowRight');
    await sleep(pg, 1.6);
    const w1 = (await P(pg)).x;
    await up(pg, 'ArrowRight');
    await sleep(pg, 0.2);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 10;
      p.y = 18;
      p.vx = 0;
    });
    await dn(pg, 'KeyG');
    await dn(pg, 'ArrowRight');
    await sleep(pg, 1.6);
    const w2 = (await P(pg)).x;
    await up(pg, 'ArrowRight');
    await up(pg, 'KeyG');
    ok('a Phase wall blocks you, but a move that passes through phase walls goes through', w1 < 14 && w2 > 15, [
      w1,
      w2
    ]);
    const r = await pg.evaluate(() => {
      const o = {},
        E = MV.data.entities;
      o.skins = ['bashpoint:bashed', 'grapplepoint:hooked', 'rail:ride'].every(k => {
        const [t, c] = k.split(':');
        return E[t].props[c] && E[t].props[c].t === 'clip';
      });
      rc = {
        gw: 20,
        gh: 10,
        grid: Array.from({ length: 10 }, () => '.'.repeat(20)),
        art: [],
        ent: [],
        tr: [],
        table: []
      };
      for (let y = 2; y < 6; y++) rc.grid[y] = rc.grid[y].slice(0, 5) + 'D' + rc.grid[y].slice(6);
      S.areas = [{ id: 'a1', n: 'A', s: '', c: '#378add', x: 0, y: 0, w: 50, h: 50, rooms: [rc], links: [] }];
      S.areas[0].rooms[0].id = 'r1';
      rc.id = 'r1';
      rc.n = 'R';
      document.getElementById('trl') || 0;
      drawTr();
      o.rows = document.querySelectorAll('#trl .row:not(.trfx)').length;
      o.label = (document.querySelector('#trl .row span') || {}).textContent;
      const wi = [...document.querySelectorAll('#trl input[type=number]')][0];
      wi.value = 3;
      wi.onchange();
      o.tiles = rc.grid.join('').split('D').length - 1;
      return o;
    });
    ok(
      'Bash orb, Grapple point and Zipline have animation slots; a doorway is one row with a width and height',
      r.skins && r.rows === 1 && /1 wide x 4 tall/.test(r.label) && r.tiles === 12,
      r
    );
  },
  async 'report: boss clips, stagger, invincible moments and free-size animation frames'(pg) {
    await pg.evaluate(() => {
      const c = document.createElement('canvas');
      c.width = 64;
      c.height = 32;
      const x = c.getContext('2d');
      x.fillStyle = '#c33';
      x.fillRect(0, 0, 64, 32);
      S.sheets = [{ id: 'sh1', name: 'test.png', url: c.toDataURL('image/png'), tw: 16, th: 16 }];
      S.anims = MV.Anim.list([
        {
          id: 'idl',
          name: 'Idle',
          frames: [
            { sheet: 'sh1', col: 0, row: 0, dur: 100 },
            { sheet: 'sh1', x: 20, y: 2, w: 10, h: 20, dur: 100 }
          ]
        },
        { id: 'stn', name: 'Stun', frames: [{ sheet: 'sh1', col: 1, row: 0, dur: 100 }] }
      ]);
      S.bosses = MV.Boss.list([
        {
          id: 'bb',
          name: 'Big',
          hp: 20,
          w: 2,
          h: 3,
          wake: 8,
          touch: 'no',
          wakeTime: 0.2,
          stagger: 25,
          staggerTime: 1,
          clips: { idle: 'idl', stun: 'stn', passive: 'idl' },
          patterns: [
            {
              id: 'sl',
              name: 'Slam',
              warn: 0.3,
              duration: 1,
              inv: [{ from: 0.2, to: 0.6 }],
              hitboxes: [{ name: 'Fist', w: 2, h: 1, dmg: 3, from: 0.1, to: 0.8, kf: [{ t: 0, x: 2.5, y: -0.5 }] }]
            }
          ],
          phases: [{ below: 100, idle: 0.2, patterns: ['sl'] }]
        }
      ]);
    });
    await start(pg, {
      grid: room(60, 20),
      spawn: [3, 18],
      tune: { maxHp: 20 },
      ents: [{ type: 'boss', x: 30, y: 17, props: { boss: 'bb' } }]
    });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 24;
      p.y = 18;
      p.inv = 9;
    });
    await sleep(pg, 2);
    const r = await pg.evaluate(() => {
      const o = {};
      const e = MV.Game.entities().find(q => q.type === 'boss');
      o.state = e.b.state;
      o.ck = e.b.ck;
      o.clip = !!MV.Boss.clipNow(e, { anims: S.anims }).cl;
      tab('boss');
      BI = 0;
      BSUB = 'patterns';
      HI = 0;
      PI = 0;
      bossUI();
      o.labels = [...document.querySelectorAll('#bform label,#bpc label,#bpc strong')]
        .map(l => l.textContent)
        .join('|');
      o.sections = [...document.querySelectorAll('#bform summary')].map(l => l.textContent).join('|');
      tab('anim');
      AXI = 0;
      AXF = 1;
      axUI();
      o.freeBtn = [...document.querySelectorAll('#axf button')].some(b => /Back to a grid cell/.test(b.textContent));
      o.pick = /Free rectangle/.test(document.getElementById('axsb').textContent);
      return o;
    });
    ok(
      'a boss plays a clip from the Animations tab and its editor offers clips, stagger, invincible moments and no old animation form',
      r.clip &&
        /Stunned after losing/.test(r.labels) &&
        /Cannot be hurt/.test(r.labels) &&
        /Boss animations \(from the Animations tab\)/.test(r.sections) &&
        !/Frame width \(px\)/.test(r.labels),
      r
    );
    ok('the animation editor can give a frame its own size and pick free rectangles', r.freeBtn && r.pick, r);
  },
  async 'items: energy, upgrade and script items, keep after use, the use hook, boss drops and pickups that come back'(
    pg
  ) {
    await pg.evaluate(() => {
      S.items = MV.Inventory.resolve([
        { id: 'tonic', name: 'Tonic', use: 'energy', amount: 10, max: 5 },
        { id: 'orb', name: 'Orb', use: 'upgrade', stat: 'maxHp', amount: 2 },
        { id: 'bell', name: 'Bell', use: 'script', fn: 'ring', keep: 'yes' },
        { id: 'pearl', name: 'Pearl', max: 9 }
      ]);
    });
    await start(pg, {
      grid: room(30, 14),
      spawn: [3, 12],
      tune: { maxHp: 5, energyMax: 50 },
      st: { items: { tonic: 2, orb: 1, bell: 1 } },
      scripts: [
        {
          id: 's',
          name: 'Bell',
          on: true,
          code:
            "fn('ring', d => game.variable('rang', (game.variable('rang') || 0) + 1));\n" +
            "on('use', d => game.variable('used_' + d.item, 1));"
        }
      ]
    });
    const sv = () =>
      pg.evaluate(() => ({
        hp: MV.Game.maxHp(),
        mp: MV.Game.energy(),
        it: Object.assign({}, MV.Game.state().items),
        v: Object.assign({}, MV.Game.state().vars)
      }));
    await pg.evaluate(() => MV.Game.energy(5));
    await tap(pg, 'KeyI', 0.05);
    await sleep(pg, 0.2);
    await tap(pg, 'Enter', 0.05);
    await sleep(pg, 0.1);
    let r = await sv();
    ok('a Restore energy item fills energy and is used up', r.mp === 15 && r.it.tonic === 1 && r.v.used_tonic === 1, r);
    await tap(pg, 'ArrowRight', 0.05);
    await tap(pg, 'Enter', 0.05);
    await sleep(pg, 0.1);
    r = await sv();
    ok('a permanent upgrade item raises max health for good and is used up', r.hp === 7 && !r.it.orb, r);
    await pg.evaluate(() => MV.Game.energy(50));
    await tap(pg, 'ArrowLeft', 0.05);
    await tap(pg, 'Enter', 0.05);
    await sleep(pg, 0.1);
    r = await sv();
    ok('energy that is already full does not use up the item', r.mp === 50 && r.it.tonic === 1, r);
    await tap(pg, 'ArrowRight', 0.05);
    await tap(pg, 'Enter', 0.05);
    await sleep(pg, 0.1);
    r = await sv();
    ok(
      'a script item runs its function, the use hook fires and a keeper stays in the bag',
      r.v.rang === 1 && r.v.used_bell === 1 && r.it.bell === 1,
      r
    );
    await tap(pg, 'KeyI', 0.05);
    // boss drops
    const SL = {
      id: 'slash',
      label: 'Slash',
      key: 'KeyX',
      duration: 0.2,
      cooldown: 0.1,
      hitboxes: [{ name: 'Blade', w: 1.8, h: 1.5, from: 0, to: 0.2, kf: [{ t: 0, x: 1, y: -0.75 }] }]
    };
    await pg.evaluate(() => {
      S.bosses = MV.Boss.list([
        {
          id: 'bd',
          name: 'Drop',
          hp: 1,
          w: 2,
          h: 3,
          wake: 8,
          touch: 'no',
          invul: 0,
          wakeTime: 0.1,
          dropItem: 'pearl',
          dropAmount: 2,
          dropCoins: 7,
          patterns: [],
          phases: [{ below: 100, idle: 5, speed: 1, patterns: [] }]
        }
      ]);
      S.items = MV.Inventory.resolve([{ id: 'pearl', name: 'Pearl', max: 9 }]);
    });
    await start(pg, {
      grid: room(40, 14),
      spawn: [3, 12],
      tune: { maxHp: 9 },
      atk: [SL],
      ents: [{ type: 'boss', x: 8, y: 11, props: { boss: 'bd' } }]
    });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 6.5;
      p.y = 12;
      p.face = 1;
    });
    for (let i = 0; i < 6 && !(await pg.evaluate(() => MV.Game.entities().find(q => q.type === 'boss').dead)); i++) {
      await tap(pg, 'KeyX', 0.05);
      await sleep(pg, 0.5);
    }
    r = await pg.evaluate(() => ({
      dead: MV.Game.entities().find(q => q.type === 'boss').dead,
      pearl: (MV.Game.state().items || {}).pearl,
      coins: MV.Game.coins()
    }));
    ok('a defeated boss gives its item and coins', r.dead && r.pearl === 2 && r.coins === 7, r);
    // a pickup that comes back
    await start(pg, {
      grid: room(30, 14),
      spawn: [3, 12],
      ents: [
        { type: 'pickup', x: 6, y: 11, props: { kind: 'item', give: 'pearl', amount: 1, again: 'yes' } },
        { type: 'pickup', x: 9, y: 11, props: { kind: 'item', give: 'pearl', amount: 1 } }
      ]
    });
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 6.3;
      p.y = 12;
    });
    await sleep(pg, 0.3);
    await pg.evaluate(() => {
      const p = MV.Game.player();
      p.x = 9.3;
      p.y = 12;
    });
    await sleep(pg, 0.3);
    r = await pg.evaluate(() => ({
      n: (MV.Game.state().items || {}).pearl,
      col: Object.keys(MV.Game.state().collected).length
    }));
    ok('a pickup with "Comes back" is not remembered as collected, an ordinary one is', r.n === 2 && r.col === 1, r);
  },
  async 'ui: the HUD follows the UI tab, the tab previews it, and the exported title screen uses it'(pg) {
    await pg.evaluate(() => {
      S.items = MV.Inventory.resolve([{ id: 'potion', name: 'Potion', use: 'heal' }]);
      S.ui = MV.UI.clean({
        hpStyle: 'hearts',
        hpCorner: 'bottom-right',
        hpColor: '#00ff00',
        hudItems: 'potion, nothing',
        deathText: 'GONE',
        msgTime: 4,
        titleText: 'Deep <b>',
        subtitle: 'A sea story',
        titleBg: '#102030'
      });
    });
    await start(pg, { grid: room(30, 14), spawn: [3, 12], tune: { maxHp: 4 }, st: { items: { potion: 3 } } });
    const calls = await pg.evaluate(() => {
      const c = document.getElementById('mtc'),
        x = c.getContext('2d'),
        log = [];
      const fr = x.fillRect.bind(x),
        ft = x.fillText.bind(x);
      x.fillText = (t, X, Y) => {
        log.push(['t', String(t), X, Y]);
        return ft(t, X, Y);
      };
      return new Promise(res =>
        setTimeout(() => {
          res(log);
          x.fillText = ft;
          x.fillRect = fr;
        }, 350)
      );
    });
    const U = await pg.evaluate(() => MV.UI.clean(S.ui));
    const cw = await pg.evaluate(() => document.getElementById('mtc').width),
      ch = await pg.evaluate(() => document.getElementById('mtc').height);
    const chip = calls.find(c => c[0] === 't' && /Potion x3/.test(c[1]));
    ok(
      'the HUD shows the chosen item counters (and hides an id that does not exist)',
      !!chip && !calls.some(c => /nothing/.test(c[1])),
      calls.slice(0, 4)
    );
    ok('the HUD sits in the corner you chose', !!chip && chip[2] > cw / 2 && chip[3] > ch / 2, chip && chip.slice(2));
    ok(
      'the message time follows the UI tab',
      (await pg.evaluate(() => {
        MV.Game.state();
        return true;
      })) && U.msgTime === 4
    );
    await pg.evaluate(() => {
      tab('player');
      psSub('ui');
    });
    await sleep(pg, 0.4);
    const r = await pg.evaluate(() => {
      const box = document.getElementById('pui');
      const pv = document.querySelector('#uiv canvas');
      const px = pv.getContext('2d').getImageData(0, 0, pv.width, pv.height).data;
      let green = 0;
      for (let i = 0; i < px.length; i += 4) if (px[i] < 40 && px[i + 1] > 200 && px[i + 2] < 40) green++;
      const sel = [...box.querySelectorAll('select')].map(s => s.value);
      return {
        fields: box.querySelectorAll('.mvf label').length,
        groups: box.querySelectorAll('#uig > details').length,
        green,
        sel
      };
    });
    ok(
      'the UI tab has every setting and a preview drawn in the chosen colour',
      r.fields >= 60 && r.groups === 14 && r.green > 20,
      r
    );
    // change a setting in the tab: it is saved, cleaned and drawn
    const ch2 = await pg.evaluate(() => {
      const lab = [...document.querySelectorAll('#uig label')].find(q => q.firstChild.textContent === 'Text');
      const i = lab.querySelector('input');
      i.value = 'FALLEN';
      i.onchange();
      return S.ui.deathText;
    });
    ok('a text setting changes the project', ch2 === 'FALLEN', ch2);
    const round = await pg.evaluate(() => {
      const t = ser(S);
      return JSON.parse(t).ui;
    });
    ok(
      'the UI settings are saved with the project',
      round && round.hpStyle === 'hearts' && round.deathText === 'FALLEN',
      round && round.hpStyle
    );
    // exported title screen
    const fs = require('fs'),
      os = require('os'),
      pth = require('path');
    const ttf = 'data:font/ttf;base64,' + fs.readFileSync(pth.join(__dirname, 'tiny-font.ttf')).toString('base64');
    const text = await pg.evaluate(ttf2 => {
      const g = [];
      for (let y = 0; y < 14; y++) g.push((y >= 12 ? '#' : '.').repeat(40));
      const w = fresh();
      w.name = 'T';
      w.fonts = MV.UI.cleanFonts([{ id: 'tb', name: 'Tiny', url: ttf2 }]);
      w.ui = MV.UI.clean({
        font: 'f:tb',
        titleText: 'Deep <b>x</b>',
        subtitle: 'A sea story',
        titleBg: '#102030',
        titleAccent: '#ff8800'
      });
      w.areas = [
        {
          id: 'a1',
          n: 'A',
          s: '',
          c: '#378add',
          x: 0,
          y: 0,
          w: 50,
          h: 50,
          rooms: [
            {
              id: 'r1',
              n: 'R',
              gw: 40,
              gh: 14,
              grid: g,
              ent: [{ id: 's', type: 'spawn', x: 3, y: 11, props: {} }],
              tr: [],
              bg: null,
              art: []
            }
          ],
          links: []
        }
      ];
      return ser(w);
    }, ttf);
    const file = pth.join(os.tmpdir(), 'mv-ui-title.html');
    fs.writeFileSync(file, require('../tools/export.js').buildGame(pth.join(__dirname, '..'), text));
    const br = await pw.chromium.launch({ args: ['--no-sandbox'] }),
      ctx = await br.newContext(),
      g = await ctx.newPage(),
      perr = [];
    g.on('pageerror', e => perr.push(e.message));
    await g.goto('file://' + file);
    await g.waitForTimeout(600);
    const t = await g.evaluate(() => {
      const c = document.getElementById('mv-canvas'),
        d = c.getContext('2d').getImageData(2, 2, 1, 1).data,
        m = window.__mvPlayer.title();
      // the chosen button is outlined in the accent colour: look for it along the first button's top edge
      const px = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
      let acc = 0;
      for (let i = 0; i < px.length; i += 4) if (px[i] === 255 && px[i + 1] === 136 && px[i + 2] === 0) acc++;
      return { bg: [d[0], d[1], d[2]], acc, items: m && m.items };
    });
    await g.keyboard.press('ArrowDown');
    await g.keyboard.press('Enter');
    await g.keyboard.press('ArrowLeft');
    await g.keyboard.press('ArrowLeft');
    const ov = await g.evaluate(() => ({
      page: window.__mvPlayer.title().page,
      vol: window.__mvPlayer.vol(),
      saved: JSON.parse(localStorage.getItem('mv_vol_t'))
    }));
    ok(
      'the exported title screen has an Options screen that changes the volume and remembers it',
      ov.page === 'options' &&
        Math.abs(ov.vol.master - 0.9) < 0.01 &&
        ov.saved &&
        Math.abs(ov.saved.master - 0.9) < 0.01,
      ov
    );
    for (let i = 0; i < 4; i++) await g.keyboard.press('ArrowDown');
    await g.keyboard.press('Enter');
    await g.keyboard.press('Enter');
    await g.keyboard.press('KeyJ');
    const cv2 = await g.evaluate(async () => {
      await document.fonts.load('16px "mvf-tb"');
      return {
        page: window.__mvPlayer.title().page,
        left: window.__mvPlayer.keys().Left,
        saved: JSON.parse(localStorage.getItem('mv_ctl_t')),
        font: document.fonts.check('16px "mvf-tb"')
      };
    });
    ok(
      'the exported title screen has a Controls page that remembers the new key, and the project font is loaded',
      cv2.page === 'controls' && cv2.left[0] === 'KeyJ' && cv2.saved && cv2.saved.Left[0] === 'KeyJ' && cv2.font,
      cv2
    );
    await br.close();
    ok(
      'the exported title screen is drawn on the canvas with the colours from the UI tab',
      t.bg.join() === '16,32,48' && t.acc > 100 && t.items[0] === 'new' && !perr.length,
      { t, perr }
    );
  },
  async 'ui: your own sprites draw the hearts, bars, coin, buttons and backgrounds, and Esc opens a pause menu you can use'(
    pg
  ) {
    // a sheet of 2 frames of 16x16: red, then green
    await pg.evaluate(() => {
      const c = document.createElement('canvas');
      c.width = 32;
      c.height = 16;
      const x = c.getContext('2d');
      x.fillStyle = '#ff0000';
      x.fillRect(0, 0, 16, 16);
      x.fillStyle = '#00ff00';
      x.fillRect(16, 0, 16, 16);
      S.sheets.push({ id: 'uis', name: 'ui.png', url: c.toDataURL(), tw: 16, th: 16 });
      const ic = (col, frames) => ({ sheet: 'uis', col, row: 0, frames: frames || 1, fps: 12, loop: false, fit: true });
      S.ui = MV.UI.clean({
        heartFull: ic(0),
        heartEmpty: ic(1),
        coinIcon: ic(1),
        hpSize: 20,
        btnImg: ic(1),
        btnImgSel: ic(0),
        menuBg: ic(0),
        cursor: ic(1)
      });
      tab('player');
      psSub('ui');
    });
    await sleep(pg, 0.8);
    const count = async scene =>
      pg.evaluate(sc => {
        const sel = document.querySelector('#uiv select');
        sel.value = sc;
        sel.onchange();
        const cv = document.querySelector('#uiv canvas'),
          d = cv.getContext('2d').getImageData(0, 0, cv.width, cv.height).data;
        let r = 0,
          g = 0;
        for (let i = 0; i < d.length; i += 4) {
          if (d[i] > 240 && d[i + 1] < 15 && d[i + 2] < 15) r++;
          if (d[i] < 15 && d[i + 1] > 240 && d[i + 2] < 15) g++;
        }
        return { r, g };
      }, scene);
    let c = await count('hurt');
    ok(
      'the preview draws your sprite for full health points (red), lost points (green) and the coin icon (green)',
      c.r >= 2 * 20 * 20 && c.g >= 3 * 20 * 20 + 15 * 15,
      c
    );
    c = await count('title');
    ok(
      'the title screen draws your background sprite over the whole screen and the button pictures',
      c.r > 800 * 448 * 0.5 && c.g > 3 * 200 * 30,
      c
    );
    c = await count('pause');
    ok('the pause menu preview draws the chosen button with its own picture', c.r > 200 * 30, c);
    // the sprite slots are in the tab and can be removed
    const r = await pg.evaluate(() => {
      const names = [...document.querySelectorAll('#uig details details summary')].map(q => q.textContent);
      const before = !!S.ui.heartFull;
      const b = [...document.querySelectorAll('#uig details details')].find(q => /full point/.test(q.textContent));
      [...b.querySelectorAll('button')].find(q => q.textContent === 'Remove picture').click();
      return { n: names.length, set: names.filter(q => /\(set\)/.test(q)).length, before, after: !!S.ui.heartFull };
    });
    ok(
      'every picture slot is in the tab, shows if it is set, and Remove picture clears it',
      r.n >= 12 && r.set >= 6 && r.before && !r.after,
      r
    );
    // the pause menu in the game
    await pg.evaluate(() => {
      S.ui = MV.UI.clean({ pauseResume: 'Back to it', pauseInv: 'Bag' });
    });
    await start(pg, { grid: room(30, 14), spawn: [3, 12] });
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.2);
    ok('Esc opens the pause menu and the world stops', await pg.evaluate(() => MV.Game.pauseOpen()));
    const x0 = (await P(pg)).x;
    await dn(pg, 'ArrowRight');
    await sleep(pg, 0.4);
    await up(pg, 'ArrowRight');
    ok('the player does not move while it is open', Math.abs((await P(pg)).x - x0) < 0.01);
    await tap(pg, 'ArrowDown', 0.05);
    await tap(pg, 'Enter', 0.05);
    await sleep(pg, 0.2);
    ok(
      'the Inventory choice closes the menu and opens the inventory',
      await pg.evaluate(() => !MV.Game.pauseOpen() && MV.Game.inventoryOpen())
    );
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.1);
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.1);
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.1);
    ok('Esc again closes the pause menu', await pg.evaluate(() => !MV.Game.pauseOpen()));
    // a mouse click on the Resume button
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.3);
    const pt = await pg.evaluate(() => {
      const cv = document.getElementById('mtc'),
        b = cv.getBoundingClientRect(),
        k = Math.min(b.width / cv.width, b.height / cv.height);
      return {
        x: b.left + (b.width - cv.width * k) / 2 + (cv.width / 2) * k,
        y: b.top + (b.height - cv.height * k) / 2 + (cv.height * 0.48 + 20) * k
      };
    });
    await pg.mouse.click(pt.x, pt.y);
    await sleep(pg, 0.2);
    ok('clicking Resume with the mouse closes the menu', await pg.evaluate(() => !MV.Game.pauseOpen()));
    await pg.evaluate(() => {
      S.ui = MV.UI.clean({ pauseOn: 'no' });
    });
    await start(pg, { grid: room(30, 14), spawn: [3, 12] });
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.2);
    ok('the pause menu can be turned off', await pg.evaluate(() => !MV.Game.pauseOpen()));
  },
  async 'ui: the options screen sets the volumes from the pause menu, the buttons can be nine-sliced and items can show pictures'(
    pg
  ) {
    await pg.evaluate(() => {
      S.ui = MV.UI.clean({});
    });
    await start(pg, { grid: room(30, 14), spawn: [3, 12] });
    const vol = () => pg.evaluate(() => MV.Audio.getVol());
    const v0 = await vol();
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.15);
    await tap(pg, 'ArrowDown', 0.05);
    await tap(pg, 'ArrowDown', 0.05);
    await tap(pg, 'ArrowDown', 0.05);
    await tap(pg, 'Enter', 0.05);
    await sleep(pg, 0.15);
    ok(
      'Options in the pause menu opens the options screen (the menu stays open)',
      await pg.evaluate(() => MV.Game.pauseOpen())
    );
    await tap(pg, 'ArrowDown', 0.05); // Music
    await tap(pg, 'ArrowLeft', 0.05);
    await tap(pg, 'ArrowLeft', 0.05);
    const v1 = await vol();
    ok(
      'Left and Right change the chosen volume in steps of 5%',
      Math.abs(v1.music - (v0.music - 0.1)) < 0.011 && v1.master === v0.master,
      [v0, v1]
    );
    // click the Master slider at 20%
    const pt = await pg.evaluate(() => {
      const cv = document.getElementById('mtc'),
        b = cv.getBoundingClientRect(),
        k = Math.min(b.width / cv.width, b.height / cv.height);
      const bw = Math.min(Math.max(240, 380), cv.width - 20),
        bx = (cv.width - bw) / 2,
        sx = bx + bw * 0.52,
        sw = bw * 0.46 - 44,
        by = cv.height * 0.24,
        bh = 40;
      return {
        x: b.left + (b.width - cv.width * k) / 2 + (sx + sw * 0.2) * k,
        y: b.top + (b.height - cv.height * k) / 2 + (by + bh / 2) * k
      };
    });
    await pg.mouse.click(pt.x, pt.y);
    await sleep(pg, 0.15);
    const v2 = await vol();
    ok('clicking a slider sets the volume where you click', Math.abs(v2.master - 0.2) < 0.06, v2);
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.1);
    ok(
      'Esc goes back from the options screen to the pause menu, which is still open',
      await pg.evaluate(() => MV.Game.pauseOpen())
    );
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.1);
    ok('and Esc again closes it', await pg.evaluate(() => !MV.Game.pauseOpen()));
    await pg.evaluate(() => {
      S.ui = MV.UI.clean({ optionsOn: 'no' });
    });
    await start(pg, { grid: room(30, 14), spawn: [3, 12] });
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.15);
    await tap(pg, 'ArrowDown', 0.05);
    await tap(pg, 'ArrowDown', 0.05);
    await tap(pg, 'ArrowDown', 0.05);
    await tap(pg, 'Enter', 0.05);
    await sleep(pg, 0.15);
    ok(
      'with Options turned off the menu has only Resume and Inventory here: two steps down wrap round to Resume, which closes it',
      await pg.evaluate(() => !MV.Game.pauseOpen())
    );
  },
  async 'ui: the minimap follows the rooms you visit, the player can pick other keys, and your own font file loads'(
    pg
  ) {
    await pg.evaluate(() => {
      S.ui = MV.UI.clean({
        mapShow: 'yes',
        mapCorner: 'top-right',
        mapHere: '#12ab34',
        mapAlpha: 1,
        mapW: 150,
        mapH: 90,
        hpShow: 'no'
      });
    });
    const R2 = Array.from({ length: 14 }, (_, y) => (y >= 12 ? '#' : '.').repeat(30));
    await start(pg, { grid: room(30, 14), spawn: [3, 12], room2: R2 });
    await sleep(pg, 0.3);
    const here = async () =>
      pg.evaluate(() => {
        const c = document.getElementById('mtc'),
          d = c.getContext('2d').getImageData(c.width - 170, 0, 170, 110).data;
        let n = 0;
        for (let i = 0; i < d.length; i += 4) if (d[i] === 0x12 && d[i + 1] === 0xab && d[i + 2] === 0x34) n++;
        return n;
      });
    ok('the minimap draws the current room in its colour', (await here()) > 20, await here());
    ok(
      'the visited rooms are remembered in the progress',
      (await pg.evaluate(() => Object.keys(MV.Game.state().seen).join())) === 't1'
    );
    await pg.evaluate(() => {
      S.ui = MV.UI.clean({ mapShow: 'no' });
    });
    await start(pg, { grid: room(30, 14), spawn: [3, 12] });
    await sleep(pg, 0.2);
    ok('with the minimap off nothing is drawn there', (await here()) === 0);
    // pick another key for Left in the pause menu
    await pg.evaluate(() => {
      S.ui = MV.UI.clean({});
    });
    await start(pg, { grid: room(30, 14), spawn: [10, 12] });
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.15);
    await tap(pg, 'ArrowDown', 0.05);
    await tap(pg, 'ArrowDown', 0.05);
    await tap(pg, 'ArrowDown', 0.05);
    await tap(pg, 'Enter', 0.05); // Options
    for (let i = 0; i < 3; i++) await tap(pg, 'ArrowDown', 0.05); // Master, Music, Effects, Controls
    await tap(pg, 'Enter', 0.05);
    await sleep(pg, 0.1);
    await tap(pg, 'Enter', 0.05); // the first action: Left
    await sleep(pg, 0.1);
    await tap(pg, 'KeyJ', 0.05);
    await sleep(pg, 0.1);
    const k = await pg.evaluate(() => MV.Game.controls().keys.Left.join());
    ok(
      'the player can pick another key for Left; the old keys still work',
      k.startsWith('KeyJ') && k.includes('ArrowLeft'),
      k
    );
    await tap(pg, 'Escape', 0.05);
    await tap(pg, 'Escape', 0.05);
    await tap(pg, 'Escape', 0.05);
    await sleep(pg, 0.15);
    ok('Esc goes back through the pages and closes the menu', await pg.evaluate(() => !MV.Game.pauseOpen()));
    const x0 = (await P(pg)).x;
    await dn(pg, 'KeyJ');
    await sleep(pg, 0.5);
    await up(pg, 'KeyJ');
    ok('the new key moves the player left', (await P(pg)).x < x0 - 0.5, [x0, (await P(pg)).x]);
    // a font file in the project is loaded and used by name; a bad one is dropped
    const fs = require('fs'),
      pth = require('path');
    const ttf = 'data:font/ttf;base64,' + fs.readFileSync(pth.join(__dirname, 'tiny-font.ttf')).toString('base64');
    const r = await pg.evaluate(async ttf2 => {
      S.fonts = MV.UI.cleanFonts([
        { id: 'tb', name: 'Tiny', url: ttf2 },
        { id: 'bad', name: 'Bad', url: 'data:font/ttf;base64,AAAA' }
      ]);
      S.ui = MV.UI.clean({ font: 'f:tb' });
      await Promise.all(MV.UI.loadFonts(S.fonts).filter ? [MV.UI.loadFonts(S.fonts)] : []);
      await document.fonts.load('16px "mvf-tb"');
      tab('player');
      psSub('ui');
      const sel = [...document.querySelectorAll('#uig select')].find(q => [...q.options].some(o => o.value === 'f:tb'));
      return {
        n: S.fonts.length,
        ok: document.fonts.check('16px "mvf-tb"'),
        listed: !!sel,
        chosen: sel && sel.value,
        ser: JSON.parse(ser(S)).fonts.length
      };
    }, ttf);
    ok(
      'a font file is loaded by the page, listed in the Font choice and saved with the project',
      r.n === 2 && r.ok && r.listed && r.chosen === 'f:tb' && r.ser === 2,
      r
    );
  },
  async 'editor: tabs build without errors and a project round-trips'(pg) {
    const r = await pg.evaluate(() => {
      const out = {};
      const g = Array.from({ length: 20 }, () => '.'.repeat(30));
      const room = okRoom({
        id: 'r1',
        n: 'R',
        x: 0,
        y: 0,
        w: 30,
        h: 20,
        gw: 30,
        gh: 20,
        grid: g,
        ent: [],
        tr: [],
        music: 'song'
      });
      S.areas = [{ id: 'a1', n: 'A', s: '', c: '#378add', x: 0, y: 0, w: 50, h: 50, rooms: [room], links: [] }];
      rc = room;
      S.sounds = MV.Audio.cleanList([
        { id: 'song', name: 'Song', music: true, src: __wav({ wave: 'sine', f0: 200, f1: 200, dur: 0.2 }) }
      ]);
      S.events = MV.Events.clean([
        { id: 'a', name: 'A', trigger: { type: 'room', room: 'r1' }, actions: [{ type: 'message', text: 'hi' }] }
      ]);
      ['audio', 'events', 'player', 'world'].forEach(t => {
        TAB = '';
        tab(t);
      });
      buildCam();
      buildMoves();
      buildAtk();
      for (let i = 0; i < 12; i++) bgAdd(false);
      const back = des(snap().core);
      out.sounds = back.sounds.length;
      out.events = back.events.length;
      out.layers = rc.bg.layers.length;
      out.music = back.areas[0].rooms[0].music;
      return out;
    });
    ok(
      'every tab builds and a project keeps its sounds, events, music and layers',
      r.sounds === 1 && r.events === 1 && r.music === 'song' && r.layers === 16,
      r
    );
  }
};

const WAVJS = `window.__wav = o => { const sr = 8000, n = Math.floor(sr * (o.dur || .1)), b = new ArrayBuffer(44 + n * 2), d = new DataView(b), w = (p, s) => { for (let i = 0; i < s.length; i++) d.setUint8(p + i, s.charCodeAt(i)); }; w(0, 'RIFF'); d.setUint32(4, 36 + n * 2, true); w(8, 'WAVEfmt '); d.setUint32(16, 16, true); d.setUint16(20, 1, true); d.setUint16(22, 1, true); d.setUint32(24, sr, true); d.setUint32(28, sr * 2, true); d.setUint16(32, 2, true); d.setUint16(34, 16, true); w(36, 'data'); d.setUint32(40, n * 2, true); for (let i = 0; i < n; i++) d.setInt16(44 + i * 2, Math.sin(i / sr * (o.f0 || 300) * 6.2832) * 9000, true); let s = ''; new Uint8Array(b).forEach(c => s += String.fromCharCode(c)); return 'data:audio/wav;base64,' + btoa(s); };`;
(async () => {
  const only = process.argv[2];
  const b = await pw.chromium.launch({ args: ['--no-sandbox'] });
  for (const name in scenarios) {
    if (only && !name.includes(only)) continue;
    console.log(name);
    const pg = await b.newPage({ viewport: { width: 1400, height: 900 } });
    await pg.addInitScript(WAVJS);
    const e = [];
    pg.on('pageerror', x => e.push(String(x)));
    pg.on('console', m => {
      if (m.type() === 'error') e.push(m.text());
      else if (/TRYATK/.test(m.text())) console.log(m.text());
    });
    await pg.goto(APP);
    await sleep(pg, 2.2);
    try {
      await scenarios[name](pg);
    } catch (x) {
      fail++;
      console.log('  FAIL scenario crashed: ' + x.message.split('\n')[0]);
    }
    ok('no page errors', e.length === 0, e);
    await pg.close();
  }
  await b.close();
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail ? 1 : 0);
})();
