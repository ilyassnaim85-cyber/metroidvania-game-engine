# How the code is organised

Nothing here changes how the engine behaves; it only says where things live.

## Engine (the game runtime, `engine/`)
- The screen look (HUD, messages, boss bar, death and title screens): `engine/ui.js` (settings and drawing, shared by the game and the preview) and `editor/ui_ui.js` (Player settings > UI).
- Exporting a PC game: `tools/pcexport.js` (copies the Electron runtime, swaps in the game) and `export/game-main.js` (the game's main process); `main.js` runs it from File > Export game for PC.
- Exporting a web page: `tools/export.js` (builds the HTML), `export/player.js` and `export/player.css` (the title screen and game loop inside every exported file); `main.js` calls it from File > Export game.
- One file per system: `camera.js`, `camera_rig.js`, `boss.js`, `enemies.js`, `events.js`, `script.js`, `camera_vcam.js` (virtual cameras), `inventory.js`, `light.js`, `world.js` ... Each adds one object to the global `MV` (for example `MV.Boss`).
- **`engine/game.js` is generated.** Edit the pieces in `engine/game/` instead, then run `node tools/build.js` (`npm start`, `npm test` and `npm run dist` run it for you; `npm run check-build` says whether it is up to date). The pieces are plain slices of one function, joined in file-name order:
  `01-core` state, saving, damage, energy, charms, upgrades | `02-rooms` building entities, doors, loading a room | `03-keys-inventory` key groups, weapons, the inventory screen | `04-attacks-moves` starting attacks and moves | `05-death-effects` dying, events, shots, combos | `06-movement-extras` ledges, rails, cannons, mounts, drowning | `07-camera-glue` camera profiles and zones | `08-sim` one simulation step (short; keeps the frame's variables in `SIM`) | `08a-sim-player` the player's movement modes | `08b-sim-entities` one function per kind of placed entity | `09-enemies-fx` enemies, drawing skins, effects | `10-paint` drawing a frame | `11-input-loop` keyboard, mouse, gamepad, the frame loop | `12-api` `MV.Game.*` and `start()` | `13-script-api` the `game` object scripts use.
- `status.js` (damage types, poison, burn, slow) and `tiles.js` (tile painter, tile pictures, auto-tiling) ; `editor/tileart_ui.js` is the room tools: tile pictures, stamps, fill border, room templates.
- Files that were not listed before: `animation.js` (animation clips and sampling), `attacks.js` (hitbox shapes, attack timelines, `shapeHit`), `audio.js` (sounds, music, volume), `background.js` (room backgrounds and layers), `controls.js` (key and gamepad bindings), `dialog.js` (dialogue boxes), `moves.js` (moves and abilities), `progress.js` (save data: flags, items, rooms seen), `sprite.js` (sprite sheets and frames), `tiles.js` (tile types and shapes), `tuning.js` (player tuning values).
- `data/config.js` holds the schemas and data tables (`MV.data.*`).

## Editor (`editor/`)
- The editor is four big scripts that share one scope, loaded in order by `index.html`: `app-01.js` world editor and room layers, `app-02.js` shape and sprite tools, templates, the Player tab (moves, attacks, inventory, controls, camera), `app-03.js` hitbox tab, boss editor, animation studio, `app-04.js` zoom, minimap, layers, lighting. **They are generated too**: edit the numbered pieces in `editor/app-01/` to `editor/app-04/` (the number is the order), then run `node tools/build.js`. They must stay one script each, because code at the top of one piece may call functions defined further down.
- `events_ui.js`, `audio_ui.js`, `enemies_ui.js`, `scripts_ui.js` are the Events, Audio, Enemies and Scripts tabs; `ui_ui.js` is Player > UI; `cam_preview.js` and `vcam_ui.js` are the camera preview and virtual cameras; `splash.js` is the start-up logo.
- `editor/theme.css` is the whole editor look (Unity-style dark theme, inspector on the right, scrolling rules for the tab pages). Colours are variables at the top of it.

## Tools and tests
- `tools/validate.js` checks a project file from the command line. `tools/build.js` builds `engine/game.js`.
- `tests/unit.js` (no browser) and `tests/browser.js` (Playwright). `npm test` runs both.
- `examples/`: `animation-demo.html`, and the showcase game `tidebound.json` (built by `tidebound-build.js` from the pictures `tidebound-art.py` draws into `tidebound-art/`, played by `tests/showcase.js`, also exported as `tidebound.html`).
- Code style: `prettier` with `.prettierrc` (120 columns).

## Known weak spot
`sim` still keeps about 50 variables in one shared object (`SIM`) that the pieces read and write. It is flatter than before but not isolated: a new system should get its own piece with a clear list of what it reads.
