const { contextBridge, ipcRenderer } = require('electron');
// Lets the editor save and open real project files. The page falls back to a download / file picker without it.
contextBridge.exposeInMainWorld('mvHost', {
  save: (json, asNew, filePath, defName) => ipcRenderer.invoke('mv-save', json, asNew, filePath, defName),
  open: () => ipcRenderer.invoke('mv-open'),
  exportFile: (json, defName) => ipcRenderer.invoke('mv-export', json, defName)
});
