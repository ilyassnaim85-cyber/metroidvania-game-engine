// UI tab (editor): Player settings > UI. Every setting of how the screen looks (health, energy, counters, messages, boss bar, death screen,
// title screen) with a preview that is drawn by the same code the game uses (MV.UI). Needs the editor globals: S, save, $, mkSel, mkNum, mkClr.
(() => {
  let box = null,
    cv = null,
    scene = 'play',
    open = {};
  const E = (t, c, x) => {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };
  const SCENES = [
    ['play', 'Playing'],
    ['hurt', 'Low health and full text'],
    ['boss', 'Boss fight'],
    ['death', 'Death screen'],
    ['pause', 'Pause menu (Esc)'],
    ['options', 'Options screen'],
    ['map', 'Map screen (M)'],
    ['title', 'Title screen']
  ];
  const css = document.createElement('style');
  css.textContent = `#uiv{position:sticky;top:0;z-index:6;background:var(--cd);border:1px solid var(--bd);border-radius:10px;padding:8px 10px;margin:0 0 10px;box-shadow:0 6px 18px rgba(0,0,0,.25)}
  #uiv .uih{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:6px}
  #uiv canvas{width:100%;max-width:640px;height:auto;display:block;border-radius:6px;background:#12324a}
  #uig details{margin:6px 0;border:1px solid var(--bd);border-radius:8px;padding:6px 10px}#uig summary{cursor:pointer;font-weight:600;font-size:14px}`;
  document.head.appendChild(css);
  const UI = () => MV.UI.clean(S.ui);
  const set = p => {
    S.ui = MV.UI.clean(Object.assign({}, S.ui, p));
    save();
    paint();
  };
  // a sample of what the game would show
  function sample(U) {
    const lowHp = scene === 'hurt';
    return {
      hp: lowHp ? 2 : 5,
      maxHp: 5,
      mp: lowHp ? 10 : 34,
      mpMax: 50,
      mpFlash: 0,
      room: 'Kelp Garden',
      coins: 37,
      abilities: lowHp ? ['dash', 'glide', 'swim'] : ['dash'],
      weapon: lowHp ? 'trident' : '',
      status: lowHp ? [{ id: 'poison', label: 'Poison', color: '#7bd05a', t: 3 }, { id: 'slow', label: 'Slow', color: '#6ab0e8', t: 2 }] : [],
      items: U.hudItems
        ? U.hudItems.split(', ').map(id => {
            const d = (S.items || []).find(q => q.id === id);
            return { name: d ? d.name : id, count: 2 };
          })
        : []
    };
  }
  function paint() {
    if (!cv) return;
    const U = UI(),
      x = cv.getContext('2d'),
      w = cv.width,
      h = cv.height;
    x.clearRect(0, 0, w, h);
    const tm = performance.now() / 1000;
    if (scene === 'map') {
      MV.UI.fullMap(x, w, h, U, {
        area: 'Kelp Garden',
        count: 3,
        rooms: [
          { x: 0, y: 0, w: 3, h: 2, seen: true, marks: [{ k: 'rest', x: 0.5, y: 0.7 }] },
          { x: 3, y: 0, w: 2, h: 2, seen: true, marks: [{ k: 'item', x: 0.4, y: 0.4 }] },
          { x: 3, y: 2, w: 2, h: 2, here: true, seen: true, marks: [{ k: 'boss', x: 0.7, y: 0.5 }] },
          { x: 1, y: 2, w: 2, h: 1, seen: true }
        ],
        px: 0.3,
        py: 0.6,
        hint: 'Left / Right: area   M or Esc: close'
      });
      return;
    }
    if (scene === 'options') {
      MV.UI.options(
        x,
        w,
        h,
        U,
        { kind: 'title', rows: MV.UI.optRows(U, { master: 1, music: 0.7, sfx: 0.5 }, true, true), sel: 1 },
        sheetOf,
        tm
      );
      return;
    }
    if (scene === 'title') {
      MV.UI.menu(
        x,
        w,
        h,
        U,
        {
          kind: 'title',
          title: U.titleText || S.name || 'My game',
          subtitle: U.subtitle,
          items: [
            { id: 'continue', label: U.titleContinue },
            { id: 'new', label: U.titleStart },
            { id: 'full', label: U.titleFull },
            { id: 'quit', label: U.titleQuit }
          ],
          sel: 1
        },
        sheetOf,
        tm
      );
      return;
    }
    // a small sea room behind the HUD
    const g = x.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0, '#1d5a7a');
    g.addColorStop(1, '#0d2a3d');
    x.fillStyle = g;
    x.fillRect(0, 0, w, h);
    x.fillStyle = '#2b3b46';
    x.fillRect(0, h - 48, w, 48);
    x.fillRect(w * 0.55, h - 110, 150, 18);
    x.fillStyle = '#5dcaa5';
    x.fillRect(w * 0.3, h - 82, 22, 34);
    const st = sample(U);
    if (scene === 'boss')
      MV.UI.bossBar(
        x,
        w,
        U,
        { name: 'The Drowned King', hp: 62, max: 100, safe: false, phases: [66, 33] },
        sheetOf,
        tm
      );
    MV.UI.hud(x, w, h, U, st, sheetOf, tm);
    MV.UI.minimap(x, w, h, U, {
      rooms: [
        { x: 0, y: 0, w: 3, h: 2, seen: true },
        { x: 3, y: 0, w: 2, h: 2, seen: true },
        { x: 3, y: 2, w: 2, h: 2, here: true },
        { x: 1, y: 2, w: 2, h: 1, seen: true },
        { x: 5, y: 1, w: 2, h: 2, seen: false }
      ].filter(r => r.seen || r.here || U.mapAll === 'yes'),
      px: 0.4,
      py: 0.6
    });
    MV.UI.messages(x, w, U, [{ t: 'Got Potion' }, { t: 'Checkpoint saved' }]);
    if (scene === 'death') MV.UI.death(x, w, h, U, 1, 1);
    if (scene === 'pause')
      MV.UI.menu(
        x,
        w,
        h,
        U,
        {
          kind: 'pause',
          title: U.pauseTitle,
          items: [
            { id: 'resume', label: U.pauseResume },
            { id: 'inv', label: U.pauseInv },
            ...(U.mapScreen === 'yes' ? [{ id: 'map', label: U.pauseMap }] : []),
            { id: 'quit', label: U.pauseQuit }
          ],
          sel: 0
        },
        sheetOf,
        tm
      );
  }
  function field(k, f, U) {
    const apply = v => set({ [k]: v });
    let l;
    if (k === 'font')
      l = mkSel(
        f.label,
        f.o
          .map(v => [v, (f.names && f.names[v]) || v])
          .concat((S.fonts || []).map(q => ['f:' + q.id, q.name + ' (your font)'])),
        U[k],
        apply
      );
    else if (f.t === 'select')
      l = mkSel(
        f.label,
        f.o.map(v => [v, (f.names && f.names[v]) || v]),
        U[k],
        apply
      );
    else if (f.t === 'number') l = mkNum(f.label, U[k], f.min, f.max, f.step, apply);
    else if (f.t === 'color') l = mkClr(f.label, U[k], apply);
    else {
      l = E('label');
      const q = E('input');
      q.type = 'text';
      q.value = U[k];
      q.maxLength = k === 'subtitle' ? 80 : k === 'hudItems' ? 80 : 40;
      q.onchange = () => apply(q.value);
      l.append(f.label, q);
    }
    l.title = f.help || '';
    return l;
  }
  // a sprite slot: pick a sheet and the frame(s), like the pictures in the Items tab
  function spriteField(k, f, U) {
    const d = E('details'),
      a = U[k];
    d.open = !!open['s:' + k];
    d.ontoggle = () => (open['s:' + k] = d.open);
    d.title = f.help || '';
    d.appendChild(E('summary', '', f.label + (a ? ' (set)' : ' (none)')));
    const put = v => {
      S.ui = MV.UI.clean(Object.assign({}, S.ui, { [k]: v }));
      save();
      build();
    };
    d.appendChild(
      animForm(
        a,
        patch => {
          const n = Object.assign(
            { sheet: '', col: 0, row: 0, frames: 1, fps: 12, loop: false, fit: true },
            a || {},
            patch
          );
          put(n.sheet ? n : null);
        },
        build
      )
    );
    if (f.help) d.appendChild(E('p', 'hint', f.help));
    if (a) {
      const b = E('button', '', 'Remove picture');
      b.onclick = () => put(null);
      d.appendChild(b);
    }
    return d;
  }
  // fonts from your own files (.ttf, .otf, .woff, .woff2): kept inside the project, so they travel with the exported game
  const FONTMIME = { ttf: 'ttf', otf: 'otf', woff: 'woff', woff2: 'woff2' };
  function fontsBox() {
    const d = E('details');
    d.open = !!open.fonts;
    d.ontoggle = () => (open.fonts = d.open);
    d.appendChild(E('summary', '', 'Fonts (your own files)'));
    d.appendChild(
      E(
        'p',
        'hint',
        'Add up to 4 font files (450 KB each). Then pick one in Text > Font. A font file must be one you may use in a game.'
      )
    );
    const msg = E('p', 'hint', '');
    (S.fonts || []).forEach(f => {
      const r = E('div', 'row');
      r.appendChild(E('span', '', f.name));
      const b = E('button', '', 'Remove');
      b.onclick = () => {
        S.fonts = S.fonts.filter(q => q.id !== f.id);
        if (S.ui.font === 'f:' + f.id) S.ui = MV.UI.clean(Object.assign({}, S.ui, { font: 'sans' }));
        save();
        build();
      };
      r.appendChild(b);
      d.appendChild(r);
    });
    const inp = E('input');
    inp.type = 'file';
    inp.accept = '.ttf,.otf,.woff,.woff2';
    inp.onchange = () => {
      const f = inp.files[0];
      inp.value = '';
      if (!f) return;
      const ext = (/\.(\w+)$/.exec(f.name) || [])[1];
      if (!FONTMIME[(ext || '').toLowerCase()]) {
        msg.textContent = 'Use a .ttf, .otf, .woff or .woff2 file.';
        return;
      }
      if (f.size > 450000) {
        msg.textContent = 'That file is too big (450 KB at most).';
        return;
      }
      if ((S.fonts || []).length >= 4) {
        msg.textContent = 'Up to 4 fonts.';
        return;
      }
      const fr = new FileReader();
      fr.onload = () => {
        const b64 = String(fr.result).split(',')[1] || '';
        const id = 'f' + Math.random().toString(36).slice(2, 7);
        const list = MV.UI.cleanFonts(
          (S.fonts || []).concat([
            {
              id,
              name: f.name.replace(/\.\w+$/, '').slice(0, 40),
              url: 'data:font/' + FONTMIME[ext.toLowerCase()] + ';base64,' + b64
            }
          ])
        );
        if (list.length === (S.fonts || []).length) {
          msg.textContent = 'That file could not be used.';
          return;
        }
        S.fonts = list;
        S.ui = MV.UI.clean(Object.assign({}, S.ui, { font: 'f:' + id }));
        MV.UI.loadFonts(S.fonts);
        save();
        build();
      };
      fr.readAsDataURL(f);
    };
    const l = E('label');
    l.append('Add a font file', inp);
    d.appendChild(l);
    d.appendChild(msg);
    return d;
  }
  function build() {
    MV.UI.loadFonts(S.fonts);
    box = $('pui');
    if (!box) return;
    box.textContent = '';
    const U = UI(),
      F = MV.UI.FIELDS;
    const pv = E('div');
    pv.id = 'uiv';
    const hd = E('div', 'uih');
    hd.appendChild(
      mkSel('Preview', SCENES, scene, v => {
        scene = v;
        paint();
      })
    );
    const rs = E('button', '', 'Reset the UI to defaults');
    rs.onclick = () => {
      if (!confirm('Put every UI setting back to its default?')) return;
      S.ui = MV.UI.def();
      save();
      build();
    };
    hd.appendChild(rs);
    hd.appendChild(E('span', 'hint', 'Drawn by the same code as the game. Hover a setting for help.'));
    pv.appendChild(hd);
    cv = E('canvas');
    cv.width = 800;
    cv.height = 448;
    pv.appendChild(cv);
    box.appendChild(pv);
    const groups = [];
    for (const k in F) if (!groups.includes(F[k].g)) groups.push(F[k].g);
    const wrap = E('div');
    wrap.id = 'uig';
    groups.forEach((gn, i) => {
      const d = E('details');
      d.open = open[gn] !== undefined ? open[gn] : i < 2;
      d.ontoggle = () => (open[gn] = d.open);
      d.appendChild(E('summary', '', gn));
      const f = E('div', 'mvf');
      for (const k in F) if (F[k].g === gn && F[k].t !== 'sprite') f.appendChild(field(k, F[k], U));
      d.appendChild(f);
      for (const k in F) if (F[k].g === gn && F[k].t === 'sprite') d.appendChild(spriteField(k, F[k], U));
      wrap.appendChild(d);
    });
    wrap.appendChild(fontsBox());
    box.appendChild(wrap);
    paint();
  }
  setInterval(() => {
    if (box && box.isConnected && !box.hidden && cv) paint(); // sprites animate
  }, 120);
  window.uiUI = build;
})();
