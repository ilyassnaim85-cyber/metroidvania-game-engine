// ===== Ability picker: one shared list of ability ids, so "Unlocked by" and a pickup's "give" always match =====
function abilityList() {
  abSync();
  const given = {},
    used = {};
  S.areas.forEach(a =>
    (a.rooms || []).forEach(r =>
      (r.ent || []).forEach(e => {
        const p = e.props || {};
        if (e.type === 'pickup' && (p.kind || 'ability') === 'ability' && p.give)
          given[p.give] = (given[p.give] || 0) + 1;
        if (e.type === 'chest' && p.reward === 'ability' && p.give) given[p.give] = (given[p.give] || 0) + 1;
      })
    )
  );
  S.moves.concat(S.attacks).forEach(m => {
    if (m.requires) (used[m.requires] = used[m.requires] || []).push(m.label);
  });
  const ids = new Set(Object.keys(MV.data.abilities));
  Object.keys(given).forEach(k => ids.add(k));
  Object.keys(used).forEach(k => ids.add(k));
  return [...ids].sort().map(id => {
    const n = given[id] || 0,
      u = used[id] || [];
    return {
      id,
      label:
        id +
        (u.length ? '  (unlocks ' + u.join(', ') + ')' : '') +
        (id === 'wallJump'
          ? '  (wall slide and wall kick, only when given)'
          : n
            ? '  (' + n + ' pickup' + (n > 1 ? 's' : '') + ' give it)'
            : '  (no pickup gives it yet)')
    };
  });
}
function abilityPick(val, cb, allowEmpty) {
  const w = document.createElement('span');
  w.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap';
  const s = document.createElement('select'),
    t = document.createElement('input');
  t.type = 'text';
  t.placeholder = 'new ability id, no spaces';
  t.hidden = true;
  const L = abilityList();
  if (allowEmpty) {
    const o = document.createElement('option');
    o.value = '';
    o.textContent = '(always available)';
    s.appendChild(o);
  }
  if (val && !L.some(q => q.id === val)) L.push({ id: val, label: val + '  (no pickup gives it yet)' });
  L.forEach(q => {
    const o = document.createElement('option');
    o.value = q.id;
    o.textContent = q.label;
    s.appendChild(o);
  });
  const on = document.createElement('option');
  on.value = '__new';
  on.textContent = 'New ability...';
  s.appendChild(on);
  s.value = val || (allowEmpty ? '' : L[0] ? L[0].id : '__new');
  if (s.value !== (val || '')) s.value = allowEmpty ? '' : '__new';
  s.onchange = () => {
    if (s.value === '__new') {
      t.hidden = false;
      t.focus();
      return;
    }
    t.hidden = true;
    cb(s.value);
  };
  t.onchange = () => {
    const v = t.value
      .trim()
      .replace(/[^A-Za-z0-9_-]/g, '')
      .slice(0, 30);
    if (!v) {
      return;
    }
    cb(v);
  };
  w.append(s, t);
  return w;
}
function focusName(host) {
  setTimeout(() => {
    const l = [...host.querySelectorAll('label')].find(x => x.firstChild && x.firstChild.textContent === 'Name'),
      i = l && l.querySelector('input');
    if (i) {
      i.focus();
      i.select();
    }
  }, 50);
}
const TYPE_LABEL = {
  dash: 'Timed move',
  sequence: 'Multi-step move',
  impulse: 'Push',
  hold: 'Hold move',
  surface: 'Wall move',
  ledge: 'Ledge grab',
  swim: 'Swimming'
};
function addMove(src) {
  if (S.moves.length >= 24) {
    $('pmsg').textContent = 'Up to 24 moves.';
    return;
  }
  MSEC = 'move';
  const m = MV.Moves.clean1(Object.assign({}, src, { id: uniqId(src.id || 'move', -1) }));
  S.moves.push(m);
  MI = S.moves.length - 1;
  mvSync();
  save();
  buildMoves();
  $('pmsg').textContent =
    'Added "' +
    m.label +
    '" and selected it. In a playtest press ' +
    keyCombo(m) +
    (m.requires ? ' (unlocked by "' + m.requires + '", ticked in Playtest setup)' : '') +
    '.';
}
let STRIPS = [];
const KEYLIST = [
  ['None', 'None'],
  ['Jump', 'Jump (Space, W, Up arrow)'],
  ['Shift', 'Shift'],
  ['Up', 'Up (W, Up arrow)'],
  ['Down', 'Down (S, Down arrow)'],
  ['Left', 'Left (A, Left arrow)'],
  ['Right', 'Right (D, Right arrow)'],
  ['KeyZ', 'Z'],
  ['KeyC', 'C'],
  ['KeyV', 'V'],
  ['KeyB', 'B'],
  ['KeyQ', 'Q'],
  ['KeyE', 'E'],
  ['KeyR', 'R'],
  ['KeyF', 'F']
];
const keyName = v => (KEYLIST.find(q => q[0] === v) || [0, String(v).replace(/^Key|^Digit/, '')])[1].split(' (')[0];
const codeToKey = c =>
  c === 'ShiftLeft' || c === 'ShiftRight'
    ? 'Shift'
    : c === 'Space'
      ? 'Jump'
      : c === 'ArrowUp' || c === 'KeyW'
        ? 'Up'
        : c === 'ArrowDown' || c === 'KeyS'
          ? 'Down'
          : c === 'ArrowLeft' || c === 'KeyA'
            ? 'Left'
            : c === 'ArrowRight' || c === 'KeyD'
              ? 'Right'
              : c;
function keyField(fd, m, k, title, cl) {
  const l = document.createElement('label'),
    row = document.createElement('div'),
    sel = document.createElement('select'),
    b = document.createElement('button');
  const addOpt = v => {
    if (![...sel.options].some(o => o.value === v)) {
      const e = document.createElement('option');
      e.value = v;
      e.textContent = keyName(v);
      sel.appendChild(e);
    }
  };
  KEYLIST.forEach(o => {
    const e = document.createElement('option');
    e.value = o[0];
    e.textContent = o[1];
    sel.appendChild(e);
  });
  addOpt(m[k]);
  sel.value = m[k];
  const apply = v => {
    m[k] = v;
    if (cl) cl(m);
    else {
      Object.assign(m, MV.Moves.clean1(m));
      mvSync();
    }
    addOpt(m[k]);
    sel.value = m[k];
    title();
    save();
  };
  sel.onchange = () => apply(sel.value);
  b.textContent = 'Press a key';
  b.title = 'Click, then press the key you want (Esc cancels)';
  b.onclick = () => {
    b.textContent = 'Press a key now...';
    const h = e => {
      e.preventDefault();
      e.stopPropagation();
      removeEventListener('keydown', h, true);
      b.textContent = 'Press a key';
      if (e.code !== 'Escape') apply(codeToKey(e.code));
    };
    addEventListener('keydown', h, true);
  };
  row.style.cssText = 'display:flex;gap:6px';
  sel.style.flex = '1';
  row.append(sel, b);
  l.title = fd.help || '';
  l.append(fd.label, row);
  return l;
}
// Every key of a move or attack together, for lists and messages: the held keys first, the main key last (X + Space + Down is written "Space + Down + X").
const keyCombo = o =>
  [o.with && o.with !== 'None' ? o.with : null]
    .concat(o.more || [], [o.key])
    .filter(Boolean)
    .map(keyName)
    .join(' + ');
// "Add key": more keys that must all be held together with Key and Also hold. change(fn) applies fn to the move or attack, cleans it, saves and redraws.
function moreKeysUI(o, change, box) {
  const d = document.createElement('div');
  d.style.cssText = 'grid-column:1/-1;display:flex;flex-wrap:wrap;gap:6px;align-items:center';
  d.className = 'morekeys';
  d.title = 'Keys that must ALL be held together with Key and Also hold, for example X + Space + Down.';
  const lab = document.createElement('span');
  lab.className = 'hint';
  lab.textContent = (o.more || []).length
    ? 'More keys held together:'
    : 'Need more than two keys (for example X + Space + Down)?';
  d.appendChild(lab);
  (o.more || []).forEach((k, i) => {
    const c = document.createElement('span');
    c.style.cssText =
      'display:inline-flex;gap:4px;align-items:center;border:1px solid var(--bd);border-radius:6px;padding:2px 4px 2px 8px';
    c.append(keyName(k));
    const x = btn('\u00d7', () =>
      change(y => {
        y.more = (y.more || []).filter((q, j) => j !== i);
      })
    );
    x.title = 'Remove this key';
    x.style.padding = '0 7px';
    c.appendChild(x);
    d.appendChild(c);
  });
  const add = btn((o.more || []).length ? 'Add another key' : 'Add key', () => {
    if ((o.more || []).length >= 5) {
      $('pmsg').textContent = 'Up to 5 more keys.';
      return;
    }
    add.textContent = 'Press a key now...';
    const h = e => {
      e.preventDefault();
      e.stopPropagation();
      removeEventListener('keydown', h, true);
      if (e.code === 'Escape') {
        add.textContent = (o.more || []).length ? 'Add another key' : 'Add key';
        return;
      }
      const k = codeToKey(e.code);
      change(y => {
        y.more = (y.more || []).concat([k]);
      });
    };
    addEventListener('keydown', h, true);
  });
  d.appendChild(add);
  box.appendChild(d);
}
function drawMoveStrip(c, m) {
  const x = c.getContext('2d'),
    a = m.sprite;
  x.fillStyle = '#2c2c2a';
  x.fillRect(0, 0, c.width, c.height);
  x.font = '11px system-ui,sans-serif';
  x.textBaseline = 'middle';
  x.textAlign = 'left';
  if (!a) {
    x.fillStyle = '#6b6a65';
    x.fillText('No animation yet. Pick a sprite sheet above.', 8, c.height / 2);
    return;
  }
  const sh = sheetOf(a.sheet);
  if (!sh) {
    x.fillStyle = '#6b6a65';
    x.fillText('Sprite sheet missing.', 8, c.height / 2);
    return;
  }
  const len = m.type === 'dash' ? Math.max(0.05, m.duration) : a.frames / a.fps,
    fps = a.fit && m.type === 'dash' ? a.frames / len : a.fps,
    fd = 1 / fps,
    W = c.width - 16,
    tx = t => 8 + (t / len) * W;
  x.fillStyle = '#b4b2a9';
  x.fillText('0 s', 8, 8);
  x.textAlign = 'right';
  x.fillText(len.toFixed(2) + ' s  (' + fps.toFixed(1) + ' frames per second)', c.width - 8, 8);
  for (let k = 0; k * fd < len - 1e-6 && k < 400; k++) {
    const t0 = k * fd,
      t1 = Math.min((k + 1) * fd, len),
      x0 = tx(t0),
      x1 = tx(t1),
      fi = a.loop ? k % a.frames : Math.min(a.frames - 1, k);
    x.strokeStyle = 'rgba(255,255,255,.25)';
    x.lineWidth = 1;
    if (x1 - x0 >= 8 && sh.img.complete && sh.img.naturalWidth) {
      const bw = x1 - x0 - 2,
        bh = c.height - 24,
        k2 = Math.min(bw / sh.tw, bh / sh.th),
        dw = sh.tw * k2,
        dh = sh.th * k2;
      x.imageSmoothingEnabled = false;
      x.drawImage(
        sh.img,
        (a.col + fi) * sh.tw,
        a.row * sh.th,
        sh.tw,
        sh.th,
        x0 + 1 + (bw - dw) / 2,
        16 + (bh - dh) / 2,
        dw,
        dh
      );
      if (x1 - x0 >= 22) {
        x.fillStyle = 'rgba(255,255,255,.65)';
        x.textAlign = 'left';
        x.fillText(String(fi + 1), x0 + 3, 22);
      }
    }
    x.strokeRect(x0 + 0.5, 14.5, Math.max(1, x1 - x0 - 1), c.height - 18);
  }
}
$('mvn').onclick = () => {
  addMove({ id: 'move', label: 'Move ' + (S.moves.length + 1) });
  focusName($('mvb'));
};
$('mvr').onclick = () => {
  const n = S.moves.length;
  if (!n) return;
  if (!confirm('Delete all ' + n + ' move' + (n > 1 ? 's' : '') + '? Undo can bring them back.')) return;
  S.moves = [];
  MI = -1;
  mvSync();
  save();
  buildMoves();
};
let ASEL = 'idle',
  pvOn = false,
  pvT = 0,
  pvLast = 0;
function setDialog(p) {
  S.dialog = MV.Dialog.clean(Object.assign({}, S.dialog, p));
  save();
  buildDialog();
}
function mkClr(lab, val, cb) {
  const l = document.createElement('label'),
    q = document.createElement('input');
  q.type = 'color';
  q.value = val;
  q.onchange = () => cb(q.value);
  l.append(lab, q);
  return l;
}
function buildDialog() {
  const D = MV.Dialog.clean(S.dialog),
    box = $('dlgp');
  if (!box) return;
  box.innerHTML = '';
  box.appendChild(mkText2('Your character name', D.name, v => setDialog({ name: v })));
  box.appendChild(
    mkSel('Box sprite', [['', '(plain box)'], ...S.sheets.map(v => [v.id, v.name])], D.sheet, v =>
      setDialog({ sheet: v })
    )
  );
  {
    const fi = document.createElement('input');
    fi.type = 'file';
    fi.accept = 'image/*';
    fi.onchange = () => {
      const fl = fi.files[0];
      fi.value = '';
      if (!fl) return;
      const fr = new FileReader();
      fr.onload = () => {
        const q = { id: 's' + rid(), name: fl.name.slice(0, 40), url: fr.result, tw: 16, th: 16 };
        S.sheets.push(q);
        setDialog({ sheet: q.id });
      };
      fr.readAsDataURL(fl);
    };
    const il = document.createElement('label');
    il.append('Import box image', fi);
    box.appendChild(il);
  }
  box.appendChild(
    mkNum('Border size (pixels of the image kept as the frame)', D.slice, 1, 64, 1, v => setDialog({ slice: +v }))
  );
  box.appendChild(mkNum('Border scale', D.scale, 1, 6, 1, v => setDialog({ scale: +v })));
  box.appendChild(mkClr('Text colour', D.tcolor, v => setDialog({ tcolor: v })));
  box.appendChild(mkClr('Other characters name colour', D.ncolor, v => setDialog({ ncolor: v })));
  box.appendChild(mkClr('Your name colour', D.pcolor, v => setDialog({ pcolor: v })));
  box.appendChild(mkClr('Plain box colour', D.bcolor, v => setDialog({ bcolor: v })));
  drawDialogPv(D);
}
function mkText2(lab, val, cb) {
  const l = document.createElement('label'),
    q = document.createElement('input');
  q.type = 'text';
  q.value = val;
  q.maxLength = 24;
  q.onchange = () => cb(q.value);
  l.append(lab, q);
  return l;
}
function drawDialogPv(D) {
  const c = $('dlgc');
  if (!c) return;
  const x = c.getContext('2d');
  x.clearRect(0, 0, c.width, c.height);
  x.fillStyle = '#12324a';
  x.fillRect(0, 0, c.width, c.height);
  const t1 = 'Hello there, traveller. Welcome to the wreck.',
    t2 = 'Hi! Can you tell me about this place?';
  const dr = () => {
    MV.Dialog.draw(x, D, sheetOf, { x: 10, y: 8, w: c.width - 20, h: 120 }, 'npc', 'Villager', t1, 999, 1);
    MV.Dialog.draw(x, D, sheetOf, { x: 10, y: 140, w: c.width - 20, h: 120 }, 'me', D.name, t2, 999, 1);
  };
  dr();
  if (D.sheet) {
    const m = sheetOf(D.sheet);
    if (m && !m.img.complete)
      m.img.addEventListener(
        'load',
        () => {
          try {
            drawDialogPv(MV.Dialog.clean(S.dialog));
          } catch (e) {}
        },
        { once: true }
      );
  }
}
