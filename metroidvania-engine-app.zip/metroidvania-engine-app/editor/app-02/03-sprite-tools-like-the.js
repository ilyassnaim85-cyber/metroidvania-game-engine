// ===== Sprite tools, like the tile tools: Place, Pencil, Line, Rectangle, Outline, Ellipse, Ellipse outline, Pick, Select (move, copy, paste, delete, flip) and Erase =====
let SPT = 'place',
  SPSH = null,
  SPSEL = null,
  SPSELD = null,
  SPMV = null,
  SPCLIP = null,
  SPPEN = null,
  SPMIR = false,
  SPFIT = true,
  SPREP = true;
const spCur = () => {
  const e = rc && rc.table[si];
  return e && sheet(e.s) ? e : null;
};
const spMsg = t => {
  const m = $('spmsg');
  if (m) m.textContent = t || '';
};
const spHit = (a, b) => a.x <= b.x1 && a.x + a.w - 1 >= b.x0 && a.y <= b.y1 && a.y + a.h - 1 >= b.y0;
const spBox = (a, b) => ({
  x0: Math.min(a.x, b.x),
  y0: Math.min(a.y, b.y),
  x1: Math.max(a.x, b.x),
  y1: Math.max(a.y, b.y)
});
const spIn = (b, p) => !!b && p.x >= b.x0 && p.x <= b.x1 && p.y >= b.y0 && p.y <= b.y1;
// Puts one sprite with its top-left tile at x,y. A sprite that starts on the same tile is replaced (when Replace is on). Mirror adds the matching one on the other side of the room.
function spPut(x, y, e2, mirror) {
  const put = (px, py) => {
    if (px < 0 || py < 0 || px >= rc.gw || py >= rc.gh) return;
    if (SPREP) {
      for (let i = rc.art.length - 1; i >= 0; i--) if (rc.art[i].x === px && rc.art[i].y === py) rc.art.splice(i, 1);
    } else if (
      rc.art.some(
        a => a.x === px && a.y === py && a.s === e2.s && a.c === e2.c && a.r === e2.r && a.w === e2.w && a.h === e2.h
      )
    )
      return;
    rc.art.push({ x: px, y: py, s: e2.s, c: e2.c, r: e2.r, w: e2.w, h: e2.h });
  };
  put(x, y);
  if (SPMIR && mirror !== false) put(rc.gw - x - e2.w, y);
}
// The tiles where a shape puts sprites. With Fit on they are spaced by the sprite's own size, so a rectangle of 2x2 sprites tiles neatly.
function spCells(a, b, m, e2) {
  const x0 = Math.min(a.x, b.x),
    y0 = Math.min(a.y, b.y),
    x1 = Math.max(a.x, b.x),
    y1 = Math.max(a.y, b.y),
    w = SPFIT ? e2.w : 1,
    h = SPFIT ? e2.h : 1;
  if (m === 'line') {
    const l = shapeCells(a, b, 'line'),
      st = SPFIT ? Math.max(e2.w, e2.h) : 1;
    return l.filter((q, i) => i % st === 0);
  }
  const xs = [],
    ys = [];
  for (let x = x0; x <= x1; x += w) xs.push(x);
  for (let y = y0; y <= y1; y += h) ys.push(y);
  if (xs.length * ys.length > 20000) return [];
  const all = [];
  ys.forEach((y, j) => xs.forEach((x, i) => all.push({ x, y, i, j })));
  if (m === 'rect') return all.map(q => [q.x, q.y]);
  if (m === 'frame')
    return all
      .filter(q => q.i === 0 || q.j === 0 || q.i === xs.length - 1 || q.j === ys.length - 1)
      .map(q => [q.x, q.y]);
  const cx = (x0 + x1 + 1) / 2,
    cy = (y0 + y1 + 1) / 2,
    rx = (x1 - x0 + 1) / 2,
    ry = (y1 - y0 + 1) / 2,
    ins = (x, y) => {
      const dx = (x + w / 2 - cx) / rx,
        dy = (y + h / 2 - cy) / ry;
      return dx * dx + dy * dy <= 1;
    },
    set = new Set(all.filter(q => ins(q.x, q.y)).map(q => q.x + ',' + q.y));
  let out = all.filter(q => set.has(q.x + ',' + q.y));
  if (m === 'ring')
    out = out.filter(
      q =>
        !(
          set.has(q.x - w + ',' + q.y) &&
          set.has(q.x + w + ',' + q.y) &&
          set.has(q.x + ',' + (q.y - h)) &&
          set.has(q.x + ',' + (q.y + h))
        )
    );
  if (!out.length) out = [{ x: x0, y: y0 }];
  return out.map(q => [q.x, q.y]);
}
const spItems = () => (SPSEL ? rc.art.filter(a => spHit(a, SPSEL)) : []);
const spRel = (it, b) => it.map(a => ({ dx: a.x - b.x0, dy: a.y - b.y0, s: a.s, c: a.c, r: a.r, w: a.w, h: a.h }));
function spCopy() {
  const it = spItems();
  if (!it.length) {
    spMsg('Nothing to copy: select some sprites first.');
    return false;
  }
  SPCLIP = { items: spRel(it, SPSEL), w: SPSEL.x1 - SPSEL.x0 + 1, h: SPSEL.y1 - SPSEL.y0 + 1 };
  spMsg('Copied ' + it.length + ' sprite' + (it.length > 1 ? 's' : '') + '.');
  return true;
}
function spDelete() {
  if (!SPSEL) return;
  const it = new Set(spItems());
  if (!it.size) return;
  rc.art = rc.art.filter(a => !it.has(a));
  save();
  drawT();
}
function spFlip(h) {
  if (!SPSEL) return;
  const b = SPSEL,
    it = spItems();
  if (!it.length) return;
  it.forEach(a => {
    if (h) a.x = b.x0 + b.x1 - (a.x + a.w - 1);
    else a.y = b.y0 + b.y1 - (a.y + a.h - 1);
  });
  save();
  drawT();
  spMsg('The layout was flipped; each sprite picture keeps its own direction.');
}
function spStartPaste() {
  if (!SPCLIP) {
    spMsg('Copy some sprites first (select them, then Copy).');
    return;
  }
  SPMV = {
    items: SPCLIP.items,
    w: SPCLIP.w,
    h: SPCLIP.h,
    gp: { x: SPSEL ? SPSEL.x0 : 0, y: SPSEL ? SPSEL.y0 : 0 },
    ox: 0,
    oy: 0,
    paste: true
  };
  drawT();
  spMsg('Click in the room to place the copied sprites. Esc cancels.');
}
function spPlace() {
  if (!SPMV) return;
  const m = SPMV;
  SPMV = null;
  m.items.forEach(q => spPut(m.gp.x + q.dx, m.gp.y + q.dy, q, false));
  SPSEL = { x0: m.gp.x, y0: m.gp.y, x1: m.gp.x + m.w - 1, y1: m.gp.y + m.h - 1 };
  save();
  drawT();
  spMsg('');
}
function spPick(c) {
  for (let i = rc.art.length - 1; i >= 0; i--) {
    const a = rc.art[i];
    if (c.x >= a.x && c.x < a.x + a.w && c.y >= a.y && c.y < a.y + a.h) {
      let k = rc.table.findIndex(t => t.s === a.s && t.c === a.c && t.r === a.r && t.w === a.w && t.h === a.h);
      if (k < 0) {
        rc.table.push({ s: a.s, c: a.c, r: a.r, w: a.w, h: a.h });
        k = rc.table.length - 1;
      }
      si = k;
      drawTable();
      setSpt('place');
      spMsg('Picked that sprite.');
      return;
    }
  }
  spMsg('No sprite there to pick.');
}
function sprDown(e) {
  if (!rc || tool === 'X') return false;
  const c = gcell(e);
  if (e.altKey) {
    spPick(c);
    return true;
  }
  if (!lyOk('scenery', true)) return true;
  if (SPMV && SPMV.paste) {
    SPMV.gp = { x: c.x, y: c.y };
    spPlace();
    return true;
  }
  if (SPT === 'pick') {
    spPick(c);
    return true;
  }
  if (SPT === 'select') {
    if (spIn(SPSEL, c)) {
      const it = spItems();
      if (!it.length) return true;
      SPMV = {
        items: spRel(it, SPSEL),
        orig: rc.art.slice(),
        gp: { x: SPSEL.x0, y: SPSEL.y0 },
        ox: c.x - SPSEL.x0,
        oy: c.y - SPSEL.y0,
        w: SPSEL.x1 - SPSEL.x0 + 1,
        h: SPSEL.y1 - SPSEL.y0 + 1
      };
      rc.art = rc.art.filter(a => !it.includes(a));
      drawT();
    } else {
      SPSELD = { a: c };
      SPSEL = spBox(c, c);
      drawT();
    }
    return true;
  }
  if (SPT === 'place') return false;
  const e2 = spCur();
  if (!e2) {
    spMsg('Choose a sprite in the list first (or Open all sprites to add some).');
    return true;
  }
  if (SPT === 'pencil') {
    SPPEN = { a: c, last: c };
    painting = true;
    spPut(c.x, c.y, e2);
    drawT();
    return true;
  }
  SPSH = { a: c, b: c };
  drawT();
  return true;
}
function sprMove(e) {
  if (SPMV) {
    const c = gcell(e);
    SPMV.gp = { x: c.x - SPMV.ox, y: c.y - SPMV.oy };
    drawT();
    return true;
  }
  if (SPSELD) {
    SPSEL = spBox(SPSELD.a, gcell(e));
    drawT();
    return true;
  }
  if (SPSH) {
    const c = gcell(e);
    if (c.x !== SPSH.b.x || c.y !== SPSH.b.y) {
      SPSH.b = c;
      drawT();
    }
    return true;
  }
  if (SPPEN && painting) {
    const e2 = spCur(),
      c = gcell(e);
    if (!e2) return true;
    shapeCells(SPPEN.last, c, 'line').forEach(q => {
      if (!SPFIT || ((q[0] - SPPEN.a.x) % e2.w === 0 && (q[1] - SPPEN.a.y) % e2.h === 0)) spPut(q[0], q[1], e2);
    });
    SPPEN.last = c;
    drawT();
    return true;
  }
  return false;
}
function sprUp() {
  if (SPSELD) {
    SPSELD = null;
    return true;
  }
  if (SPMV && !SPMV.paste) {
    spPlace();
    return true;
  }
  if (SPSH) {
    const e2 = spCur();
    if (e2) {
      spCells(SPSH.a, SPSH.b, SPT, e2).forEach(q => spPut(q[0], q[1], e2));
      save();
    }
    SPSH = null;
    drawT();
    return true;
  }
  if (SPPEN) {
    SPPEN = null;
    painting = false;
    save();
    return true;
  }
  return false;
}
function sprOverlay(c) {
  if (!rc || (!SPSH && !SPSEL && !SPMV)) return;
  ctx.save();
  ctx.imageSmoothingEnabled = false;
  const draw = (q, x, y, a) => {
    const s = sheet(q.s),
      m = s && img(s);
    ctx.globalAlpha = a;
    if (m && m.complete && m.naturalWidth)
      ctx.drawImage(m, q.c * s.tw, q.r * s.th, q.w * s.tw, q.h * s.th, x * c, y * c, q.w * c, q.h * c);
    else {
      ctx.fillStyle = '#fff';
      ctx.fillRect(x * c, y * c, q.w * c, q.h * c);
    }
    ctx.globalAlpha = 1;
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 1;
    ctx.strokeRect(x * c + 0.5, y * c + 0.5, q.w * c - 1, q.h * c - 1);
  };
  if (SPSH) {
    const e2 = spCur();
    if (e2) spCells(SPSH.a, SPSH.b, SPT, e2).forEach(q => draw(e2, q[0], q[1], 0.6));
  }
  if (SPMV) SPMV.items.forEach(q => draw(q, SPMV.gp.x + q.dx, SPMV.gp.y + q.dy, 0.75));
  if (SPSEL && !SPMV) {
    const x = SPSEL.x0 * c,
      y = SPSEL.y0 * c,
      w = (SPSEL.x1 - SPSEL.x0 + 1) * c,
      h = (SPSEL.y1 - SPSEL.y0 + 1) * c;
    ctx.fillStyle = 'rgba(124,200,255,.12)';
    ctx.fillRect(x, y, w, h);
    ctx.strokeStyle = '#7cc8ff';
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.strokeRect(x, y, w, h);
  }
  ctx.restore();
}
function sprUI() {
  const er = $('erow');
  if (er) {
    er.hidden = tool !== 'X';
    document.querySelectorAll('#erow .shb').forEach(b => b.classList.toggle('on', b.dataset.er === SHAPE));
  }
  document.querySelectorAll('#spshp .spb').forEach(b => b.classList.toggle('on', b.dataset.sp === SPT));
  if ($('spsel')) $('spsel').hidden = SPT !== 'select';
}
function setSpt(t) {
  SPT = t;
  SPSH = null;
  SPSELD = null;
  SPPEN = null;
  if (SPMV && SPMV.orig) rc.art = SPMV.orig;
  SPMV = null;
  if (t !== 'select') SPSEL = null;
  if (t === 'erase') setTool('X');
  else if (tool !== 'S') setTool('S');
  sprUI();
  spMsg('');
  if (rc && V === 'rm') drawT();
}
(() => {
  const host = $('spt'),
    before = $('tb'),
    mkRow = id => {
      const d = document.createElement('div');
      d.className = 'row';
      d.id = id;
      return d;
    };
  const w = mkRow('spshp');
  w.title = 'How the sprite tools place sprites.';
  [
    ['place', 'Place', 'Click to place one sprite.'],
    ['pencil', 'Pencil', 'Drag to place sprites along the path.'],
    ['line', 'Line', 'Drag to place sprites along a straight line.'],
    ['rect', 'Rectangle', 'Drag to fill a rectangle with the chosen sprite.'],
    ['frame', 'Outline', 'Drag to place sprites around a rectangle.'],
    ['ellipse', 'Ellipse', 'Drag a box to fill an ellipse inside it.'],
    ['ring', 'Ellipse outline', 'Drag a box to place sprites around an ellipse.'],
    [
      'pick',
      'Pick sprite',
      'Click a placed sprite in the room to choose it as your brush. Hold Alt with any tool to do the same.'
    ],
    [
      'select',
      'Select',
      'Drag over sprites to select them, then move them (drag inside), Copy, Cut, Paste, Delete or Flip.'
    ]
  ].forEach(t => {
    const b = document.createElement('button');
    b.className = 'spb' + (t[0] === 'place' ? ' on' : '');
    b.dataset.sp = t[0];
    b.textContent = t[1];
    b.title = t[2];
    b.onclick = () => setSpt(t[0]);
    w.appendChild(b);
  });
  const opt = (txt, title, init, fn) => {
    const l = document.createElement('label'),
      c = document.createElement('input');
    l.title = title;
    c.type = 'checkbox';
    c.checked = init;
    c.onchange = () => fn(c.checked);
    l.append(c, ' ' + txt);
    w.appendChild(l);
  };
  opt(
    'Fit to sprite size',
    'Line, rectangle, outline and ellipse space the sprites by their own size so they sit side by side. Off: one sprite on every tile.',
    true,
    v => {
      SPFIT = v;
    }
  );
  opt('Replace', 'A sprite placed where another one starts replaces it. Off: they stack.', true, v => {
    SPREP = v;
  });
  opt('Mirror left-right', 'Every sprite you place is also placed on the other side of the room.', false, v => {
    SPMIR = v;
  });
  const s = mkRow('spsel');
  s.hidden = true;
  [
    ['Copy', () => spCopy(), 'Copy the selected sprites (Ctrl+C).'],
    [
      'Cut',
      () => {
        if (spCopy()) spDelete();
      },
      'Copy and remove (Ctrl+X).'
    ],
    ['Paste', spStartPaste, 'Click in the room to place the copied sprites (Ctrl+V).'],
    ['Delete', spDelete, 'Remove the selected sprites (Delete).'],
    ['Flip left-right', () => spFlip(true), 'Mirror the layout of the selected sprites.'],
    ['Flip up-down', () => spFlip(false), 'Turn the layout of the selected sprites upside down.'],
    [
      'Deselect',
      () => {
        SPSEL = null;
        SPMV = null;
        drawT();
      },
      'Clear the selection (Esc).'
    ]
  ].forEach(t => {
    const b = document.createElement('button');
    b.textContent = t[0];
    b.title = t[2];
    b.onclick = t[1];
    s.appendChild(b);
  });
  const m = document.createElement('span');
  m.className = 'hint';
  m.id = 'spmsg';
  host.insertBefore(w, before);
  host.insertBefore(s, before);
  host.insertBefore(m, before);
})();
