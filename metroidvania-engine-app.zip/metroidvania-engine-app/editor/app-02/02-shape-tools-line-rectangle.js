// ---- shape tools: Line, Rectangle, Outline and Fill for the terrain tiles, and room flipping ----
let SHAPE = 'pencil',
  SH = null;
const GT = MV.Tiles.PALETTE.map(p => p[1])
  .filter(c => c !== 'D')
  .join(''); // the tiles the line, rectangle, outline and fill tools can draw
const gcell = e => {
  const r = rr(),
    x = Math.floor(((e.clientX - r.left) / r.width) * rc.gw),
    y = Math.floor(((e.clientY - r.top) / r.height) * rc.gh);
  return { x: Math.max(0, Math.min(rc.gw - 1, x)), y: Math.max(0, Math.min(rc.gh - 1, y)) };
};
function shapeCells(a, b, m) {
  const out = [],
    x0 = Math.min(a.x, b.x),
    x1 = Math.max(a.x, b.x),
    y0 = Math.min(a.y, b.y),
    y1 = Math.max(a.y, b.y);
  if ((m === 'rect' || m === 'frame' || m === 'ellipse' || m === 'ring') && (x1 - x0 + 1) * (y1 - y0 + 1) > 1500000)
    return out;
  if (m === 'rect' || m === 'frame') {
    for (let y = y0; y <= y1; y++)
      for (let x = x0; x <= x1; x++) if (m === 'rect' || x === x0 || x === x1 || y === y0 || y === y1) out.push([x, y]);
  } else if (m === 'ramp') {
    if (a.x === b.x) return out;
    const L = a.x < b.x ? a : b,
      R = a.x < b.x ? b : a,
      up = R.y < L.y,
      w = R.x - L.x + 1,
      gentle = Math.abs(R.y - L.y) * 1.5 < w - 1; // steep (one up per tile across) or gentle (one up per two tiles), with the right pieces
    for (let i = 0; i < w; i++) {
      const j = gentle ? Math.floor(i / 2) : i,
        y = up ? L.y - j : L.y + j,
        x = L.x + i,
        ch = gentle ? (up ? (i % 2 ? ']' : '[') : i % 2 ? '}' : '{') : up ? '/' : '\\';
      if (y < 0 || y >= rc.gh) continue;
      out.push([x, y, ch]);
      if (RFILL)
        for (let yy = y + 1; yy < rc.gh && yy - y < 400; yy++) {
          if (rc.grid[yy][x] !== '.') break;
          out.push([x, yy, '#']);
        }
    }
  } else if (m === 'ellipse' || m === 'ring') {
    const rx = (x1 - x0 + 1) / 2,
      ry = (y1 - y0 + 1) / 2,
      mx = x0 + rx,
      my = y0 + ry,
      ins = (x, y) => {
        const dx = (x + 0.5 - mx) / rx,
          dy = (y + 0.5 - my) / ry;
        return dx * dx + dy * dy <= 1;
      };
    if (rx * ry * 4 > 1500000) return out;
    for (let y = y0; y <= y1; y++)
      for (let x = x0; x <= x1; x++)
        if (ins(x, y) && (m === 'ellipse' || !(ins(x - 1, y) && ins(x + 1, y) && ins(x, y - 1) && ins(x, y + 1))))
          out.push([x, y]);
  } else {
    let x = a.x,
      y = a.y;
    const dx = Math.abs(b.x - a.x),
      dy = -Math.abs(b.y - a.y),
      sx = a.x < b.x ? 1 : -1,
      sy = a.y < b.y ? 1 : -1;
    let er = dx + dy;
    for (;;) {
      out.push([x, y]);
      if (x === b.x && y === b.y) break;
      const e2 = 2 * er;
      if (e2 >= dy) {
        er += dy;
        x += sx;
      }
      if (e2 <= dx) {
        er += dx;
        y += sy;
      }
    }
  }
  return out;
}
function fillFrom(x, y) {
  const g = rc.grid,
    t = g[y][x];
  if (t === tool) return [];
  const out = [],
    seen = new Set(),
    st = [[x, y]];
  while (st.length) {
    if (out.length > 1500000) {
      alert('That area is too big to fill in one go (over 1.5 million tiles). Use Rectangle on a smaller part.');
      return [];
    }
    const q = st.pop(),
      cx = q[0],
      cy = q[1];
    if (cx < 0 || cy < 0 || cx >= rc.gw || cy >= rc.gh) continue;
    const k = cy * rc.gw + cx;
    if (seen.has(k) || g[cy][cx] !== t) continue;
    seen.add(k);
    out.push([cx, cy]);
    st.push([cx + 1, cy], [cx - 1, cy], [cx, cy + 1], [cx, cy - 1]);
  }
  return out;
}
// Erase (sprites): removes every sprite that covers one of the cells. Works with the pencil brush size, line, rectangle, outline, ellipse and mirror like the tile tools.
function eraseCells(cells) {
  if (!lyOk('scenery')) return;
  const list = MIR ? cells.concat(cells.map(q => [rc.gw - 1 - q[0], q[1]])) : cells,
    n = rc.art.length;
  rc.art = rc.art.filter(a => !list.some(q => q[0] >= a.x && q[0] < a.x + a.w && q[1] >= a.y && q[1] < a.y + a.h));
  if (rc.art.length !== n) drawT();
}
function applyCells(cells) {
  if (tool === 'X') {
    eraseCells(cells);
    return;
  }
  if (!lyOk(lyOf(tool))) return;
  const g = rc.grid;
  let any = false;
  const list =
    MIR && tool !== 'D' ? cells.concat(cells.map(q => [rc.gw - 1 - q[0], q[1], MV.Tiles.mirror(q[2] || tool)])) : cells;
  for (const q of list) {
    const x = q[0],
      y = q[1],
      ch = q[2] || tool;
    if (x < 0 || y < 0 || x >= rc.gw || y >= rc.gh) continue;
    const old = g[y][x];
    if (old === ch) continue;
    if ((old === 'D' && !LY.objects.v) || (old === 'D' && LY.objects.l)) continue;
    if (old === 'D') rc.tr = rc.tr.filter(t => !(t.x === x && t.y === y));
    g[y] = g[y].slice(0, x) + ch + g[y].slice(x + 1);
    any = true;
  }
  if (any) {
    drawT();
    drawTr();
  }
}
function shapePreview() {
  if (!SH) return;
  const c = rr().width / rc.gw;
  ctx.save();
  ctx.fillStyle = 'rgba(255,255,255,.4)';
  ctx.strokeStyle = '#fff';
  shapeCells(SH.a, SH.b, SHAPE).forEach(q => {
    ctx.fillRect(q[0] * c, q[1] * c, c, c);
    ctx.strokeRect(q[0] * c + 0.5, q[1] * c + 0.5, c - 1, c - 1);
  });
  ctx.restore();
}
let BR = 1,
  MIR = false,
  RFILL = true,
  SEL = null,
  SELD = null,
  CLIP = null,
  PASTE = false,
  GP = { x: 0, y: 0 },
  MOVE = null;
const tileMode = () => GT.includes(tool);
const brushCells = (x, y) => {
  const o = Math.floor((BR - 1) / 2),
    out = [];
  for (let j = 0; j < BR; j++) for (let i = 0; i < BR; i++) out.push([x - o + i, y - o + j]);
  return out;
};
function setShape(s) {
  SHAPE = s;
  SH = null;
  PASTE = false;
  MOVE = null;
  SELD = null;
  if (s !== 'select') SEL = null;
  document.querySelectorAll('#shp .shb').forEach(q => q.classList.toggle('on', q.dataset.sh === s));
  $('tsel').hidden = s !== 'select';
  if (rc && V === 'rm') drawT();
}
function pickAt(c) {
  const ch = rc.grid[c.y][c.x];
  if (MV.Tiles.PALETTE.some(p => p[1] === ch)) {
    LASTTILE = ch;
    setTool(ch);
  }
  if (SHAPE === 'pick') setShape('pencil');
}
// Replace all: every tile like the one clicked (in the whole room, or only inside the selection) becomes the chosen tile.
function replaceAll(c) {
  if (!lyOk('tiles')) return;
  const g = rc.grid,
    old = g[c.y][c.x],
    nw = tool;
  if (old === nw || nw === 'D') return;
  const full = !SEL,
    x0 = full ? 0 : SEL.x0,
    x1 = full ? rc.gw - 1 : SEL.x1,
    y0 = full ? 0 : SEL.y0,
    y1 = full ? rc.gh - 1 : SEL.y1;
  let n = 0,
    lastIn = null,
    lastOut = null;
  for (let y = y0; y <= y1; y++) {
    const r = g[y];
    if (x0 === 0 && x1 === rc.gw - 1) {
      if (r === lastIn) {
        g[y] = lastOut;
        continue;
      }
      lastIn = r;
      if (r.indexOf(old) < 0) {
        lastOut = r;
        continue;
      }
      lastOut = r.split(old).join(nw);
      g[y] = lastOut;
      n++;
    } else {
      const seg = r.slice(x0, x1 + 1);
      if (seg.indexOf(old) < 0) continue;
      g[y] = r.slice(0, x0) + seg.split(old).join(nw) + r.slice(x1 + 1);
      n++;
    }
  }
  if (old === 'D') rc.tr = rc.tr.filter(t => !(t.x >= x0 && t.x <= x1 && t.y >= y0 && t.y <= y1));
  if (n) {
    drawT();
    drawTr();
    save();
  }
}
// Selection: drag a box; drag inside it to move it; copy, cut, paste, flip, fill and delete. Only tiles are copied (not entities, sprites or doorways).
const normBox = (a, b) => ({
  x0: Math.min(a.x, b.x),
  y0: Math.min(a.y, b.y),
  x1: Math.max(a.x, b.x),
  y1: Math.max(a.y, b.y)
});
const inSel = c => !!SEL && c.x >= SEL.x0 && c.x <= SEL.x1 && c.y >= SEL.y0 && c.y <= SEL.y1;
function selCopy() {
  if (!SEL) return false;
  const rows = [];
  for (let y = SEL.y0; y <= SEL.y1; y++) rows.push(rc.grid[y].slice(SEL.x0, SEL.x1 + 1).replace(/D/g, '.'));
  CLIP = { w: SEL.x1 - SEL.x0 + 1, h: rows.length, rows };
  return true;
}
function selSet(ch) {
  for (let y = SEL.y0; y <= SEL.y1; y++) {
    const r = rc.grid[y];
    rc.grid[y] = r.slice(0, SEL.x0) + ch.repeat(SEL.x1 - SEL.x0 + 1) + r.slice(SEL.x1 + 1);
  }
  rc.tr = rc.tr.filter(t => !(t.x >= SEL.x0 && t.x <= SEL.x1 && t.y >= SEL.y0 && t.y <= SEL.y1));
}
function selDelete() {
  if (!SEL || !lyOk('tiles')) return;
  selSet('.');
  drawT();
  drawTr();
  save();
}
function selFill() {
  if (!SEL || tool === 'D' || !tileMode()) return;
  selSet(tool);
  drawT();
  drawTr();
  save();
}
function selFlip(horiz) {
  if (!SEL) return;
  const hh = SEL.y1 - SEL.y0 + 1,
    seg = [];
  for (let y = SEL.y0; y <= SEL.y1; y++) seg.push(rc.grid[y].slice(SEL.x0, SEL.x1 + 1));
  const out = horiz ? seg.map(s => s.split('').reverse().map(MV.Tiles.mirror).join('')) : seg.slice().reverse();
  for (let j = 0; j < hh; j++) {
    const y = SEL.y0 + j,
      r = rc.grid[y];
    rc.grid[y] = r.slice(0, SEL.x0) + out[j] + r.slice(SEL.x1 + 1);
  }
  rc.tr = rc.tr.map(t => {
    if (t.x < SEL.x0 || t.x > SEL.x1 || t.y < SEL.y0 || t.y > SEL.y1) return t;
    return horiz ? { ...t, x: SEL.x0 + SEL.x1 - t.x } : { ...t, y: SEL.y0 + SEL.y1 - t.y };
  });
  drawT();
  drawTr();
  save();
}
function startPaste() {
  if (!CLIP) return;
  PASTE = true;
  MOVE = null;
  drawT();
  pasteGhost();
}
function pasteGhost() {
  if (!PASTE || !CLIP) return;
  const c = rr().width / rc.gw;
  ctx.save();
  ctx.globalAlpha = 0.65;
  for (let j = 0; j < CLIP.h; j++)
    for (let i = 0; i < CLIP.w; i++) {
      const ch = CLIP.rows[j][i];
      if (ch === '.') continue;
      if (!MV.Tiles.draw(ctx, ch, (GP.x + i) * c, (GP.y + j) * c, c, { edit: true, tx: GP.x + i, ty: GP.y + j })) {
        ctx.fillStyle = '#8aa';
        ctx.fillRect((GP.x + i) * c, (GP.y + j) * c, c, c);
      }
    }
  ctx.globalAlpha = 1;
  ctx.strokeStyle = '#ffd24a';
  ctx.lineWidth = 2;
  ctx.strokeRect(GP.x * c, GP.y * c, CLIP.w * c, CLIP.h * c);
  ctx.restore();
}
function placePaste() {
  if (!PASTE || !CLIP) return;
  if (!lyOk('tiles')) {
    PASTE = false;
    MOVE = null;
    drawT();
    return;
  }
  const ow = $('pe').checked && !MOVE;
  for (let j = 0; j < CLIP.h; j++) {
    const y = GP.y + j;
    if (y < 0 || y >= rc.gh) continue;
    let r = rc.grid[y];
    for (let i = 0; i < CLIP.w; i++) {
      const x = GP.x + i;
      if (x < 0 || x >= rc.gw) continue;
      const ch = CLIP.rows[j][i];
      if (ch === '.' && !ow) continue;
      if (r[x] === ch) continue;
      if (r[x] === 'D') rc.tr = rc.tr.filter(t => !(t.x === x && t.y === y));
      r = r.slice(0, x) + ch + r.slice(x + 1);
    }
    rc.grid[y] = r;
  }
  PASTE = false;
  MOVE = null;
  SEL = {
    x0: Math.max(0, GP.x),
    y0: Math.max(0, GP.y),
    x1: Math.min(rc.gw - 1, GP.x + CLIP.w - 1),
    y1: Math.min(rc.gh - 1, GP.y + CLIP.h - 1)
  };
  drawT();
  drawTr();
  save();
}
function selOverlay(c) {
  if (!SEL || !rc) return;
  ctx.save();
  const x = SEL.x0 * c,
    y = SEL.y0 * c,
    w = (SEL.x1 - SEL.x0 + 1) * c,
    h = (SEL.y1 - SEL.y0 + 1) * c;
  if (!PASTE) {
    ctx.fillStyle = 'rgba(255,210,74,.12)';
    ctx.fillRect(x, y, w, h);
  }
  ctx.strokeStyle = '#ffd24a';
  ctx.lineWidth = 2;
  ctx.setLineDash([6, 4]);
  ctx.strokeRect(x, y, w, h);
  ctx.restore();
}
addEventListener('keydown', e => {
  if (
    TAB !== 'world' ||
    V !== 'rm' ||
    !rc ||
    inText(e.target) ||
    /^(INPUT|TEXTAREA|SELECT)$/.test(String(e.target && e.target.tagName))
  )
    return;
  if ((e.ctrlKey || e.metaKey) && !e.altKey) {
    const k = e.key.toLowerCase();
    if (k === 'c' && SEL) {
      e.preventDefault();
      selCopy();
    } else if (k === 'x' && SEL) {
      e.preventDefault();
      selCopy();
      selDelete();
    } else if (k === 'v' && CLIP && tileMode()) {
      e.preventDefault();
      if (SHAPE !== 'select') setShape('select');
      startPaste();
    }
    return;
  }
  if (e.key === 'Escape') {
    if (PASTE && MOVE) {
      GP = { x: SEL.x0, y: SEL.y0 };
      placePaste();
    } else if (PASTE) {
      PASTE = false;
      drawT();
    } else if (SEL) {
      SEL = null;
      drawT();
    }
  } else if ((e.key === 'Delete' || e.key === 'Backspace') && SEL && SHAPE === 'select') {
    e.preventDefault();
    selDelete();
  }
});
// The tool row: Pencil, Line, Rectangle, Outline, Ellipse, Ellipse outline, Fill, Replace all, Pick tile, Select; then brush size and mirror drawing.
[
  ['pencil', 'Pencil', 'Draw tiles by dragging. Hold Alt and click a tile to pick it up as your brush.'],
  ['line', 'Line', 'Drag to draw a straight line.'],
  ['rect', 'Rectangle', 'Drag to fill a rectangle.'],
  ['frame', 'Outline', 'Drag to draw a rectangle outline.'],
  ['ellipse', 'Ellipse', 'Drag a box to fill an ellipse inside it.'],
  ['ring', 'Ellipse outline', 'Drag a box to draw an ellipse outline inside it.'],
  [
    'ramp',
    'Ramp',
    'Drag from one end of a slope to the other. It picks steep or gentle slope pieces for you (shallow drags make gentle slopes) and can fill the ground under it.'
  ],
  ['fill', 'Fill', 'Click an area to fill it with the chosen tile.'],
  [
    'replace',
    'Replace all',
    'Click a tile: every tile like it in the room (or inside the selection) becomes the chosen tile.'
  ],
  ['pick', 'Pick tile', 'Click a tile in the room to choose it as your brush. Hold Alt with any tool to do the same.'],
  [
    'select',
    'Select',
    'Drag to select tiles. Drag inside the selection to move it. Copy, cut, paste, flip, fill and delete with the buttons or Ctrl+C, Ctrl+X, Ctrl+V and Delete.'
  ]
].forEach(a => {
  const b = document.createElement('button');
  b.className = 'shb' + (a[0] === 'pencil' ? ' on' : '');
  b.dataset.sh = a[0];
  b.textContent = a[1];
  b.title = a[2];
  b.onclick = () => setShape(a[0]);
  $('shp').appendChild(b);
});
{
  const l = document.createElement('label');
  l.title = 'How many tiles wide the pencil is.';
  l.append('Brush ');
  const s = document.createElement('select');
  s.id = 'brs';
  [1, 2, 3, 4, 5, 7, 9].forEach(n => {
    const o = document.createElement('option');
    o.value = n;
    o.textContent = n + 'x' + n;
    s.appendChild(o);
  });
  s.onchange = () => {
    BR = +s.value || 1;
  };
  l.appendChild(s);
  $('shp').appendChild(l);
  const m = document.createElement('label');
  m.title = 'Everything you draw is mirrored across the middle of the room (slopes and belts flip too).';
  const mc = document.createElement('input');
  mc.type = 'checkbox';
  mc.id = 'mir';
  mc.onchange = () => {
    MIR = mc.checked;
  };
  m.append(mc, ' Mirror left-right');
  $('shp').appendChild(m);
}
{
  const l = document.createElement('label');
  l.title = 'Ramp tool: also fill the empty tiles under the slope with walls.';
  const c = document.createElement('input');
  c.type = 'checkbox';
  c.checked = true;
  c.id = 'rfill';
  c.onchange = () => {
    RFILL = c.checked;
  };
  l.append(c, ' Fill under ramps');
  $('shp').appendChild(l);
  const fb = document.createElement('button');
  fb.textContent = 'Frame room';
  fb.title = 'Draw the chosen tile (wall if none) all around the edge of the room.';
  fb.onclick = () => {
    if (!rc) return;
    const ch = GT.includes(tool) && tool !== '.' ? tool : '#',
      cells = [];
    for (let x = 0; x < rc.gw; x++) {
      cells.push([x, 0, ch], [x, rc.gh - 1, ch]);
    }
    for (let y = 1; y < rc.gh - 1; y++) {
      cells.push([0, y, ch], [rc.gw - 1, y, ch]);
    }
    applyCells(cells);
    save();
  };
  $('shp').appendChild(fb);
}
{
  const B = (t, f, title) => {
    const b = document.createElement('button');
    b.textContent = t;
    if (title) b.title = title;
    b.onclick = f;
    $('tsel').appendChild(b);
    return b;
  };
  B(
    'Copy',
    () => {
      selCopy();
    },
    'Copy the selected tiles (Ctrl+C).'
  );
  B(
    'Cut',
    () => {
      if (selCopy()) selDelete();
    },
    'Copy and clear the selection (Ctrl+X).'
  );
  B('Paste', () => startPaste(), 'Click in the room to place the copied tiles (Ctrl+V).');
  B('Delete', selDelete, 'Clear the selection (Delete).');
  B('Fill with tile', selFill, 'Fill the selection with the chosen tile.');
  B('Flip left-right', () => selFlip(true), 'Mirror the selected tiles left to right.');
  B('Flip up-down', () => selFlip(false), 'Turn the selected tiles upside down.');
  B(
    'Deselect',
    () => {
      SEL = null;
      PASTE = false;
      MOVE = null;
      if (rc && V === 'rm') drawT();
    },
    'Clear the selection (Esc).'
  );
  const l = document.createElement('label');
  l.title = 'Off: pasting leaves what is already there where the copy is empty.';
  const c = document.createElement('input');
  c.type = 'checkbox';
  c.id = 'pe';
  l.append(c, ' Paste empty tiles too');
  $('tsel').appendChild(l);
  const hn = document.createElement('span');
  hn.className = 'hint';
  hn.textContent = 'Drag to select. Drag inside the selection to move it.';
  $('tsel').appendChild(hn);
}
function flipRoom(h) {
  if (!lyOk('tiles') || !lyOk('scenery') || !lyOk('objects')) return;
  const W = rc.gw,
    H = rc.gh;
  if (h) {
    rc.grid = rc.grid.map(r => r.split('').reverse().map(MV.Tiles.mirror).join(''));
    rc.tr = rc.tr.map(t => ({ ...t, x: W - 1 - t.x }));
    rc.art = rc.art.map(a => ({ ...a, x: W - a.x - a.w }));
  } else {
    rc.grid = rc.grid.slice().reverse();
    rc.tr = rc.tr.map(t => ({ ...t, y: H - 1 - t.y }));
    rc.art = rc.art.map(a => ({ ...a, y: H - a.y - a.h }));
  }
  const E = MV.data.entities;
  rc.ent.forEach(e => {
    const d = E[e.type] || {},
      p = e.props || (e.props = {}),
      w = [
        'breakable',
        'collapse',
        'conveyor',
        'secret',
        'spring',
        'hazard',
        'stickwall',
        'dashpad',
        'current',
        'lowgrav',
        'msgzone',
        'blink',
        'icezone',
        'mudzone'
      ].includes(e.type)
        ? Math.max(1, Math.round(+p.width || d.w || 1))
        : 1,
      hh = [
        'breakable',
        'collapse',
        'secret',
        'ladder',
        'stickwall',
        'current',
        'lowgrav',
        'msgzone',
        'blink',
        'icezone',
        'mudzone'
      ].includes(e.type)
        ? Math.max(1, Math.round(+p.height || (e.type === 'ladder' ? 3 : 1)))
        : 1;
    if (h) {
      e.x = W - e.x - w;
      if (p.pts) p.pts = p.pts.map(q => [-q[0], q[1]]);
      if (e.type === 'platform' && p.dx !== undefined) p.dx = -p.dx;
      if (e.type === 'conveyor') p.speed = -(+p.speed || 0);
      if ((e.type === 'dashpad' || e.type === 'current') && p.dir)
        p.dir = { right: 'left', left: 'right' }[p.dir] || p.dir;
    } else {
      e.y = H - 1 - e.y + hh - 1;
      if (p.pts) p.pts = p.pts.map(q => [q[0], -q[1]]);
      if (e.type === 'platform' && p.dy !== undefined) p.dy = -p.dy;
      if ((e.type === 'dashpad' || e.type === 'stickwall' || e.type === 'current') && p.dir)
        p.dir = { up: 'down', down: 'up' }[p.dir] || p.dir;
    }
  });
  drawT();
  drawTr();
  drawEn();
  save();
}
$('mfx').onclick = () => {
  if (rc) flipRoom(true);
};
$('mfy').onclick = () => {
  if (rc) flipRoom(false);
};
