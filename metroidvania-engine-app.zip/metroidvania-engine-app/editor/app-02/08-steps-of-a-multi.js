// ===== Steps of a multi-step move, and the extras shared by moves and attacks (chain, charge, shots, effects) =====
function seqVel(m, s) {
  let t = 0;
  for (const q of m.steps) {
    t += q.dur;
    if (s < t) return q.vx;
  }
  return 0;
}
function fieldNum(host, lab, val, min, max, step, cb, tip) {
  const l = mkNum(lab, val, min, max, step, v => cb(+v));
  if (tip) l.title = tip;
  host.appendChild(l);
}
function stepsUI(B0, m, ch) {
  const sh = document.createElement('strong');
  sh.textContent = 'Steps';
  B0.appendChild(sh);
  const hp = document.createElement('p');
  hp.className = 'hint';
  hp.textContent =
    'Each step runs for its Length, or less if its "Ends when" happens. Forward speed is along the way the player faces; Up/down speed is negative to go up. Gravity 0 holds the vertical speed exactly; above 0 the player arcs. Steering lets you add left/right control (0 none, 1 full). Total length: ' +
    m.duration +
    ' s.';
  B0.appendChild(hp);
  m.steps.forEach((q, i) => {
    const d = document.createElement('div');
    d.className = 'mv';
    const h = document.createElement('strong');
    h.textContent = i + 1 + '. ' + q.name;
    d.appendChild(h);
    const f = document.createElement('div');
    f.className = 'mvf';
    f.appendChild(
      mkText('Name', q.name, v =>
        ch(x => {
          x.steps[i].name = v;
        })
      )
    );
    fieldNum(f, 'Length (s)', q.dur, 0.02, 3, 0.01, v =>
      ch(x => {
        x.steps[i].dur = v;
      })
    );
    fieldNum(f, 'Forward speed (tiles/s)', q.vx, -80, 80, 0.5, v =>
      ch(x => {
        x.steps[i].vx = v;
      })
    );
    fieldNum(f, 'Up/down speed (negative = up)', q.vy, -80, 80, 0.5, v =>
      ch(x => {
        x.steps[i].vy = v;
      })
    );
    fieldNum(f, 'Speeds up (tiles/s each second)', q.accel, -300, 300, 1, v =>
      ch(x => {
        x.steps[i].accel = v;
      })
    );
    fieldNum(f, 'Gravity x', q.gravity, 0, 3, 0.05, v =>
      ch(x => {
        x.steps[i].gravity = v;
      })
    );
    fieldNum(f, 'Steering (0 to 1)', q.steer, 0, 1, 0.05, v =>
      ch(x => {
        x.steps[i].steer = v;
      })
    );
    f.appendChild(
      mkSel(
        'Goes',
        [
          ['forward', 'the way you face'],
          ['input', 'the way you hold the arrow keys (8 directions) when the step starts']
        ],
        q.aim || 'forward',
        v =>
          ch(x => {
            x.steps[i].aim = v;
          })
      )
    );
    f.appendChild(
      mkSel(
        'Ends when',
        [
          ['jump', 'you press jump'],
          ['time', 'its length is up'],
          ['land', 'you land (counts once you are in the air)'],
          ['wall', 'you hit a wall'],
          ['ceiling', 'you hit a ceiling'],
          ['release', 'you let go of the key']
        ],
        q.until,
        v =>
          ch(x => {
            x.steps[i].until = v;
          })
      )
    );
    d.appendChild(f);
    const r = document.createElement('div');
    r.className = 'row';
    if (i > 0)
      r.appendChild(
        btn('Move up', () =>
          ch(x => {
            const t = x.steps[i];
            x.steps[i] = x.steps[i - 1];
            x.steps[i - 1] = t;
          })
        )
      );
    if (i < m.steps.length - 1)
      r.appendChild(
        btn('Move down', () =>
          ch(x => {
            const t = x.steps[i];
            x.steps[i] = x.steps[i + 1];
            x.steps[i + 1] = t;
          })
        )
      );
    if (m.steps.length < 8)
      r.appendChild(
        btn('Duplicate step', () =>
          ch(x => {
            x.steps.splice(i + 1, 0, JSON.parse(JSON.stringify(x.steps[i])));
          })
        )
      );
    if (m.steps.length > 1)
      r.appendChild(
        btn('Remove step', () =>
          ch(x => {
            x.steps.splice(i, 1);
          })
        )
      );
    d.appendChild(r);
    B0.appendChild(d);
  });
  B0.appendChild(
    btn('Add step', () => {
      if (m.steps.length >= 8) {
        $('pmsg').textContent = 'Up to 8 steps.';
        return;
      }
      ch(x => {
        x.steps.push({
          name: 'Step ' + (x.steps.length + 1),
          dur: 0.2,
          vx: 0,
          vy: 0,
          gravity: 1,
          steer: 0,
          accel: 0,
          aim: 'forward',
          until: 'time'
        });
      });
    })
  );
}
const FX_ON = [
  ['start', 'the move starts'],
  ['hit', 'it hits something'],
  ['land', 'the player lands'],
  ['wall', 'the player hits a wall'],
  ['end', 'the move ends'],
  ['charged', 'the charge time is complete (held moves)']
];
const FX_DO = [
  ['bounce', 'Bounce up (value = speed, a pogo)'],
  ['refill', 'Refill uses and cooldowns'],
  ['slow', 'Slow time (value 0.1 to 1)'],
  ['teleport', 'Teleport forward (value = tiles)'],
  ['knock', 'Push back (value = speed)'],
  ['heal', 'Heal (value = health)'],
  ['endmove', 'End the move early'],
  ['sound', 'Play a sound (pick it below)'],
  ['energy', 'Give energy (value, negative spends it)']
];
function extrasUI(host, o, isA, ch) {
  const h = document.createElement('strong');
  h.textContent = 'Chain, charge, shots and effects';
  host.appendChild(h);
  const hp = document.createElement('p');
  hp.className = 'hint';
  hp.textContent =
    "Chain: press the next move or attack's key near the end of this one (or right after) to continue into it, even if it is on cooldown (a combo). Charge: hold the key to charge, release to fire; charging up to the max time gives the full damage multiplier and faster shots. Shots: things that fly out with their own attack box. Effects: do something when an event happens.";
  host.appendChild(hp);
  {
    const dt = document.createElement('details');
    dt.innerHTML =
      '<summary>I do not understand this section: what are chain, charge, shots and effects?</summary><div class="hint"><p><b>Chain (combo)</b>: makes one move or attack lead into another. Example: on "Slash 1" choose <i>Continues into: Attack: Slash 2</i>. Press Slash 2\'s key just before Slash 1 ends and Slash 2 plays right away, even if it is on cooldown.</p><p><b>Charge</b>: hold the key to wind up, let go to fire. Example: Charge 1.5 s and Full charge damage x 3 means a full wind-up hits three times harder (and shots fly faster). Leave Charge at 0 for no charging.</p><p><b>Shots</b>: things that fly out of the player on their own, each with its own box, speed and damage. Example: a fireball is one shot with Speed 15, Damage 2, Fires at 0.1 s. Fires at is when, in seconds after the move starts, it is thrown. Starts forward / up are where it appears next to the player.</p><p><b>Effects</b>: "When something happens, do this". Example: <i>When: hits, Do: bounce, Value: 12</i> makes a downward slash bounce you up off enemies (a pogo). <i>When: starts, Do: sound</i> plays a sound. <i>When: end, Do: refill</i> gives your dashes back.</p></div>';
    host.appendChild(dt);
  }
  const opts = [['', '(none)']].concat(
    S.moves
      .filter(q => q !== o && q.type !== 'hold' && q.type !== 'swim' && q.type !== 'surface')
      .map(q => ['m:' + q.id, 'Move: ' + q.label]),
    S.attacks.filter(q => q !== o).map(q => ['a:' + q.id, 'Attack: ' + q.label])
  );
  const g = document.createElement('div');
  g.className = 'mvf';
  g.appendChild(
    mkSel('Continues into (chain)', opts, o.chainTo, v =>
      ch(x => {
        x.chainTo = v;
      })
    )
  );
  fieldNum(
    g,
    'Chain window (s)',
    o.chainWin,
    0.05,
    2,
    0.05,
    v =>
      ch(x => {
        x.chainWin = v;
      }),
    'How long before the end and after it the next key still counts.'
  );
  fieldNum(g, 'Charge up to (s, 0 = no charging)', o.charge, 0, 5, 0.1, v =>
    ch(x => {
      x.charge = v;
    })
  );
  fieldNum(g, 'Full charge damage x', o.chargeMult, 1, 10, 0.1, v =>
    ch(x => {
      x.chargeMult = v;
    })
  );
  g.appendChild(
    mkSel(
      'Hold still while charging',
      [
        ['no', 'No'],
        ['yes', 'Yes']
      ],
      o.chargeLock,
      v =>
        ch(x => {
          x.chargeLock = v;
        })
    )
  );
  host.appendChild(g);
  const sh = document.createElement('strong');
  sh.textContent = 'Shots (' + o.shots.length + ')';
  host.appendChild(sh);
  o.shots.forEach((q, i) => {
    const d = document.createElement('div');
    d.className = 'mv';
    const f = document.createElement('div');
    f.className = 'mvf';
    f.appendChild(
      mkText('Name', q.name, v =>
        ch(x => {
          x.shots[i].name = v;
        })
      )
    );
    fieldNum(f, 'Fires at (s)', q.at, 0, o.duration, 0.01, v =>
      ch(x => {
        x.shots[i].at = v;
      })
    );
    f.appendChild(
      mkSel(
        'Shape',
        [
          ['rect', 'Rectangle'],
          ['circle', 'Circle']
        ],
        q.shape,
        v =>
          ch(x => {
            x.shots[i].shape = v;
          })
      )
    );
    if (q.shape === 'circle')
      fieldNum(f, 'Radius (tiles)', q.r, 0.05, 5, 0.05, v =>
        ch(x => {
          x.shots[i].r = v;
        })
      );
    else {
      fieldNum(f, 'Width (tiles)', q.w, 0.1, 10, 0.1, v =>
        ch(x => {
          x.shots[i].w = v;
        })
      );
      fieldNum(f, 'Height (tiles)', q.h, 0.1, 10, 0.1, v =>
        ch(x => {
          x.shots[i].h = v;
        })
      );
    }
    fieldNum(f, 'Speed (tiles/s)', q.speed, 0, 80, 0.5, v =>
      ch(x => {
        x.shots[i].speed = v;
      })
    );
    fieldNum(f, 'Angle (0 forward, 90 up)', q.angle, -180, 180, 5, v =>
      ch(x => {
        x.shots[i].angle = v;
      })
    );
    fieldNum(f, 'Starts forward (tiles)', q.ox, -10, 10, 0.1, v =>
      ch(x => {
        x.shots[i].ox = v;
      })
    );
    fieldNum(f, 'Starts up/down (tiles, up is negative)', q.oy, -10, 10, 0.1, v =>
      ch(x => {
        x.shots[i].oy = v;
      })
    );
    fieldNum(f, 'Gravity x', q.gravity, 0, 3, 0.05, v =>
      ch(x => {
        x.shots[i].gravity = v;
      })
    );
    fieldNum(f, 'Lives (s)', q.life, 0.1, 10, 0.1, v =>
      ch(x => {
        x.shots[i].life = v;
      })
    );
    fieldNum(f, 'Damage', q.damage, 0, 99, 1, v =>
      ch(x => {
        x.shots[i].damage = v;
      })
    );
    f.appendChild(
      mkSel(
        'Goes through enemies',
        [
          ['no', 'No, it stops'],
          ['yes', 'Yes']
        ],
        q.pierce,
        v =>
          ch(x => {
            x.shots[i].pierce = v;
          })
      )
    );
    d.appendChild(f);
    d.appendChild(
      btn('Remove shot', () =>
        ch(x => {
          x.shots.splice(i, 1);
        })
      )
    );
    host.appendChild(d);
  });
  host.appendChild(
    btn('Add shot', () => {
      if (o.shots.length >= 8) {
        $('pmsg').textContent = 'Up to 8 shots.';
        return;
      }
      ch(x => {
        x.shots.push({ name: 'Shot ' + (x.shots.length + 1), at: 0 });
      });
    })
  );
  const eh = document.createElement('strong');
  eh.textContent = 'Effects (' + o.effects.length + ')';
  host.appendChild(eh);
  o.effects.forEach((q, i) => {
    const r = document.createElement('div');
    r.className = 'mvf';
    r.appendChild(
      mkSel('When', FX_ON, q.on, v =>
        ch(x => {
          x.effects[i].on = v;
        })
      )
    );
    r.appendChild(
      mkSel('Do', FX_DO, q.do, v =>
        ch(x => {
          x.effects[i].do = v;
        })
      )
    );
    if (q.do === 'sound')
      r.appendChild(
        mkSel('Sound', [['', '(none)']].concat((S.sounds || []).map(z => [z.id, z.name])), q.snd, v =>
          ch(x => {
            x.effects[i].snd = v;
          })
        )
      );
    else
      fieldNum(r, 'Value', q.value, -60, 60, 0.5, v =>
        ch(x => {
          x.effects[i].value = v;
        })
      );
    host.appendChild(r);
    host.appendChild(
      btn('Remove effect ' + (i + 1), () =>
        ch(x => {
          x.effects.splice(i, 1);
        })
      )
    );
  });
  host.appendChild(
    btn('Add effect', () => {
      if (o.effects.length >= 8) {
        $('pmsg').textContent = 'Up to 8 effects.';
        return;
      }
      ch(x => {
        x.effects.push({ on: 'hit', do: 'bounce', value: 12 });
      });
    })
  );
}
function buildMoves() {
  const F = MV.data.moveFields;
  if (MI >= S.moves.length) MI = S.moves.length - 1;
  const L = $('mvl');
  L.innerHTML = '';
  STRIPS = [];
  const label = m => m.label + '  (' + (TYPE_NAME[m.type] || m.type) + ', ' + keyCombo(m) + ')';
  const core = document.createElement('button');
  core.className = 'item core' + (MI < 0 ? ' on' : '');
  core.textContent = 'Core movement';
  core.title = 'Run speed, acceleration, jumping and gravity';
  core.onclick = () => {
    MI = -1;
    buildMoves();
  };
  L.appendChild(core);
  if (!S.moves.length) {
    const h = document.createElement('p');
    h.className = 'hint';
    h.textContent = 'No moves yet. Click New move to build one.';
    L.appendChild(h);
  }
  S.moves.forEach((m, i) => {
    const b = document.createElement('button');
    b.className = 'item' + (i === MI ? ' on' : '');
    b.textContent = label(m);
    b.title = m.label;
    b.onclick = () => {
      MI = i;
      buildMoves();
    };
    L.appendChild(b);
  });
  const T0 = $('mvt'),
    B0 = $('mvb');
  T0.innerHTML = '';
  B0.innerHTML = '';
  T0.className = 'mdt';
  if (MI < 0) {
    coreView(T0, B0);
    return;
  }
  const i = MI,
    m = S.moves[i],
    f = document.createElement('div'),
    f2 = document.createElement('div'),
    r = document.createElement('div');
  f.className = 'mvf';
  f2.className = 'mvf';
  r.className = 'row';
  const title = () => {
    const b = L.children[i + 1];
    if (b) b.textContent = label(m);
  };
  const adv = isAdv(),
    timed = MV_TIMED.includes(m.type),
    topK = adv
      ? ['id', 'label', 'type', 'key', 'with', 'priority', 'requires', 'where'].concat(
          (timed && m.type !== 'sequence') || m.type === 'impulse' ? ['duration'] : []
        )
      : ['label', 'type', 'key', 'with', 'priority', 'requires', 'where'],
    botK = adv ? (MV_SHOW[m.type] || []).filter(k => k !== 'duration') : MV_BASIC[m.type] || [];
  const mkField = (k, box) => {
    const fd = F[k];
    if (k === 'requires') {
      const l = document.createElement('label');
      l.title = fd.help || '';
      l.append(
        fd.label,
        abilityPick(
          m.requires,
          v => {
            Object.assign(m, MV.Moves.clean1(Object.assign({}, m, { requires: v })));
            mvSync();
            save();
            buildMoves();
          },
          true
        )
      );
      box.appendChild(l);
      return;
    }
    if (fd.t === 'key') {
      box.appendChild(keyField(fd, m, k, title));
      if (k === 'with') moreKeysUI(m, chm, box);
      return;
    }
    const l = document.createElement('label');
    let inp;
    l.title = fd.help || '';
    if (fd.t === 'select') {
      inp = document.createElement('select');
      fd.o.concat((fd.legacy || []).includes(m[k]) ? [m[k]] : []).forEach(v => {
        const o = document.createElement('option');
        o.value = v;
        o.textContent = (fd.names && fd.names[v]) || v;
        inp.appendChild(o);
      });
    } else {
      inp = document.createElement('input');
      inp.type = fd.t === 'number' ? 'number' : 'text';
      if (fd.t === 'number') {
        inp.min = fd.min;
        inp.max = fd.max;
        inp.step = fd.step;
      }
    }
    inp.value = m[k];
    inp.onchange = () => {
      const raw = inp.value,
        next = MV.Moves.clean1(Object.assign({}, m, { [k]: raw }));
      if (k === 'id') next.id = uniqId(next.id, i);
      if (k === 'type' && raw === 'bash' && m.type !== 'bash')
        Object.assign(next, { speed: 32, duration: 0.22, keep: 0.5, reach: 5, aim: 0.6 });
      if (
        k === 'type' &&
        /^(Move \d+|New move|Timed move|Multi-step move|Push|Hold move|Wall move|Swimming)$/.test(m.label)
      ) {
        next.label = TYPE_LABEL[next.type] || next.label;
        if (/^move\d*$/.test(m.id))
          next.id = uniqId(next.label.replace(/[^A-Za-z0-9]/g, '').replace(/^./, c => c.toLowerCase()) || 'move', i);
      }
      Object.assign(m, next);
      inp.value = m[k];
      $('pmsg').textContent =
        fd.t === 'number' && String(+raw) !== String(m[k])
          ? fd.label + ' adjusted to ' + m[k] + ' (allowed ' + fd.min + ' to ' + fd.max + ')'
          : '';
      title();
      mvSync();
      save();
      if (k === 'type' || k === 'duration' || k === 'label') buildMoves();
    };
    l.append(fd.label, inp);
    box.appendChild(l);
  };
  // The move editor is split into sections so each screen is about one thing: Move (what it does), Hitbox (the part that gets hurt), Attack boxes, Path and speed, Shots and effects, Animation.
  const hold = ['hold', 'swim'].includes(m.type),
    secs = [['move', 'Move']];
  if (m.type === 'hold') secs.push(['hfx', 'Charge effects']);
  if (hold) secs.push(['hitbox', 'Hitbox'], ['anim', 'Animation']);
  else {
    secs.push(['hitbox', 'Hitbox'], ['attack', 'Attack boxes']);
    if (adv) {
      if (MV_PATH.includes(m.type) || MV_CURVE.includes(m.type)) secs.push(['path', 'Path and speed']);
      if (m.type !== 'surface') secs.push(['fx', 'Shots and effects']);
      secs.push(['anim', 'Animation']);
    }
  }
  let sec = MSEC;
  if (!secs.some(q => q[0] === sec)) sec = 'move';
  const bar = document.createElement('div');
  bar.className = 'row secbar';
  secs.forEach(q => {
    const b = btn(q[1], () => {
      MSEC = q[0];
      buildMoves();
    });
    if (q[0] === sec) b.className = 'on';
    bar.appendChild(b);
  });
  T0.appendChild(bar);
  const hint = t => {
    const p = document.createElement('p');
    p.className = 'hint';
    p.textContent = t;
    T0.appendChild(p);
  };
  const sub = () => {
    const d = document.createElement('div');
    B0.appendChild(d);
    return d;
  };
  const tlo = (sh, title, hnt) => ({
    T: () => m,
    list: 'hit',
    body: false,
    curve: MV_CURVE.includes(m.type),
    path: MV_PATH.includes(m.type),
    sh,
    title,
    hint: hnt,
    fit: timed,
    an: () => m.sprite,
    dur: () => Math.max(0.05, m.duration),
    vel: s =>
      m.type === 'sequence'
        ? seqVel(m, s)
        : (m.type === 'dash' && m.dir === 'forward') || m.type === 'roll'
          ? Math.max(0, m.speed + m.accel * s)
          : 0,
    ch: fn => {
      fn(m);
      Object.assign(m, MV.Moves.clean1(m));
      mvSync();
      save();
    }
  });
  const chm = fn => {
    fn(m);
    Object.assign(m, MV.Moves.clean1(m));
    mvSync();
    save();
    buildMoves();
  };
  if (sec === 'move') {
    hint(
      m.type === 'hold'
        ? MV_HINT.hold
        : m.type === 'surface'
          ? MV_HINT.surface
          : m.type === 'swim'
            ? 'Swimming works in water.'
            : MV_HINT[m.type] || ''
    );
    if (!adv) {
      hint(
        "This is the Basic view: the Move and Hitbox sections. Advanced adds the id, a second key, attack boxes, the player's own route, the speed curve, shots, effects and the animation."
      );
      const rr = document.createElement('div');
      rr.className = 'row';
      rr.append(
        btn('Open Advanced view', () => setView('adv')),
        btn('Test movement', mtOpen)
      );
      T0.appendChild(rr);
    }
    const sh0 = document.createElement('strong');
    sh0.textContent = 'Move';
    B0.appendChild(sh0);
    topK.forEach(k => mkField(k, f));
    B0.appendChild(f);
    if (m.type === 'sequence')
      stepsUI(B0, m, fn => {
        fn(m);
        Object.assign(m, MV.Moves.clean1(m));
        mvSync();
        save();
        buildMoves();
      });
    const mh = document.createElement('strong');
    mh.textContent = 'Movement settings';
    B0.appendChild(mh);
    if (m.path && m.path.length > 1 && m.type !== 'sequence' && m.type !== 'path' && m.type !== 'surface') {
      const pw = document.createElement('div');
      pw.className = 'cwarn';
      pw.textContent =
        'This move follows a route drawn in Path and speed, so Direction, Angle, Speed and Acceleration do nothing. Gravity, Duration, Keep speed and Stop when blocked still work (gravity pulls the player down on top of the route).';
      B0.appendChild(pw);
      const pr2 = document.createElement('div');
      pr2.className = 'row';
      pr2.append(
        btn('Delete the route (use these settings)', () =>
          chm(x => {
            x.path = [];
          })
        ),
        btn('Edit the route', () => {
          MSEC = 'path';
          buildMoves();
        })
      );
      B0.appendChild(pr2);
    }
    B0.appendChild(f2);
    botK.forEach(k => mkField(k, f2));
    const dup = document.createElement('button'),
      del = document.createElement('button');
    dup.textContent = 'Duplicate';
    del.textContent = 'Delete';
    dup.onclick = () => {
      if (S.moves.length >= 24) {
        $('pmsg').textContent = 'Up to 24 moves.';
        return;
      }
      S.moves.splice(
        i + 1,
        0,
        MV.Moves.clean1(Object.assign({}, m, { id: uniqId(m.id + '_copy', -1), label: m.label + ' copy' }))
      );
      MI = i + 1;
      mvSync();
      save();
      buildMoves();
    };
    del.onclick = () => {
      S.moves.splice(i, 1);
      MI = Math.max(-1, Math.min(i, S.moves.length - 1));
      mvSync();
      save();
      buildMoves();
    };
    r.append(btn('Test movement', mtOpen), dup, del);
    B0.appendChild(r);
  } else if (sec === 'hitbox' && hold) {
    hint(
      'The hitbox is the part of the player that gets hurt. For a held or swimming move you choose its shape while the move is active: a Circle makes the player a ball (a morph ball) only while the key is held; when you let go the normal hitbox comes back. Its size follows Body width while held and Body height (squash) in the Move section.'
    );
    const hb0 = sub();
    hb0.appendChild(
      mkSel(
        'Body shape while this move is active',
        [
          ['', 'Normal (the player hitbox)'],
          ['rect', 'Rectangle'],
          ['circle', 'Circle (a ball)'],
          ['polygon', 'Polygon (the corners of the normal hitbox, set in Hitbox > The normal hitbox)']
        ],
        (m.body && m.body.shape) || '',
        v =>
          chm(x => {
            x.body = x.body || { off: [], kf: [] };
            x.body.shape = v;
          })
      )
    );
  } else if (sec === 'hitbox') {
    hint(
      'The hitbox is the part of the player that gets hurt (enemies, boss attacks, spikes). Pick a time with the slider, then drag the green box on the screen to move it and its white corner squares to resize it. Every change makes a keyframe and the box glides between keyframes. Add invincible periods (from a time to a time) when nothing can hurt the player. In Test movement the player picture follows this hitbox. Its shape (rectangle, circle, polygon) and normal size are set by choosing "The normal hitbox" in the Editing menu above the picture.'
    );
    hbMount(sub(), 'm:' + m.id);
  } else if (sec === 'attack') {
    hint(
      'Attack boxes hurt what they touch. Add a box, move the time slider, and drag the box in the picture: each drag adds a keyframe, and the box sweeps between them. Each box has a from and to time, a shape and its own look.'
    );
    tlBuild(sub(), 'm:' + m.id + ':a', tlo({ hits: true, path: false, curve: false }, 'Attack boxes', ''));
  } else if (sec === 'path') {
    hint(
      'The path is where the player goes during the move; the speed curve changes how fast. With fewer than two points the move uses its speed settings (Direction, Speed, Acceleration). Gravity works with a route too: it pulls the player down on top of it.'
    );
    tlBuild(sub(), 'm:' + m.id + ':p', tlo({ hits: false, path: true, curve: true }, 'Path and speed', ''));
  } else if (sec === 'hfx') {
    hint(
      'For held moves that charge (set Charge time in Move): what happens each time the charge is complete. A focus heal = Charge time 1.2, Energy cost 33, Charge again while held Yes, Hold still while charging Yes, and one effect: when the charge is complete, Heal 1. Energy needs a maximum in Settings.'
    );
    const hb = sub(),
      ho = m;
    hb.appendChild(
      mkSel(
        'Hold still while charging',
        [
          ['no', 'No'],
          ['yes', 'Yes (you cannot move or jump until it is complete)']
        ],
        m.chargeLock,
        v =>
          chm(x => {
            x.chargeLock = v;
          })
      )
    );
    const eh2 = document.createElement('strong');
    eh2.textContent = 'Effects (' + m.effects.length + ')';
    hb.appendChild(eh2);
    m.effects.forEach((q, i) => {
      const r = document.createElement('div');
      r.className = 'mvf';
      r.appendChild(mkSel('When', [['charged', 'the charge time is complete']], 'charged', v => {}));
      r.appendChild(
        mkSel(
          'Do',
          FX_DO.filter(z => ['heal', 'energy', 'sound', 'refill', 'slow', 'knock', 'bounce'].includes(z[0])),
          q.do,
          v =>
            chm(x => {
              x.effects[i].do = v;
            })
        )
      );
      if (q.do === 'sound')
        r.appendChild(
          mkSel('Sound', [['', '(none)']].concat((S.sounds || []).map(z => [z.id, z.name])), q.snd, v =>
            chm(x => {
              x.effects[i].snd = v;
            })
          )
        );
      else
        fieldNum(r, 'Value', q.value, -60, 60, 0.5, v =>
          chm(x => {
            x.effects[i].value = v;
          })
        );
      hb.appendChild(r);
      hb.appendChild(
        btn('Remove effect ' + (i + 1), () =>
          chm(x => {
            x.effects.splice(i, 1);
          })
        )
      );
    });
    hb.appendChild(
      btn('Add effect', () => {
        if (m.effects.length >= 8) {
          $('pmsg').textContent = 'Up to 8 effects.';
          return;
        }
        chm(x => {
          x.effects.push({ on: 'charged', do: 'heal', value: 1 });
        });
      })
    );
  } else if (sec === 'fx') {
    hint(
      'What else the move does: chain into another move (combos), charge up, fire shots, and trigger effects when it starts, hits, lands, touches a wall or ends.'
    );
    extrasUI(sub(), m, false, fn => chm(fn));
  } else if (sec === 'anim') {
    const setMA = patch => {
      const a = Object.assign(
        {
          sheet: '',
          col: 0,
          row: 0,
          frames: 1,
          fps: 12,
          loop: ['hold', 'swim', 'surface'].includes(m.type),
          fit: true
        },
        m.sprite || {},
        patch
      );
      m.sprite = a.sheet ? a : null;
      Object.assign(m, MV.Moves.clean1(m));
      mvSync();
      save();
      buildMoves();
    };
    hint(
      ['hold', 'swim', 'surface'].includes(m.type)
        ? 'The animation that plays (and loops) while this move is active: held, swimming, or clinging to a wall or ceiling. If you set none, the player uses the matching animation from the Sprite tab.'
        : timed
          ? "Sprites shown while this move plays. The strip shows each frame across the move's " +
            m.duration +
            ' s. "Fit" spreads all frames over that time.'
          : 'Sprites shown when this move fires. Impulses are instant, so the animation plays once at its own speed.'
    );
    const A = sub();
    A.appendChild(animForm(m.sprite, setMA, buildMoves));
    const fl = document.createElement('label'),
      fc = document.createElement('input');
    fc.type = 'checkbox';
    fc.checked = !m.sprite || m.sprite.fit;
    fc.disabled = !m.sprite || !timed;
    fc.onchange = () => setMA({ fit: fc.checked });
    fl.append(fc, ' Fit all frames into the duration');
    A.appendChild(fl);
    const sc = document.createElement('canvas');
    sc.className = 'mstrip';
    sc.width = 640;
    sc.height = 64;
    sc.style.cssText = 'width:100%;height:auto;border:1px solid var(--bd);border-radius:8px;margin-top:6px';
    A.appendChild(sc);
    STRIPS.push({ c: sc, m });
    drawMoveStrip(sc, m);
  }
}
