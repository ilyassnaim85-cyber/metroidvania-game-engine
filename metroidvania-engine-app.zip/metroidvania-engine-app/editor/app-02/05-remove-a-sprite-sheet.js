// remove a sprite sheet and every reference to it (room art, tables, backgrounds, clips, player, moves, bosses)
function purgeSheet(id) {
  S.sheets = S.sheets.filter(x => x.id !== id);
  {
    const gone = a => (a && a.sheet === id ? null : a);
    if (S.inv) {
      if (S.inv.sheet === id) S.inv.sheet = '';
      S.inv.tabs.forEach(t => {
        t.icon = gone(t.icon);
      });
      for (const k in S.inv.meta) S.inv.meta[k].icon = gone(S.inv.meta[k].icon);
    }
    S.items.forEach(d => {
      d.icon = gone(d.icon);
    });
  }
  if (S.dialog && S.dialog.sheet === id) S.dialog.sheet = '';
  S.areas.forEach(a =>
    (a.rooms || []).forEach(v => {
      v.art = (v.art || []).filter(t => t.s !== id);
      v.table = (v.table || []).filter(t => t.s !== id);
      if (v.bg)
        v.bg.layers.forEach(l => {
          if (l.sheet === id) l.sheet = '';
        });
    })
  );
  S.anims.forEach(c => {
    c.frames = c.frames.filter(f => f.sheet !== id);
  });
  const dropAn = o =>
    Object.keys(o).forEach(k => {
      if (o[k] && o[k].sheet === id) delete o[k];
    });
  dropAn(S.sprite.anims);
  S.moves.forEach(m => {
    if (m.sprite && m.sprite.sheet === id) m.sprite = null;
    (m.hit || []).forEach(h => {
      if (h.vis && h.vis.sheet === id) h.vis = null;
    });
  });
  S.attacks.forEach(a => {
    if (a.anim && a.anim.sheet === id) a.anim = null;
    a.hitboxes.forEach(h => {
      if (h.vis && h.vis.sheet === id) h.vis = null;
    });
  });
  S.bosses.forEach(b => {
    dropAn(b.sprite.anims);
    b.patterns.forEach(p =>
      p.hitboxes.forEach(h => {
        if (h.vis && h.vis.sheet === id) h.vis = null;
      })
    );
  });
}
$('sd').onclick = () => {
  const s = cs();
  if (!s) return;
  purgeSheet(s.id);
  si = -1;
  save();
  refSheets();
  drawT();
  drawTable();
};
[WC, AC].forEach(c => {
  const f = () => {
    const d = c.dim(),
      w = CL(Math.round((+c.zw.value || d.mw) / 100) * 100),
      h = CL(Math.round((+c.zh.value || d.mh) / 100) * 100);
    d.mw = w;
    d.mh = h;
    c.list().forEach(i => {
      i.x = Math.max(0, Math.min(i.x, w - i.w));
      i.y = Math.max(0, Math.min(i.y, h - i.h));
    });
    save();
    draw(c);
  };
  c.zw.onchange = f;
  c.zh.onchange = f;
});
function trOpts(sel, val) {
  sel.innerHTML = '';
  const z = document.createElement('option');
  z.value = '';
  z.textContent = '(not set)';
  sel.appendChild(z);
  S.areas.forEach(a => {
    ensureRooms(a);
    a.rooms.forEach(m => {
      const o = document.createElement('option');
      o.value = a.id + '|' + m.id;
      o.textContent = a.n + ' / ' + m.n;
      sel.appendChild(o);
    });
  });
  if (val) sel.value = val;
}
function drawTr() {
  const b = $('trl');
  b.innerHTML = '';
  const seen = new Set(),
    isD = (x, y) => x >= 0 && y >= 0 && x < rc.gw && y < rc.gh && rc.grid[y][x] === 'D';
  const setDest = (g, val) => {
    g.tiles.forEach(t => {
      rc.tr = rc.tr.filter(q => !(q.x === t[0] && q.y === t[1]));
      if (val) {
        const q = val.split('|');
        rc.tr.push({ x: t[0], y: t[1], a: q[0], r: q[1] });
      }
    });
    save();
  };
  const setCell = (x, y, ch) => {
    if (x < 0 || y < 0 || x >= rc.gw || y >= rc.gh) return;
    const g = rc.grid;
    g[y] = g[y].slice(0, x) + ch + g[y].slice(x + 1);
    if (ch !== 'D') rc.tr = rc.tr.filter(t => !(t.x === x && t.y === y));
  };
  for (let y = 0; y < rc.gh; y++) {
    if (rc.grid[y].indexOf('D') < 0) continue;
    for (let x = 0; x < rc.gw; x++) {
      if (!isD(x, y) || seen.has(x + ',' + y)) continue;
      const g = { tiles: [], x0: x, y0: y, x1: x, y1: y },
        st = [[x, y]];
      seen.add(x + ',' + y);
      while (st.length) {
        const q = st.pop();
        g.tiles.push(q);
        g.x0 = Math.min(g.x0, q[0]);
        g.x1 = Math.max(g.x1, q[0]);
        g.y0 = Math.min(g.y0, q[1]);
        g.y1 = Math.max(g.y1, q[1]);
        [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1]
        ].forEach(d => {
          const nx = q[0] + d[0],
            ny = q[1] + d[1];
          if (isD(nx, ny) && !seen.has(nx + ',' + ny)) {
            seen.add(nx + ',' + ny);
            st.push([nx, ny]);
          }
        });
      }
      const w = g.x1 - g.x0 + 1,
        h = g.y1 - g.y0 + 1,
        full = g.tiles.length === w * h,
        dests = new Set(
          g.tiles.map(t => {
            const e = rc.tr.find(q => q.x === t[0] && q.y === t[1]);
            return e ? e.a + '|' + e.r : '';
          })
        ),
        val = dests.size === 1 ? [...dests][0] : '';
      const row = document.createElement('div');
      row.className = 'row';
      const sl = document.createElement('select'),
        lb = document.createElement('span'),
        rm = document.createElement('button');
      lb.textContent = 'Doorway at (' + g.x0 + ', ' + g.y0 + '), ' + w + ' wide x ' + h + ' tall, leads to';
      trOpts(sl, val);
      if (dests.size > 1) {
        const o = document.createElement('option');
        o.value = '__mixed';
        o.textContent = '(different tiles go to different rooms)';
        sl.insertBefore(o, sl.firstChild);
        sl.value = '__mixed';
      }
      sl.onchange = () => {
        if (sl.value === '__mixed') return;
        setDest(g, sl.value);
      };
      rm.textContent = 'Remove';
      rm.onclick = () => {
        g.tiles.forEach(t => setCell(t[0], t[1], '.'));
        save();
        drawT();
        drawTr();
      };
      row.append(lb, sl, rm);
      if (full) {
        const mkS = (name, val2, min, fn) => {
          const l = document.createElement('label'),
            i = document.createElement('input');
          i.type = 'number';
          i.min = min;
          i.max = 60;
          i.value = val2;
          i.style.width = '60px';
          i.onchange = () => {
            fn(Math.max(min, Math.min(60, Math.round(+i.value) || min)));
          };
          l.append(name + ' ', i);
          return l;
        };
        const resize = (nw, nh) => {
          const dest = val;
          for (let yy = g.y0; yy <= g.y0 + Math.max(h, nh) - 1; yy++)
            for (let xx = g.x0; xx <= g.x0 + Math.max(w, nw) - 1; xx++) {
              if (xx >= rc.gw || yy >= rc.gh) continue;
              const inside = xx < g.x0 + nw && yy < g.y0 + nh;
              if (inside) {
                if (rc.grid[yy][xx] === '.' || rc.grid[yy][xx] === 'D') {
                  setCell(xx, yy, 'D');
                  if (dest) {
                    rc.tr = rc.tr.filter(q => !(q.x === xx && q.y === yy));
                    const q = dest.split('|');
                    rc.tr.push({ x: xx, y: yy, a: q[0], r: q[1] });
                  }
                }
              } else if (rc.grid[yy][xx] === 'D') setCell(xx, yy, '.');
            }
          save();
          drawT();
          drawTr();
        };
        row.append(
          mkS('Width', w, 1, v => resize(v, h)),
          mkS('Height', h, 1, v => resize(w, v))
        );
      }
      b.appendChild(row);
    }
  }
  if (!b.children.length) {
    b.textContent =
      'No transitions yet. Pick the Transition tool, drag a doorway of any size, then choose where it leads here.';
    b.style.color = 'var(--mu)';
  } else b.style.color = '';
}
function etySync() {
  document.querySelectorAll('#etyg .echip').forEach(b => b.classList.toggle('on', b.dataset.k === $('ety').value));
}
function etyOpts() {
  const g = $('etyg'),
    q = $('ety');
  g.innerHTML = '';
  const ks = Object.keys(MV.data.entities).filter(k => !['enemy', 'hazard', 'boss'].includes(k));
  if (!q._p) {
    const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    Object.defineProperty(q, 'value', {
      get() {
        return d.get.call(q);
      },
      set(v) {
        d.set.call(q, v);
        etySync();
      }
    });
    q._p = 1;
  }
  ks.filter(k => !['enemy', 'hazard', 'boss'].includes(k)).forEach(k => {
    const d = MV.data.entities[k],
      b = document.createElement('button');
    b.type = 'button';
    b.className = 'echip';
    b.dataset.k = k;
    const i = document.createElement('i');
    i.style.background = d.color || '#888';
    b.append(i, d.label);
    b.onclick = () => {
      q.value = k;
      setTool('N');
    };
    g.appendChild(b);
  });
  if (!ks.includes(q.value)) q.value = ks[0];
  etySync();
}
function drawEn() {
  const b = $('enl');
  b.innerHTML = '';
  rc.ent.forEach((e, i) => {
    const d = MV.data.entities[e.type];
    if (!d) return;
    if (lampT(e.type)) {
      b.appendChild(lampRow(e));
      return;
    }
    const row = document.createElement('div');
    row.className = 'row';
    const t = document.createElement('strong');
    t.textContent = d.label + ' (' + e.x + ', ' + e.y + ')';
    row.appendChild(t);
    {
      const hp = (MV.data.entityHelp || {})[e.type];
      if (hp) {
        const h = document.createElement('span');
        h.className = 'hint';
        h.style.flexBasis = '100%';
        h.textContent = hp;
        row.appendChild(h);
      }
    }
    for (const k in d.props) {
      const df = d.props[k];
      if (df.t === 'key') {
        row.appendChild(keyCap(e, k));
        continue;
      }
      if (
        k === 'give' &&
        ((e.type === 'pickup' && (e.props.kind || 'ability') === 'ability') ||
          (e.type === 'chest' && e.props.reward === 'ability'))
      ) {
        const lb2 = document.createElement('label');
        lb2.append(
          k + ' ',
          abilityPick(
            e.props[k] !== undefined ? e.props[k] : df.d,
            v => {
              e.props[k] = v;
              save();
              drawEn();
            },
            false
          )
        );
        row.appendChild(lb2);
        continue;
      }
      const lb = document.createElement('label'),
        inp = document.createElement(
          df.t === 'select' ||
            df.t === 'boss' ||
            df.t === 'enemy' ||
            df.t === 'clip' ||
            df.t === 'sprite' ||
            df.t === 'camprofile'
            ? 'select'
            : df.t === 'longtext'
              ? 'textarea'
              : 'input'
        );
      if (df.t === 'longtext') {
        inp.rows = 4;
        inp.style.minWidth = '260px';
        inp.placeholder = 'One line per turn. Start a line with > for your character.';
      }
      if (df.t === 'clip') {
        const o0 = document.createElement('option');
        o0.value = '';
        o0.textContent = '(pick an animation)';
        inp.appendChild(o0);
        S.anims.forEach(q => {
          const o = document.createElement('option');
          o.value = q.id;
          o.textContent = q.name;
          inp.appendChild(o);
        });
      } else if (df.t === 'sprite') {
        spriteOpts(inp, e.props[k]);
      } else if (df.t === 'camprofile') {
        const o0 = document.createElement('option');
        o0.value = '';
        o0.textContent = "(the room's own)";
        inp.appendChild(o0);
        MV.Camera.all(S.camProfiles).forEach(q => {
          const o = document.createElement('option');
          o.value = q.id;
          o.textContent = q.name;
          inp.appendChild(o);
        });
      } else if (df.t === 'boss')
        S.bosses.forEach(q => {
          const o = document.createElement('option');
          o.value = q.id;
          o.textContent = q.name;
          inp.appendChild(o);
        });
      else if (df.t === 'enemy') {
        const o0 = document.createElement('option');
        o0.value = '';
        o0.textContent = '(simple enemy: health, speed, range below)';
        inp.appendChild(o0);
        (S.enemies || []).forEach(q => {
          const o = document.createElement('option');
          o.value = q.id;
          o.textContent = q.name + ' (' + q.id + ')';
          inp.appendChild(o);
        });
      } else if (df.t === 'select')
        df.o.forEach(v => {
          const o = document.createElement('option');
          o.value = o.textContent = v;
          inp.appendChild(o);
        });
      else if (df.t !== 'longtext') {
        inp.type = df.t === 'number' ? 'number' : 'text';
        const gk = k === 'give' ? (e.type === 'pickup' ? e.props.kind : e.type === 'chest' ? e.props.reward : '') : '';
        if (gk === 'weapon' || gk === 'item' || gk === 'upgrade') {
          let dl = document.getElementById('wplist');
          if (!dl) {
            dl = document.createElement('datalist');
            dl.id = 'wplist';
            document.body.appendChild(dl);
          }
          dl.innerHTML = '';
          (gk === 'upgrade'
            ? ['maxHp', 'energyMax', 'charmSlots']
            : gk === 'weapon'
              ? [...new Set(S.attacks.map(q => q.weapon).filter(Boolean))]
              : S.items.map(q => q.id)
          ).forEach(w => {
            const o = document.createElement('option');
            o.value = w;
            dl.appendChild(o);
          });
          inp.setAttribute('list', 'wplist');
          inp.placeholder = gk + ' id';
        }
      }
      if (df.t === 'number') inp.step = 'any';
      inp.value = e.props[k] !== undefined ? e.props[k] : df.d;
      inp.onchange = () => {
        e.props[k] = df.t === 'number' ? +inp.value || 0 : inp.value;
        save();
        if ((e.type === 'pickup' && k === 'kind') || (e.type === 'chest' && k === 'reward')) drawEn();
      };
      lb.append(k + ' ', inp);
      row.appendChild(lb);
    }
    const rm = document.createElement('button');
    rm.textContent = 'Remove';
    rm.onclick = () => {
      rc.ent.splice(i, 1);
      save();
      drawT();
      drawEn();
    };
    row.appendChild(rm);
    b.appendChild(row);
  });
  if (!b.children.length) {
    b.textContent = 'No entities yet. Pick the Entity tool, choose a type, then click the room.';
    b.style.color = 'var(--mu)';
  } else b.style.color = '';
}
function drawArt(x, room, Z) {
  (room.art || []).forEach(a => {
    const s = sheet(a.s);
    if (!s) return;
    const m = img(s);
    if (m.complete && m.naturalWidth)
      x.drawImage(m, a.c * s.tw, a.r * s.th, a.w * s.tw, a.h * s.th, a.x * Z, a.y * Z, a.w * Z, a.h * Z);
  });
}
etyOpts();
buildPo();
$('pb').onclick = () => {
  mtStop();
  abSync();
  let st,
    persist = false;
  if ($('psv').checked) {
    st = MV.Progress.load(S);
    persist = true;
  } else {
    st = MV.Progress.fresh();
    document.querySelectorAll('#po input[data-ab]').forEach(c => {
      if (c.checked) st.abilities[c.dataset.ab] = true;
    });
    ($('pfl').value || '')
      .split(',')
      .map(x => x.trim())
      .filter(Boolean)
      .forEach(f => (st.flags[f] = 1));
  }
  show('pl');
  MV.Game.start({
    enemies: () => S.enemies,
    bosses: () => S.bosses,
    canvas: $('pc'),
    world: S,
    room: rc,
    state: st,
    persist,
    art: drawArt,
    tuning: () => S.player,
    image: bgImg,
    moves: () => S.moves,
    attacks: () => S.attacks,
    items: () => S.items,
    body: () => S.body,
    controls: () => S.controls,
    sprite: () => S.sprite,
    sheet: sheetOf
  });
};
$('pbk').onclick = () => {
  const r = MV.Game.room(),
    a = MV.Game.area();
  MV.Game.stop();
  if (a) cur = a;
  openRoom(r || rc);
};
$('dbg').onchange = () => {
  MV.Game.debug = $('dbg').checked;
};
$('cdb').onchange = () => drawT();
$('rstr').onchange = () => {
  rc.stream = Math.max(0, Math.min(200, Math.round(+$('rstr').value || 0)));
  $('rstr').value = rc.stream || '';
  save();
};
$('cm').onchange = $('cf').onchange = () => {
  const v = $('cf').value.trim();
  rc.cam = {
    mode: 'follow',
    profile: $('cm').value === 'default' ? '' : $('cm').value,
    follow: v === '' ? null : Math.max(0.02, Math.min(1, +v || 0.12))
  };
  if (!rc.cam.profile && rc.cam.follow === null) rc.cam = null;
  save();
};

let U = [],
  R = [],
  prev = null,
  lastPush = 0,
  dirty = false,
  V = 'ov',
  TAB = 'world';
const snap = () => ({
  core: ser({
    areas: S.areas,
    links: S.links,
    mw: S.mw,
    mh: S.mh,
    player: S.player,
    moves: S.moves,
    attacks: S.attacks,
    items: S.items,
    enemies: S.enemies,
    inv: S.inv,
    body: S.body,
    controls: S.controls,
    camProfiles: S.camProfiles,
    events: S.events,
    scripts: S.scripts,
    sounds: S.sounds,
    sfx: S.sfx,
    vol: S.vol,
    sprite: S.sprite,
    bosses: S.bosses,
    anims: S.anims,
    dialog: S.dialog,
    templates: S.templates,
    pins: S.pins
  }),
  sheets: S.sheets.map(x => ({ ...x }))
});
const same = (a, b) =>
  a.core === b.core &&
  a.sheets.length === b.sheets.length &&
  a.sheets.every((x, i) => {
    const y = b.sheets[i];
    return x.id === y.id && x.name === y.name && x.tw === y.tw && x.th === y.th && x.url === y.url;
  });
function rebase() {
  prev = snap();
}
function hist() {
  if (!prev) return;
  const n = snap();
  if (same(n, prev)) return;
  const t = Date.now();
  if (t - lastPush > 500) {
    U.push(prev);
    if (U.length > 100) U.shift();
  }
  lastPush = t;
  prev = n;
  R.length = 0;
  dirty = true;
  ui();
}
function ui() {
  $('un').disabled = !U.length || playing();
  $('rd').disabled = !R.length || playing();
  $('st').textContent = dirty ? '● Unsaved changes' : 'Saved';
}
function restoreSnap(sn) {
  leavePlay();
  const ci = cur && cur.id,
    ri = rc && rc.id,
    o = des(sn.core);
  S.areas = o.areas;
  S.links = o.links;
  S.mw = o.mw;
  S.mh = o.mh;
  S.player = o.player || {};
  S.bosses = o.bosses || [];
  S.anims = o.anims || [];
  S.moves = o.moves;
  S.attacks = MV.Attacks.resolve(o.attacks, o.player);
  S.items = MV.Inventory.resolve(o.items);
  S.enemies = MV.Enemies.resolve(o.enemies);
  S.inv = MV.Inventory.cleanDesign(o.inv);
  S.body = MV.Attacks.bodyClean(o.body);
  S.controls = MV.Controls.clean(o.controls);
  S.camProfiles = MV.Camera.cleanProfiles(o.camProfiles);
  S.events = MV.Events.clean(o.events);
  S.scripts = MV.Script.clean(o.scripts);
  S.sounds = MV.Audio.cleanList(o.sounds);
  S.sfx = MV.Audio.cleanSfx(o.sfx);
  S.vol = MV.Audio.cleanVol(o.vol);
  S.sprite = o.sprite;
  S.dialog = MV.Dialog.clean(o.dialog);
  S.templates = o.templates || [];
  S.pins = o.pins || [];
  S.sheets = sn.sheets.map(x => ({ ...x }));
  wReset();
  cur = S.areas.find(a => a.id === ci) || null;
  if (cur && V !== 'ov') ensureRooms(cur);
  rc = cur && cur.rooms ? cur.rooms.find(x => x.id === ri) || null : null;
  if (V === 'rm' && rc) openRoom(rc);
  else if (V !== 'ov' && cur) {
    show('ar');
    draw(AC);
  } else {
    show('ov');
    draw(WC);
  }
  prev = snap();
  lastPush = 0;
  dirty = true;
  persist();
  ui();
  if (TAB === 'anim') axUI();
  if (TAB === 'events') evUI();
  if (TAB === 'scripts') scUI();
}
const inText = el =>
  el && /^(INPUT|TEXTAREA)$/.test(el.tagName) && !['checkbox', 'button', 'range', 'file'].includes(el.type);
function mvUndo() {
  if (inText(document.activeElement)) {
    document.execCommand('undo');
    return;
  }
  if (!U.length || playing()) return;
  R.push(prev);
  restoreSnap(U.pop());
}
function mvRedo() {
  if (inText(document.activeElement)) {
    document.execCommand('redo');
    return;
  }
  if (!R.length || playing()) return;
  U.push(prev);
  restoreSnap(R.pop());
}
async function mvSave(asNew) {
  if (!PID) return;
  persist();
  const json = ser(S, 1);
  try {
    if (window.mvHost) {
      const r = await window.mvHost.save(
        json,
        !!asNew,
        PFILE,
        (S.name || 'project').replace(/[^\w.-]+/g, '_') + '.json'
      );
      if (!r) return;
      if (!r.ok) {
        if (r.error) $('st').textContent = 'Save failed: ' + r.error;
        return;
      }
      PFILE = r.path;
      metaSet({ file: r.path });
      $('st').title = 'Saved to ' + r.name;
    } else {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
      a.download = (S.name || 'project').replace(/[^\w.-]+/g, '_') + '.json';
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    }
    dirty = false;
    ui();
  } catch (e) {
    $('st').textContent = 'Save failed: ' + e.message;
  }
}
function bgImg(id) {
  const q = sheet(id);
  return q ? img(q) : null;
}
function sheetOf(id) {
  const q = sheet(id);
  return q ? { img: img(q), tw: q.tw, th: q.th } : null;
}
function sub(t) {
  const TILE = '#g=/\\~D.';
  $('bsp').hidden = t !== 'bosses';
  $('bst').classList.toggle('on', t === 'bosses');
  if (t === 'bosses') bossCards();
  $('enp').hidden = t !== 'entities';
  $('ent2').classList.toggle('on', t === 'entities');
  $('tt').hidden = t !== 'tiles';
  $('spt').hidden = t !== 'sprites';
  $('stt').classList.toggle('on', t === 'tiles');
  $('sst').classList.toggle('on', t === 'sprites');
  if (t === 'tiles') {
    if (!TILE.includes(tool)) setTool(LASTTILE);
  } else setTool(t === 'entities' ? 'N' : t === 'sprites' ? 'S' : 'O');
} // each section clicks the room with its own tool
$('bst').onclick = () => sub('bosses');
$('stt').onclick = () => sub('tiles');
$('sst').onclick = () => sub('sprites');
$('ent2').onclick = () => sub('entities');
$('erx').onclick = () => setTool('X');
$('anc').oninput = () => {
  if (cur) {
    cur.note = $('anc').value.slice(0, 2000);
    save();
  }
};
function bgSet(p) {
  rc.bg = MV.Background.clean(Object.assign({}, rc.bg || MV.Background.def(), p));
  save();
  bgUI();
  drawT();
}
function bgLayer(i, p) {
  const L = (rc.bg || MV.Background.def()).layers.map(l => ({ ...l }));
  Object.assign(L[i], p);
  bgSet({ layers: L });
}
function mkSel(lab, opts, val, cb) {
  const l = document.createElement('label'),
    q = document.createElement('select');
  opts.forEach(o => {
    const e = document.createElement('option');
    e.value = o[0];
    e.textContent = o[1];
    q.appendChild(e);
  });
  q.value = val;
  if (q.value !== val) q.value = opts[0][0];
  q.onchange = () => cb(q.value);
  l.append(lab, q);
  return l;
}
function mkNum(lab, val, min, max, step, cb, dis) {
  const l = document.createElement('label'),
    q = document.createElement('input');
  q.type = 'number';
  q.min = min;
  q.max = max;
  q.step = step;
  q.value = val;
  q.disabled = !!dis;
  q.onchange = () => cb(q.value);
  l.append(lab, q);
  return l;
}
function bgSwap(i, j) {
  const b = rc.bg || MV.Background.def(),
    L = b.layers.map(l => ({ ...l }));
  if (j < 0 || j >= L.length) return;
  const t = L[i];
  L[i] = L[j];
  L[j] = t;
  BGE = -1;
  bgSet({ layers: L });
}
function bgAdd(front) {
  const b = rc.bg || MV.Background.def();
  if (b.layers.length >= MV.Background.MAXL) {
    alert('That is the most layers a room can have (' + MV.Background.MAXL + ').');
    return;
  }
  const L = b.layers.map(l => ({ ...l })),
    d = MV.Background.layerDef(L.length);
  d.name = 'Layer ' + (L.length + 1);
  d.front = !!front;
  d.parallax = front ? 1.15 : 0.6;
  L.push(d);
  bgSet({ layers: L });
}
function mkCol(lab, val, cb) {
  const l = document.createElement('label'),
    q = document.createElement('input');
  q.type = 'color';
  q.value = val;
  q.onchange = () => cb(q.value);
  l.append(lab, q);
  return l;
}
function bgUI() {
  const b = rc.bg || MV.Background.def();
  $('bgc').value = b.color;
  const box = $('bgl');
  box.innerHTML = '';
  b.layers.forEach((L, i) => {
    const d = document.createElement('div'),
      f = document.createElement('div'),
      hd = document.createElement('div');
    d.className = 'mv';
    f.className = 'mvf';
    hd.style.cssText = 'display:flex;gap:.3rem;align-items:center;margin-bottom:.3rem';
    const nm = document.createElement('input');
    nm.type = 'text';
    nm.value = L.name;
    nm.maxLength = 30;
    nm.style.cssText = 'flex:1;font-weight:600';
    nm.onchange = () => bgLayer(i, { name: nm.value });
    hd.appendChild(nm);
    const bt = (t, ti, fn, dis) => {
      const e = document.createElement('button');
      e.textContent = t;
      e.title = ti;
      e.disabled = !!dis;
      e.onclick = fn;
      hd.appendChild(e);
    };
    bt(L.vis === false ? 'Show' : 'Hide', 'Hide or show this layer in the editor and the game', () =>
      bgLayer(i, { vis: L.vis === false })
    );
    bt('Up', 'Move this layer earlier (drawn first, so further back)', () => bgSwap(i, i - 1), i === 0);
    bt(
      'Down',
      'Move this layer later (drawn on top of the ones before it)',
      () => bgSwap(i, i + 1),
      i === b.layers.length - 1
    );
    bt('Copy', 'Duplicate this layer', () => {
      const Ls = b.layers.map(l => ({ ...l }));
      if (Ls.length >= MV.Background.MAXL) return;
      const c = { ...L, name: (L.name + ' copy').slice(0, 30) };
      Ls.splice(i + 1, 0, c);
      bgSet({ layers: Ls });
    });
    bt('Delete', 'Delete this layer', () => {
      if (!confirm('Delete "' + L.name + '"?')) return;
      const Ls = b.layers.map(l => ({ ...l }));
      Ls.splice(i, 1);
      BGE = -1;
      bgSet({ layers: Ls });
    });
    d.appendChild(hd);
    f.appendChild(
      mkSel('Image', [['', '(none)'], ...S.sheets.map(v => [v.id, v.name])], L.sheet, v => bgLayer(i, { sheet: v }))
    );
    f.appendChild(
      mkSel(
        'Fit',
        [
          ['cover', 'Cover room'],
          ['stretch', 'Stretch'],
          ['tile', 'Tile'],
          ['free', 'Free (drag and resize)']
        ],
        L.mode,
        v => {
          const p = { mode: v };
          if (v === 'free') p.parallax = 1;
          if (v === 'free' && !(L.w > 0)) {
            const m = L.sheet ? bgImg(L.sheet) : null;
            p.x = 0;
            p.y = 0;
            p.w = rc.gw;
            p.h = m && m.naturalWidth ? Math.round(((rc.gw * m.naturalHeight) / m.naturalWidth) * 100) / 100 : 0;
          }
          BGE = v === 'free' ? i : BGE === i ? -1 : BGE;
          bgLayer(i, p);
        }
      )
    );
    if (L.mode === 'free') {
      f.appendChild(mkNum('X (tiles)', L.x, -20000, 20000, 0.1, v => bgLayer(i, { x: +v || 0 })));
      f.appendChild(mkNum('Y (tiles)', L.y, -20000, 20000, 0.1, v => bgLayer(i, { y: +v || 0 })));
      f.appendChild(mkNum('Width (tiles)', L.w, 0, 20000, 0.1, v => bgLayer(i, { w: Math.max(0, +v || 0) })));
      f.appendChild(mkNum('Height (0 = keep shape)', L.h, 0, 20000, 0.1, v => bgLayer(i, { h: Math.max(0, +v || 0) })));
      const bb = document.createElement('button');
      bb.textContent = BGE === i ? 'Done moving' : 'Move and resize on the room';
      bb.onclick = () => {
        BGE = BGE === i ? -1 : i;
        bgUI();
        drawT();
      };
      const bl = document.createElement('label');
      bl.append(' ', bb);
      f.appendChild(bl);
    }
    f.appendChild(
      mkNum('Scroll with camera', L.parallax, 0, 2, 0.05, v =>
        bgLayer(i, { parallax: Math.max(0, Math.min(2, +v || 0)) })
      )
    );
    f.appendChild(
      mkSel(
        'Draw',
        [
          ['b', 'Behind the game'],
          ['f', 'In front of the player']
        ],
        L.front ? 'f' : 'b',
        v => bgLayer(i, { front: v === 'f' })
      )
    );
    f.appendChild(
      mkNum('Opacity (0 to 1)', L.alpha, 0, 1, 0.05, v => bgLayer(i, { alpha: Math.max(0, Math.min(1, +v || 0)) }))
    );
    f.appendChild(
      mkNum('Blur (0 to 40)', L.blur, 0, 40, 0.5, v => bgLayer(i, { blur: Math.max(0, Math.min(40, +v || 0)) }))
    );
    f.appendChild(
      mkNum('Fog amount (0 to 1)', L.fog, 0, 1, 0.05, v => bgLayer(i, { fog: Math.max(0, Math.min(1, +v || 0)) }))
    );
    f.appendChild(mkCol('Fog colour', L.fogColor, v => bgLayer(i, { fogColor: v })));
    f.appendChild(
      mkSel(
        'Fog spreads',
        [
          ['even', 'Evenly over the layer'],
          ['bottom', 'Thicker toward the bottom'],
          ['top', 'Thicker toward the top']
        ],
        L.fogDir,
        v => bgLayer(i, { fogDir: v })
      )
    );
    d.appendChild(f);
    box.appendChild(d);
  });
  const row = document.createElement('div');
  row.className = 'row';
  const ab = document.createElement('button');
  ab.textContent = 'Add layer behind the game';
  ab.onclick = () => bgAdd(false);
  const af = document.createElement('button');
  af.textContent = 'Add layer in front of the player';
  af.onclick = () => bgAdd(true);
  const ct = document.createElement('span');
  ct.className = 'hint';
  ct.textContent =
    ' ' +
    b.layers.length +
    ' of ' +
    MV.Background.MAXL +
    ' layers. Layers are drawn in this order: the first is furthest back.';
  row.append(ab, ' ', af, ct);
  box.appendChild(row);
}
const TUNE_CORE = ['Movement', 'Jump'];
function tuneBuild(b, pick, after) {
  const sc = MV.data.playerSchema;
  b.innerHTML = '';
  let box = null,
    grp = '';
  for (const k in sc) {
    const d = sc[k];
    if (d.hide || !pick(d.group)) continue;
    if (d.group !== grp) {
      grp = d.group;
      box = document.createElement('section');
      box.className = 'pgroup';
      const h = document.createElement('h2');
      h.textContent = grp;
      box.appendChild(h);
      b.appendChild(box);
    }
    const row = document.createElement('div');
    row.className = 'prow';
    const lb = document.createElement('label'),
      nm = document.createElement('span'),
      inp = document.createElement('input'),
      hp = document.createElement('div');
    nm.textContent = d.label + (d.unit ? ' (' + d.unit + ')' : '');
    inp.type = 'number';
    inp.min = d.min;
    inp.max = d.max;
    inp.step = d.step;
    inp.value = S.player[k] !== undefined ? S.player[k] : d.def;
    hp.className = 'hint';
    hp.textContent = (d.help || '') + ' Default ' + d.def + ', allowed ' + d.min + ' to ' + d.max + '.';
    inp.onchange = () => {
      const raw = Number(inp.value),
        v = MV.Tuning.clamp(k, inp.value);
      inp.value = v;
      $('pmsg').textContent =
        raw !== v ? d.label + ' adjusted to ' + v + ' (allowed ' + d.min + ' to ' + d.max + ')' : '';
      if (v === d.def) delete S.player[k];
      else S.player[k] = v;
      save();
      if (after) after();
    };
    lb.append(nm, inp);
    row.append(lb, hp);
    box.appendChild(row);
  }
}
function buildTune() {
  tuneBuild($('pset'), g => !TUNE_CORE.includes(g) && g !== 'Camera');
  buildMoves();
  buildAtk();
  buildCt();
  buildSprite();
  buildPo();
  buildDialog();
}
function uniqId(id, skip) {
  let n = id,
    k = 2;
  while (S.moves.some((m, j) => j !== skip && m.id === n)) n = id + k++;
  return n;
}
function mvSync() {
  abSync();
  buildPo();
}
