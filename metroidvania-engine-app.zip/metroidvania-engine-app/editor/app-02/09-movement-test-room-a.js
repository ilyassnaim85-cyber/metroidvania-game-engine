// ===== Movement test room: a small flat room with gaps, platforms, walls and targets, played with the normal game physics. Moves, attacks and tuning are re-read every frame, so changes apply at once. =====
let MTROOM = null;
function mtBuild() {
  const gw = 76,
    gh = 26,
    g = [];
  for (let y = 0; y < gh; y++) g.push('.'.repeat(gw));
  const set = (x, y, c) => {
    g[y] = g[y].substring(0, x) + (c || '#') + g[y].substring(x + 1);
  };
  for (let y = 0; y < gh; y++) {
    set(0, y);
    set(gw - 1, y);
  }
  for (let x = 0; x < gw; x++) for (let y = 22; y < gh; y++) set(x, y);
  const pit = (a, b) => {
    for (let x = a; x <= b; x++) for (let y = 22; y < gh; y++) set(x, y, '.');
  };
  pit(24, 27);
  pit(36, 46); // a short gap to jump and a wide gap to dash or grapple across. The ground right of the start is clear for 10 tiles, so ground moves can run; spikes are at x 33.
  for (let x = 2; x <= 9; x++) set(x, 20); // a low tunnel on the left: roll through it
  [
    [54, 56, 19],
    [57, 59, 16],
    [60, 62, 13],
    [63, 65, 10]
  ].forEach(q => {
    for (let x = q[0]; x <= q[1]; x++) set(x, q[2], '=');
  }); // one-way platforms going up
  for (let y = 6; y <= 21; y++) {
    set(68, y);
    set(72, y);
  } // two walls to wall jump between
  const ent = [],
    E = (type, x, y, props) => ent.push({ id: 't' + ent.length, type, x, y, props: props || {} });
  E('spawn', 12, 21);
  E('breakable', 22, 20, { width: 1, height: 2, hp: 3 });
  E('enemy', 29, 21, { hp: 99, speed: 2, range: 2 });
  E('hazard', 33, 21, { width: 2, height: 0.5 });
  E('breakable', 35, 20, { width: 1, height: 2, hp: 3 });
  E('enemy', 50, 21, { hp: 99, speed: 2, range: 3 });
  E('grapplepoint', 38, 15);
  E('grapplepoint', 44, 15);
  E('bashpoint', 58, 15);
  E('bashpoint', 64, 12);
  return {
    id: 'mt',
    n: 'Movement test',
    s: '',
    x: 40,
    y: 40,
    w: 130,
    h: 44,
    note: '',
    grid: g,
    gw,
    gh,
    art: [],
    table: [],
    tr: [],
    ent,
    cam: null
  };
}
function mtStart() {
  if (V === 'pl') return;
  if (window.cpvStop) cpvStop();
  abSync();
  MTROOM = mtBuild();
  const area = {
      id: '__mt',
      n: 'Movement test',
      s: '',
      c: '#378add',
      x: 0,
      y: 0,
      w: 170,
      h: 56,
      rooms: [MTROOM],
      links: []
    },
    world = Object.assign({}, S, { areas: [area] }),
    st = MV.Progress.fresh();
  for (const id in MV.data.abilities) if (id !== 'wallJump') st.abilities[id] = true;
  st.items = {};
  S.items.forEach(d => {
    st.items[d.id] = Math.min(d.max, 3);
  });
  S.attacks.forEach(a => {
    if (a.weapon) {
      st.weapons = st.weapons || {};
      st.weapons[a.weapon] = 1;
      if (!st.weapon) st.weapon = a.weapon;
    }
  });
  $('mtp').hidden = false;
  MV.Game.debug = $('mtd').checked;
  MV.Game.boxes = $('mtb').checked;
  MV.Game.start({
    enemies: () => S.enemies,
    bosses: () => S.bosses,
    canvas: $('mtc'),
    world,
    room: MTROOM,
    state: st,
    persist: false,
    art: drawArt,
    tuning: () => Object.assign({}, S.player, { maxHp: 99 }),
    image: bgImg,
    moves: () => S.moves,
    attacks: () => S.attacks,
    items: () => S.items,
    body: () => S.body,
    controls: () => S.controls,
    sprite: () => S.sprite,
    sheet: sheetOf
  });
}
function mtStop() {
  if (MTROOM && MV.Game.room() === MTROOM) MV.Game.stop();
  MTROOM = null;
  const p = $('mtp');
  if (p) p.hidden = true;
}
function mtOpen() {
  mtStart();
}
$('mtg').onclick = mtOpen;
$('mtr').onclick = mtStart;
$('mtx').onclick = mtStop;
$('mtd').onchange = () => {
  MV.Game.debug = $('mtd').checked;
};
$('mtb').onchange = () => {
  MV.Game.boxes = $('mtb').checked;
};
