// ===== Inventory tab: items, tabs, weapons and abilities, design =====
let II = 0,
  IVS = 'items',
  IVT = 0,
  IVSEL = 0;
const IV_SEC = [
  ['items', 'Items'],
  ['tabs', 'Tabs'],
  ['meta', 'Weapons and abilities'],
  ['design', 'Design']
];
const IV = () => S.inv || (S.inv = MV.Inventory.cleanDesign(null));
const ivSet = p => {
  S.inv = MV.Inventory.cleanDesign(Object.assign({}, IV(), p));
  save();
  buildItems();
};
function uniqItem(id, skip) {
  let n = id,
    k = 2;
  while (S.items.some((q, j) => j !== skip && q.id === n)) n = id + k++;
  return n;
}
const iconSet = (get, put) => patch => {
  const a = Object.assign(
    { sheet: '', col: 0, row: 0, frames: 1, fps: 12, loop: false, fit: true },
    get() || {},
    patch
  );
  put(a.sheet ? a : null);
  save();
  buildItems();
};
function iconBox(host, title, get, put) {
  const d = document.createElement('details');
  d.open = !!get();
  const sm = document.createElement('summary');
  sm.textContent = title + (get() ? ' (set)' : ' (none)');
  d.appendChild(sm);
  const set = iconSet(get, put);
  d.appendChild(animForm(get(), set, buildItems));
  if (get())
    d.appendChild(
      btn('Remove picture', () => {
        put(null);
        save();
        buildItems();
      })
    );
  host.appendChild(d);
}
// the sample the preview draws: every item (a few of each), every weapon the attacks name, and the abilities
function ivSample() {
  const st = { items: {}, weapons: {}, weapon: '', abilities: {} };
  S.items.forEach(d => {
    st.items[d.id] = Math.min(d.max, 3);
  });
  [
    ...new Set(
      S.attacks
        .map(q => q.weapon)
        .filter(Boolean)
        .concat(
          Object.keys(IV().meta)
            .filter(k => k[0] === 'w')
            .map(k => k.slice(2))
        )
    )
  ].forEach((w, i) => {
    st.weapons[w] = 1;
    if (!i) st.weapon = w;
  });
  for (const k in MV.data.abilities) st.abilities[k] = 1;
  return st;
}
function invPreview() {
  const c = $('ivc');
  if (!c || $('pit').hidden) return;
  const x = c.getContext('2d'),
    D = IV();
  x.clearRect(0, 0, c.width, c.height);
  x.fillStyle = '#2b6b8f';
  x.fillRect(0, 0, c.width, c.height);
  x.fillStyle = '#1d4a63';
  for (let i = 0; i < 10; i++) x.fillRect(i * 70, 250 + (i % 3) * 14, 60, 110);
  x.fillStyle = '#e8c34a';
  x.fillRect(120, 90, 40, 40);
  x.fillRect(430, 150, 60, 24); // a scene behind the panel so the transparency shows
  if (IVT >= D.tabs.length) IVT = D.tabs.length - 1;
  const l = MV.Inventory.entries(D, ivSample(), S.items, IVT, MV.data.abilities);
  if (IVSEL >= l.length) IVSEL = Math.max(0, l.length - 1);
  MV.Inventory.draw(x, c.width, c.height, D, { tab: IVT, sel: IVSEL, list: l }, sheetOf, performance.now() / 1000);
}
setInterval(invPreview, 120);
function buildItems() {
  const bar = $('ivbar'),
    B = $('ivb');
  if (!bar) return;
  bar.innerHTML = '';
  B.innerHTML = '';
  const D = IV();
  if (IVT >= D.tabs.length) IVT = 0;
  IV_SEC.forEach(q => {
    const b = btn(q[1], () => {
      IVS = q[0];
      buildItems();
    });
    if (q[0] === IVS) b.className = 'on';
    bar.appendChild(b);
  });
  const ts = $('ivt');
  ts.innerHTML = '';
  D.tabs.forEach((t, i) => {
    const o = document.createElement('option');
    o.value = i;
    o.textContent = t.name;
    ts.appendChild(o);
  });
  ts.value = IVT;
  ts.onchange = () => {
    IVT = +ts.value;
    IVSEL = 0;
    invPreview();
  };
  $('ivh').textContent = 'The picture is a preview with sample counts.';
  if (IVS === 'items') ivItems(B, D);
  else if (IVS === 'tabs') ivTabs(B, D);
  else if (IVS === 'meta') ivMeta(B, D);
  else ivDesign(B, D);
  invPreview();
}
function ivItems(B, D) {
  const wrap = document.createElement('div');
  wrap.className = 'mde';
  const asd = document.createElement('aside');
  asd.className = 'mdl';
  asd.innerHTML = '<div class="mdh">Items</div>';
  const L = document.createElement('div');
  asd.appendChild(L);
  const add = document.createElement('div');
  add.className = 'mdadd';
  add.append(
    btn('New item', () => {
      if (S.items.length >= 24) {
        $('pmsg').textContent = 'Up to 24 items.';
        return;
      }
      const n = S.items.length + 1;
      S.items.push(MV.Inventory.clean1({ id: uniqItem('item' + n, -1), name: 'Item ' + n }));
      II = S.items.length - 1;
      save();
      buildItems();
      focusName($('ivb'));
    }),
    btn('Delete all items', () => {
      const n = S.items.length;
      if (!n) return;
      if (!confirm('Delete all ' + n + ' item' + (n > 1 ? 's' : '') + '? Undo can bring them back.')) return;
      S.items = [];
      II = 0;
      save();
      buildItems();
    })
  );
  asd.appendChild(add);
  wrap.appendChild(asd);
  if (II >= S.items.length) II = Math.max(0, S.items.length - 1);
  S.items.forEach((d, i) => {
    const b = document.createElement('button');
    b.className = 'item' + (i === II ? ' on' : '');
    b.textContent = d.name + '  (' + d.id + ')';
    b.onclick = () => {
      II = i;
      buildItems();
    };
    L.appendChild(b);
  });
  const R = document.createElement('div');
  R.className = 'mdr';
  const body = document.createElement('div');
  body.className = 'mdb';
  R.appendChild(body);
  wrap.appendChild(R);
  B.appendChild(wrap);
  const d = S.items[II];
  if (!d) {
    const h = document.createElement('p');
    h.className = 'hint';
    h.textContent = 'No items yet. Click New item to define one (a potion, a key...).';
    body.appendChild(h);
    return;
  }
  const f = document.createElement('div');
  f.className = 'mvf';
  const F = MV.Inventory.FIELDS;
  for (const k in F) {
    const fd = F[k];
    if (k === 'amount' && d.use !== 'heal') continue;
    if ((k === 'notches' || k === 'grant') && d.use !== 'charm') continue;
    let l;
    const apply = v => {
      const nx = MV.Inventory.clean1(Object.assign({}, d, { [k]: v }));
      if (k === 'id') nx.id = uniqItem(nx.id, II);
      Object.assign(d, nx);
      save();
      buildItems();
    };
    if (k === 'tab') {
      const tabs = D.tabs.filter(t => t.kind === 'items');
      l = mkSel(
        fd.label,
        tabs
          .map(t => [t.id, t.name])
          .concat(d.tab && !tabs.some(t => t.id === d.tab) ? [[d.tab, d.tab + ' (missing)']] : []),
        d.tab || (tabs[0] && tabs[0].id) || '',
        apply
      );
    } else if (fd.t === 'select')
      l = mkSel(
        fd.label,
        fd.o.map(v => [v, (fd.names && fd.names[v]) || v]),
        d[k],
        apply
      );
    else if (fd.t === 'number') l = mkNum(fd.label, d[k], fd.min, fd.max, fd.step, apply);
    else {
      l = document.createElement('label');
      const q = document.createElement('input');
      q.type = 'text';
      q.value = d[k];
      q.maxLength = k === 'desc' ? 90 : 24;
      q.onchange = () => apply(q.value);
      l.append(fd.label, q);
    }
    l.title = fd.help || '';
    f.appendChild(l);
  }
  body.appendChild(f);
  if (d.use === 'charm') {
    const mh = document.createElement('strong');
    mh.textContent = 'What the charm changes while equipped';
    body.appendChild(mh);
    const MD = MV.Inventory.MODS,
      setMods = fn => {
        const mods = JSON.parse(JSON.stringify(d.mods || []));
        fn(mods);
        Object.assign(d, MV.Inventory.clean1(Object.assign({}, d, { mods })));
        save();
        buildItems();
      };
    (d.mods || []).forEach((q, i) => {
      const r = document.createElement('div');
      r.className = 'mvf';
      r.appendChild(
        mkSel(
          'Changes',
          Object.keys(MD).map(k => [k, MD[k][0]]),
          q.key,
          v =>
            setMods(a => {
              a[i].key = v;
            })
        )
      );
      r.appendChild(
        mkNum('By (negative lowers)', q.add, MD[q.key][1], MD[q.key][2], 0.5, v =>
          setMods(a => {
            a[i].add = v;
          })
        )
      );
      r.appendChild(
        btn('Remove', () =>
          setMods(a => {
            a.splice(i, 1);
          })
        )
      );
      body.appendChild(r);
    });
    if ((d.mods || []).length < 6)
      body.appendChild(
        btn('Add a change', () =>
          setMods(a => {
            const k = Object.keys(MD).find(z => !a.some(q => q.key === z)) || 'damage';
            a.push({ key: k, add: 1 });
          })
        )
      );
    const ch2 = document.createElement('p');
    ch2.className = 'hint';
    ch2.textContent =
      'The player equips charms in the inventory (Enter). They only fit while the notches used stay within the notches you have (Settings, Charms; upgrade pickups give more). The item must be in the bag.';
    body.appendChild(ch2);
  }
  iconBox(
    body,
    'Picture (sprite)',
    () => d.icon,
    v => {
      d.icon = v;
      Object.assign(d, MV.Inventory.clean1(d));
    }
  );
  const r = document.createElement('div');
  r.className = 'row';
  r.append(
    btn('Duplicate', () => {
      if (S.items.length >= 24) {
        $('pmsg').textContent = 'Up to 24 items.';
        return;
      }
      const c = MV.Inventory.clean1(Object.assign({}, d, { id: uniqItem(d.id, -1) }));
      S.items.splice(II + 1, 0, c);
      II++;
      save();
      buildItems();
    }),
    btn('Delete item', () => {
      S.items.splice(II, 1);
      save();
      buildItems();
    })
  );
  body.appendChild(r);
  const u = document.createElement('p');
  u.className = 'hint';
  u.textContent = 'To give it: Entities, Pickup, kind item, give ' + d.id + '. A chest can give it too (reward item).';
  body.appendChild(u);
}
function ivTabs(B, D) {
  const h = document.createElement('p');
  h.className = 'hint';
  h.textContent =
    'Each tab is a page of the inventory screen. Items tab: lists the items assigned to it (set an item\'s "Shown in tab" in Items). Weapons tab: the weapons you own. Abilities tab: the abilities you have unlocked. Up to 8 tabs.';
  B.appendChild(h);
  D.tabs.forEach((t, i) => {
    const box = document.createElement('div');
    box.className = 'mv';
    const hd = document.createElement('strong');
    hd.textContent = i + 1 + '. ' + t.name;
    box.appendChild(hd);
    const f = document.createElement('div');
    f.className = 'mvf';
    const put = fn => {
      const tabs = JSON.parse(JSON.stringify(D.tabs));
      fn(tabs);
      ivSet({ tabs });
    };
    f.appendChild(
      mkText('Name', t.name, v =>
        put(a => {
          a[i].name = v;
        })
      )
    );
    f.appendChild(
      mkText('Id (items refer to it)', t.id, v =>
        put(a => {
          const old = a[i].id,
            nid = (v || '').replace(/[^\w-]/g, '').slice(0, 24) || old;
          if (!a.some((q, j) => j !== i && q.id === nid)) {
            a[i].id = nid;
            S.items.forEach(d => {
              if (d.tab === old) d.tab = nid;
            });
          }
        })
      )
    );
    f.appendChild(
      mkSel(
        'Shows',
        [
          ['items', 'Items assigned to it'],
          ['weapons', 'Weapons you own'],
          ['abilities', 'Abilities you have']
        ],
        t.kind,
        v =>
          put(a => {
            a[i].kind = v;
          })
      )
    );
    box.appendChild(f);
    iconBox(
      box,
      'Tab picture (sprite)',
      () => t.icon,
      v => {
        const tabs = JSON.parse(JSON.stringify(IV().tabs));
        tabs[i].icon = v;
        S.inv = MV.Inventory.cleanDesign(Object.assign({}, IV(), { tabs }));
      }
    );
    const r = document.createElement('div');
    r.className = 'row';
    if (i > 0)
      r.appendChild(
        btn('Move left', () =>
          put(a => {
            const q = a[i];
            a[i] = a[i - 1];
            a[i - 1] = q;
          })
        )
      );
    if (i < D.tabs.length - 1)
      r.appendChild(
        btn('Move right', () =>
          put(a => {
            const q = a[i];
            a[i] = a[i + 1];
            a[i + 1] = q;
          })
        )
      );
    if (D.tabs.length > 1)
      r.appendChild(
        btn('Remove tab', () =>
          put(a => {
            a.splice(i, 1);
          })
        )
      );
    box.appendChild(r);
    B.appendChild(box);
  });
  B.appendChild(
    btn('Add tab', () => {
      if (D.tabs.length >= 8) {
        $('pmsg').textContent = 'Up to 8 tabs.';
        return;
      }
      const tabs = JSON.parse(JSON.stringify(D.tabs)),
        n = tabs.length + 1;
      let id = 'tab' + n;
      while (tabs.some(q => q.id === id)) id += 'x';
      tabs.push({ id, name: 'Tab ' + n, kind: 'items', icon: null });
      ivSet({ tabs });
    })
  );
}
function ivMeta(B, D) {
  const h = document.createElement('p');
  h.className = 'hint';
  h.textContent =
    'Give weapons and abilities a display name, a description and a picture for the inventory. Weapons come from the "Weapon id" of your attacks; abilities from your pickups and moves. Leave a name empty to show the id.';
  B.appendChild(h);
  const row = (key, label) => {
    const m = D.meta[key] || { name: '', desc: '', icon: null },
      d = document.createElement('details');
    d.open = !!(m.name || m.desc || m.icon);
    const sm = document.createElement('summary');
    sm.textContent = label + (m.name ? ' - ' + m.name : '') + (m.icon ? ' (picture)' : '');
    d.appendChild(sm);
    const put = fn => {
      const meta = JSON.parse(JSON.stringify(IV().meta));
      meta[key] = meta[key] || { name: '', desc: '', icon: null };
      fn(meta[key]);
      ivSet({ meta });
    };
    const f = document.createElement('div');
    f.className = 'mvf';
    f.appendChild(
      mkText('Name', m.name, v =>
        put(q => {
          q.name = v;
        })
      )
    );
    f.appendChild(
      mkText('Description', m.desc, v =>
        put(q => {
          q.desc = v;
        })
      )
    );
    d.appendChild(f);
    iconBox(
      d,
      'Picture (sprite)',
      () => (IV().meta[key] || {}).icon || null,
      v => {
        const meta = JSON.parse(JSON.stringify(IV().meta));
        meta[key] = meta[key] || { name: '', desc: '', icon: null };
        meta[key].icon = v;
        S.inv = MV.Inventory.cleanDesign(Object.assign({}, IV(), { meta }));
      }
    );
    B.appendChild(d);
  };
  const ws = [...new Set(S.attacks.map(q => q.weapon).filter(Boolean))];
  const ab = Object.keys(MV.data.abilities);
  const t1 = document.createElement('strong');
  t1.textContent = 'Weapons';
  B.appendChild(t1);
  if (!ws.length) {
    const p = document.createElement('p');
    p.className = 'hint';
    p.textContent = 'No attack has a Weapon id yet (Attacks tab).';
    B.appendChild(p);
  }
  ws.forEach(w => row('w:' + w, w));
  const t2 = document.createElement('strong');
  t2.textContent = 'Abilities';
  B.appendChild(t2);
  ab.forEach(a => row('a:' + a, MV.data.abilities[a].label || a));
}
function ivDesign(B, D) {
  const f = document.createElement('div');
  f.className = 'mvf';
  const set = ivSet;
  f.appendChild(mkText('Title', D.title, v => set({ title: v })));
  f.appendChild(
    keyField(
      { label: 'Open and close with', help: 'The key that opens the inventory in the game.' },
      D,
      'key',
      () => {},
      m => {
        S.inv = MV.Inventory.cleanDesign(m);
      }
    )
  );
  f.appendChild(
    mkSel(
      'Layout',
      [
        ['grid', 'Grid of slots'],
        ['list', 'List']
      ],
      D.layout,
      v => set({ layout: v })
    )
  );
  f.appendChild(mkNum('Columns (grid)', D.cols, 1, 10, 1, v => set({ cols: +v })));
  f.appendChild(mkNum('Slot size (px)', D.slot, 24, 96, 1, v => set({ slot: +v })));
  f.appendChild(mkNum('Panel width (% of screen)', D.w, 30, 100, 1, v => set({ w: +v })));
  f.appendChild(mkNum('Panel height (% of screen)', D.h, 30, 100, 1, v => set({ h: +v })));
  f.appendChild(mkNum('Panel opacity (0 = see-through, 1 = solid)', D.opacity, 0, 1, 0.05, v => set({ opacity: +v })));
  f.appendChild(mkNum('Darken the game behind (0 to 1)', D.dim, 0, 1, 0.05, v => set({ dim: +v })));
  f.appendChild(mkNum('Slot opacity (0 to 1)', D.slota, 0, 1, 0.05, v => set({ slota: +v })));
  f.appendChild(mkNum('Text size (px)', D.font, 10, 24, 1, v => set({ font: +v })));
  f.appendChild(mkNum('Corner roundness (px)', D.radius, 0, 30, 1, v => set({ radius: +v })));
  f.appendChild(mkNum('Border width (px)', D.bwidth, 0, 8, 1, v => set({ bwidth: +v })));
  f.appendChild(
    mkSel(
      'Description panel',
      [
        ['yes', 'Show'],
        ['no', 'Hide']
      ],
      D.detail,
      v => set({ detail: v })
    )
  );
  [
    ['Panel colour', 'panel'],
    ['Border colour', 'border'],
    ['Text colour', 'text'],
    ['Faded text colour', 'muted'],
    ['Selection and tab colour', 'accent'],
    ['Slot colour', 'slotc']
  ].forEach(([lab, k]) => f.appendChild(mkClr(lab, D[k], v => set({ [k]: v }))));
  B.appendChild(f);
  const t = document.createElement('strong');
  t.textContent = 'Panel picture';
  B.appendChild(t);
  const p = document.createElement('p');
  p.className = 'hint';
  p.textContent =
    'Draw the panel from a picture instead of a colour. The corners of the image (Border size pixels) are kept and the middle is stretched. The panel opacity applies to the picture too.';
  B.appendChild(p);
  const g = document.createElement('div');
  g.className = 'mvf';
  g.appendChild(
    mkSel('Panel sprite', [['', '(plain colour)'], ...S.sheets.map(v => [v.id, v.name])], D.sheet, v =>
      set({ sheet: v })
    )
  );
  {
    const il = document.createElement('label'),
      fi = document.createElement('input');
    fi.type = 'file';
    fi.accept = 'image/*';
    fi.onchange = () => {
      const fl = fi.files[0];
      fi.value = '';
      if (!fl) return;
      const fr = new FileReader();
      fr.onload = () => {
        const q = { id: 's' + rid(), name: fl.name.slice(0, 40), url: fr.result, tw: 16, th: 16 };
        S.sheets.push(q);
        set({ sheet: q.id });
      };
      fr.readAsDataURL(fl);
    };
    il.append('Import image', fi);
    g.appendChild(il);
  }
  g.appendChild(
    mkNum('Border size (pixels of the image kept as the frame)', D.slice, 1, 64, 1, v => set({ slice: +v }))
  );
  g.appendChild(mkNum('Border scale', D.scale, 1, 6, 1, v => set({ scale: +v })));
  B.appendChild(g);
  B.appendChild(
    btn('Reset the design', () => {
      if (!confirm('Put every inventory design setting back to the default? Tabs and pictures are kept.')) return;
      const k = MV.Inventory.defDesign();
      set({
        layout: k.layout,
        cols: k.cols,
        slot: k.slot,
        w: k.w,
        h: k.h,
        opacity: k.opacity,
        dim: k.dim,
        radius: k.radius,
        font: k.font,
        detail: k.detail,
        panel: k.panel,
        border: k.border,
        bwidth: k.bwidth,
        text: k.text,
        muted: k.muted,
        accent: k.accent,
        slotc: k.slotc,
        slota: k.slota,
        sheet: '',
        slice: k.slice,
        scale: k.scale,
        title: k.title,
        key: k.key
      });
    })
  );
}
