// ===== Player tab: sub-tabs, attacks, and the hitbox timeline used by attacks and moves =====
let PSUB = 'set',
  AI = 0,
  MI = -1,
  TLACT = null,
  TLLAST = 0,
  TLON = false;
const TLS = {},
  TLE = {},
  TLZ = 44;
function abSync() {
  MV.Moves.sync(MV.Moves.resolve(S.moves).concat(MV.Attacks.resolve(S.attacks, S.player)));
}
function psSub(s) {
  PSUB = s;
  if (s !== 'cam' && window.cpvStop) cpvStop();
  document.querySelectorAll('#psub .tab').forEach(b => b.classList.toggle('on', b.dataset.ps === s));
  document.querySelectorAll('#pls>[data-ps]').forEach(e => {
    e.hidden = e.dataset.ps !== s;
  });
  if (s === 'anim') {
    buildSprite();
    pvStart();
  }
  if (s === 'atk') buildAtk();
  if (s === 'it') {
    buildItems();
  }
  if (s === 'hb') buildHb();
  if (s === 'ct') buildCt();
  if (s === 'ui' && window.uiUI) uiUI();
  if (s === 'cam') buildCam();
  if (s === 'mv') buildMoves();
  tlStart();
}
document.querySelectorAll('#psub .tab').forEach(b => (b.onclick = () => psSub(b.dataset.ps)));
function uniqAtk(id, skip) {
  let n = id,
    k = 2;
  while (S.attacks.some((a, j) => j !== skip && a.id === n)) n = id + k++;
  return n;
}
const atkApply = a => fn => {
  fn(a);
  Object.assign(a, MV.Attacks.clean1(a));
  abSync();
  save();
};
const ATK_BASIC = [
    'label',
    'key',
    'with',
    'requires',
    'weapon',
    'where',
    'damage',
    'dtype',
    'inflict',
    'inflictTime',
    'cost',
    'duration',
    'cooldown',
    'speed'
  ],
  ATK_BASIC_TOP = ['label', 'key', 'with', 'requires', 'weapon', 'where'];
function buildAtk() {
  if (AI >= S.attacks.length) AI = Math.max(0, S.attacks.length - 1);
  const L = $('atl');
  L.innerHTML = '';
  // Weapons: the weapon ids the attacks belong to. A filter shows one weapon's attacks, and each attack in the list shows its weapon.
  const WPS = [...new Set(S.attacks.map(q => q.weapon).filter(Boolean))];
  if (AFILT !== '*' && AFILT !== '' && !WPS.includes(AFILT)) AFILT = '*';
  if (WPS.length) {
    const fs = document.createElement('select');
    fs.title = 'Show only the attacks of one weapon';
    fs.style.cssText = 'width:100%;margin-bottom:6px';
    [
      ['*', 'All attacks (' + S.attacks.length + ')'],
      ['', 'No weapon (' + S.attacks.filter(q => !q.weapon).length + ')']
    ]
      .concat(WPS.map(w => [w, 'Weapon: ' + w + ' (' + S.attacks.filter(q => q.weapon === w).length + ')']))
      .forEach(([v, t]) => {
        const o = document.createElement('option');
        o.value = v;
        o.textContent = t;
        fs.appendChild(o);
      });
    fs.value = AFILT;
    fs.onchange = () => {
      AFILT = fs.value;
      buildAtk();
    };
    L.appendChild(fs);
  }
  S.attacks.forEach((a, i) => {
    if (AFILT !== '*' && (a.weapon || '') !== AFILT && i !== AI) return;
    const b = document.createElement('button');
    b.className = 'item' + (i === AI ? ' on' : '');
    b.textContent = a.label + '  (' + keyCombo(a) + ')' + (a.weapon ? '  [' + a.weapon + ']' : '');
    b.onclick = () => {
      AI = i;
      buildAtk();
    };
    L.appendChild(b);
  });
  if (WPS.length) {
    const wn = document.createElement('p');
    wn.className = 'hint';
    wn.textContent =
      'Weapons: ' +
      WPS.join(', ') +
      '. To give one, place a Pickup (or Chest) of kind weapon and write the weapon id in give. Tab switches weapons in the game.';
    L.appendChild(wn);
  }
  const T0 = $('att'),
    F = $('atb');
  T0.innerHTML = '';
  F.innerHTML = '';
  const a = S.attacks[AI];
  if (!a) {
    T0.className = 'mdt hint';
    T0.textContent = 'No attacks yet, so the attack keys do nothing. Click New attack to build one.';
    return;
  }
  T0.className = 'mdt';
  const adv = isAdv(),
    ch = atkApply(a),
    cl = m => {
      Object.assign(m, MV.Attacks.clean1(m));
      abSync();
    };
  const f = document.createElement('div'),
    f2 = document.createElement('div');
  f.className = 'mvf';
  f2.className = 'mvf';
  for (const k in MV.Attacks.FIELDS) {
    if (!adv && !ATK_BASIC.includes(k)) continue;
    const fd = MV.Attacks.FIELDS[k],
      box = (adv ? MV.Attacks.TOP : ATK_BASIC_TOP).includes(k) ? f : f2;
    if (k === 'requires') {
      const l = document.createElement('label');
      l.title = fd.help || '';
      l.append(
        fd.label,
        abilityPick(
          a.requires,
          v => {
            ch(x => {
              x.requires = v;
            });
            buildAtk();
          },
          true
        )
      );
      box.appendChild(l);
      continue;
    }
    if (fd.t === 'key') {
      box.appendChild(keyField(fd, a, k, () => {}, cl));
      if (k === 'with')
        moreKeysUI(
          a,
          fn => {
            ch(fn);
            buildAtk();
          },
          box
        );
      continue;
    }
    const l = document.createElement('label');
    let inp;
    l.title = fd.help || '';
    if (fd.t === 'select') {
      inp = document.createElement('select');
      fd.o.forEach(v => {
        const o = document.createElement('option');
        o.value = o.textContent = v;
        inp.appendChild(o);
      });
    } else {
      inp = document.createElement('input');
      inp.type = fd.t === 'number' ? 'number' : 'text';
      if (fd.t === 'number') {
        inp.min = fd.min;
        inp.max = fd.max;
        inp.step = fd.step;
      }
    }
    inp.value = a[k];
    inp.onchange = () => {
      const raw = inp.value;
      ch(x => {
        x[k] = raw;
      });
      $('pmsg').textContent =
        fd.t === 'number' && String(+raw) !== String(a[k])
          ? fd.label + ' adjusted to ' + a[k] + ' (allowed ' + fd.min + ' to ' + fd.max + ')'
          : '';
      buildAtk();
    };
    l.append(fd.label, inp);
    box.appendChild(l);
  }
  if (!adv && a.hitboxes.length) {
    const h0 = a.hitboxes[0];
    if (h0.shape === 'circle')
      f2.appendChild(
        mkNum('Attack box radius (tiles)', h0.r, 0.05, 15, 0.05, v => {
          ch(x => {
            x.hitboxes[0].r = +v;
          });
          buildAtk();
        })
      );
    else if (h0.shape === 'rect') {
      f2.appendChild(
        mkNum('Attack box width (tiles)', h0.w, 0.1, 30, 0.1, v => {
          ch(x => {
            x.hitboxes[0].w = +v;
          });
          buildAtk();
        })
      );
      f2.appendChild(
        mkNum('Attack box height (tiles)', h0.h, 0.1, 30, 0.1, v => {
          ch(x => {
            x.hitboxes[0].h = +v;
          });
          buildAtk();
        })
      );
    }
  }
  // The attack editor is split into sections, like moves: Attack (what it does), Hitbox (the part of the player that gets hurt), Attack boxes, Path and speed, Shots and effects, Animation.
  const secs = [
    ['attack', 'Attack'],
    ['hitbox', 'Hitbox'],
    ['boxes', 'Attack boxes']
  ];
  if (adv) secs.push(['path', 'Path and speed'], ['fx', 'Shots and effects'], ['anim', 'Animation']);
  let sec = ASEC;
  if (!secs.some(q => q[0] === sec)) sec = 'attack';
  const bar = document.createElement('div');
  bar.className = 'row secbar';
  secs.forEach(q => {
    const b = btn(q[1], () => {
      ASEC = q[0];
      buildAtk();
    });
    if (q[0] === sec) b.className = 'on';
    bar.appendChild(b);
  });
  T0.appendChild(bar);
  const hint = t => {
    const p = document.createElement('p');
    p.className = 'hint';
    p.textContent = t;
    T0.appendChild(p);
  };
  const sub = () => {
    const d = document.createElement('div');
    F.appendChild(d);
    return d;
  };
  const tlo = (sh, title, hnt) => ({
    T: () => a,
    list: 'hitboxes',
    body: false,
    curve: true,
    path: true,
    sh,
    title,
    hint: hnt,
    fit: true,
    an: () => a.anim,
    dur: () => a.duration,
    vel: () => (a.lock === 'yes' || a.speed > 0 ? a.speed : 0),
    ch
  });
  if (sec === 'attack') {
    hint('An attack: attack boxes that hurt what they touch for a moment.');
    if (!adv) {
      hint(
        "This is the Basic view: the Attack and Hitbox sections. Advanced adds moving and shaping attack boxes through time, the player's own route, the speed curve, shots, effects and the animation."
      );
      const rr = document.createElement('div');
      rr.className = 'row';
      rr.append(
        btn('Open Advanced view', () => setView('adv')),
        btn('Test movement', mtOpen)
      );
      T0.appendChild(rr);
    }
    const sh0 = document.createElement('strong');
    sh0.textContent = 'Attack';
    F.appendChild(sh0);
    F.appendChild(f);
    const mh = document.createElement('strong');
    mh.textContent = 'Movement and timing';
    F.appendChild(mh);
    if (adv) {
      const mp = document.createElement('p');
      mp.className = 'hint';
      mp.textContent =
        'To move the player during the attack (a dash slash), draw a route in Path and speed, or use Forward speed here. The route wins when it has two or more points.';
      F.appendChild(mp);
      if (a.path && a.path.length > 1) {
        const pw = document.createElement('div');
        pw.className = 'cwarn';
        pw.textContent = 'This attack follows a route drawn in Path and speed, so Forward speed does nothing.';
        F.appendChild(pw);
        const pr2 = document.createElement('div');
        pr2.className = 'row';
        pr2.append(
          btn('Delete the route (use Forward speed)', () => {
            ch(x => {
              x.path = [];
            });
            buildAtk();
          }),
          btn('Edit the route', () => {
            ASEC = 'path';
            buildAtk();
          })
        );
        F.appendChild(pr2);
      }
    }
    F.appendChild(f2);
    const r = document.createElement('div');
    r.className = 'row';
    r.append(
      btn('Duplicate', () => {
        if (S.attacks.length >= 12) {
          $('pmsg').textContent = 'Up to 12 attacks.';
          return;
        }
        S.attacks.splice(
          AI + 1,
          0,
          MV.Attacks.clean1(
            Object.assign(JSON.parse(JSON.stringify(a)), { id: uniqAtk(a.id + '_copy', -1), label: a.label + ' copy' })
          )
        );
        AI++;
        abSync();
        save();
        buildAtk();
      }),
      btn('Delete', () => {
        S.attacks.splice(AI, 1);
        abSync();
        save();
        buildAtk();
      })
    );
    F.appendChild(r);
  } else if (sec === 'hitbox') {
    hint(
      'The hitbox is the part of the player that gets hurt (enemies, boss attacks, spikes). Pick a time with the slider, then drag the green box on the screen to move it and its white corner squares to resize it. Every change makes a keyframe and the box glides between keyframes. Add invincible periods (from a time to a time) when nothing can hurt the player during the attack. In Test movement the player picture follows this hitbox. Its shape (rectangle, circle, polygon) and normal size are set by choosing "The normal hitbox" in the Editing menu above the picture.'
    );
    hbMount(sub(), 'a:' + a.id);
  } else if (sec === 'boxes') {
    hint(
      'Attack boxes hurt what they touch. Add a box, move the time slider, and drag the box in the picture: each drag adds a keyframe, and the box sweeps between them. Each box has a from and to time, a shape and its own look.'
    );
    tlBuild(sub(), 'a:' + a.id + ':a', tlo({ hits: true, path: false, curve: false }, 'Attack boxes', ''));
  } else if (sec === 'path') {
    hint(
      'The path is where the player goes during the attack (a dash slash); the speed curve changes how fast. With fewer than two points the attack uses Forward speed.'
    );
    tlBuild(sub(), 'a:' + a.id + ':p', tlo({ hits: false, path: true, curve: true }, 'Path and speed', ''));
  } else if (sec === 'fx') {
    hint(
      'What else the attack does: chain into another move or attack (combos), charge up, fire shots, and trigger effects when it starts, hits, lands, touches a wall or ends.'
    );
    extrasUI(sub(), a, true, fn => {
      ch(fn);
      buildAtk();
    });
  } else if (sec === 'anim') {
    const A = sub();
    {
      const hp = document.createElement('p');
      hp.className = 'hint';
      hp.textContent =
        'The picture shown on the player while this attack plays. "Fit" spreads all frames over the attack\'s ' +
        a.duration +
        ' s. Without one, the player uses its Attack animation from the Sprite and animations tab.';
      A.appendChild(hp);
      A.appendChild(
        animForm(
          a.anim,
          patch => {
            ch(x => {
              const n = Object.assign(
                { sheet: '', col: 0, row: 0, frames: 1, fps: 12, loop: false, fit: true },
                x.anim || {},
                patch
              );
              x.anim = n.sheet ? n : null;
            });
            buildAtk();
          },
          buildAtk
        )
      );
      const fl = document.createElement('label'),
        fc = document.createElement('input');
      fc.type = 'checkbox';
      fc.checked = !a.anim || a.anim.fit;
      fc.disabled = !a.anim;
      fc.onchange = () => {
        ch(x => {
          x.anim.fit = fc.checked;
        });
        buildAtk();
      };
      fl.append(fc, ' Fit all frames into the attack length');
      A.appendChild(fl);
      const sc = document.createElement('canvas');
      sc.width = 640;
      sc.height = 64;
      sc.style.cssText = 'width:100%;height:auto;border:1px solid var(--bd);border-radius:8px;margin-top:6px';
      A.appendChild(sc);
      drawMoveStrip(sc, { sprite: a.anim, type: 'dash', duration: a.duration });
    }
  }
}
function addAtk(src) {
  if (S.attacks.length >= 12) {
    $('pmsg').textContent = 'Up to 12 attacks.';
    return;
  }
  ASEC = 'attack';
  const a = MV.Attacks.clean1(Object.assign(JSON.parse(JSON.stringify(src)), { id: uniqAtk(src.id || 'attack', -1) }));
  S.attacks.push(a);
  AI = S.attacks.length - 1;
  abSync();
  save();
  buildAtk();
  $('pmsg').textContent =
    'Added "' +
    a.label +
    '". In a playtest press ' +
    keyCombo(a) +
    (a.requires ? ' (unlocked by "' + a.requires + '", ticked in Playtest setup)' : '') +
    '.';
}
$('atn').onclick = () => {
  addAtk({
    id: 'attack',
    label: 'Attack ' + (S.attacks.length + 1),
    hitboxes: [{ name: 'Attack box 1', w: 1.2, h: 1, from: 0.05, to: 0.2, kf: [{ t: 0.05, x: 1, y: -0.8 }] }]
  });
  focusName($('atb'));
};
$('atr').onclick = () => {
  const n = S.attacks.length;
  if (!n) return;
  if (!confirm('Delete all ' + n + ' attack' + (n > 1 ? 's' : '') + '? Undo can bring them back.')) return;
  S.attacks = [];
  AI = 0;
  abSync();
  save();
  buildAtk();
};
