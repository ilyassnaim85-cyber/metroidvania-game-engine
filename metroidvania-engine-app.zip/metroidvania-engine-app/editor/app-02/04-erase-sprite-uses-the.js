// Erase sprite uses the same shapes as the tile tools: drag with a pencil (any brush size), or drag a line, rectangle, outline or ellipse and every sprite it touches is removed.
(() => {
  const d = document.createElement('div');
  d.className = 'row';
  d.id = 'erow';
  d.hidden = true;
  d.title = 'How Erase sprite removes sprites.';
  [
    ['pencil', 'Pencil (drag)', 'Erase sprites under the brush as you drag.'],
    ['line', 'Line', 'Drag a line: every sprite on it is erased.'],
    ['rect', 'Rectangle', 'Drag a box: every sprite inside is erased.'],
    ['frame', 'Outline', 'Drag a box: only sprites on its outline are erased.'],
    ['ellipse', 'Ellipse', 'Drag a box: sprites inside the ellipse are erased.'],
    ['ring', 'Ellipse outline', 'Drag a box: sprites on the ellipse outline are erased.']
  ].forEach(a => {
    const b = document.createElement('button');
    b.className = 'shb';
    b.dataset.er = a[0];
    b.textContent = a[1];
    b.title = a[2];
    b.onclick = () => {
      setShape(a[0]);
      sprUI();
    };
    d.appendChild(b);
  });
  const l = document.createElement('label');
  l.title = 'How many tiles wide the pencil eraser is.';
  l.append('Brush ');
  const sl = document.createElement('select');
  [1, 2, 3, 4, 5, 7, 9].forEach(n => {
    const o = document.createElement('option');
    o.value = n;
    o.textContent = n + 'x' + n;
    sl.appendChild(o);
  });
  sl.value = BR;
  sl.onchange = () => {
    BR = +sl.value || 1;
    const m = $('brs');
    if (m) m.value = sl.value;
  };
  l.appendChild(sl);
  d.appendChild(l);
  const m = document.createElement('label');
  m.title = 'Also erase on the other side of the room.';
  const mc = document.createElement('input');
  mc.type = 'checkbox';
  mc.onchange = () => {
    MIR = mc.checked;
    const q = $('mir');
    if (q) q.checked = mc.checked;
  };
  m.append(mc, ' Mirror left-right');
  d.appendChild(m);
  $('spt').insertBefore(d, $('tb'));
})();
addEventListener('keydown', e => {
  if (
    TAB !== 'world' ||
    V !== 'rm' ||
    !rc ||
    (tool !== 'S' && tool !== 'X') ||
    inText(e.target) ||
    /^(INPUT|TEXTAREA|SELECT)$/.test(String(e.target && e.target.tagName))
  )
    return;
  if ((e.ctrlKey || e.metaKey) && !e.altKey) {
    const k = e.key.toLowerCase();
    if (SPT === 'select' && k === 'c') {
      e.preventDefault();
      spCopy();
    } else if (SPT === 'select' && k === 'x') {
      e.preventDefault();
      if (spCopy()) spDelete();
    } else if (k === 'v' && SPCLIP) {
      e.preventDefault();
      setSpt('select');
      spStartPaste();
    }
    return;
  }
  if (e.key === 'Escape') {
    if (SPMV) {
      if (SPMV.orig) rc.art = SPMV.orig;
      SPMV = null;
      drawT();
    } else if (SPSEL) {
      SPSEL = null;
      drawT();
    }
  } else if ((e.key === 'Delete' || e.key === 'Backspace') && SPSEL && SPT === 'select') {
    e.preventDefault();
    spDelete();
  }
});
cv.addEventListener('pointerdown', e => {
  cv.setPointerCapture(e.pointerId);
  if (bgDown(e)) return;
  if (lampDown(e)) return;
  if (tileMode()) {
    const c = gcell(e);
    if (e.altKey) {
      pickAt(c);
      return;
    }
    if (PASTE) {
      if (!MOVE) GP = { x: c.x, y: c.y };
      placePaste();
      return;
    }
    if (SHAPE === 'pick') {
      pickAt(c);
      return;
    }
    if (SHAPE === 'replace') {
      replaceAll(c);
      return;
    }
    if (SHAPE === 'select') {
      if (inSel(c)) {
        if (!lyOk('tiles')) return;
        MOVE = { ox: c.x - SEL.x0, oy: c.y - SEL.y0 };
        selCopy();
        selSet('.');
        PASTE = true;
        GP = { x: SEL.x0, y: SEL.y0 };
        drawT();
        drawTr();
        pasteGhost();
      } else {
        SELD = { a: c };
        SEL = normBox(c, c);
        drawT();
      }
      return;
    }
    if (SHAPE === 'fill') {
      applyCells(fillFrom(c.x, c.y));
      save();
      return;
    }
    if (SHAPE !== 'pencil') {
      SH = { a: c, b: c };
      drawT();
      shapePreview();
      return;
    }
  }
  if (
    tool === 'X' &&
    rc &&
    SHAPE !== 'pencil' &&
    SHAPE !== 'select' &&
    SHAPE !== 'replace' &&
    SHAPE !== 'pick' &&
    SHAPE !== 'fill'
  ) {
    const c = gcell(e);
    SH = { a: c, b: c };
    drawT();
    shapePreview();
    return;
  }
  if ((tool === 'S' || tool === 'X') && sprDown(e)) return;
  painting = true;
  paint(e, true);
});
cv.addEventListener('pointermove', e => {
  if (BD) {
    bgMove(e);
    return;
  }
  if (LD) lampMove(e);
  else if (SELD) {
    SEL = normBox(SELD.a, gcell(e));
    drawT();
  } else if (PASTE) {
    const c = gcell(e),
      a = MOVE ? { x: c.x - MOVE.ox, y: c.y - MOVE.oy } : c;
    if (a.x !== GP.x || a.y !== GP.y) {
      GP = a;
      drawT();
      pasteGhost();
    }
  } else if (SH) {
    const c = gcell(e);
    if (c.x !== SH.b.x || c.y !== SH.b.y) {
      SH.b = c;
      drawT();
      shapePreview();
    }
  } else if (sprMove(e)) {
  } else if (painting) paint(e);
});
cv.addEventListener('pointerup', () => {
  if (BD) {
    bgUp();
    return;
  }
  if (LD) {
    lampUp();
    return;
  }
  if (SELD) {
    SELD = null;
    return;
  }
  if (PASTE && MOVE) {
    placePaste();
    return;
  }
  if (SH) {
    applyCells(shapeCells(SH.a, SH.b, SHAPE));
    SH = null;
    save();
    return;
  }
  if (sprUp()) return;
  if (painting) {
    painting = false;
    save();
  }
});
let LASTTILE = '#'; // the Tiles palette is terrain and level layout only; enemies, pickups, hazards and the rest are Entities
(() => {
  let grp = null,
    box = null;
  MV.Tiles.PALETTE.forEach(t => {
    if (t[0] !== grp) {
      grp = t[0];
      box = document.createElement('div');
      box.className = 'pgrp';
      const gb = document.createElement('b');
      gb.textContent = grp;
      box.appendChild(gb);
      $('pal').appendChild(box);
    }
    const b = document.createElement('button');
    b.className = 'tl' + (t[1] === '#' ? ' on' : '');
    b.dataset.t = t[1];
    b.title = t[4];
    const sw = document.createElement('canvas');
    sw.width = sw.height = 14;
    sw.className = 'sw';
    sw.style.cssText = 'background:#0c1722;margin-right:6px;vertical-align:-2px';
    const sx = sw.getContext('2d');
    if (t[3]) {
      if (!MV.Tiles.draw(sx, t[1], 0, 0, 14, { edit: true })) {
        sx.fillStyle = t[3];
        sx.fillRect(0, 0, 14, 14);
      }
    }
    b.appendChild(sw);
    b.appendChild(document.createTextNode(t[2]));
    b.onclick = () => {
      LASTTILE = t[1];
      setTool(t[1]);
    };
    box.appendChild(b);
  });
})();
$('rw').onchange = rsz;
$('rh').onchange = rsz;
$('rn').oninput = e => {
  rc.n = e.target.value;
  save();
  bc();
};
$('nt').oninput = e => {
  rc.note = e.target.value;
  save();
};
$('bgc').oninput = () => bgSet({ color: $('bgc').value });
$('bgf').onchange = e => {
  const f = e.target.files[0];
  e.target.value = '';
  if (!f) return;
  const fr = new FileReader();
  fr.onload = () => {
    const sh = { id: 's' + rid(), name: f.name.slice(0, 40), url: fr.result, tw: 16, th: 16 };
    S.sheets.push(sh);
    const b = rc.bg || MV.Background.def();
    let i = b.layers.findIndex(l => !l.sheet);
    if (i < 0) i = 0;
    const L = b.layers.map(l => ({ ...l }));
    L[i].sheet = sh.id;
    bgSet({ layers: L });
  };
  fr.readAsDataURL(f);
};
$('prs').onclick = () => {
  S.player = {};
  save();
  buildTune();
  $('pmsg').textContent = 'Reset to defaults.';
};
$('cl').onclick = () => {
  if (!lyOk('tiles') || !lyOk('scenery') || !lyOk('objects')) return;
  rc.grid = blank(rc.gw, rc.gh);
  rc.tr = [];
  rc.ent = [];
  drawT();
  drawTr();
  drawEn();
  save();
};
$('b1').onclick = () => {
  save();
  show('ov');
  draw(WC);
};
$('b2').onclick = () => {
  save();
  show('ar');
  draw(AC);
};
$('rs').onclick = () => {
  S.areas.forEach(a => {
    const d = A.find(x => x[0] === a.id);
    if (d) {
      a.x = d[4];
      a.y = d[5];
      a.w = 170;
      a.h = 56;
    }
  });
  draw(WC);
  save();
};
$('ex').onclick = () => {
  const s = ser(S, 1);
  $('ta').value = s;
  $('ta').select();
  $('msg').textContent = 'Exported. Copy the text and keep it in a .json file.';
  try {
    navigator.clipboard.writeText(s);
  } catch (e) {}
};
$('im').onclick = () => {
  try {
    const nm = S.name;
    merge(des($('ta').value));
    S.name = S.name || nm;
    $('pn').value = S.name;
    save();
    show('ov');
    setMode(WC, 'm');
    $('msg').textContent = 'Imported.';
  } catch (e) {
    $('msg').textContent = 'Could not import: ' + e.message;
  }
};
const sheet = id => S.sheets.find(x => x.id === id),
  cs = () => sheet($('ss').value);
function img(s) {
  let m = imgs[s.id];
  if (!m) {
    m = new Image();
    m.onload = () => {
      drawSp();
      if (!$('rm').hidden) {
        drawT();
        drawTable();
      }
      STRIPS.forEach(q => drawMoveStrip(q.c, q.m));
      if (TAB === 'boss') {
        drawBoss();
        drawTl();
      }
      if (TAB === 'anim') axDrawAll();
    };
    m.src = s.url;
    imgs[s.id] = m;
  }
  return m;
}
function blankT(s, c, r) {
  try {
    const m = img(s),
      q = document.createElement('canvas');
    q.width = s.tw;
    q.height = s.th;
    const x = q.getContext('2d');
    x.drawImage(m, c * s.tw, r * s.th, s.tw, s.th, 0, 0, s.tw, s.th);
    const d = x.getImageData(0, 0, s.tw, s.th).data;
    for (let i = 3; i < d.length; i += 4) if (d[i]) return false;
    return true;
  } catch (e) {
    return false;
  }
}
function setTool(t) {
  tool = t;
  if (t === 'X') {
    SPT = 'erase';
    if (!['pencil', 'line', 'rect', 'frame', 'ellipse', 'ring'].includes(SHAPE)) setShape('pencil');
  } else if (t === 'S' && SPT === 'erase') SPT = 'place';
  if (typeof sprUI === 'function') sprUI();
  if (!GT.includes(t)) {
    PASTE = false;
    MOVE = null;
  }
  document.querySelectorAll('.tl').forEach(b => b.classList.toggle('on', b.dataset.t === t));
}
function drawTable() {
  const b = $('tb');
  b.innerHTML = '';
  if (!rc.table.length) {
    b.textContent = 'No sprites in this room yet. Click Open all sprites and drag over the ones you want.';
    b.style.color = 'var(--mu)';
    return;
  }
  b.style.color = '';
  rc.table.forEach((e, i) => {
    const s = sheet(e.s);
    if (!s) return;
    const m = img(s),
      q = document.createElement('canvas'),
      w = e.w * s.tw,
      h = e.h * s.th,
      k = Math.min(44 / w, 44 / h);
    q.width = 48;
    q.height = 48;
    q.className = i === si ? 'on' : '';
    const x = q.getContext('2d');
    x.imageSmoothingEnabled = false;
    if (m.complete && m.naturalWidth)
      x.drawImage(m, e.c * s.tw, e.r * s.th, w, h, (48 - w * k) / 2, (48 - h * k) / 2, w * k, h * k);
    q.onclick = () => {
      si = i;
      setTool('S');
      drawTable();
    };
    b.appendChild(q);
  });
}
function syncTile() {
  const s = cs();
  $('tw').value = s ? s.tw : 16;
  $('th').value = s ? s.th : 16;
}
function refSheets(keep) {
  const o = $('ss');
  o.innerHTML = '';
  S.sheets.forEach(v => {
    const q = document.createElement('option');
    q.value = v.id;
    q.textContent = v.name;
    o.appendChild(q);
  });
  if (keep && sheet(keep)) o.value = keep;
  syncTile();
  drawSp();
  if (rc && V === 'rm') bgUI();
}
const rect = () => ({
  c0: Math.min(ld.c0, ld.c1),
  c1: Math.max(ld.c0, ld.c1),
  r0: Math.min(ld.r0, ld.r1),
  r1: Math.max(ld.r0, ld.r1)
});
function drawSp() {
  const s = cs(),
    c = $('sp'),
    x = c.getContext('2d');
  if (!s) {
    c.height = 40;
    x.clearRect(0, 0, c.width, 40);
    return;
  }
  const m = img(s);
  if (!m.complete || !m.naturalWidth) return;
  const k = Math.max(1, Math.min(8, Math.floor(672 / m.naturalWidth)));
  c.width = m.naturalWidth * k;
  c.height = m.naturalHeight * k;
  x.imageSmoothingEnabled = false;
  x.fillStyle = '#12324a';
  x.fillRect(0, 0, c.width, c.height);
  x.drawImage(m, 0, 0, c.width, c.height);
  x.strokeStyle = 'rgba(255,255,255,.25)';
  x.lineWidth = 1;
  for (let a = 0; a <= m.naturalWidth; a += s.tw) {
    x.beginPath();
    x.moveTo(a * k, 0);
    x.lineTo(a * k, c.height);
    x.stroke();
  }
  for (let b = 0; b <= m.naturalHeight; b += s.th) {
    x.beginPath();
    x.moveTo(0, b * k);
    x.lineTo(c.width, b * k);
    x.stroke();
  }
  if (ld) {
    const a = rect();
    x.fillStyle = 'rgba(239,159,39,.4)';
    x.fillRect(a.c0 * s.tw * k, a.r0 * s.th * k, (a.c1 - a.c0 + 1) * s.tw * k, (a.r1 - a.r0 + 1) * s.th * k);
  }
}
function tileAt(e) {
  const s = cs(),
    c = $('sp'),
    b = c.getBoundingClientRect(),
    m = img(s),
    k = c.width / m.naturalWidth,
    nc = Math.ceil(m.naturalWidth / s.tw),
    nr = Math.ceil(m.naturalHeight / s.th);
  return {
    c: Math.max(0, Math.min(nc - 1, Math.floor((((e.clientX - b.left) / b.width) * c.width) / k / s.tw))),
    r: Math.max(0, Math.min(nr - 1, Math.floor((((e.clientY - b.top) / b.height) * c.height) / k / s.th)))
  };
}
function addSel(s, a) {
  if (V !== 'rm') {
    $('lm').textContent = 'Open a room first, then drag here to add sprites to it.';
    return;
  }
  $('lm').textContent = '';
  const add = (c, r, w, h) => {
    if (!rc.table.some(t => t.s === s.id && t.c === c && t.r === r && t.w === w && t.h === h))
      rc.table.push({ s: s.id, c, r, w, h });
  };
  if ($('gp').checked) add(a.c0, a.r0, a.c1 - a.c0 + 1, a.r1 - a.r0 + 1);
  else for (let r = a.r0; r <= a.r1; r++) for (let c = a.c0; c <= a.c1; c++) if (!blankT(s, c, r)) add(c, r, 1, 1);
  if (rc.table.length) {
    if (si < 0) si = 0;
    setTool('S');
  }
  $('lib').hidden = true;
  save();
  drawT();
  drawTable();
}
$('sp').oncontextmenu = e => e.preventDefault();
$('sp').onpointerdown = e => {
  const s = cs();
  if (!s || !img(s).naturalWidth) return;
  e.preventDefault();
  $('sp').setPointerCapture(e.pointerId);
  const t = tileAt(e);
  ld = { c0: t.c, r0: t.r, c1: t.c, r1: t.r };
  drawSp();
};
$('sp').onpointermove = e => {
  if (!ld) return;
  const t = tileAt(e);
  ld.c1 = t.c;
  ld.r1 = t.r;
  drawSp();
};
$('sp').onpointerup = () => {
  if (!ld) return;
  const s = cs(),
    a = rect();
  ld = null;
  addSel(s, a);
};
$('ol').onclick = () => {
  $('lib').hidden = false;
  refSheets($('ss').value);
  $('lib').scrollIntoView({ block: 'nearest' });
};
$('lc').onclick = () => {
  $('lib').hidden = true;
};
$('tr').onclick = () => {
  if (si < 0 || !rc.table[si]) return;
  rc.table.splice(si, 1);
  si = -1;
  save();
  drawTable();
};
$('fi').onchange = e => {
  [...e.target.files].forEach(f => {
    const fr = new FileReader();
    fr.onload = () => {
      const s = { id: 's' + rid(), name: f.name.slice(0, 40), url: fr.result, tw: 16, th: 16 };
      S.sheets.push(s);
      save();
      refSheets(s.id);
    };
    fr.readAsDataURL(f);
  });
  e.target.value = '';
};
$('ss').onchange = () => {
  syncTile();
  drawSp();
};
$('tw').onchange = () => {
  const s = cs();
  if (s) {
    s.tw = Math.max(1, +$('tw').value || 16);
    save();
    drawSp();
    drawT();
  }
};
$('th').onchange = () => {
  const s = cs();
  if (s) {
    s.th = Math.max(1, +$('th').value || 16);
    save();
    drawSp();
    drawT();
  }
};
