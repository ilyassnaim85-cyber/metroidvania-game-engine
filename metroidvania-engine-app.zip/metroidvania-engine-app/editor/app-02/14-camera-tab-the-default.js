// ---- Camera tab: the default camera, your own camera profiles, and how to swap them ----
