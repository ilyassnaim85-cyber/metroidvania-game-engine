// Part 2 of the editor script (split from index.html; the parts run in order and share one scope, exactly like the old single script).
let SELL = null,
  LD = null;
const lampT = t => t === 'lamp' || t === 'darkness' || t === 'lightzone'; // lamps (light), darkness zones and light zones share the same shape editing
const shapeOf = e =>
  e.type === 'darkness'
    ? MV.Light.zonesFromEntities([e])[0]
    : e.type === 'lightzone'
      ? Object.assign(MV.Light.geom(e), { color: '#f2d36b' })
      : MV.Light.fromEntities([e])[0];
const lampEnt = () => rc && rc.ent.find(q => q.id === SELL && lampT(q.type));
const tpt = e => {
  const r = rr();
  return {
    x: ((e.clientX - r.left) / r.width) * rc.gw,
    y: ((e.clientY - r.top) / r.height) * rc.gh,
    pp: r.width / rc.gw
  };
};
const q4 = v => Math.round(v * 4) / 4;
function newLamp(x, y, type) {
  type = type || 'lamp';
  const id = 'e' + rid();
  rc.ent.push({
    id,
    type,
    x,
    y,
    props:
      type === 'lightzone'
        ? {
            shape: 'polygon',
            radius: 2.5,
            sides: 4,
            pts: [
              [-2, -1.5],
              [2, -1.5],
              [2, 1.5],
              [-2, 1.5]
            ],
            dark: 1,
            color: MV.Light.SHADE,
            fade: 0.4,
            stay: 'no',
            invert: 'no'
          }
        : type === 'darkness'
          ? {
              shape: 'circle',
              radius: 5,
              amount: 1,
              color: MV.Light.SHADE,
              sides: 5,
              soft: 0.5,
              walls: 'yes',
              bleed: 0.2,
              oval: 0
            }
          : { shape: 'circle', radius: 5, level: 1, color: MV.Light.LAMP, sides: 5 }
  });
  SELL = id;
  save();
  drawT();
  drawEn();
}
function drawLamp(c, e) {
  const l = shapeOf(e),
    sel = SELL === e.id,
    dz = e.type === 'darkness' || e.type === 'lightzone';
  ctx.save();
  ctx.strokeStyle = ctx.fillStyle = e.type === 'lightzone' ? '#f2d36b' : dz ? '#a9b4ff' : l.color;
  ctx.lineWidth = sel ? 2 : 1.2;
  ctx.setLineDash([5, 3]);
  ctx.beginPath();
  if (l.shape === 'polygon')
    l.pts.forEach((q, i) => (i ? ctx.lineTo(q[0] * c, q[1] * c) : ctx.moveTo(q[0] * c, q[1] * c)));
  else if (l.ov > 0) {
    const o = l.ov;
    ctx.ellipse(l.x * c, l.y * c, l.r * (1 + o) * c, l.r * (1 - o * 0.5) * c, 0, Math.PI, 2 * Math.PI);
    ctx.ellipse(l.x * c, l.y * c, l.r * (1 + o) * c, l.r * (1 + o * 0.6) * c, 0, 0, Math.PI);
  } else ctx.arc(l.x * c, l.y * c, l.r * c, 0, 7);
  if (l.shape === 'polygon') ctx.closePath();
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.globalAlpha = 0.12;
  ctx.fill();
  ctx.globalAlpha = 1;
  ctx.beginPath();
  ctx.arc(l.x * c, l.y * c, c * 0.32, 0, 7);
  ctx.fill();
  ctx.strokeStyle = '#12324a';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  if (sel) {
    ctx.fillStyle = '#fff';
    ctx.strokeStyle = e.type === 'lightzone' ? '#f2d36b' : dz ? '#a9b4ff' : l.color;
    ctx.lineWidth = 2;
    (l.shape === 'polygon' ? l.pts : [[l.x + l.r * (1 + (l.ov || 0)), l.y]]).forEach(q => {
      ctx.fillRect(q[0] * c - 5, q[1] * c - 5, 10, 10);
      ctx.strokeRect(q[0] * c - 5, q[1] * c - 5, 10, 10);
    });
  }
  ctx.restore();
}
function lampDown(e) {
  if (tool !== 'N' || !lyOk('objects', false)) return false;
  const q = tpt(e),
    tol = 10 / q.pp,
    L = lampEnt();
  if (L) {
    const l = shapeOf(L);
    if (l.shape === 'polygon') {
      const P = L.props;
      if (!MV.Light.cleanPts(P.pts)) P.pts = MV.Light.regular(P.sides, P.radius);
      const i = l.pts.findIndex(v => Math.hypot(v[0] - q.x, v[1] - q.y) <= tol);
      if (i >= 0) {
        LD = { m: 'v', i };
        return true;
      }
    } else if (Math.hypot(l.x + l.r * (1 + (l.ov || 0)) - q.x, l.y - q.y) <= tol) {
      LD = { m: 'r' };
      return true;
    }
  }
  const hit = rc.ent.find(v => lampT(v.type) && Math.hypot(v.x + 0.5 - q.x, v.y + 0.5 - q.y) <= Math.max(0.5, tol));
  if (hit) {
    SELL = hit.id;
    LD = { m: 'move', dx: q.x - (hit.x + 0.5), dy: q.y - (hit.y + 0.5) };
    drawT();
    drawEn();
    return true;
  }
  return false;
}
function lampMove(e) {
  const L = lampEnt();
  if (!L || !LD) return;
  const q = tpt(e),
    P = L.props;
  if (LD.m === 'move') {
    L.x = Math.max(0, Math.min(rc.gw - 1, Math.round(q.x - LD.dx - 0.5)));
    L.y = Math.max(0, Math.min(rc.gh - 1, Math.round(q.y - LD.dy - 0.5)));
  } else if (LD.m === 'v') {
    const cl = v => Math.max(-40, Math.min(40, q4(v)));
    P.pts[LD.i] = [cl(q.x - (L.x + 0.5)), cl(q.y - (L.y + 0.5))];
  } else {
    const ov = L.type === 'darkness' ? (P.oval === undefined ? 0 : +P.oval) || 0 : 0;
    P.radius = Math.max(0.5, Math.min(40, q4(Math.hypot((q.x - (L.x + 0.5)) / (1 + ov), q.y - (L.y + 0.5)))));
  }
  drawT();
}
function lampUp() {
  const L = lampEnt();
  LD = null;
  if (L && L.props.shape === 'polygon' && L.props.pts) {
    L.props.radius = Math.max(0.5, q4(Math.max(...L.props.pts.map(v => Math.hypot(v[0], v[1])))));
    L.props.sides = L.props.pts.length;
  }
  save();
  drawEn();
}
function lampRow(e) {
  const P = e.props,
    lz = e.type === 'lightzone',
    dz = e.type === 'darkness' || lz,
    d = document.createElement('div'),
    h = document.createElement('strong'),
    f = document.createElement('div'),
    poly = P.shape === 'polygon';
  d.className = 'mv' + (SELL === e.id ? ' sel' : '');
  h.textContent =
    (lz ? 'Light zone (' : dz ? 'Darkness (' : 'Lamp (') +
    e.x +
    ', ' +
    e.y +
    ')' +
    (SELL === e.id ? ' - selected' : '');
  h.style.cursor = 'pointer';
  h.onclick = () => {
    if (SELL !== e.id) {
      SELL = e.id;
      drawT();
      drawEn();
    }
  };
  d.appendChild(h);
  f.className = 'mvf';
  const ch = () => {
    save();
    drawT();
  };
  f.appendChild(
    mkSel(
      'Shape',
      [
        ['circle', 'Circle'],
        ['polygon', 'Polygon (drag its corners)']
      ],
      poly ? 'polygon' : 'circle',
      v => {
        P.shape = v;
        if (v === 'polygon' && !MV.Light.cleanPts(P.pts)) P.pts = MV.Light.regular(P.sides, P.radius);
        SELL = e.id;
        ch();
        drawEn();
      }
    )
  );
  f.appendChild(
    mkNum(poly ? 'Size (radius, tiles)' : 'Radius (tiles)', P.radius, 0.5, 40, 0.25, v => {
      const old = +P.radius || 5,
        nr = Math.max(0.5, Math.min(40, +v || 5));
      if (poly && P.pts) {
        const k = nr / old;
        P.pts = P.pts.map(q => [q[0] * k, q[1] * k]);
      }
      P.radius = nr;
      ch();
      drawEn();
    })
  );
  if (poly)
    f.appendChild(
      mkNum('Sides', P.pts ? P.pts.length : P.sides, 3, 16, 1, v => {
        P.sides = Math.max(3, Math.min(16, Math.round(+v) || 5));
        P.pts = MV.Light.regular(P.sides, P.radius);
        ch();
        drawEn();
      })
    );
  if (lz) {
    f.appendChild(
      mkNum('Darkness from outside (0 none, 1 black)', P.dark === undefined ? 1 : P.dark, 0, 1, 0.05, v => {
        P.dark = Math.max(0, Math.min(1, +v || 0));
        ch();
      })
    );
    f.appendChild(
      mkNum('Fade time (seconds)', P.fade === undefined ? 0.4 : P.fade, 0, 5, 0.1, v => {
        P.fade = Math.max(0, Math.min(5, +v || 0));
        ch();
      })
    );
    f.appendChild(
      mkSel(
        'Stay lit once entered',
        [
          ['no', 'No (dark again when you leave)'],
          ['yes', 'Yes (saved with the game)']
        ],
        P.stay === 'yes' ? 'yes' : 'no',
        v => {
          P.stay = v;
          ch();
        }
      )
    );
    f.appendChild(
      mkSel(
        'Darken the outside while you are inside',
        [
          ['no', 'No'],
          [
            'yes',
            'Yes (invert: the box is dark and the room lit from outside; inside, the room goes dark and the box lit)'
          ]
        ],
        P.invert === 'yes' ? 'yes' : 'no',
        v => {
          P.invert = v;
          ch();
        }
      )
    );
  } else if (dz) {
    f.appendChild(
      mkNum('Darkness amount (0 none, 1 deepest)', P.amount === undefined ? 1 : P.amount, 0, 1, 0.05, v => {
        P.amount = Math.max(0, Math.min(1, +v || 0));
        ch();
      })
    );
    f.appendChild(
      mkNum('Edge softness (0 hard, 1 soft)', P.soft === undefined ? 0.5 : P.soft, 0, 1, 0.05, v => {
        P.soft = Math.max(0, Math.min(1, +v || 0));
        ch();
      })
    );
    f.appendChild(
      mkSel(
        'Walls stop the darkness',
        [
          ['yes', 'Yes (stays inside its room)'],
          ['no', 'No (goes through walls)']
        ],
        P.walls === 'no' ? 'no' : 'yes',
        v => {
          P.walls = v;
          ch();
        }
      )
    );
    f.appendChild(
      mkNum('Egg shape (0 round circle, 1 very oval)', P.oval === undefined ? 0 : P.oval, 0, 1, 0.05, v => {
        P.oval = Math.max(0, Math.min(1, +v || 0));
        ch();
      })
    );
    f.appendChild(
      mkNum(
        'Wall bleed (0 blocked by the wall, 1 reaches its far side)',
        P.bleed === undefined ? 0.2 : P.bleed,
        0,
        1,
        0.05,
        v => {
          P.bleed = Math.max(0, Math.min(1, +v || 0));
          ch();
        }
      )
    );
  } else {
    f.appendChild(
      mkNum('Light level (0 off, 1 full)', P.level, 0, 1, 0.05, v => {
        P.level = Math.max(0, Math.min(1, +v || 0));
        ch();
      })
    );
    f.appendChild(
      mkNum('Edge softness (0 hard, 1 soft)', P.soft === undefined ? 0.9 : P.soft, 0, 1, 0.05, v => {
        P.soft = Math.max(0, Math.min(1, +v || 0));
        ch();
      })
    );
    f.appendChild(
      mkNum('Flicker (0 to 1)', P.flicker || 0, 0, 1, 0.05, v => {
        P.flicker = Math.max(0, Math.min(1, +v || 0));
        ch();
      })
    );
    f.appendChild(
      mkSel(
        'Walls block the light',
        [
          ['yes', 'Yes (casts shadows)'],
          ['no', 'No (shines through walls)']
        ],
        P.shadows === 'no' ? 'no' : 'yes',
        v => {
          P.shadows = v;
          ch();
        }
      )
    );
  }
  const col = document.createElement('label'),
    ci = document.createElement('input'),
    rgbIn = [];
  ci.type = 'color';
  ci.value = MV.Light.hex(P.color) || (dz ? MV.Light.SHADE : MV.Light.LAMP);
  col.append(dz ? 'Shade colour' : 'Colour', ci);
  f.appendChild(col);
  const setCol = (hx, final) => {
    P.color = hx;
    const c3 = MV.Light.rgb(hx);
    rgbIn.forEach((q, i) => (q.value = c3[i]));
    if (final) ch();
    else {
      drawT();
    }
  };
  ci.oninput = () => setCol(ci.value, false);
  ci.onchange = () => setCol(ci.value, true);
  ['R', 'G', 'B'].forEach((n, i) => {
    const l = document.createElement('label'),
      q = document.createElement('input');
    q.type = 'number';
    q.min = 0;
    q.max = 255;
    q.step = 1;
    q.value = MV.Light.rgb(MV.Light.hex(P.color) || (dz ? MV.Light.SHADE : MV.Light.LAMP))[i];
    rgbIn.push(q);
    q.onchange = () => {
      const c3 = rgbIn.map(x => Math.max(0, Math.min(255, Math.round(+x.value) || 0)));
      const hx = MV.Light.toHex(...c3);
      ci.value = hx;
      setCol(hx, true);
    };
    l.append(n + ' (0-255)', q);
    f.appendChild(l);
  });
  d.appendChild(f);
  const r = document.createElement('div');
  r.className = 'row';
  if (poly) {
    r.appendChild(
      btn('Regular shape', () => {
        P.pts = MV.Light.regular(P.sides, P.radius);
        ch();
        drawEn();
      })
    );
  }
  r.appendChild(
    btn('Remove', () => {
      rc.ent = rc.ent.filter(q => q !== e);
      if (SELL === e.id) SELL = null;
      save();
      drawT();
      drawEn();
    })
  );
  d.appendChild(r);
  return d;
}
function paint(e, first) {
  const r = rr(),
    x = Math.floor(((e.clientX - r.left) / r.width) * rc.gw),
    y = Math.floor(((e.clientY - r.top) / r.height) * rc.gh);
  if (x < 0 || y < 0 || x >= rc.gw || y >= rc.gh) return;
  if (!lyOk(lyOf(tool), first)) return;
  if (tool === 'S') {
    if (!first) return;
    const e2 = rc.table[si];
    if (!e2 || !sheet(e2.s)) return;
    spPut(x, y, e2);
    drawT();
    return;
  }
  if (tool === 'O') {
    if (!first) return;
    placeBoss(BPICK || (S.bosses[0] && S.bosses[0].id), x, y);
    return;
  }
  if (tool === 'M') {
    if (!first) return;
    const pr = {};
    if (EPICK.type === 'enemy' && EPICK.kind) pr.kind = EPICK.kind;
    rc.ent.push({ id: 'e' + rid(), type: EPICK.type, x, y, props: pr });
    save();
    drawT();
    drawEn();
    return;
  }
  if (tool === 'N') {
    if (!first) return;
    if (lampT($('ety').value)) {
      newLamp(x, y, $('ety').value);
      return;
    }
    rc.ent.push({ id: 'e' + rid(), type: $('ety').value, x, y, props: newProps($('ety').value) });
    drawT();
    drawEn();
    return;
  }
  if (tool === 'X') {
    eraseCells(brushCells(x, y));
    return;
  }
  if (tool !== 'D' && (BR > 1 || MIR)) {
    applyCells(brushCells(x, y));
    return;
  }
  const g = rc.grid,
    old = g[y][x];
  if (old === 'D' && tool !== 'D' && !lyOk('objects', first)) return;
  if (tool === 'D') {
    const tw = Math.max(1, Math.min(30, Math.floor(+$('trw').value) || 1)),
      th = Math.max(1, Math.min(30, Math.floor(+$('trh').value) || 1)),
      v = $('trt').value,
      q = v ? v.split('|') : null;
    for (let j = 0; j < th; j++)
      for (let i = 0; i < tw; i++) {
        const xx = x + i,
          yy = y + j;
        if (xx >= rc.gw || yy >= rc.gh) continue;
        rc.tr = rc.tr.filter(t => !(t.x === xx && t.y === yy));
        if (q) rc.tr.push({ x: xx, y: yy, a: q[0], r: q[1] });
        g[yy] = g[yy].slice(0, xx) + 'D' + g[yy].slice(xx + 1);
      }
    drawT();
    drawTr();
    return;
  }
  if (tool === 'D') {
    rc.tr = rc.tr.filter(t => !(t.x === x && t.y === y));
    const v = $('trt').value;
    if (v) {
      const q = v.split('|');
      rc.tr.push({ x, y, a: q[0], r: q[1] });
    }
  } else if (old === 'D') rc.tr = rc.tr.filter(t => !(t.x === x && t.y === y));
  if (old === tool && tool !== 'D') return;
  g[y] = g[y].slice(0, x) + tool + g[y].slice(x + 1);
  drawT();
  drawTr();
}
function rsz() {
  const nw = Math.max(8, Math.min(10000, +$('rw').value || rc.gw)),
    nh = Math.max(6, Math.min(10000, +$('rh').value || rc.gh));
  $('rw').value = nw;
  $('rh').value = nh;
  const o = rc.grid,
    g = [];
  let lr = null,
    lo = null,
    bl = null;
  for (let y = 0; y < nh; y++) {
    const r = o[y - (nh - rc.gh)];
    let q;
    if (r === undefined) q = bl || (bl = '.'.repeat(nw));
    else if (r === lr) q = lo;
    else {
      q = r.length === nw ? r : r.slice(0, nw).padEnd(nw, /^#+$/.test(r) ? '#' : '.');
      lr = r;
      lo = q;
    }
    g.push(q);
  }
  const dy = nh - rc.gh;
  rc.art = rc.art.map(a => ({ ...a, y: a.y + dy })).filter(a => a.x < nw && a.y + a.h > 0);
  rc.tr = rc.tr.map(t => ({ ...t, y: t.y + dy })).filter(t => t.x < nw && t.y >= 0);
  rc.ent = rc.ent.map(e => ({ ...e, y: e.y + dy })).filter(e => e.x < nw && e.y >= 0);
  rc.grid = g;
  rc.gw = nw;
  rc.gh = nh;
  if (nw * nh > 1e6 && !rc.stream) {
    rc.stream = 5;
    $('rstr').value = 5;
  }
  drawT();
  drawTr();
  drawEn();
  save();
}
