// ===== Controls tab: keys and gamepad buttons =====
let CTT = 0;
function ctlSet(fn) {
  const c = JSON.parse(JSON.stringify(S.controls));
  fn(c);
  S.controls = MV.Controls.clean(c);
  save();
  buildCt();
}
function ctlWarn() {
  const w = $('ctw');
  if (!w) return;
  const l = MV.Controls.conflicts(S.controls, S.moves, S.attacks);
  w.innerHTML = '';
  if (!l.length) {
    const p = document.createElement('p');
    p.className = 'hint';
    p.textContent = 'No conflicts: no two actions share a key or a gamepad button.';
    w.appendChild(p);
    return;
  }
  l.forEach(t => {
    const d = document.createElement('div');
    d.className = 'cwarn';
    d.textContent = '\u26a0 ' + t;
    w.appendChild(d);
  });
}
function learnKeyBtn(txt, cb) {
  const b = document.createElement('button');
  b.textContent = txt;
  b.title = 'Click, then press a key. Esc cancels, Backspace clears.';
  b.onclick = () => {
    b.textContent = 'Press a key...';
    const h = e => {
      e.preventDefault();
      e.stopPropagation();
      removeEventListener('keydown', h, true);
      if (e.code === 'Escape') {
        buildCt();
        return;
      }
      cb(e.code === 'Backspace' || e.code === 'Delete' ? null : e.code);
    };
    addEventListener('keydown', h, true);
  };
  return b;
}
function padPick(val, cb) {
  const w = document.createElement('span');
  w.style.cssText = 'display:flex;gap:6px';
  const s = document.createElement('select');
  [[-1, 'None']].concat(MV.Controls.PAD.map((n, i) => [i, n + ' (' + i + ')'])).forEach(o => {
    const e = document.createElement('option');
    e.value = o[0];
    e.textContent = o[1];
    s.appendChild(e);
  });
  s.value = val === undefined ? -1 : val;
  s.onchange = () => cb(+s.value);
  const b = document.createElement('button');
  b.textContent = 'Press a button';
  b.title = 'Click, then press a button on your gamepad';
  b.onclick = () => {
    b.textContent = 'Press it now...';
    let n = 0;
    const t = setInterval(() => {
      const g = [...(navigator.getGamepads ? navigator.getGamepads() : [])].find(x => x && x.connected),
        i = g ? g.buttons.slice(0, MV.Controls.PAD.length).findIndex(x => x.pressed) : -1;
      if (i >= 0) {
        clearInterval(t);
        cb(i);
      } else if (++n > 80) {
        clearInterval(t);
        b.textContent = 'Press a button';
        if (!g) b.title = 'No gamepad found. Connect one and press a button on it first.';
      }
    }, 60);
  };
  w.append(s, b);
  return w;
}
