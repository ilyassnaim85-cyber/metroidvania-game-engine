// ===== Optional templates: load one, then edit every number. Nothing here is required, and nothing is added unless you click. =====
const FEEL = [
  [
    'Tight and precise',
    {
      run: 9,
      accel: 140,
      decel: 160,
      airControl: 0.95,
      jumpHeight: 3.2,
      gravity: 70,
      maxFall: 30,
      jumpCut: 0.4,
      coyote: 0.08,
      buffer: 0.1
    }
  ],
  [
    'Floaty',
    {
      run: 7,
      accel: 50,
      decel: 40,
      airControl: 0.9,
      jumpHeight: 4,
      gravity: 30,
      maxFall: 16,
      jumpCut: 0.6,
      coyote: 0.15,
      buffer: 0.15
    }
  ],
  [
    'Heavy',
    {
      run: 6,
      accel: 60,
      decel: 120,
      airControl: 0.4,
      jumpHeight: 2.4,
      gravity: 80,
      maxFall: 34,
      jumpCut: 0.5,
      coyote: 0.06,
      buffer: 0.1
    }
  ],
  ['Back to the engine defaults', {}]
];
const TPL = [
  [
    'Double jump',
    {
      id: 'doubleJump',
      label: 'Double jump',
      type: 'impulse',
      key: 'Jump',
      where: 'air',
      dir: 'up',
      speed: 15,
      uses: 1,
      cooldown: 0.1,
      keep: 0.5,
      requires: 'doubleJump'
    },
    'Press Jump again in the air. Unlocked by an ability pickup with the id doubleJump.'
  ],
  [
    'Dash',
    {
      id: 'dash',
      label: 'Dash',
      type: 'dash',
      key: 'Shift',
      dir: 'forward',
      speed: 24,
      duration: 0.15,
      cooldown: 0.5,
      uses: 1,
      gravity: 0,
      keep: 0.2,
      requires: 'dash'
    },
    'A short fast burst forward. Unlocked by an ability pickup with the id dash.'
  ],
  [
    'Sprint',
    { id: 'sprint', label: 'Sprint', type: 'hold', key: 'Shift', on: 'ground', runs: 12, requires: '' },
    'Hold Shift on the ground to run faster.'
  ],
  [
    'Glide',
    {
      id: 'glide',
      label: 'Glide',
      type: 'hold',
      key: 'Jump',
      on: 'air',
      speed: 3,
      accel: 0,
      gravity: 0.3,
      requires: 'glide'
    },
    'Hold Jump in the air to fall slowly. Unlocked by an ability pickup with the id glide.'
  ],
  [
    'Focus heal (needs energy)',
    {
      id: 'focus',
      label: 'Focus',
      type: 'hold',
      key: 'KeyF',
      on: 'ground',
      windup: 1.1,
      cost: 33,
      recharge: 'yes',
      chargeLock: 'yes',
      nojump: 'yes',
      effects: [{ on: 'charged', do: 'heal', value: 1 }],
      requires: ''
    },
    'Hold F on the ground: after 1.1 s it heals 1 and spends 33 energy, and keeps going while you hold. Set the energy size, regrowth and energy per hit in Settings, Energy.'
  ]
];
function tplUI(B0) {
  const h = document.createElement('strong');
  h.textContent = 'Start from a template (optional)';
  B0.appendChild(h);
  const p = document.createElement('p');
  p.className = 'hint';
  p.textContent =
    'Nothing is added to your project unless you click. A feel preset only changes the run and jump numbers above, and Back to the engine defaults undoes it. A starter move is added to the move list like any move you built yourself, so you can change every field or delete it.';
  B0.appendChild(p);
  const a = document.createElement('div');
  a.className = 'row';
  FEEL.forEach(f =>
    a.appendChild(
      btn('Feel: ' + f[0], () => {
        S.player = MV.Tuning.clean(
          Object.assign(
            {},
            S.player,
            Object.fromEntries(
              Object.keys(MV.data.playerSchema)
                .filter(k => ['Movement', 'Jump'].includes(MV.data.playerSchema[k].group))
                .map(k => [k, undefined])
            ),
            f[1]
          )
        );
        save();
        buildTune();
        $('pmsg').textContent = 'Feel preset loaded: ' + f[0] + '.';
      })
    )
  );
  B0.appendChild(a);
  const b = document.createElement('div');
  b.className = 'row';
  TPL.forEach(t => {
    const bt = btn('Add move: ' + t[0], () => {
      addMove(t[1]);
      $('pmsg').textContent = t[2];
    });
    bt.title = t[2];
    b.appendChild(bt);
  });
  B0.appendChild(b);
}
