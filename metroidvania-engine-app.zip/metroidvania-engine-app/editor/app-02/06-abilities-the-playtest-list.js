// abilities the playtest list has shown before: a new one starts ticked, except Wall jump (the player has no wall sliding or kicking until you give it)
function buildPo() {
  const PO_SEEN = window.PO_SEEN || (window.PO_SEEN = {}),
    po = $('po'),
    off = {};
  po.querySelectorAll('input[data-ab]').forEach(c => {
    if (!c.checked) off[c.dataset.ab] = 1;
  });
  const fl = $('pfl') ? $('pfl').value : '',
    sv = $('psv') ? $('psv').checked : false;
  po.innerHTML = '';
  abSync();
  for (const k in MV.data.abilities) {
    const l = document.createElement('label'),
      c = document.createElement('input');
    c.type = 'checkbox';
    c.checked = PO_SEEN[k] ? !off[k] : k !== 'wallJump';
    PO_SEEN[k] = 1;
    c.dataset.ab = k;
    l.append(c, ' ' + MV.data.abilities[k].label);
    po.appendChild(l);
  }
  po.insertAdjacentHTML(
    'beforeend',
    '<label>Flags <input type="text" id="pfl" placeholder="switch1, boss1" style="width:170px"></label><label><input type="checkbox" id="psv"> Use my saved game</label>'
  );
  $('pfl').value = fl;
  $('psv').checked = sv;
}
const MV_TIMED = ['dash', 'roll', 'grapple', 'bash', 'path', 'sequence', 'scripted'],
  MV_CURVE = ['dash', 'roll', 'grapple', 'path', 'surface'],
  MV_PATH = ['dash', 'roll', 'path', 'surface'];
const MV_SHOW = {
  impulse: ['cost', 'dir', 'angle', 'speed', 'gravity', 'cooldown', 'uses', 'keep', 'damage'],
  dash: [
    'cost',
    'duration',
    'dir',
    'angle',
    'speed',
    'accel',
    'gravity',
    'cooldown',
    'uses',
    'keep',
    'stop',
    'squash',
    'damage'
  ],
  roll: ['cost', 'duration', 'speed', 'accel', 'gravity', 'cooldown', 'uses', 'keep', 'stop', 'squash', 'damage'],
  grapple: [
    'cost',
    'duration',
    'dir',
    'angle',
    'how',
    'reach',
    'hook',
    'pull',
    'accel',
    'gravity',
    'fuel',
    'anchor',
    'cooldown',
    'uses',
    'keep',
    'damage'
  ],
  bash: ['cost', 'duration', 'speed', 'reach', 'aim', 'stop', 'cooldown', 'uses', 'keep', 'damage'],
  throw: ['cost', 'dir', 'angle', 'speed', 'reach', 'gravity', 'life', 'cooldown', 'uses'],
  path: ['cost', 'duration', 'cooldown', 'uses', 'keep', 'stop', 'squash', 'damage'],
  scripted: ['script', 'cost', 'duration', 'cooldown', 'uses', 'keep', 'squash', 'damage'],
  sequence: ['cost', 'repeat', 'cooldown', 'uses', 'keep', 'squash', 'damage'],
  surface: ['surface', 'mode', 'speed', 'slide', 'fuel', 'kick', 'duration', 'loop'],
  hold: [
    'cost',
    'drain',
    'recharge',
    'on',
    'runs',
    'squash',
    'sqw',
    'state',
    'nojump',
    'speed',
    'accel',
    'gravity',
    'side',
    'windup',
    'fuel',
    'fly',
    'phase'
  ],
  ledge: ['grab', 'climb', 'slide', 'fuel', 'kick'],
  swim: ['speed', 'accel', 'gravity', 'cooldown']
};
const MV_HINT = {
  impulse:
    'An instant push, like a jump: it gives the player a speed once. The attack boxes you add hurt what they touch while the move fires.',
  dash: "A timed move: it plays for its duration. Push the player in a direction at a speed, or draw the player's own route in the timeline and the speed settings are not used. Add attack boxes to hurt things, switch the body hitbox off for a moment to dodge, give it a low body to fit through gaps, and shape the speed over time with the speed curve.",
  hold: 'Works while its key is held. Works = in the air (glide, jetpack), on the ground (sprint, crouch, crawl, morph ball) or both; it never runs out unless you set Time it works. Run speed while held, Body height and Body width change how you move and what you fit through; Plays animation picks the crouch, sprint or morph clip. Fly speed above 0 lets Up and Down fly you around (hover, levitate, fly). Passes through lets you ghost through every wall or only through Soft ground (burrow).  Speed = the fastest you can fall (0 = unchanged), Lift pushes you up, Gravity x scales gravity. Charge time makes you hold the key a while before it starts (a bar fills above the player). Time it works limits one air time (it fills up when you land) and Left/right speed lets you keep or lose sideways control.',
  swim: 'How the player moves in water tiles.'
};
MV_HINT.roll = MV_HINT.path = MV_HINT.dash;
MV_HINT.ledge =
  'Grab and climb ledges: when you fall beside the edge of a block with your head just below its top (Grab reach), you catch it and hang. Up or Jump pulls you up over the edge (Climb time), Down lets go, and Jump while holding away from the wall leaps off. Key None = it works by itself. Slide down speed makes you sag while you hang and Time it works limits how long you can hang.';
MV_HINT.grapple =
  'Grapple works as Pull (you are reeled in) or Swing (a rope: you swing like a pendulum, Left and Right pump the swing, Up and Down change the rope, let go of the key or press Jump to fly off with your speed). A hook flies out in the direction you choose (Direction below) and sticks to a wall or to a Grapple point you placed in a room (see Hook sticks to), then pulls you there. Press Jump to let go. Place Grapple points from the Entities list in the World editor.';
MV_HINT.bash =
  'Launch off a Bash orb: stand near an orb (within Hook reach), press the key and the world slows while you aim with the direction keys; let go of the key (or wait for Aim time) and you fly off at Speed for Duration seconds, then keep a share of that speed (Keep speed) and coast. For a bigger launch raise Speed, Duration and Keep speed. The orb comes back after its respawn time. Place Bash orbs from the Entities list in the World editor.';
MV_HINT.throw =
  'Press the key to throw an item in the Direction you pick: it flies up to Hook reach tiles and stops at a wall (Gravity x makes it fall in an arc). Press the same key again and you teleport to the item (or the nearest free spot beside it). The item fades away after Item stays, and then the move cools down.';
MV_HINT.scripted =
  'A move a script drives. Name a function in Script function (made in the Scripts tab with fn("name", me => { ... })). It runs every frame while the move plays and sets the player\'s speed, gravity and facing. Duration is the longest it can last; me.end() stops it sooner. Attack boxes added here hurt what they touch, and me.hitbox(...) can make more. See SCRIPTING.md.';
MV_HINT.sequence =
  'A move made of steps, one after the other: each step has its own speed, gravity and steering and ends after its length or when something happens (you land, you hit a wall or ceiling, you let go of the key). For example a leap, a hang and a slam down. Attack boxes, the body hitbox, shots and effects are timed along the whole move.';
MV_HINT.surface =
  'Works while the key is held, you are in the air, and you touch a wall (beside you) or a ceiling (above you): cling to it, climb it, or run up it. Jump lets go with a push away from the wall (Jump-off push). Slide down speed lets you slip down slowly instead of hanging still, and Time it works is how long you can cling before you let go (it fills up when you land). The Hitbox and Attack boxes sections animate the body hitbox (size, position, invincible periods) and attack boxes while you cling: Duration is how long that animation lasts and Repeat makes it start again. In Advanced, Path and speed draws a route you follow while clinging (drawn from where you grabbed the surface; forward is toward the wall, so use up and down) and a speed curve for how fast you climb or run.';
const TYPE_NAME = {
  sequence: 'steps',
  scripted: 'script',
  surface: 'surface',
  ledge: 'ledge',
  dash: 'timed',
  impulse: 'push',
  hold: 'held',
  swim: 'swim',
  roll: 'roll',
  grapple: 'grapple',
  bash: 'bash',
  throw: 'throw',
  path: 'path'
};
let VIEW = (() => {
  try {
    return localStorage.getItem('mv_pview') === 'adv' ? 'adv' : 'basic';
  } catch (e) {
    return 'basic';
  }
})();
const isAdv = () => VIEW === 'adv';
function setView(v) {
  VIEW = v;
  try {
    localStorage.setItem('mv_pview', v);
  } catch (e) {}
  document.querySelectorAll('.vseg button').forEach(b => b.classList.toggle('on', b.dataset.v === v));
  buildMoves();
  buildAtk();
}
document.querySelectorAll('.vseg button').forEach(b => {
  b.classList.toggle('on', b.dataset.v === VIEW);
  b.onclick = () => setView(b.dataset.v);
});
const MV_BASIC = {
  impulse: ['cost', 'dir', 'speed', 'uses', 'cooldown'],
  dash: ['cost', 'speed', 'duration', 'cooldown', 'squash'],
  roll: ['cost', 'speed', 'duration', 'cooldown', 'squash'],
  grapple: ['cost', 'how', 'reach', 'pull', 'cooldown'],
  bash: ['cost', 'reach', 'speed', 'duration', 'keep', 'aim'],
  throw: ['cost', 'dir', 'speed', 'reach', 'gravity', 'life'],
  path: ['cost', 'duration', 'cooldown'],
  scripted: ['script', 'duration', 'cost', 'cooldown'],
  sequence: ['cost', 'repeat', 'cooldown', 'squash'],
  surface: ['surface', 'mode', 'speed', 'fuel'],
  hold: ['cost', 'on', 'runs', 'squash', 'state', 'speed', 'accel', 'gravity', 'windup', 'fuel', 'fly', 'phase'],
  ledge: ['grab', 'climb'],
  swim: ['speed', 'accel']
};
function coreView(T0, B0) {
  const hp = document.createElement('p');
  hp.className = 'hint';
  hp.textContent =
    'How the player runs and jumps. The picture is one full jump with your current numbers. Every other movement (a dash, a double jump, a glide, a roll, anything you invent) is a move that you build yourself in the list on the left.';
  T0.appendChild(hp);
  const c = document.createElement('canvas');
  c.width = 640;
  c.height = 210;
  c.style.cssText = 'width:100%;max-width:640px;border:1px solid var(--bd);border-radius:8px;display:block';
  T0.appendChild(c);
  const draw = () => {
    const x = c.getContext('2d'),
      pr = MV.Tuning.resolve(S.player),
      g = pr.gravity,
      v0 = Math.sqrt(2 * g * pr.jumpHeight),
      T = (2 * v0) / g,
      dist = pr.run * T,
      K = Math.max(6, Math.min(26, 560 / Math.max(1, dist + 2), 150 / Math.max(0.5, pr.jumpHeight))),
      GY = 185,
      X0 = 40;
    x.fillStyle = '#12324a';
    x.fillRect(0, 0, c.width, c.height);
    x.fillStyle = 'rgba(255,255,255,.12)';
    x.fillRect(0, GY, c.width, c.height - GY);
    x.strokeStyle = 'rgba(255,255,255,.07)';
    for (let t = 0; X0 + t * K < c.width; t++) {
      x.beginPath();
      x.moveTo(X0 + t * K + 0.5, 0);
      x.lineTo(X0 + t * K + 0.5, GY);
      x.stroke();
    }
    x.strokeStyle = '#5dcaa5';
    x.lineWidth = 2;
    x.beginPath();
    for (let u = 0; u <= T + 1e-6; u += T / 60) {
      const px = X0 + pr.run * u * K,
        py = GY - (v0 * u - (g * u * u) / 2) * K;
      u ? x.lineTo(px, py) : x.moveTo(px, py);
    }
    x.stroke();
    x.lineWidth = 1;
    x.strokeStyle = '#ef9f27';
    x.setLineDash([4, 3]);
    [0, T / 2, T].forEach(u => {
      const px = X0 + pr.run * u * K,
        py = GY - (v0 * u - (g * u * u) / 2) * K;
      x.strokeRect(px - (pr.w * K) / 2, py - pr.h * K, pr.w * K, pr.h * K);
    });
    x.setLineDash([]);
    x.fillStyle = '#fff';
    x.font = '12px system-ui,sans-serif';
    x.textAlign = 'left';
    x.fillText(
      'Jump: ' +
        pr.jumpHeight +
        ' tiles high, ' +
        dist.toFixed(1) +
        ' tiles far at full speed, ' +
        T.toFixed(2) +
        ' s in the air. Orange boxes are the player; grid squares are tiles.',
      8,
      16
    );
  };
  draw();
  const hs = document.createElement('div');
  B0.appendChild(hs);
  tuneBuild(hs, g => TUNE_CORE.includes(g), draw);
  tplUI(B0);
  const r = document.createElement('div');
  r.className = 'row';
  r.appendChild(btn('Test movement', mtOpen));
  B0.appendChild(r);
}
