// Camera preview (editor): a small window at the top of Player settings > Camera. It plays the real game camera in a small room with a
// player that runs, jumps, drops and peeks by itself, and it re-plays the part that fits the setting you just changed.
// Needs the editor globals: S (the project), V, CPI (the profile being edited), $, mtStop().
(() => {
  let ROOM = null,
    box = null,
    cv = null,
    note = null,
    info = null,
    timer = null,
    demo = 'auto',
    run = null,
    prev = null,
    down = new Set(),
    big = false,
    paused = false,
    lastChange = '',
    shown = 'default';
  const E = (t, c, x) => {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };
  const css = document.createElement('style');
  css.textContent = `#cpv{position:sticky;top:0;z-index:6;background:var(--cd);border:1px solid var(--bd);border-radius:10px;padding:8px 10px;margin:0 0 10px;box-shadow:0 6px 18px rgba(0,0,0,.25)}
  #cpv .cph{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:6px}#cpv .cph select{max-width:210px}#cpv .cph label{font-size:12px;display:flex;gap:4px;align-items:center}
  #cpv .cph button{padding:2px 10px;font-size:13px}
  #cpv canvas{width:100%;max-width:480px;height:auto;display:block;border-radius:6px;background:#12324a}#cpv.big canvas{max-width:760px}
  #cpv .cpi{font:12px/1.4 ui-monospace,Consolas,monospace;margin-top:6px;color:var(--mu,#8fa3b3)}#cpv .cpn{font-size:13px;margin-top:4px;min-height:1.3em}`;
  document.head.appendChild(css);

  // ---- the little room: flat ground, two steps up to a plateau with an edge, walls at both ends ----
  function build() {
    const gw = 72,
      gh = 30,
      g = [];
    for (let y = 0; y < gh; y++) g.push('.'.repeat(gw));
    const fill = (x0, x1, y0, y1) => {
      for (let y = y0; y <= y1; y++) g[y] = g[y].slice(0, x0) + '#'.repeat(x1 - x0 + 1) + g[y].slice(x1 + 1);
    };
    fill(0, gw - 1, 24, gh - 1);
    fill(0, 0, 0, gh - 1);
    fill(gw - 1, gw - 1, 0, gh - 1);
    fill(40, 42, 22, 23);
    fill(43, 45, 20, 23);
    fill(46, 60, 18, 23);
    // floating one-way platforms every few tiles: landmarks that make the camera's movement easy to see (they never block the player)
    for (let x = 4, n = 0; x < gw - 6; x += 7, n++) {
      const y = n % 2 ? 17 : 20;
      g[y] = g[y].slice(0, x) + '===' + g[y].slice(x + 3);
    }
    return {
      id: '__cpv',
      n: 'Camera preview',
      s: '',
      x: 40,
      y: 40,
      w: 130,
      h: 44,
      note: '',
      grid: g,
      gw,
      gh,
      art: [],
      table: [],
      tr: [],
      ent: [{ id: 'sp', type: 'spawn', x: 6, y: 23, props: {} }],
      cam: null
    };
  }

  // ---- what the player does for each kind of setting (it loops) ----
  const T = (x, y, f) => ({ tp: [x, y, f || 1] });
  const W = (t, ...k) => ({ t, k });
  const DEMOS = {
    walk: [T(8, 24), W(1.8, 'Right'), W(0.9), W(1.8, 'Left'), W(0.9)],
    hop: [
      T(8, 24),
      W(0.3, 'Right'),
      W(0.5, 'Right', 'Jump'),
      W(0.7, 'Right'),
      W(0.5, 'Right', 'Jump'),
      W(0.9),
      W(0.4, 'Left'),
      W(0.5, 'Left', 'Jump'),
      W(0.9)
    ],
    climb: [
      T(36, 24),
      W(0.35, 'Right'),
      W(0.5, 'Right', 'Jump'),
      W(0.6, 'Right'),
      W(0.5, 'Right', 'Jump'),
      W(0.6, 'Right'),
      W(0.5, 'Right', 'Jump'),
      W(1.2)
    ],
    drop: [T(58.5, 18), W(0.5), W(1.2, 'Right'), W(2)],
    ledge: [T(60.7, 18), W(2.6)],
    peek: [T(20, 24), W(0.6), W(1.7, 'Down'), W(0.6), W(1.7, 'Up'), W(0.6)],
    still: [T(20, 24), W(3)],
    hands: null
  };
  DEMOS.all = [].concat(DEMOS.walk, DEMOS.hop, DEMOS.drop, DEMOS.ledge, DEMOS.peek);
  const DEMO_NAMES = [
    ['auto', 'Follow my last change'],
    ['walk', 'Run right and left'],
    ['hop', 'Jump while running'],
    ['climb', 'Climb the steps'],
    ['drop', 'Run off the plateau'],
    ['ledge', 'Stand at a ledge'],
    ['peek', 'Stand and look up and down'],
    ['still', 'Stand still'],
    ['all', 'Everything in turn'],
    ['hands', 'I steer (arrows or A D, Space)']
  ];
  // which part of the demo shows a setting best
  const demoFor = k =>
    /Peek/i.test(k)
      ? 'peek'
      : /Ledge/i.test(k)
        ? 'ledge'
        : /FallLook|RiseLook|Vel|jump/i.test(k)
          ? 'hop'
          : /drop|fall/i.test(k)
            ? 'drop'
            : /mode(Y|X)|lock(Y|X)|grounded|pad|edge|soft|dead/i.test(k)
              ? 'hop'
              : 'walk';

  // ---- keys ----
  const code = name => {
    const c = S.controls && S.controls.keys && S.controls.keys[name];
    return (
      (c && c[0]) || { Right: 'ArrowRight', Left: 'ArrowLeft', Up: 'ArrowUp', Down: 'ArrowDown', Jump: 'Space' }[name]
    );
  };
  const fire = (type, c) =>
    document.body.dispatchEvent(new KeyboardEvent(type, { code: c, key: c, bubbles: true, cancelable: true }));
  const setKeys = list => {
    const want = new Set(list.map(code));
    down.forEach(c => {
      if (!want.has(c)) {
        fire('keyup', c);
        down.delete(c);
      }
    });
    want.forEach(c => {
      if (!down.has(c)) {
        fire('keydown', c);
        down.add(c);
      }
    });
  };
  const releaseAll = () => setKeys([]);

  // ---- running ----
  const mine = () => !!ROOM && MV.Game.room() === ROOM;
  function startGame() {
    if (typeof V !== 'undefined' && V === 'pl') return false;
    if (typeof mtStop === 'function') mtStop();
    ROOM = build();
    const area = {
        id: '__cpv',
        n: 'Camera preview',
        s: '',
        c: '#378add',
        x: 0,
        y: 0,
        w: 170,
        h: 56,
        rooms: [ROOM],
        links: []
      },
      world = Object.assign({}, S, { areas: [area], events: [], scripts: [], bosses: [], vcams: S.vcams }),
      st = MV.Progress.fresh();
    // the live project's profiles and virtual cameras, so every edit shows at once
    Object.defineProperties(world, {
      camProfiles: { get: () => S.camProfiles, enumerable: true },
      vcams: { get: () => S.vcams, enumerable: true }
    });
    for (const id in MV.data.abilities) st.abilities[id] = true;
    MV.Game.debug = false;
    MV.Game.boxes = false;
    MV.Game.start({
      enemies: () => [],
      bosses: () => [],
      canvas: cv,
      world,
      room: ROOM,
      state: st,
      persist: false,
      art: typeof drawArt === 'function' ? drawArt : () => {},
      tuning: () => Object.assign({}, S.player, { maxHp: 99 }),
      image: typeof bgImg === 'function' ? bgImg : () => null,
      moves: () => S.moves,
      attacks: () => S.attacks,
      items: () => S.items,
      body: () => S.body,
      controls: () => S.controls,
      sprite: () => S.sprite,
      sheet: typeof sheetOf === 'function' ? sheetOf : () => null
    });
    MV.Game.camera.debug(box.querySelector('.cpd').checked);
    applyView();
    pick(demo === 'auto' ? 'walk' : demo);
    return true;
  }
  function pick(name) {
    releaseAll();
    run = DEMOS[name] ? { name, i: -1, t: 0, steps: DEMOS[name] } : null;
    if (run) next();
  }
  function next() {
    if (!run) return;
    run.i = (run.i + 1) % run.steps.length;
    const s = run.steps[run.i];
    run.t = s.t || 0;
    if (s.tp) {
      const p = MV.Game.player();
      if (p) {
        p.x = s.tp[0];
        p.y = s.tp[1];
        p.vx = p.vy = 0;
        p.face = s.tp[2];
        p.on = false;
        MV.Game.camera.rig().sceneChange();
      }
      setKeys([]);
      run.t = 0.05;
    } else setKeys(s.k || []);
  }
  function applyView() {
    if (!mine()) return;
    const sel = box.querySelector('.cpw').value;
    shown = sel;
    const C = MV.Game.camera;
    if (sel.startsWith('v:')) C.vcamSolo(sel.slice(2));
    else {
      C.vcamSolo(null);
      if (sel === 'default') C.reset();
      else C.set(sel.slice(2));
    }
  }

  // ---- finding what changed ----
  function snapshot() {
    const o = {},
      keys = MV.Camera.fields();
    keys.forEach(k => {
      o['Default camera: ' + ((MV.data.playerSchema[k] || {}).label || k) + '\u0001' + k] = S.player[k];
    });
    const pf = (S.camProfiles || []).find(q => q.id === (typeof CPI !== 'undefined' ? CPI : ''));
    if (pf)
      for (const k in pf.p) {
        const d = MV.data.playerSchema[k] || MV.data.camExtra[k] || {};
        o['Profile "' + pf.name + '": ' + (d.label || k) + '\u0001' + k] = pf.p[k];
      }
    (S.vcams || []).forEach(c => {
      for (const k in c) {
        if (k === 'id') continue;
        o['Virtual camera "' + c.name + '": ' + k + '\u0001' + k] = JSON.stringify(c[k]);
      }
    });
    return o;
  }
  function diff() {
    const now = snapshot();
    if (prev) {
      for (const k in now)
        if (JSON.stringify(now[k]) !== JSON.stringify(prev[k]) && k in prev) {
          const [label, key] = k.split('\u0001');
          lastChange = label + ': ' + fmt(prev[k]) + ' → ' + fmt(now[k]);
          note.textContent = 'Changed: ' + lastChange + '. Watch the picture.';
          if (demo === 'auto' && mine()) pick(demoFor(key));
          break;
        }
    }
    prev = now;
  }
  const fmt = v => {
    if (v === undefined || v === null || v === '') return '(default)';
    const s = String(v);
    return s.length > 40 ? s.slice(0, 38) + '...' : s;
  };

  // ---- the ticking loop (50 ms) ----
  let t0 = 0;
  function tick() {
    if (!box || !document.body.contains(box)) return stop();
    if (!mine()) return;
    const now = performance.now(),
      dt = Math.min(0.2, (now - t0) / 1000);
    t0 = now;
    if (run && !paused) {
      run.t -= dt;
      if (run.t <= 0) next();
    }
    diff();
    refreshViews();
    const C = MV.Game.camera,
      s = C.status ? C.status() : {},
      g = C.get ? C.get() : {},
      d = (g && g.debug) || {},
      f = v => (typeof v === 'number' && isFinite(v) ? v.toFixed(2) : '-');
    info.textContent =
      'camera ' +
      f(d.x) +
      ', ' +
      f(d.y) +
      '   zoom ' +
      f(s.zoom) +
      '   tilt ' +
      f(s.rot) +
      '   profile ' +
      (g.profile || 'default') +
      (C.vcamActive && C.vcamActive() ? '   virtual camera ' + C.vcamActive() : '') +
      (g.zone ? '   zone ' + g.zone : '') +
      (g.ledge ? '   ledge' : '');
  }
  function refreshViews() {
    // keep the "preview with" list in step with the project
    const sel = box.querySelector('.cpw'),
      want = viewOptions();
    if (sel.dataset.sig !== JSON.stringify(want)) {
      const cur = sel.value;
      fillViews(sel, want);
      sel.value = want.some(o => o[0] === cur) ? cur : 'default';
    }
  }
  const viewOptions = () => {
    const o = [['default', 'Default camera']];
    MV.Camera.all(S.camProfiles || []).forEach(q => q.id !== 'default' && o.push(['p:' + q.id, 'Profile: ' + q.name]));
    (S.vcams || []).forEach(c => o.push(['v:' + c.id, 'Virtual camera: ' + c.name]));
    return o;
  };
  function fillViews(sel, list) {
    sel.innerHTML = '';
    list.forEach(o => {
      const op = E('option', '', o[1]);
      op.value = o[0];
      sel.appendChild(op);
    });
    sel.dataset.sig = JSON.stringify(list);
  }

  // ---- the box ----
  function make() {
    box = E('div');
    box.id = 'cpv';
    const h = E('div', 'cph');
    h.appendChild(E('strong', '', 'Camera preview'));
    const view = E('select');
    view.className = 'cpw';
    view.title = 'Which camera to look through';
    view.onchange = applyView;
    const dm = E('select');
    dm.title = 'What the player does';
    DEMO_NAMES.forEach(n => {
      const o = E('option', '', n[1]);
      o.value = n[0];
      dm.appendChild(o);
    });
    dm.value = demo;
    dm.onchange = () => {
      demo = dm.value;
      if (demo === 'auto') pick('walk');
      else pick(demo);
      note.textContent = demo === 'hands' ? 'You steer: arrows or A and D to move, Space to jump.' : '';
    };
    const dl = E('label'),
      dc = E('input');
    dc.type = 'checkbox';
    dc.className = 'cpd';
    dc.checked = true;
    dc.onchange = () => mine() && MV.Game.camera.debug(dc.checked);
    dl.append(dc, 'Show the camera (view, dead zone, soft zone, look-ahead, limits)');
    const b = (t, f, title) => {
      const x = E('button', '', t);
      x.onclick = f;
      if (title) x.title = title;
      return x;
    };
    h.append(
      view,
      dm,
      b('Replay', () => pick(run ? run.name : 'walk'), 'Start the movement again'),
      b('Pause', function () {
        paused = !paused;
        this.textContent = paused ? 'Play' : 'Pause';
        if (paused) {
          releaseAll();
          MV.Game.pause();
        } else MV.Game.resume();
      }),
      b('Bigger', function () {
        big = !big;
        box.classList.toggle('big', big);
        this.textContent = big ? 'Smaller' : 'Bigger';
      }),
      dl
    );
    cv = E('canvas');
    cv.width = 800;
    cv.height = 448;
    note = E('div', 'cpn', 'Change any camera setting below: the player replays the part where it shows.');
    info = E('div', 'cpi');
    box.append(h, cv, note, info);
    fillViews(view, viewOptions());
    const cpi = typeof CPI !== 'undefined' ? CPI : 'default';
    view.value = viewOptions().some(o => o[0] === 'p:' + cpi) ? 'p:' + cpi : 'default';
    return box;
  }
  function stop() {
    if (timer) clearInterval(timer);
    timer = null;
    releaseAll();
    run = null;
    if (mine()) MV.Game.stop();
    ROOM = null;
    prev = null;
    paused = false;
    if (box) box.hidden = true;
  }
  window.cpvStop = stop;
  window.cpvUI = function () {
    const host = $('pcm');
    if (!host) return;
    if (!box) make();
    if (box.parentNode !== host || host.firstChild !== box) host.insertBefore(box, host.firstChild);
    box.hidden = false;
    if (mine() && timer) return; // already running: the panel below was only rebuilt
    if (typeof V !== 'undefined' && V === 'pl') {
      note.textContent = 'Stop the playtest in the World tab to use the preview.';
      return;
    }
    if (!startGame()) return;
    prev = snapshot();
    t0 = performance.now();
    if (timer) clearInterval(timer);
    timer = setInterval(tick, 50);
  };
})();
