// ---- JSON: individual clips and libraries, with their sprite sheets ----
async function axSaveJson(obj, defName) {
  const json = JSON.stringify(obj, null, 1);
  try {
    if (window.mvHost && window.mvHost.exportFile) {
      const r = await window.mvHost.exportFile(json, defName);
      if (!r || !r.ok) {
        if (r && r.error) axMsg('Export failed: ' + r.error);
        return;
      }
      axMsg('Exported ' + r.name + '.');
    } else {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
      a.download = defName;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
      axMsg('Exported ' + defName + '.');
    }
  } catch (e) {
    axMsg('Export failed: ' + e.message);
  }
}
$('axe1').onclick = () => {
  const c = axClip();
  if (!c) {
    axMsg('Select a clip first.');
    return;
  }
  axSaveJson(MV.Anim.exportClip(S, c.id), slug(c.name) + '.clip.json');
};
$('axe2').onclick = () => {
  if (!S.anims.length) {
    axMsg('There are no clips to export.');
    return;
  }
  axSaveJson(MV.Anim.exportLibrary(S), slug(S.name || 'project') + '.animations.json');
};
async function axImportText(text) {
  try {
    const r = MV.Anim.importInto(S, JSON.parse(text));
    AXI = Math.max(0, S.anims.length - 1);
    AXF = -1;
    AXP = null;
    save();
    axUI();
    axMsg(
      'Imported ' +
        r.clips +
        ' clip' +
        (r.clips === 1 ? '' : 's') +
        ' and ' +
        r.sheets +
        ' new sprite sheet' +
        (r.sheets === 1 ? '' : 's') +
        '.'
    );
    return r;
  } catch (e) {
    axMsg('Could not import: ' + e.message);
  }
}
$('axi').onclick = async () => {
  try {
    let r;
    if (window.mvHost && window.mvHost.open) {
      r = await window.mvHost.open();
      if (!r || !r.ok) {
        if (r && r.error) axMsg('Could not open that file: ' + r.error);
        return;
      }
    } else
      r = await new Promise(res => {
        const i = document.createElement('input');
        i.type = 'file';
        i.accept = '.json,application/json';
        i.onchange = () => {
          const f = i.files[0];
          if (!f) return res(null);
          const fr = new FileReader();
          fr.onload = () => res({ text: fr.result });
          fr.readAsText(f);
        };
        i.click();
      });
    if (r) await axImportText(r.text);
  } catch (e) {
    axMsg('Could not import: ' + e.message);
  }
};
addEventListener('keydown', e => {
  if (TAB !== 'anim' || e.key !== 'Delete' || inText(e.target)) return;
  e.preventDefault();
  axDelFrame();
});
