// ---- lighting (per room): room light level, player light radius and level; Light entities are placed like other entities ----
const LC = {};
function drawLightPreview(c) {
  if (!rc || !$('lgp').checked) return;
  const L = MV.Light.clean(rc.light) || MV.Light.def();
  const lights = MV.Light.fromEntities(rc.ent).map(l => MV.Light.scale(l, c, VO.x, VO.y)),
    zones = MV.Light.zonesFromEntities(rc.ent).map(l => MV.Light.scale(l, c, VO.x, VO.y));
  const cellOf = (tx, ty) => (tx >= 0 && tx < rc.gw && ty >= 0 && ty < rc.gh ? rc.grid[ty][tx] : '');
  const solid = (tx, ty) => (tx < 0 || tx >= rc.gw || ty < 0 ? true : MV.Light.tileSolid(cellOf(tx, ty)));
  const zsolid = (tx, ty) => (tx < 0 || tx >= rc.gw || ty < 0 ? true : MV.Light.tileZsolid(cellOf(tx, ty)));
  const slope = (tx, ty) => {
    const ch = cellOf(tx, ty);
    return MV.Light.PROFILES[ch] ? ch : null;
  };
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.globalAlpha = 0.88;
  MV.Light.draw(
    ctx,
    {
      w: cv.width,
      h: cv.height,
      ambient: L.ambient,
      tint: L.tint,
      lights,
      zones,
      solid,
      zsolid,
      slope,
      k: c,
      ox: VO.x,
      oy: VO.y
    },
    LC
  );
  ctx.restore();
}
function lightUI() {
  const L = MV.Light.clean(rc && rc.light) || MV.Light.def();
  $('lga').value = L.ambient;
  $('lgt').value = L.tint;
  $('lgh').value = L.hz;
  $('lgr').value = L.pr;
  $('lgl').value = L.pl;
}
function lightSet() {
  if (!rc) return;
  rc.light = MV.Light.clean({
    ambient: $('lga').value,
    tint: $('lgt').value,
    hz: $('lgh').value,
    pr: $('lgr').value,
    pl: $('lgl').value
  });
  save();
  lightUI();
  drawT();
}
$('lga').onchange = $('lgt').onchange = $('lgh').onchange = $('lgr').onchange = $('lgl').onchange = lightSet;
$('lgp').onchange = () => {
  if (rc) drawT();
};
const playing = () => V === 'pl' && TAB === 'world';
function tab(t) {
  if (t === TAB) return;
  TAB = t;
  if (t !== 'player') mtStop();
  $('ws').hidden = t !== 'world';
  $('pls').hidden = t !== 'player';
  $('bc').hidden = t !== 'world';
  $('tabw').classList.toggle('on', t === 'world');
  $('tabp').classList.toggle('on', t === 'player');
  $('bsg').hidden = t !== 'boss';
  $('tabb').classList.toggle('on', t === 'boss');
  $('axg').hidden = t !== 'anim';
  $('taba').classList.toggle('on', t === 'anim');
  $('evg').hidden = t !== 'events';
  $('tabe').classList.toggle('on', t === 'events');
  $('aug').hidden = t !== 'audio';
  $('tabu').classList.toggle('on', t === 'audio');
  $('scg').hidden = t !== 'scripts';
  $('tabj').classList.toggle('on', t === 'scripts');
  $('eng').hidden = t !== 'enemies';
  $('tabn').classList.toggle('on', t === 'enemies');
  if (t === 'enemies') {
    if (V === 'pl') MV.Game.pause();
    enUI();
  } else if (t === 'scripts') {
    if (V === 'pl') MV.Game.pause();
    scUI();
  } else if (t === 'audio') {
    if (V === 'pl') MV.Game.pause();
    auUI();
  } else if (t === 'events') {
    if (V === 'pl') MV.Game.pause();
    evUI();
  } else if (t === 'anim') {
    if (V === 'pl') MV.Game.pause();
    axUI();
    axTickStart();
  } else if (t === 'boss') {
    if (V === 'pl') MV.Game.pause();
    bossUI();
    bossTickStart();
  } else if (t === 'player') {
    if (V === 'pl') MV.Game.pause();
    buildTune();
    psSub(PSUB);
    pvStart();
    tlStart();
    trOpts($('ptr'), cur && rc ? cur.id + '|' + rc.id : '');
  } else if (V === 'pl') MV.Game.resume();
  ui();
}
$('tabw').onclick = () => tab('world');
$('tabp').onclick = () => tab('player');
$('tabb').onclick = () => tab('boss');
$('taba').onclick = () => tab('anim');
$('tabe').onclick = () => tab('events');
$('tabu').onclick = () => tab('audio');
$('tabn').onclick = () => tab('enemies');
$('tabj').onclick = () => tab('scripts');
$('ptg').onclick = () => {
  const q = ($('ptr').value || '').split('|'),
    rm = MV.Progress.find(S, q[0], q[1]);
  if (!rm) {
    $('pmsg').textContent = 'Pick a room to test in.';
    return;
  }
  leavePlay();
  cur = MV.Progress.areaOf(S, rm);
  rc = rm;
  tab('world');
  openRoom(rm);
  $('pb').click();
};
function leavePlay() {
  if (V !== 'pl') return;
  const a = MV.Game.area(),
    r = MV.Game.room();
  MV.Game.stop();
  if (a) cur = a;
  if (r) rc = r;
}
function bc() {
  const b = $('bc');
  b.innerHTML = '';
  const add = (t, f) => {
    const e = document.createElement(f ? 'button' : 'span');
    e.textContent = t;
    if (f) e.onclick = f;
    b.appendChild(e);
  };
  add(
    'World',
    V === 'ov'
      ? null
      : () => {
          leavePlay();
          show('ov');
          draw(WC);
        }
  );
  if (cur && V !== 'ov') {
    add('›');
    add(
      cur.n,
      V === 'ar'
        ? null
        : () => {
            leavePlay();
            show('ar');
            draw(AC);
          }
    );
  }
  if (rc && (V === 'rm' || V === 'pl')) {
    add('›');
    add(
      rc.n,
      V === 'rm'
        ? null
        : () => {
            leavePlay();
            openRoom(rc);
          }
    );
  }
}
$('sv').onclick = () => mvSave(false);
$('un').onclick = mvUndo;
$('rd').onclick = mvRedo;
$('jb').onclick = () => $('jd').showModal();
$('jx').onclick = () => $('jd').close();
addEventListener('keydown', e => {
  if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
  const k = e.key.toLowerCase();
  if (k === 's') {
    e.preventDefault();
    mvSave(e.shiftKey);
  } else if (k === 'z' && !e.shiftKey) {
    if (!inText(e.target)) {
      e.preventDefault();
      mvUndo();
    }
  } else if (k === 'y' || (k === 'z' && e.shiftKey)) {
    if (!inText(e.target)) {
      e.preventDefault();
      mvRedo();
    }
  }
});
function leaveProject() {
  if (PID) persist();
  PID = null;
  MV.Game.stop();
}
function renderStart() {
  const L = $('pl2'),
    idx = idxGet().sort((a, b) => (b.updated || 0) - (a.updated || 0));
  L.innerHTML = '';
  $('sm').textContent = '';
  if (!idx.length) {
    const e = document.createElement('p');
    e.className = 'hint';
    e.textContent = 'No projects yet. Create one on the left, or open a project file.';
    L.appendChild(e);
  }
  idx.forEach(m => {
    const row = document.createElement('div'),
      info = document.createElement('div'),
      n = document.createElement('strong'),
      d = document.createElement('span'),
      o = document.createElement('button'),
      x = document.createElement('button');
    row.className = 'prj';
    info.className = 'pinfo';
    d.className = 'hint';
    n.textContent = m.name;
    d.textContent =
      'Last edited ' +
      new Date(m.updated || m.created || 0).toLocaleString() +
      (m.file ? ' - ' + String(m.file).split(/[\\/]/).pop() : '');
    info.append(n, d);
    o.textContent = 'Open';
    o.onclick = () => openProject(m.id);
    x.textContent = 'Delete';
    x.onclick = () => {
      if (confirm('Delete project "' + m.name + '"? This cannot be undone.')) delProject(m.id);
    };
    row.ondblclick = () => openProject(m.id);
    row.append(info, o, x);
    L.appendChild(row);
  });
}
function delProject(id) {
  const m = idxGet().find(p => p.id === id);
  idxSet(idxGet().filter(p => p.id !== id));
  try {
    localStorage.removeItem('mv_proj_' + id);
    if (m && m.saveKey && m.saveKey !== 'mv_save_v1') localStorage.removeItem(m.saveKey);
  } catch (e) {}
  renderStart();
}
function closeProject() {
  leaveProject();
  $('app').hidden = true;
  $('start').hidden = false;
  renderStart();
}
// File menu (main.js) calls these two: New project goes to the start screen with the name box ready, Close project goes back to the start screen.
function mvClose() {
  closeProject();
}
function mvNew() {
  closeProject();
  const n = $('nn');
  if (n) {
    n.focus();
    n.select();
  }
}
function startScreen() {
  $('ver').textContent = $('ver2').textContent = 'v' + APP_VER;
  document.title = 'Metroidvania Engine ' + APP_VER;
  try {
    if (localStorage.getItem('mv_migrated') === null) {
      localStorage.setItem('mv_migrated', '1');
      const old = localStorage.getItem('seamap2');
      if (old && !idxGet().length) {
        const id = 'p' + rid();
        localStorage.setItem('mv_proj_' + id, old);
        idxSet([
          {
            id,
            name: 'My game (from the earlier version)',
            created: Date.now(),
            updated: Date.now(),
            file: null,
            saveKey: 'mv_save_v1'
          }
        ]);
      }
    }
  } catch (e) {}
  $('app').hidden = true;
  $('start').hidden = false;
  renderStart();
}
function openProject(id) {
  const m = idxGet().find(p => p.id === id);
  if (!m) return;
  let raw = null;
  try {
    raw = localStorage.getItem('mv_proj_' + id);
  } catch (e) {}
  leaveProject();
  S = fresh();
  try {
    if (raw) merge(des(raw));
  } catch (e) {
    S = fresh();
    console.error('open project failed', e);
    $('sm').textContent =
      'Could not open "' +
      m.name +
      '": ' +
      (e instanceof SyntaxError
        ? 'its saved data is damaged.'
        : 'something in it could not be read (' + ((e && e.message) || e) + '). Your saved data is untouched.');
    return;
  }
  S.name = S.name || m.name;
  PID = id;
  PFILE = m.file || null;
  MV.Progress.setKey(m.saveKey || 'mv_save_' + id);
  U = [];
  R = [];
  lastPush = 0;
  dirty = false;
  cur = null;
  rc = null;
  wReset();
  $('start').hidden = true;
  $('app').hidden = false;
  if (TAB !== 'world') tab('world');
  $('pn').value = S.name;
  document.title = S.name + ' - Metroidvania Engine ' + APP_VER;
  setMode(WC, 'm');
  show('ov');
  persist();
  metaSet({ name: S.name, updated: Date.now() });
  rebase();
  ui();
}
function addProject(data, name, file) {
  const id = 'p' + rid();
  const a = idxGet();
  a.push({ id, name, created: Date.now(), updated: Date.now(), file: file || null, saveKey: 'mv_save_' + id });
  try {
    localStorage.setItem('mv_proj_' + id, ser(data));
  } catch (e) {
    $('sm').textContent = 'Could not store the project (storage is full).';
    return;
  }
  idxSet(a);
  openProject(id);
}
function newProject(name, tpl) {
  leaveProject();
  const w = fresh();
  if (tpl !== 'sea') {
    w.areas = [{ id: 'a1', n: 'Start area', s: '', c: 't', x: 40, y: 40, w: 170, h: 56, rooms: null, links: [] }];
    w.links = [];
  }
  w.name = name;
  addProject(w, name, null);
}
function projectFromJson(text, fname, path) {
  leaveProject();
  let o;
  try {
    o = des(text);
    if (!o || typeof o.areas !== 'object') throw 0;
    if (
      o.scripts &&
      o.scripts.length &&
      !confirm(
        'This project contains ' +
          o.scripts.length +
          ' script(s). Scripts are code that runs in the game. Only open it if you trust where the file came from.\n\nOpen it?'
      )
    ) {
      S = fresh();
      $('sm').textContent = 'Not opened.';
      return false;
    }
    S = fresh();
    merge(o);
  } catch (e) {
    S = fresh();
    $('sm').textContent = 'That file is not a Metroidvania Engine project.';
    return false;
  }
  const name = (S.name || String(fname || '').replace(/\.json$/i, '') || 'Opened project').slice(0, 40),
    same = path && idxGet().find(p => p.file === path);
  S.name = name;
  if (same) {
    try {
      localStorage.setItem('mv_proj_' + same.id, ser(S));
    } catch (e) {}
    openProject(same.id);
    return true;
  }
  addProject(S, name, path);
  return true;
}
async function mvOpenFile() {
  try {
    let r;
    if (window.mvHost && window.mvHost.open) {
      r = await window.mvHost.open();
      if (!r || !r.ok) {
        if (r && r.error) $('sm').textContent = 'Could not open that file: ' + r.error;
        return;
      }
    } else
      r = await new Promise(res => {
        const i = document.createElement('input');
        i.type = 'file';
        i.accept = '.json,application/json';
        i.onchange = () => {
          const f = i.files[0];
          if (!f) return res(null);
          const fr = new FileReader();
          fr.onload = () => res({ text: fr.result, name: f.name, path: null });
          fr.readAsText(f);
        };
        i.click();
      });
    if (!r) return;
    projectFromJson(r.text, r.name, r.path);
  } catch (e) {
    $('sm').textContent = 'Could not open that file: ' + e.message;
  }
}
$('ncr').onclick = () => {
  newProject(($('nn').value || '').trim().slice(0, 40) || 'Untitled project', $('nt2').value);
};
$('nn').onkeydown = e => {
  if (e.key === 'Enter') $('ncr').onclick();
};
$('opf').onclick = mvOpenFile;
$('pj').onclick = closeProject;
$('pn').onchange = () => {
  S.name = ($('pn').value || '').trim().slice(0, 40) || 'Untitled project';
  $('pn').value = S.name;
  document.title = S.name + ' - Metroidvania Engine ' + APP_VER;
  metaSet({ name: S.name });
  persist();
};
tb(WC);
tb(AC);
startScreen();
