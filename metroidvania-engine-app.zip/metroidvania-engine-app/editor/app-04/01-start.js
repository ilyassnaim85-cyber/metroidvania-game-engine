// Part 4 of the editor script (split from index.html; the parts run in order and share one scope, exactly like the old single script).
$('axn').onclick = () => {
  if (S.anims.length >= 100) {
    axMsg('Up to 100 clips.');
    return;
  }
  S.anims.push(MV.Anim.clean({ name: 'Animation ' + (S.anims.length + 1) }));
  AXI = S.anims.length - 1;
  AXF = -1;
  save();
  axUI();
};
$('axd').onclick = () => {
  const c = axClip();
  if (!c || S.anims.length >= 100) return;
  const k = JSON.parse(JSON.stringify(c));
  k.id = '';
  k.name = (c.name + ' copy').slice(0, 40);
  S.anims.splice(AXI + 1, 0, MV.Anim.clean(k));
  AXI++;
  AXF = -1;
  save();
  axUI();
};
$('axx').onclick = () => {
  const c = axClip();
  if (!c || !confirm('Delete the animation "' + c.name + '"?')) return;
  S.anims.splice(AXI, 1);
  AXI = Math.max(0, AXI - 1);
  AXF = -1;
  AXP = null;
  save();
  axUI();
};
