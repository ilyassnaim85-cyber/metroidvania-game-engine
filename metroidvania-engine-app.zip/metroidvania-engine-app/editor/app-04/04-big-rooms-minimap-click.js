// ---- big rooms: minimap (click or drag to jump), arrow-key panning, tile readout, go to tile ----
(() => {
  const wr = zWrap('room'),
    par = wr.parentNode,
    bar = wr.previousElementSibling;
  par.style.position = 'relative';
  const mm = document.createElement('div');
  mm.id = 'mm';
  mm.hidden = true;
  mm.title = 'Whole room. Click or drag to jump there.';
  const mc = document.createElement('canvas');
  mm.appendChild(mc);
  par.appendChild(mm);
  const mx = mc.getContext('2d');
  const COL = {
      '#': [91, 107, 122],
      g: [122, 106, 154],
      '=': [166, 124, 82],
      '~': [59, 139, 212],
      D: [239, 159, 39],
      '^': [216, 90, 48],
      i: [143, 208, 232],
      m: [107, 79, 51],
      '>': [201, 152, 58],
      '<': [201, 152, 58],
      u: [47, 158, 120],
      y: [150, 215, 235],
      o: [47, 58, 71],
      x: [70, 70, 84],
      '/': [91, 107, 122],
      '\\': [91, 107, 122],
      '[': [91, 107, 122],
      ']': [91, 107, 122],
      '{': [91, 107, 122],
      '}': [91, 107, 122],
      _: [91, 107, 122]
    },
    BG = [16, 23, 33];
  let OPEN = false;
  const shown = () => OPEN && rc && V === 'rm' && TAB === 'world';
  function mmDraw() {
    if (!shown()) {
      mm.hidden = true;
      return;
    }
    mm.hidden = false;
    const gw = rc.gw,
      gh = rc.gh,
      s = Math.min(190 / gw, 190 / gh),
      w = Math.max(8, Math.round(gw * s)),
      h = Math.max(8, Math.round(gh * s));
    if (mc.width !== w || mc.height !== h) {
      mc.width = w;
      mc.height = h;
    }
    const im = mx.createImageData(w, h),
      d = im.data,
      sx = gw / w,
      sy = gh / h,
      g = rc.grid;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let c = null;
        for (let j = 0; j < 2 && !c; j++) {
          const row = g[Math.min(gh - 1, Math.floor((y + j * 0.5) * sy))];
          if (!row) continue;
          for (let i = 0; i < 2; i++) {
            const ch = row[Math.min(gw - 1, Math.floor((x + i * 0.5) * sx))];
            if (ch && ch !== '.') {
              c = COL[ch] || COL['#'];
              break;
            }
          }
        }
        c = c || BG;
        const o = (y * w + x) * 4;
        d[o] = c[0];
        d[o + 1] = c[1];
        d[o + 2] = c[2];
        d[o + 3] = 255;
      }
    }
    mx.putImageData(im, 0, 0);
    mx.fillStyle = '#ffd24a';
    (rc.ent || [])
      .slice(0, 600)
      .forEach(e => mx.fillRect(Math.floor((e.x * w) / gw), Math.floor((e.y * h) / gh), 2, 2));
    const r = rr(),
      c = r.width / gw,
      wb = wr.getBoundingClientRect(),
      vx = Math.max(0, (wb.left - r.left) / c),
      vy = Math.max(0, (wb.top - r.top) / c),
      vw = wr.clientWidth / c,
      vh = wr.clientHeight / c;
    mx.strokeStyle = '#fff';
    mx.lineWidth = 1.5;
    mx.fillStyle = 'rgba(255,255,255,.12)';
    const rx = (vx * w) / gw,
      ry = (vy * h) / gh,
      rw = Math.max(3, (vw * w) / gw),
      rh = Math.max(3, (vh * h) / gh);
    mx.fillRect(rx, ry, rw, rh);
    mx.strokeRect(rx + 0.5, ry + 0.5, rw, rh);
  }
  function goTo(tx, ty) {
    if (!rc) return;
    const r = rr(),
      c = r.width / rc.gw,
      wb = wr.getBoundingClientRect();
    wr.scrollLeft += r.left + (tx + 0.5) * c - (wb.left + wr.clientWidth / 2);
    wr.scrollTop += r.top + (ty + 0.5) * c - (wb.top + wr.clientHeight / 2);
  }
  let MD = false;
  const jump = e => {
    const b = mc.getBoundingClientRect();
    goTo(
      Math.max(0, Math.min(rc.gw - 1, ((e.clientX - b.left) / b.width) * rc.gw)),
      Math.max(0, Math.min(rc.gh - 1, ((e.clientY - b.top) / b.height) * rc.gh))
    );
  };
  mc.addEventListener('pointerdown', e => {
    e.preventDefault();
    e.stopPropagation();
    MD = true;
    mc.setPointerCapture(e.pointerId);
    jump(e);
  });
  mc.addEventListener('pointermove', e => {
    if (MD) jump(e);
  });
  mc.addEventListener('pointerup', () => {
    MD = false;
  });
  mc.addEventListener('pointercancel', () => {
    MD = false;
  });
  let MT = 0;
  const mmSoon = () => {
    if (MT) return;
    MT = requestAnimationFrame(() => {
      MT = 0;
      mmDraw();
    });
  };
  wr.addEventListener('scroll', mmSoon);
  setInterval(() => {
    if (shown()) mmDraw();
    else mm.hidden = true;
  }, 300);
  // the map is closed until you press the Map button in the toolbar (it is never over the room while you build)
  const tg = btn('Map \u25BE', () => {
    OPEN ? closeMap() : openMap();
  });
  tg.title =
    'Show the whole room as a small map. Click or drag it to jump. It closes when you click the room, or press Esc.';
  tg.className = 'mapbtn';
  function openMap() {
    OPEN = true;
    tg.textContent = 'Map \u25B4';
    mm.style.top = bar.offsetTop + bar.offsetHeight + 4 + 'px';
    mmDraw();
  }
  function closeMap() {
    OPEN = false;
    tg.textContent = 'Map \u25BE';
    mm.hidden = true;
  }
  wr.addEventListener(
    'pointerdown',
    () => {
      if (OPEN) closeMap();
    },
    true
  );
  addEventListener('keydown', e => {
    if (e.key === 'Escape' && OPEN) closeMap();
  });
  // readout under the mouse, and go to tile
  const pt = document.createElement('span');
  pt.className = 'ptile';
  pt.textContent = 'Tile: move over the room';
  const gi = document.createElement('input');
  gi.type = 'text';
  gi.className = 'gox';
  gi.placeholder = 'x, y';
  gi.title = 'Type a tile position like 500, 320 and press Enter';
  const gb = btn('Go to', () => {
    const m = /(-?\d+)\D+(-?\d+)/.exec(gi.value);
    if (m && rc) goTo(Math.max(0, Math.min(rc.gw - 1, +m[1])), Math.max(0, Math.min(rc.gh - 1, +m[2])));
  });
  gb.title = 'Scroll the room so this tile is in the middle';
  gi.onkeydown = e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      gb.click();
    }
  };
  bar.append(tg, pt, gi, gb);
  cv.addEventListener('pointermove', e => {
    if (!rc) return;
    const r = rr(),
      x = Math.floor(((e.clientX - r.left) / r.width) * rc.gw),
      y = Math.floor(((e.clientY - r.top) / r.height) * rc.gh);
    if (x >= 0 && y >= 0 && x < rc.gw && y < rc.gh) {
      const ch = rc.grid[y][x];
      pt.textContent = 'Tile ' + x + ', ' + y + (ch && ch !== '.' ? '  (' + MV.Tiles.nameOf(ch) + ')' : '');
    }
  });
  // arrow keys pan at a steady speed (Shift = 4x), so you can steer in a huge room
  const PK = {};
  let PL = 0,
    PT = 0;
  function pkLoop(t) {
    if (zActive() !== 'room' || !(PK.ArrowLeft || PK.ArrowRight || PK.ArrowUp || PK.ArrowDown)) {
      PL = 0;
      return;
    }
    const dt = Math.min(0.05, Math.max(0.001, (t - PT) / 1000));
    PT = t;
    const c = rr().width / rc.gw,
      sp = Math.max(c * 14, 260) * (PK.fast ? 4 : 1);
    wr.scrollLeft += ((PK.ArrowRight ? 1 : 0) - (PK.ArrowLeft ? 1 : 0)) * sp * dt;
    wr.scrollTop += ((PK.ArrowDown ? 1 : 0) - (PK.ArrowUp ? 1 : 0)) * sp * dt;
    PL = requestAnimationFrame(pkLoop);
  }
  addEventListener('keydown', e => {
    if (
      !/^Arrow(Left|Right|Up|Down)$/.test(e.code) ||
      e.ctrlKey ||
      e.metaKey ||
      e.altKey ||
      /^(INPUT|TEXTAREA|SELECT)$/.test(String(e.target && e.target.tagName)) ||
      zActive() !== 'room'
    )
      return;
    e.preventDefault();
    PK[e.code] = 1;
    PK.fast = e.shiftKey;
    if (!PL) {
      PT = performance.now();
      PL = requestAnimationFrame(pkLoop);
    }
  });
  addEventListener('keyup', e => {
    if (PK[e.code]) delete PK[e.code];
  });
  addEventListener('blur', () => {
    for (const k in PK) delete PK[k];
  });
})();
