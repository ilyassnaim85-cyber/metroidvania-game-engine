// ---- the Layers button (room editor): hide or lock Tiles, Scenery and Gameplay objects ----
(() => {
  const wr = zWrap('room'),
    par = wr.parentNode,
    bar = wr.previousElementSibling;
  const pop = document.createElement('div');
  pop.id = 'lyp';
  pop.hidden = true;
  par.appendChild(pop);
  const tg = btn('Layers ▾', () => {
    pop.hidden ? open() : shut();
  });
  tg.className = 'mapbtn';
  tg.title = 'Hide or lock the Tiles, Scenery and Gameplay objects while you edit';
  const ROWS = [
    ['tiles', 'Tiles', 'Terrain, slopes, water, belts'],
    ['scenery', 'Scenery', 'Sprites and the background'],
    ['objects', 'Gameplay objects', 'Entities, bosses, lamps, transitions']
  ];
  function sync() {
    const on = ROWS.some(r => !LY[r[0]].v || LY[r[0]].l);
    tg.classList.toggle('lyon', on);
    tg.textContent = 'Layers ' + (pop.hidden ? '▾' : '▴') + (on ? ' ●' : '');
  }
  function build() {
    pop.innerHTML = '';
    ROWS.forEach(([k, n, d]) => {
      const r = document.createElement('div');
      r.className = 'lr';
      const t = document.createElement('b');
      t.innerHTML = esc(n) + '<small>' + esc(d) + '</small>';
      const e = btn(LY[k].v ? '👁 Shown' : 'Hidden', () => {
        LY[k].v = LY[k].v ? 0 : 1;
        lyApply();
        build();
      });
      e.className = LY[k].v ? '' : 'on';
      e.title = 'Show or hide this layer in the editor (the game is not affected)';
      const l = btn(LY[k].l ? '🔒 Locked' : 'Unlocked', () => {
        LY[k].l = LY[k].l ? 0 : 1;
        lyApply();
        build();
      });
      l.className = LY[k].l ? 'on' : '';
      l.title = 'A locked layer cannot be painted, erased, moved or deleted';
      r.append(t, e, l);
      pop.appendChild(r);
    });
    const a = document.createElement('div');
    a.className = 'la';
    a.append(
      btn('Show all', () => {
        for (const k in LY) LY[k].v = 1;
        lyApply();
        build();
      }),
      btn('Unlock all', () => {
        for (const k in LY) LY[k].l = 0;
        lyApply();
        build();
      }),
      btn('Only tiles', () => {
        LY.tiles = { v: 1, l: 0 };
        LY.scenery = { v: 0, l: 0 };
        LY.objects = { v: 0, l: 0 };
        lyApply();
        build();
      })
    );
    pop.appendChild(a);
    sync();
  }
  function open() {
    build();
    pop.hidden = false;
    pop.style.top = bar.offsetTop + bar.offsetHeight + 4 + 'px';
    sync();
  }
  function shut() {
    pop.hidden = true;
    sync();
  }
  lyUI = () => {
    if (!pop.hidden) build();
    else sync();
  };
  wr.addEventListener(
    'pointerdown',
    () => {
      if (!pop.hidden) shut();
    },
    true
  );
  addEventListener('keydown', e => {
    if (e.key === 'Escape' && !pop.hidden) shut();
  });
  const mapBtn = [...bar.querySelectorAll('button')].find(b => /^Map/.test(b.textContent));
  bar.insertBefore(tg, mapBtn ? mapBtn.nextSibling : null);
  lyApply();
})();
