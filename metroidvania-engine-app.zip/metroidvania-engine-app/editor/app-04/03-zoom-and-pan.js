// ================= Zoom and pan =================
// Every big surface (world map, rooms map, room editor, boss arena) scrolls inside its frame. Zoom changes its size, pan is scrolling.
// Default view = the whole thing at 100%, shrunk to fit if it is bigger than the window. Fit = zoom to the content. Reset view = default.
const ZMIN = 0.1,
  ZMAX = 8,
  TS = 24,
  VIEWS = {},
  ZL = {},
  ZK = {};
let SPACE = false,
  ZP = null,
  ZT = 0;
const bboxOf = l =>
  l && l.length
    ? {
        x0: Math.min(...l.map(i => i.x)),
        y0: Math.min(...l.map(i => i.y)),
        x1: Math.max(...l.map(i => i.x + i.w)),
        y1: Math.max(...l.map(i => i.y + i.h))
      }
    : null;
const ZS = {
  world: {
    el: () => $('svg'),
    nat: () => [S.mw, S.mh],
    redraw: () => draw(WC),
    key: () => 'world',
    cap: 30000,
    box: () => bboxOf(S.areas)
  },
  rooms: {
    el: () => $('sv2'),
    nat: () => [cur.mw, cur.mh],
    redraw: () => draw(AC),
    key: () => 'rooms:' + cur.id,
    cap: 30000,
    box: () => bboxOf(cur.rooms)
  },
  room: {
    el: () => $('cvs'),
    nat: () => [rc.gw * TS, rc.gh * TS],
    redraw: () => drawT(),
    key: () => 'room:' + rc.id,
    cap: 3e7
  },
  boss: {
    el: () => $('bcv'),
    nat: () => {
      const b = cb(),
        A = b ? b.arena : { gw: 32, gh: 18 };
      return [A.gw * TS, A.gh * TS];
    },
    redraw: () => {
      if (cb()) drawBoss();
    },
    key: () => 'boss:' + (cb() ? cb().id : ''),
    cap: 8192
  }
};
const zWrap = n => ZS[n].el().closest('.cvw');
let SCR = 0;
zWrap('room').addEventListener('scroll', () => {
  if (SCR || !rc) return;
  SCR = requestAnimationFrame(() => {
    SCR = 0;
    if (!rc || !cv.offsetParent) return;
    const a = cv.getBoundingClientRect(),
      b = rr();
    if (Math.abs(a.left - b.left - VO.x) > 0.5 || Math.abs(a.top - b.top - VO.y) > 0.5) drawT();
  });
});
const zClamp = (z, n, w, h) => Math.max(ZMIN, Math.min(ZMAX, ZS[n].cap / Math.max(w, h, 1), z));
function zFitZ(w, h, wr) {
  const cw = wr.clientWidth - 18,
    ch = wr.clientHeight - 18;
  return cw > 20 && ch > 20 ? Math.min(cw / w, ch / h) : 1;
}
function zUse(n) {
  const s = ZS[n],
    nat = s.nat(),
    w = nat[0],
    h = nat[1],
    k = s.key(),
    wr = zWrap(n);
  if (ZK[n] !== k) {
    ZK[n] = k;
    wr.scrollLeft = 0;
    wr.scrollTop = 0;
  }
  const z = zClamp(typeof VIEWS[k] === 'number' ? VIEWS[k] : Math.min(1, zFitZ(w, h, wr)), n, w, h);
  if (ZL[n]) ZL[n].textContent = Math.round(z * 100) + '%';
  return z;
}
function zoomTo(n, z1, anchor) {
  const s = ZS[n],
    nat = s.nat(),
    wr = zWrap(n),
    el = s.el(),
    r0 = el.getBoundingClientRect(),
    wb = wr.getBoundingClientRect(),
    ax = anchor ? anchor.x : wb.left + wb.width / 2,
    ay = anchor ? anchor.y : wb.top + wb.height / 2,
    fx = Math.max(0, Math.min(1, (ax - r0.left) / (r0.width || 1))),
    fy = Math.max(0, Math.min(1, (ay - r0.top) / (r0.height || 1)));
  VIEWS[s.key()] = zClamp(z1, n, nat[0], nat[1]);
  s.redraw();
  const r1 = el.getBoundingClientRect();
  wr.scrollLeft += r1.left + fx * r1.width - ax;
  wr.scrollTop += r1.top + fy * r1.height - ay;
}
const zoomBy = (n, f, anchor) => zoomTo(n, zUse(n) * f, anchor);
function zoomFit(n) {
  const s = ZS[n],
    nat = s.nat(),
    wr = zWrap(n),
    b = s.box && s.box();
  if (b) {
    const m = 24,
      z = zClamp(zFitZ(b.x1 - b.x0 + 2 * m, b.y1 - b.y0 + 2 * m, wr), n, nat[0], nat[1]);
    VIEWS[s.key()] = z;
    s.redraw();
    wr.scrollLeft = Math.max(0, (b.x0 - m) * z);
    wr.scrollTop = Math.max(0, (b.y0 - m) * z);
  } else {
    VIEWS[s.key()] = zClamp(zFitZ(nat[0], nat[1], wr), n, nat[0], nat[1]);
    s.redraw();
    wr.scrollLeft = 0;
    wr.scrollTop = 0;
  }
}
function zoomReset(n) {
  const s = ZS[n],
    wr = zWrap(n);
  delete VIEWS[s.key()];
  s.redraw();
  wr.scrollLeft = 0;
  wr.scrollTop = 0;
}
function zWheel(n, e) {
  e.preventDefault();
  if (e.shiftKey) {
    zWrap(n).scrollLeft += e.deltaY || e.deltaX;
    return;
  }
  const d = e.deltaMode === 1 ? e.deltaY * 18 : e.deltaY;
  zoomBy(n, Math.exp(-Math.max(-120, Math.min(120, d)) * 0.0015), { x: e.clientX, y: e.clientY });
}
// pan: middle mouse button, Space + drag, or drag the empty background of a map
const zIsBg = t => !!t && (String(t.tagName).toLowerCase() === 'svg' || (t.classList && t.classList.contains('bgr')));
function zPanStart(e, wr, bg) {
  if (!(e.button === 1 || (SPACE && e.button === 0) || (bg && e.button === 0 && !e.shiftKey))) return false;
  ZP = { w: wr, x: e.clientX, y: e.clientY, sl: wr.scrollLeft, st: wr.scrollTop };
  wr.classList.add('panning');
  return true;
}
function zPanMove(e) {
  if (ZP) {
    if (Math.abs(e.clientX - ZP.x) + Math.abs(e.clientY - ZP.y) > 3) ZP.moved = true;
    ZP.w.scrollLeft = ZP.sl - (e.clientX - ZP.x);
    ZP.w.scrollTop = ZP.st - (e.clientY - ZP.y);
  }
}
function zPanEnd() {
  if (ZP) {
    if (ZP.moved) {
      zWasPan = true;
      setTimeout(() => {
        zWasPan = false;
      }, 60);
    }
    ZP.w.classList.remove('panning');
    ZP = null;
  }
}
function zBar(n, wr) {
  const bar = document.createElement('div'),
    mkb = (t, ti, f) => {
      const b = btn(t, f);
      b.title = ti;
      return b;
    };
  bar.className = 'row zbar';
  const lb = document.createElement('span');
  lb.className = 'hint';
  lb.style.minWidth = '44px';
  lb.style.textAlign = 'center';
  ZL[n] = lb;
  const hn = document.createElement('span');
  hn.className = 'hint';
  hn.textContent = 'Wheel zooms. Space + drag, or middle-drag, pans.';
  bar.append(
    mkb('\u2212', 'Zoom out (-)', () => zoomBy(n, 1 / 1.25)),
    lb,
    mkb('+', 'Zoom in (+)', () => zoomBy(n, 1.25)),
    mkb('Fit', 'Zoom to fit everything (F)', () => zoomFit(n)),
    mkb('Reset view', 'Back to the default view (0)', () => zoomReset(n)),
    hn
  );
  wr.parentNode.insertBefore(bar, wr);
}
Object.keys(ZS).forEach(n => {
  const wr = zWrap(n);
  wr.classList.add('zoomable');
  wr.addEventListener('wheel', e => zWheel(n, e), { passive: false });
  wr.addEventListener(
    'pointerdown',
    e => {
      if (zPanStart(e, wr, zIsBg(e.target))) {
        e.preventDefault();
        e.stopPropagation();
        if (wr.setPointerCapture) wr.setPointerCapture(e.pointerId);
      }
    },
    true
  );
  wr.addEventListener('pointermove', zPanMove);
  wr.addEventListener('pointerup', zPanEnd);
  wr.addEventListener('pointercancel', zPanEnd);
  wr.addEventListener('mousedown', e => {
    if (e.button === 1) e.preventDefault();
  });
  zBar(n, wr);
});
const zActive = () =>
  TAB === 'boss'
    ? cb()
      ? 'boss'
      : null
    : TAB === 'world'
      ? V === 'ov'
        ? 'world'
        : V === 'ar' && cur
          ? 'rooms'
          : V === 'rm' && rc
            ? 'room'
            : null
      : null;
function zKey(e) {
  if (e.ctrlKey || e.metaKey || e.altKey || /^(INPUT|TEXTAREA|SELECT)$/.test(String(e.target && e.target.tagName)))
    return;
  if (e.code === 'Space') {
    SPACE = true;
    document.querySelectorAll('.zoomable').forEach(w => w.classList.add('pan'));
    return;
  }
  const n = zActive();
  if (!n) return;
  if (e.key === '+' || e.key === '=') zoomBy(n, 1.25);
  else if (e.key === '-' || e.key === '_') zoomBy(n, 1 / 1.25);
  else if (e.key === '0') zoomReset(n);
  else if (e.key === 'f' || e.key === 'F') zoomFit(n);
}
const zSpaceOff = () => {
  SPACE = false;
  document.querySelectorAll('.zoomable').forEach(w => w.classList.remove('pan'));
};
addEventListener('keydown', zKey);
addEventListener('keyup', e => {
  if (e.code === 'Space') zSpaceOff();
});
addEventListener('blur', zSpaceOff);
addEventListener('resize', () => {
  clearTimeout(ZT);
  ZT = setTimeout(() => {
    try {
      const n = zActive();
      if (n && typeof VIEWS[ZS[n].key()] !== 'number') ZS[n].redraw();
    } catch (e) {}
  }, 120);
});
