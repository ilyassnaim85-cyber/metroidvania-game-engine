// Fades the start splash out once the page has loaded.
(function(){const sp=document.getElementById('splash');if(!sp)return;const t0=performance.now(),go=()=>{const w=Math.max(0,1700-(performance.now()-t0));setTimeout(()=>{sp.classList.add('out');setTimeout(()=>sp.remove(),700)},w)};document.readyState==='complete'?go():addEventListener('load',go)})()
