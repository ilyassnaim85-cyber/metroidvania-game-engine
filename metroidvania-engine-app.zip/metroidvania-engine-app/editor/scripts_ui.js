// Scripts tab (editor). A list of scripts on the left, a code box on the right, a console and a reference below.
// Needs the editor globals: S (the project), $, save(). Scripts are described in SCRIPTING.md.
(() => {
  const SC = MV.Script;
  let SEL = '';
  const css = document.createElement('style');
  css.textContent = `#scg{display:grid;grid-template-columns:240px minmax(0,1fr);gap:12px;align-items:start;padding:10px}
  #scg .scl{border:2px solid var(--bd);border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:6px;min-height:320px}
  #scg .scl .item{text-align:left;padding:5px 8px;font-size:13px;border-radius:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  #scg .scl .item.on{border-color:#ef9f27;font-weight:600}#scg .scl .item.off{opacity:.55}
  #scg .scc{border:1px solid var(--bd);border-radius:10px;padding:10px 12px;background:var(--cd);margin-bottom:10px}
  #scg .scc h3{margin:0 0 6px;font-size:14px}
  #scg .scr{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:8px}
  #scg textarea.code{width:100%;min-height:360px;box-sizing:border-box;font:13px/1.45 ui-monospace,Consolas,monospace;tab-size:2;white-space:pre;overflow:auto;resize:vertical}
  #scg .bad{color:#ff8a80}#scg .ok{color:#8fe3c0}#scg .warn{color:#ffd98a}
  #scg pre{margin:0;font:12px/1.45 ui-monospace,Consolas,monospace;white-space:pre-wrap;max-height:220px;overflow:auto}
  #scg table{border-collapse:collapse;font-size:12px}#scg td{padding:2px 10px 2px 0;vertical-align:top}#scg td:first-child{font-family:ui-monospace,Consolas,monospace;white-space:nowrap}
  @media(max-width:900px){#scg{grid-template-columns:1fr}}`;
  document.head.appendChild(css);
  const E = (t, c, x) => {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };
  const bt = (t, f, title) => {
    const b = E('button', '', t);
    b.onclick = f;
    if (title) b.title = title;
    return b;
  };
  const list = () => S.scripts || (S.scripts = []);
  const cur = () => list().find(s => s.id === SEL) || null;
  const commit = () => {
    S.scripts = SC.clean(S.scripts);
    save();
    scUI();
  };
  // a change that should not rebuild the page (typing): keep the text, save, refresh only the status line
  const quiet = () => {
    save();
  };

  const API_ROWS = [
    ['on("room", fn)', 'React to a game event. See the hook list.'],
    ['fn("name", fn)', 'Offer a function the Events tab can run ("Run a script function").'],
    ['game.say(text)', 'Show a message on screen.'],
    ['game.dialogue(text, who, done)', 'Open a dialogue box.'],
    ['game.flag(name, on?)', 'Read a flag, or set it.'],
    ['game.variable(name, value?)', 'Read or set a number variable.'],
    ['game.hp(v?)  heal(n)  hurt(n)', 'Player health.'],
    ['game.coins(v?)  addEnergy(n)  upgrade(stat, n)', 'Coins, energy, stat upgrades.'],
    ['game.give(id, n)  take(id, n)  itemCount(id)', 'Inventory.'],
    ['game.ability(id, on)  giveWeapon(id)', 'Abilities and weapons.'],
    ['game.player.x / .y', 'Where the player is (tiles).'],
    ['game.room()  goRoom(id, x, y)', 'Current room, or go to another.'],
    [
      'game.entities(type?)  entity(uid)  spawn(type, x, y, props)',
      'Look at, move (moveTo), damage or remove things in the room.'
    ],
    ['game.event(id)', 'Run an event from the Events tab.'],
    ['game.sound(id)  music(id)', 'Audio.'],
    ['game.camera', 'Camera calls (see CAMERA.md), including vcam(id, on), vcamSolo(id), freeze(sec), debug(true).'],
    ['game.shake(a)  save()  isDown(key)  random()', 'Small helpers.'],
    ['game.after(sec, fn)  every(sec, fn)  cancel(id)', 'Timers. { room: true } cancels them on room change.'],
    ['game.player.tune(name, v?)', 'Read or change a movement setting (jumpHeight, run, gravity ...) for this play.'],
    ['game.player.setVelocity(vx, vy)  invulnerable(s)', 'Push or protect the player.'],
    ['entity.get(name)  entity.set(name, v)', 'Read or change a setting of one enemy or boss.'],
    ['fn("brain", me => ...)', 'Enemy brain (Moves = Script), boss brain (AI = Script) or scripted move: runs every frame. See SCRIPTING.md.'],
    ['log(...)', 'Write to the console below.']
  ];

  function consoleBox() {
    const box = E('div', 'scc');
    box.appendChild(E('h3', '', 'Console'));
    const g = (window.MV && MV.Game && MV.Game.script) || null;
    const pre = E('pre');
    const fill = () => {
      const errs = g && g.errors ? g.errors() : [],
        logs = g && g.logs ? g.logs() : [];
      if (!g) pre.textContent = 'Press Play in the World tab, then come back to see messages and errors here.';
      else if (!errs.length && !logs.length) pre.textContent = '(nothing yet)';
      else
        pre.textContent = errs
          .map(e => '✖ [' + e.script + ' / ' + e.hook + '] ' + e.message)
          .concat(logs.map(l => '• [' + l.script + '] ' + l.text))
          .join('\n');
    };
    fill();
    const row = E('div', 'scr');
    row.append(
      bt('Refresh', fill),
      bt('Clear', () => {
        if (g && g.clear) g.clear();
        fill();
      })
    );
    box.append(row, pre);
    return box;
  }

  function reference() {
    const d = E('details', 'scc');
    d.appendChild(E('summary', '', 'Hooks and the game API'));
    const h = E('p', '', 'Hooks (use on("name", function)):');
    const t = E('table');
    Object.keys(SC.HOOKS).forEach(k => {
      const tr = E('tr');
      tr.append(E('td', '', k), E('td', '', SC.HOOKS[k]));
      t.appendChild(tr);
    });
    t.appendChild(E('tr')).appendChild(E('td', '', ' '));
    API_ROWS.forEach(r => {
      const tr = E('tr');
      tr.append(E('td', '', r[0]), E('td', '', r[1]));
      t.appendChild(tr);
    });
    d.append(h, t);
    return d;
  }

  function editor(s) {
    const box = E('div', 'scc');
    const top = E('div', 'scr');
    const name = E('input');
    name.type = 'text';
    name.value = s.name;
    name.onchange = () => {
      s.name = name.value.trim() || 'Script';
      commit();
    };
    const on = E('label');
    const cb = E('input');
    cb.type = 'checkbox';
    cb.checked = s.on;
    cb.onchange = () => {
      s.on = cb.checked;
      commit();
    };
    on.append(cb, ' Enabled');
    top.append(name, on);
    const status = E('div', 'ok');
    const ta = E('textarea', 'code');
    ta.spellcheck = false;
    ta.value = s.code;
    const check = () => {
      const m = SC.syntax(ta.value);
      status.className = m ? 'bad' : 'ok';
      status.textContent = m ? 'Syntax error: ' + m : 'Syntax OK';
    };
    ta.oninput = () => {
      s.code = ta.value;
      check();
      quiet();
    };
    ta.onchange = () => commit();
    ta.onkeydown = e => {
      if (e.key !== 'Tab') return;
      e.preventDefault();
      const a = ta.selectionStart,
        b = ta.selectionEnd;
      ta.value = ta.value.slice(0, a) + '  ' + ta.value.slice(b);
      ta.selectionStart = ta.selectionEnd = a + 2;
      ta.oninput();
    };
    check();
    box.append(top, ta, status);
    SC.validate({ scripts: [s], events: S.events || [] }).forEach(i =>
      box.appendChild(E('div', i.level === 'error' ? 'bad' : 'warn', i.text))
    );
    return box;
  }

  window.scUI = function () {
    const root = $('scg');
    if (!root) return;
    root.textContent = '';
    if (!cur()) SEL = list()[0] ? list()[0].id : '';
    const left = E('div', 'scl');
    const nb = bt('+ New script', () => {
      const s = SC.blank('Script ' + (list().length + 1));
      list().push(s);
      S.scripts = SC.clean(S.scripts);
      SEL = S.scripts[S.scripts.length - 1].id;
      save();
      scUI();
    });
    left.appendChild(nb);
    list().forEach(s => {
      const b = bt(s.name, () => {
        SEL = s.id;
        scUI();
      });
      b.className = 'item' + (s.id === SEL ? ' on' : '') + (s.on ? '' : ' off');
      left.appendChild(b);
    });
    const right = E('div');
    const s = cur();
    if (s) {
      const row = E('div', 'scr');
      row.append(
        bt('Duplicate', () => {
          list().push(Object.assign({}, s, { id: '', name: s.name + ' copy' }));
          S.scripts = SC.clean(S.scripts);
          SEL = S.scripts[S.scripts.length - 1].id;
          commit();
        }),
        bt('Delete', () => {
          if (!confirm('Delete script "' + s.name + '"?')) return;
          S.scripts = list().filter(x => x !== s);
          SEL = '';
          commit();
        }),
        bt('Insert template', () => {
          s.code = (s.code ? s.code + '\n' : '') + SC.TEMPLATE;
          commit();
        })
      );
      right.append(row, editor(s));
    } else
      right.appendChild(
        E('p', '', 'No scripts yet. Press "+ New script". A script is plain JavaScript that reacts to game events.')
      );
    right.append(consoleBox(), reference());
    root.append(left, right);
  };
})();
