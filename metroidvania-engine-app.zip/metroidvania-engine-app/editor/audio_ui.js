// Audio tab (editor): the sound library (imported files only), the sounds the player makes by itself, and the volumes.
// Needs the editor globals: S (the project), $, save(). The engine side is engine/audio.js.
(() => {
  const AU = MV.Audio;
  let SEL = '';
  const css = document.createElement('style');
  css.textContent = `#aug{display:grid;grid-template-columns:260px minmax(0,1fr);gap:12px;align-items:start;padding:10px}
  #aug .aul{border:2px solid var(--bd);border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:6px;min-height:320px}
  #aug .aul .item{text-align:left;padding:5px 8px;font-size:13px;border-radius:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  #aug .aul .item.on{border-color:#ef9f27;font-weight:600}
  #aug .auc{border:1px solid var(--bd);border-radius:10px;padding:10px 12px;background:var(--cd);margin-bottom:10px}
  #aug .auc h3{margin:0 0 6px;font-size:14px}#aug .sub{font-size:12px;color:var(--mu,#8fa3b3);margin:0 0 8px}
  #aug .aur{display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:5px 0}#aug .aur label{display:flex;gap:5px;align-items:center;font-size:13px}
  #aug .aur input[type=number]{width:80px}#aug .aur input[type=text]{width:170px}#aug .aur .sl{min-width:210px}
  @media(max-width:900px){#aug{grid-template-columns:1fr}}`;
  document.head.appendChild(css);
  const E = (t, c, x) => {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };
  const bt = (t, f, title, dis) => {
    const b = E('button', '', t);
    b.onclick = f;
    if (title) b.title = title;
    b.disabled = !!dis;
    return b;
  };
  const lib = () => S.sounds || (S.sounds = []);
  const cur = () => lib().find(s => s.id === SEL) || null;
  const commit = redraw => {
    if (redraw !== false) {
      S.sounds = AU.cleanList(S.sounds);
      S.sfx = AU.cleanSfx(S.sfx);
      S.vol = AU.cleanVol(S.vol);
    }
    save();
    if (redraw !== false) auUI();
  }; // (a change with no redraw keeps the same objects so the form keeps working on them)
  const kb = s => Math.round((s.src.length * 0.75) / 1024);
  const total = () => lib().reduce((n, s) => n + s.src.length * 0.75, 0);
  // a quick preview that does not touch the project: plays a data URL
  let prev = null;
  const preview = (src, vol) => {
    try {
      if (prev) prev.pause();
      prev = new Audio(src);
      prev.volume = Math.max(0, Math.min(1, vol === undefined ? 1 : vol));
      prev.play().catch(() => {});
    } catch (e) {}
  };
  const num = (label, val, min, max, step, on) => {
    const l = E('label');
    l.append(label + ' ');
    const i = E('input');
    i.type = 'number';
    i.min = min;
    i.max = max;
    i.step = step;
    i.value = val;
    i.onchange = () => on(i.value === '' ? null : +i.value);
    l.appendChild(i);
    return l;
  };
  const sel = (label, opts, val, on) => {
    const l = E('label');
    if (label) l.append(label + ' ');
    const s = E('select');
    opts.forEach(o => {
      const op = E('option', '', o[1]);
      op.value = o[0];
      s.appendChild(op);
    });
    if (val && !opts.some(o => o[0] === val)) {
      const op = E('option', '', '(missing) ' + val);
      op.value = val;
      s.appendChild(op);
    }
    s.value = val || '';
    s.onchange = () => on(s.value);
    l.appendChild(s);
    return l;
  };
  const uses = id => {
    const out = [];
    const chk = (t, o) => {
      if (o) out.push(t);
    };
    (S.areas || []).forEach(a =>
      (a.rooms || []).forEach(r => {
        if (r.music === id) out.push('Music of ' + r.n);
      })
    );
    Object.keys(S.sfx || {}).forEach(k => {
      if (S.sfx[k] === id) out.push('Player sound: ' + k);
    });
    (S.events || []).forEach(ev =>
      ev.actions.forEach(a => {
        if ((a.type === 'sound' || a.type === 'music') && a.sound === id) out.push('Event "' + ev.name + '"');
      })
    );
    [].concat(S.moves || [], S.attacks || []).forEach(m =>
      (m.effects || []).forEach(f => {
        if (f.do === 'sound' && f.snd === id) out.push('Effect of "' + (m.label || m.id) + '"');
      })
    );
    return [...new Set(out)];
  };
  const newId = base => {
    let n = 1;
    const ids = new Set(lib().map(s => s.id));
    base =
      (base || 'sound')
        .toLowerCase()
        .replace(/[^a-z0-9_-]/g, '')
        .slice(0, 18) || 'sound';
    let id = base;
    while (ids.has(id)) id = base + ++n;
    return id;
  };
  const add = (name, src, extra) => {
    if (lib().length >= 200) {
      alert('A project can hold up to 200 sounds.');
      return null;
    }
    const id = newId(name);
    lib().push(
      Object.assign(
        { id, name: name.slice(0, 40), src, vol: 1, rate: 1, vary: 0, loop: false, music: false, syn: null },
        extra || {}
      )
    );
    SEL = id;
    commit();
    return id;
  };
  const fileBtn = () => {
    const l = E('label');
    const i = E('input');
    i.type = 'file';
    i.accept = 'audio/*';
    i.multiple = true;
    i.style.display = 'none';
    const b = bt('Import sound files', () => i.click(), 'wav, mp3, ogg... up to 3 MB each');
    i.onchange = async () => {
      for (const f of i.files) {
        if (f.size > 3000000) {
          alert(f.name + ' is bigger than 3 MB. Use a shorter or smaller file.');
          continue;
        }
        const src = await new Promise(r => {
          const fr = new FileReader();
          fr.onload = () => r(String(fr.result));
          fr.readAsDataURL(f);
        });
        const fixed = src.replace(/^data:[^;]*;/, m =>
          /^data:audio\//.test(m)
            ? m
            : 'data:audio/' + (f.name.split('.').pop() || 'wav').toLowerCase().replace(/[^a-z0-9]/g, '') + ';'
        );
        add(f.name.replace(/\.[^.]+$/, ''), fixed);
      }
      i.value = '';
    };
    l.append(b, i);
    return l;
  };

  window.auUI = function () {
    const host = $('aug');
    if (!host) return;
    host.innerHTML = '';
    S.sfx = S.sfx || {};
    S.vol = S.vol || AU.cleanVol();
    const left = E('div', 'aul');
    left.appendChild(E('strong', '', 'Sounds (' + lib().length + ')'));
    lib().forEach(s => {
      const b = E('button', 'item' + (s.id === SEL ? ' on' : ''), (s.music ? '♫ ' : '') + s.name);
      b.onclick = () => {
        SEL = s.id;
        auUI();
      };
      left.appendChild(b);
    });
    left.appendChild(fileBtn());
    const tot = total() / 1048576;
    left.appendChild(E('div', 'sub', tot.toFixed(1) + ' MB of 24 MB used' + (tot > 18 ? ' - getting full' : '')));
    left.appendChild(E('div', 'sub', 'Sounds are saved inside the project file.'));
    host.appendChild(left);
    const right = E('div');
    host.appendChild(right);
    // volumes
    const cv = E('div', 'auc');
    cv.appendChild(E('h3', '', 'Volumes'));
    const rv = E('div', 'aur');
    [
      ['master', 'Everything'],
      ['music', 'Music'],
      ['sfx', 'Sounds']
    ].forEach(([k, l]) => {
      const lab = E('label');
      lab.append(l + ' ');
      const i = E('input');
      i.type = 'range';
      i.min = 0;
      i.max = 1;
      i.step = 0.05;
      i.value = S.vol[k];
      i.onchange = () => {
        S.vol[k] = +i.value;
        commit(false);
        AU.setVol(S.vol);
      };
      lab.appendChild(i);
      rv.appendChild(lab);
    });
    cv.appendChild(rv);
    right.appendChild(cv);
    // selected sound
    const s = cur();
    if (s) {
      const c = E('div', 'auc');
      c.appendChild(E('h3', '', 'Sound: ' + s.name));
      const r = E('div', 'aur');
      const nm = E('input');
      nm.type = 'text';
      nm.value = s.name;
      nm.maxLength = 40;
      nm.onchange = () => {
        s.name = nm.value.trim() || s.id;
        commit();
      };
      const nl = E('label');
      nl.append('Name ', nm);
      r.appendChild(nl);
      r.append(
        num('Volume', s.vol, 0, 1, 0.05, v => {
          s.vol = v;
          commit(false);
        }),
        num('Pitch (1 = normal)', s.rate, 0.25, 4, 0.05, v => {
          s.rate = v;
          commit(false);
        }),
        num('Random pitch (0 to .5)', s.vary, 0, 0.5, 0.05, v => {
          s.vary = v;
          commit(false);
        })
      );
      r.appendChild(
        sel(
          '',
          [
            ['no', 'A sound effect'],
            ['yes', 'Music (loops)']
          ],
          s.music ? 'yes' : 'no',
          v => {
            s.music = v === 'yes';
            commit();
          }
        )
      );
      c.appendChild(r);
      const r2 = E('div', 'aur');
      r2.append(
        bt('Play', () => preview(s.src, s.vol)),
        E('span', 'sub', 'id: ' + s.id + ' - ' + kb(s) + ' KB' + (s.src ? '' : ' - EMPTY (re-import it)'))
      );
      r2.appendChild(
        bt('Remove', () => {
          const u = uses(s.id);
          if (
            !confirm(
              u.length
                ? 'This sound is used by:\n' + u.join('\n') + '\n\nRemove it anyway? Those places will go quiet.'
                : 'Remove "' + s.name + '"?'
            )
          )
            return;
          S.sounds = lib().filter(q => q.id !== s.id);
          Object.keys(S.sfx).forEach(k => {
            if (S.sfx[k] === s.id) delete S.sfx[k];
          });
          SEL = '';
          commit();
        })
      );
      c.appendChild(r2);
      const u = uses(s.id);
      c.appendChild(E('div', 'sub', u.length ? 'Used by: ' + u.join(', ') : 'Nothing uses this sound yet.'));
      right.appendChild(c);
    }
    // the player's own sounds
    const cs = E('div', 'auc');
    cs.appendChild(E('h3', '', 'Sounds the player makes by itself'));
    cs.appendChild(
      E(
        'p',
        'sub',
        'Played by the game without any move: pick a sound for each. Sounds for moves and attacks are set in their Effects ("Play a sound"), and sounds in the story in the Events tab. Music for a room is set in the World editor under Level Settings.'
      )
    );
    const ops = [['', '(none)']].concat(lib().map(q => [q.id, q.name]));
    AU.SLOTS.forEach(([k, l]) => {
      const r = E('div', 'aur');
      const lb = E('span', 'sl', l);
      r.appendChild(lb);
      r.appendChild(
        sel('', ops, S.sfx[k] || '', v => {
          if (v) S.sfx[k] = v;
          else delete S.sfx[k];
          commit(false);
        })
      );
      r.appendChild(
        bt(
          'Play',
          () => {
            const q = lib().find(x => x.id === S.sfx[k]);
            if (q) preview(q.src, q.vol);
          },
          'Hear it',
          !S.sfx[k]
        )
      );
      cs.appendChild(r);
    });
    right.appendChild(cs);
    const ck = E('div', 'auc');
    ck.appendChild(E('h3', '', 'Checks'));
    const iss = AU.validate(S);
    if (!iss.length) ck.appendChild(E('div', 'sub', 'No problems found: every sound that something uses exists.'));
    iss.forEach(x => {
      const d = E('div', 'sub', (x.level === 'error' ? 'Problem: ' : 'Note: ') + x.text);
      d.style.color = x.level === 'error' ? '#ff8a80' : '#ffd98a';
      ck.appendChild(d);
    });
    right.appendChild(ck);
  };
})();
