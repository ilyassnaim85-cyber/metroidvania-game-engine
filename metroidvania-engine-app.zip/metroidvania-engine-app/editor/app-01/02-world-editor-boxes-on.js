// ---- world editor: boxes on the world map (areas) and on an area map (rooms) ----
// Click selects, double-click opens, drag moves, handles resize. Shift-click or Shift-drag selects several. Everything else (snap, align, copy,
// search, markers, notes, the world check and templates) is built on MV.World (engine/world.js).
const WK = 'mv_wopt',
  MW = MV.World,
  PINK = Object.assign(
    { note: { t: '✎', c: '#d3d1c7', n: 'Note' } },
    Object.fromEntries(MW.MANUAL.map(k => [k, MW.MARKS[k]]))
  );
const WO = Object.assign(
  { snap: true, step: 10, grid: false, guides: true, doors: true, auto: true, notes: true },
  (() => {
    try {
      return JSON.parse(localStorage.getItem(WK)) || {};
    } catch (e) {
      return {};
    }
  })()
);
WO.q = '';
WO.fl = [];
const wsave = () => {
  try {
    localStorage.setItem(
      WK,
      JSON.stringify({
        snap: WO.snap,
        step: WO.step,
        grid: WO.grid,
        guides: WO.guides,
        doors: WO.doors,
        auto: WO.auto,
        notes: WO.notes
      })
    );
  } catch (e) {}
};
let CLIPR = null,
  CLIPC = null,
  PASTEN = 0,
  ISS = [],
  ISS_MAP = new Map(),
  VPON = false,
  POPK = null,
  zWasPan = false;
// a deleted area or room must not leave transitions pointing at it
function dropTr(a, r) {
  S.areas.forEach(A2 =>
    (A2.rooms || []).forEach(v => {
      v.tr = (v.tr || []).filter(t => !(t.a === a && (r === undefined || t.r === r)));
    })
  );
}
const newRoom = (n, spot) => ({
  id: MW.newId('r', new Set(cur.rooms.map(r => r.id))),
  n: 'Room ' + (n + 1),
  s: '',
  x: spot.x,
  y: spot.y,
  w: 130,
  h: 44,
  note: '',
  grid: null,
  gw: 48,
  gh: 24,
  art: [],
  table: [],
  tr: [],
  ent: [],
  cam: null,
  mk: []
});
const WC = {
  sv: svg,
  vw: 680,
  vh: 700,
  md: $('mw'),
  pn: $('pw'),
  hn: $('hw'),
  ty: 1,
  zn: 'world',
  dim: () => S,
  zw: $('zw1'),
  zh: $('zh1'),
  mode: 'm',
  pend: null,
  sel: null,
  ms: new Set(),
  pinSel: null,
  addPin: null,
  list: () => S.areas,
  links: () => S.links,
  cls: i => i.c,
  open: i => openArea(i),
  minW: 60,
  minH: 36,
  del: i => {
    dropTr(i.id);
    S.areas = S.areas.filter(x => x !== i);
    S.links = S.links.filter(l => l[0] !== i.id && l[1] !== i.id);
  },
  add: () => {
    const a = {
        id: 'a' + rid(),
        n: 'New area',
        s: '',
        c: 't',
        x: 0,
        y: 0,
        w: 150,
        h: 50,
        rooms: null,
        links: [],
        mw: 680,
        mh: 520,
        note: ''
      },
      sp = MW.freeSpot(S.areas, a.w, a.h, S.mw, S.mh);
    a.x = sp.x;
    a.y = sp.y;
    S.areas.push(a);
    return a;
  }
};
const AC = {
  sv: sv2,
  vw: 680,
  vh: 520,
  md: $('ma'),
  pn: $('pa'),
  hn: $('ah'),
  zn: 'rooms',
  dim: () => cur,
  zw: $('zw2'),
  zh: $('zh2'),
  mode: 'm',
  pend: null,
  sel: null,
  ms: new Set(),
  pinSel: null,
  addPin: null,
  list: () => cur.rooms,
  links: () => cur.links,
  cls: () => cur.c,
  open: i => openRoom(i),
  minW: 60,
  minH: 36,
  del: i => {
    dropTr(cur.id, i.id);
    cur.rooms = cur.rooms.filter(x => x !== i);
    cur.links = cur.links.filter(l => l[0] !== i.id && l[1] !== i.id);
  },
  add: () => {
    const r = newRoom(cur.rooms.length, MW.freeSpot(cur.rooms, 130, 44, cur.mw, cur.mh));
    cur.rooms.push(r);
    return r;
  }
};
const MODES2 = [
    ['m', 'Select / move / open'],
    ['c', 'Link lines'],
    ['x', 'Remove lines'],
    ['d', 'Delete']
  ],
  HINT2 = {
    m: 'Click selects, double-click opens. Drag moves. Shift-click or Shift-drag the background selects several. Delete removes. Arrows nudge.',
    c: 'Click one box, then another, to draw or remove a sketch line between them (this is only a drawing aid; real doors are transitions).',
    x: 'Click a red line to remove that sketch line.',
    d: 'Click a box to delete it.'
  };
const wc = () => (V === 'ov' || !cur ? WC : AC);
const pinsOf = c => {
  const d = c.dim();
  return d.pins || (d.pins = []);
};
const selItems = c => c.list().filter(i => c.ms.has(i.id));
const wstep = () => (WO.snap ? WO.step : 1);
function wReset() {
  [WC, AC].forEach(c => {
    c.ms = new Set();
    c.sel = null;
    c.pend = null;
    c.pinSel = null;
    c.addPin = null;
  });
  ISS = [];
  VPON = false;
  const v = $('vp');
  if (v) v.hidden = true;
}
function upd(c) {
  c.hn.textContent = HINT2[c.mode];
  [...c.md.querySelectorAll('button[data-m]')].forEach(b => b.classList.toggle('on', b.dataset.m === c.mode));
}
function setMode(c, m) {
  c.mode = m;
  c.pend = null;
  c.addPin = null;
  upd(c);
  draw(c);
}
function tb(c) {
  MODES2.forEach(m => {
    const b = document.createElement('button');
    b.textContent = m[1];
    b.dataset.m = m[0];
    b.onclick = () => setMode(c, m[0]);
    c.md.appendChild(b);
  });
  const a = document.createElement('button');
  a.textContent = 'Add new';
  a.onclick = () => {
    const n = c.add();
    c.ms = new Set([n.id]);
    c.pinSel = null;
    save();
    draw(c);
    wReveal(c, n);
  };
  c.md.appendChild(a);
  upd(c);
}
// keep an item in view (scroll the map so it is visible)
function wReveal(c, i) {
  const wr = c.sv.closest('.cvw'),
    z = zUse(c.zn),
    x = i.x * z,
    y = i.y * z,
    w = i.w * z,
    h = i.h * z;
  if (x < wr.scrollLeft || x + w > wr.scrollLeft + wr.clientWidth)
    wr.scrollLeft = Math.max(0, x + w / 2 - wr.clientWidth / 2);
  if (y < wr.scrollTop || y + h > wr.scrollTop + wr.clientHeight)
    wr.scrollTop = Math.max(0, y + h / 2 - wr.clientHeight / 2);
}
