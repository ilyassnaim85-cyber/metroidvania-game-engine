// ---- lamps: a light with a shape and colour. Click one to select it, drag the middle to move it, drag its corners (or the edge handle of a circle) to reshape it ----
