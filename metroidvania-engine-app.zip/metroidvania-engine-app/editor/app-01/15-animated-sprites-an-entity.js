// ---- animated sprites (an entity that plays one of your Animations clips) and the free background layer (drag and resize it on the room) ----
const newProps = t => (t === 'animsprite' && S.anims[0] ? { clip: S.anims[0].id } : {});
function drawAnimSpr(c, e) {
  const cl = MV.Anim.find(S.anims, e.props.clip),
    w = Math.max(0.2, +e.props.width || 2);
  let ok = false;
  if (cl && cl.frames.length) {
    const sh = sheetOf(cl.frames[0].sheet);
    if (sh && sh.img.complete && sh.img.naturalWidth)
      ok = MV.Anim.draw(
        ctx,
        cl,
        e.props.when && e.props.when !== 'always'
          ? { frame: cl.frames[0] }
          : MV.Anim.sample(cl, performance.now() / 1000),
        sheetOf,
        (e.x + 0.5) * c,
        (e.y + 1) * c,
        { scale: (w * c) / sh.tw, flipX: e.props.flip === 'yes' }
      );
  }
  ctx.save();
  ctx.setLineDash([3, 3]);
  ctx.strokeStyle = ok ? 'rgba(224,163,255,.7)' : '#e0a3ff';
  ctx.strokeRect(e.x * c + 0.5, e.y * c + 0.5, c - 1, c - 1);
  ctx.restore();
  if (!ok) {
    ctx.fillStyle = '#e0a3ff';
    ctx.fillText(cl ? '...' : '?', (e.x + 0.5) * c, (e.y + 0.5) * c);
  }
  if (e.props.when && e.props.when !== 'always') {
    ctx.fillStyle = '#e0a3ff';
    ctx.fillText('on: ' + e.props.when, (e.x + 0.5) * c, (e.y - 0.2) * c);
  }
}
