// ---- keys ----
addEventListener('keydown', e => {
  if (
    TAB !== 'world' ||
    (V !== 'ov' && V !== 'ar') ||
    inText(e.target) ||
    /^(SELECT|TEXTAREA)$/.test(e.target.tagName) ||
    document.querySelector('dialog[open]')
  )
    return;
  const c = wc(),
    mod = e.ctrlKey || e.metaKey,
    k = e.key;
  if (mod && !e.altKey) {
    const l = k.toLowerCase();
    if (l === 'c') {
      wCopy(c);
      e.preventDefault();
    } else if (l === 'v') {
      wPaste(c);
      e.preventDefault();
    } else if (l === 'd') {
      wDup(c);
      e.preventDefault();
    } else if (l === 'a') {
      c.ms = new Set(c.list().map(i => i.id));
      c.pinSel = null;
      draw(c);
      e.preventDefault();
    }
    return;
  }
  if (e.altKey) return;
  if (k === 'Delete' || k === 'Backspace') {
    if (c.ms.size || c.pinSel) {
      wDelete(c);
      e.preventDefault();
    }
  } else if (k === 'Escape') {
    if (POP && !POP.hidden) {
      POP.hidden = true;
      return;
    }
    if (c.addPin) {
      c.addPin = null;
      wBarSync(c);
      wBarMsg('');
      return;
    }
    if (c.ms.size || c.pinSel || c.pend) {
      c.ms = new Set();
      c.pinSel = null;
      c.pend = null;
      draw(c);
    }
  } else if (k === 'Enter') {
    const s = selItems(c);
    if (s.length === 1) {
      c.open(s[0]);
      e.preventDefault();
    }
  } else if (k === 'F2') {
    const n = c.pn.querySelector('.pn');
    if (n) {
      n.focus();
      n.select();
      e.preventDefault();
    }
  } else if (k.startsWith('Arrow')) {
    const s = selItems(c);
    if (!s.length) return;
    const st = (wstep() > 1 ? wstep() : 1) * (e.shiftKey ? 5 : 1),
      dm = c.dim(),
      dx = k === 'ArrowLeft' ? -st : k === 'ArrowRight' ? st : 0,
      dy = k === 'ArrowUp' ? -st : k === 'ArrowDown' ? st : 0;
    const mx = Math.min(...s.map(i => i.x)),
      my = Math.min(...s.map(i => i.y)),
      Mx = Math.max(...s.map(i => i.x + i.w)),
      My = Math.max(...s.map(i => i.y + i.h)),
      ax = Math.max(-mx, Math.min(dm.mw - Mx, dx)),
      ay = Math.max(-my, Math.min(dm.mh - My, dy));
    s.forEach(i => {
      i.x += ax;
      i.y += ay;
    });
    place(c);
    wPanelSync(c);
    clearTimeout(c.nt);
    c.nt = setTimeout(() => {
      save();
      draw(c);
    }, 250);
    e.preventDefault();
  }
});

wBg(WC);
wBg(AC);
wBuildBar('ov', WC);
wBuildBar('ar', AC);
function show(v) {
  V = v;
  buildTune();
  ['ov', 'ar', 'rm', 'pl'].forEach(i => ($(i).hidden = i !== v));
  $('lsw').hidden = v !== 'ov';
  $('lsa').hidden = v !== 'ar';
  $('lsr').hidden = v !== 'rm';
  $('lsp2').hidden = v !== 'pl';
  bc();
  ui();
}
function ensureRooms(a) {
  if (!a.rooms) {
    a.rooms = [
      {
        id: 'r1',
        n: 'Entrance',
        s: '',
        x: 40,
        y: 40,
        w: 130,
        h: 44,
        note: '',
        grid: null,
        gw: 48,
        gh: 24,
        art: [],
        table: [],
        tr: [],
        ent: [],
        cam: null
      }
    ];
    a.links = [];
  }
}
function openArea(a) {
  if (cur !== a) {
    AC.ms = new Set();
    AC.pinSel = null;
  }
  cur = a;
  if (!a.mw) {
    a.mw = 680;
    a.mh = 520;
  }
  ensureRooms(a);
  $('at').textContent = a.n + ' - rooms';
  setMode(AC, 'm');
  show('ar');
  $('anc').value = a.note || '';
  rebase();
}
function blank(w, h) {
  const g = [],
    a = '.'.repeat(w),
    b = '#'.repeat(w);
  for (let y = 0; y < h; y++) g.push(y >= h - 2 ? b : a);
  return g;
}
function openRoom(r) {
  rc = r;
  BGE = -1;
  SEL = null;
  SELD = null;
  PASTE = false;
  MOVE = null;
  if (!r.art) r.art = [];
  if (!r.tr) r.tr = [];
  if (!r.ent) r.ent = [];
  if (!r.table) r.table = [];
  si = -1;
  $('lib').hidden = true;
  if (!r.grid) r.grid = blank(r.gw, r.gh);
  $('rn').value = r.n;
  $('nt').value = r.note;
  $('rw').value = r.gw;
  $('rh').value = r.gh;
  $('rstr').value = r.stream || '';
  show('rm');
  drawT();
  drawTable();
  trOpts($('trt'), $('trt').value);
  drawTr();
  drawEn();
  fillCamSel(r);
  $('cf').value = r.cam && typeof r.cam.follow === 'number' ? r.cam.follow : '';
  bgUI();
  lightUI();
  if (window.tartUI) tartUI();
  rebase();
}
// The room is drawn through a window: #cvs is as big as the whole room (so the scrollbars are right) and the canvas inside it only covers what you can see, so rooms up to 10000 x 10000 tiles stay fast.
let VO = { x: 0, y: 0 };
const rr = () => $('cvs').getBoundingClientRect();
