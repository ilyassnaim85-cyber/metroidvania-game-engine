// ---- the toolbar under the header ----
const WB = {};
function wBarMsg(t) {
  ['ov', 'ar'].forEach(v => {
    const m = WB[v] && WB[v].querySelector('.wmsg');
    if (m) {
      m.textContent = t;
      clearTimeout(m.t);
      m.t = setTimeout(() => (m.textContent = ''), 4000);
    }
  });
}
function wBarSync(c) {
  const b = WB[c === WC ? 'ov' : 'ar'];
  if (!b) return;
  const n = c.ms.size,
    set = (k, on) => {
      b.querySelectorAll(k).forEach(e => {
        e.disabled = !on;
      });
    };
  set('.b-dup', n > 0);
  set('.b-copy', n > 0);
  set('.b-paste', !!CLIPR && CLIPR.room === (c === AC));
  set('.b-del', n > 0 || !!c.pinSel);
  b.querySelectorAll('.wal-b,.b-al').forEach(e => (e.disabled = n < 2));
  set('.b-dist', n >= 3);
  const iss = b.querySelector('.b-val');
  if (iss && VPON) {
    const e = ISS.filter(i => i.sev === 'error').length,
      w = ISS.filter(i => i.sev === 'warn').length;
    iss.textContent = 'World check' + (e + w ? ' (' + (e + w) + ')' : ' ✓');
  }
  const pb = b.querySelector('.b-pin');
  if (pb) pb.classList.toggle('on', !!c.addPin);
}
function wBuildBar(v, c) {
  const view = $(v),
    head = view.querySelector('.eh'),
    bar = document.createElement('div');
  bar.className = 'eh wbar';
  WB[v] = bar;
  const grp = (l, items) => {
    const g = document.createElement('div');
    g.className = 'wg';
    if (l) {
      const s = document.createElement('span');
      s.className = 'wl';
      s.textContent = l;
      g.appendChild(s);
    }
    items.forEach(x => g.appendChild(x));
    bar.appendChild(g);
    return g;
  };
  const b = (t, f, ti, cls) => {
    const e = document.createElement('button');
    e.textContent = t;
    e.onclick = f;
    if (ti) e.title = ti;
    if (cls) e.className = cls;
    return e;
  };
  const chk = (t, k, ti, cb) => {
    const l = document.createElement('label'),
      i = document.createElement('input');
    i.type = 'checkbox';
    i.checked = !!WO[k];
    i.onchange = () => {
      WO[k] = i.checked;
      wsave();
      cb && cb();
      draw(c);
    };
    l.append(i, document.createTextNode(' ' + t));
    if (ti) l.title = ti;
    return l;
  };
  grp('Edit', [
    b('Duplicate', () => wDup(c), 'Duplicate the selection (Ctrl+D)', 'b-dup'),
    b('Copy', () => wCopy(c), 'Ctrl+C', 'b-copy'),
    b('Paste', () => wPaste(c), 'Ctrl+V', 'b-paste'),
    b('Delete', () => wDelete(c), 'Delete key', 'b-del')
  ]);
  const st = document.createElement('select');
  [5, 10, 20, 40].forEach(n => {
    const o = document.createElement('option');
    o.value = n;
    o.textContent = n + ' px';
    st.appendChild(o);
  });
  st.value = WO.step;
  st.onchange = () => {
    WO.step = +st.value;
    wsave();
    draw(c);
  };
  st.title = 'Grid step used by snapping';
  grp('Grid', [
    chk('Snap', 'snap', 'Snap moving and resizing to the grid'),
    st,
    chk('Show grid', 'grid', 'Draw the grid on the map'),
    chk('Align to others', 'guides', 'Snap to the edges and centers of other boxes while you drag')
  ]);
  const al = document.createElement('div');
  al.className = 'wal row';
  wAlignRow(c, al);
  al.querySelectorAll('button').forEach(x => {
    x.classList.add('b-al');
    if (/Distribute/.test(x.textContent)) x.classList.add('b-dist');
  });
  grp('Align', [...al.children]);
  const q = document.createElement('input');
  q.type = 'text';
  q.placeholder = c === AC ? 'Search rooms...' : 'Search areas...';
  q.className = 'wq';
  q.oninput = () => {
    WO.q = q.value;
    draw(c);
  };
  const fl = Object.keys(MW.FILTERS).map(k => {
    const e = b(
      MW.FILTERS[k],
      () => {
        const i = WO.fl.indexOf(k);
        i >= 0 ? WO.fl.splice(i, 1) : WO.fl.push(k);
        e.classList.toggle('on', WO.fl.includes(k));
        draw(c);
      },
      'Only light up ' + (c === AC ? 'rooms' : 'areas') + ' that have ' + MW.FILTERS[k].toLowerCase()
    );
    e.className = 'chipb';
    e.dataset.f = k;
    return e;
  });
  const clr = b(
    'Clear',
    () => {
      WO.q = '';
      WO.fl = [];
      q.value = '';
      fl.forEach(e => e.classList.remove('on'));
      draw(c);
    },
    'Clear the search and filters'
  );
  grp('Find', [q, ...fl, clr]);
  const pin = document.createElement('select');
  pin.className = 'b-pin';
  const o0 = document.createElement('option');
  o0.value = '';
  o0.textContent = 'Add pin...';
  pin.appendChild(o0);
  Object.keys(PINK).forEach(k => {
    const o = document.createElement('option');
    o.value = k;
    o.textContent = PINK[k].n;
    pin.appendChild(o);
  });
  pin.onchange = () => {
    c.addPin = pin.value || null;
    pin.value = '';
    wBarSync(c);
    wBarMsg(c.addPin ? 'Click the map to drop the ' + PINK[c.addPin].n.toLowerCase() + ' pin. Esc cancels.' : '');
  };
  pin.title = 'Drop a note or marker anywhere on the map';
  const items = [
    pin,
    chk('Notes', 'notes', 'Show pin notes next to the pins'),
    chk('Doors', 'doors', 'Draw arrows for transitions between boxes'),
    chk('Auto markers', 'auto', 'Show start, checkpoint, boss, locked-door and loot markers on rooms'),
    b('Legend', e => wPop('leg', e.target), 'What the markers and lines mean')
  ];
  if (c === AC)
    items.unshift(b('Templates', e => wPop('tpl', e.target), 'Start a room from a template, or keep a room as one'));
  grp('Map', items);
  grp('', [
    b(
      'World check',
      () => wValToggle(),
      'Look for broken transitions, rooms nobody can reach, rooms with no way in or out, and likely softlocks',
      'b-val'
    )
  ]);
  const m = document.createElement('span');
  m.className = 'wmsg hint';
  bar.appendChild(m);
  head.after(bar);
}
