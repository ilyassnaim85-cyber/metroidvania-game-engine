// ---- popovers: legend and templates ----
let POP = null;
function wPop(k, anchor) {
  const c = wc();
  if (!POP) {
    POP = document.createElement('div');
    POP.id = 'wpop';
    $('ed').appendChild(POP);
    document.addEventListener(
      'pointerdown',
      e => {
        if (POP.hidden) return;
        if (!POP.contains(e.target) && !(e.target.closest && e.target.closest('.wbar'))) POP.hidden = true;
      },
      true
    );
  }
  if (POPK === k && !POP.hidden && anchor) {
    POP.hidden = true;
    POPK = null;
    return;
  }
  POPK = k;
  POP.hidden = false;
  POP.innerHTML = '';
  const r = (anchor || WB[V] || $('ed')).getBoundingClientRect(),
    h = $('ed').getBoundingClientRect();
  POP.style.left = Math.max(8, Math.min(h.width - 330, r.left - h.left)) + 'px';
  POP.style.top = r.bottom - h.top + 4 + 'px';
  if (k === 'leg') {
    const hd = document.createElement('b');
    hd.textContent = 'Markers';
    POP.appendChild(hd);
    Object.keys(MW.MARKS).forEach(m => {
      const row = document.createElement('div'),
        dot = document.createElement('span'),
        nm = document.createElement('span');
      row.className = 'wcr';
      dot.className = 'dot';
      dot.style.background = MW.MARKS[m].c;
      dot.textContent = MW.MARKS[m].t;
      nm.textContent = MW.MARKS[m].n + (MW.MARKS[m].auto ? ' (automatic)' : '');
      row.append(dot, nm);
      POP.appendChild(row);
    });
    const lines = document.createElement('div');
    lines.innerHTML =
      '<b style="margin-top:8px;display:block">Lines</b><div class="wcr"><svg width="30" height="8"><line x1="0" y1="4" x2="30" y2="4" stroke="#22b8cf" stroke-width="2"/></svg><span>Doors both ways</span></div><div class="wcr"><svg width="30" height="8"><line x1="0" y1="4" x2="30" y2="4" stroke="#f0a030" stroke-width="2"/></svg><span>One-way door</span></div><div class="wcr"><svg width="30" height="8"><line x1="0" y1="4" x2="30" y2="4" stroke="currentColor" stroke-dasharray="5 4"/></svg><span>Sketch line (Link lines mode)</span></div><div class="wcr"><span class="dot" style="background:#e24b4a;color:#fff">!</span><span>A transition leads nowhere</span></div><div class="wcr"><span class="dot" style="background:#ef9f27"></span><span>Problem found by the world check</span></div>';
    POP.append(...lines.childNodes);
    return;
  }
  if (k === 'tpl') {
    const sel = selItems(AC),
      box = document.createElement('div');
    POP.appendChild(box);
    const add = t => {
      const room = newRoom(cur.rooms.length, MW.freeSpot(cur.rooms, 130, 44, cur.mw, cur.mh));
      const cnt = MW.fromTemplate(t);
      Object.assign(room, cnt);
      room.n = String(t.name).slice(0, 30);
      room.mk = [];
      cur.rooms.push(room);
      AC.ms = new Set([room.id]);
      AC.pinSel = null;
      save();
      draw(AC);
      wReveal(AC, room);
      POP.hidden = true;
    };
    const sec = title => {
      const h = document.createElement('b');
      h.textContent = title;
      h.style.display = 'block';
      h.style.margin = '6px 0 2px';
      box.appendChild(h);
    };
    const item = (t, del) => {
      const r = document.createElement('div');
      r.className = 'wcr';
      const s = document.createElement('span');
      s.innerHTML =
        '<b>' +
        esc(t.name) +
        '</b><br><small>' +
        esc(t.desc || (t.gw || '?') + '×' + (t.gh || '?') + ' tiles') +
        '</small>';
      r.appendChild(s);
      const a = document.createElement('button');
      a.textContent = 'Add room';
      a.onclick = () => add(t);
      r.appendChild(a);
      if (del) {
        const d = document.createElement('button');
        d.textContent = '×';
        d.title = 'Delete this template';
        d.onclick = () => {
          S.templates = S.templates.filter(x => x !== t);
          save();
          wPop('tpl');
        };
        r.appendChild(d);
      }
      box.appendChild(r);
    };
    sec('Built in');
    MW.TEMPLATES.forEach(t => item(t));
    sec('Yours');
    const mine = S.templates || [];
    if (!mine.length) {
      const p = document.createElement('p');
      p.className = 'hint';
      p.textContent = 'Nothing saved yet. Select a room, then use "Save as template" in its panel (or below).';
      p.style.margin = '2px 0';
      box.appendChild(p);
    }
    mine.forEach(t => item(t, true));
    const row = document.createElement('div');
    row.className = 'row';
    const ni = document.createElement('input');
    ni.type = 'text';
    ni.placeholder = 'Template name';
    ni.maxLength = 30;
    ni.style.width = '150px';
    if (sel.length === 1) ni.value = sel[0].n;
    const sb = document.createElement('button');
    sb.textContent = 'Save selected room';
    sb.disabled = sel.length !== 1;
    sb.onclick = () => {
      const t = MW.toTemplate(sel[0], ni.value || sel[0].n);
      (S.templates = S.templates || []).push(t);
      save();
      wPop('tpl');
    };
    row.append(ni, sb);
    box.appendChild(row);
  }
}
