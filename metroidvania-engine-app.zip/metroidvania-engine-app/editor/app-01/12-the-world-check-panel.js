// ---- the world check panel ----
function wValRun() {
  ISS = MW.validate(S);
  // events and sounds that point at something missing are listed here too (they are not in a room, so they cannot be clicked open)
  try {
    const sv = l => (l === 'error' ? 'error' : 'warn'),
      add = (code, pre, p) =>
        ISS.push({ sev: sv(p.level), code, msg: pre + p.text, a: null, r: null, name: '', area: '' });
    MV.Events.validate(S).forEach(p => {
      const ev = (S.events || []).find(e => e.id === p.ev);
      add('event', 'Event "' + (ev ? ev.name : p.ev) + '": ', p);
    });
    MV.Audio.validate(S).forEach(p => add('audio', 'Audio: ', p));
    MV.Script.validate(S).forEach(p => add('script', 'Scripts: ', p));
  } catch (e) {}
  const ord = { error: 0, warn: 1, info: 2 };
  ISS.sort((p, q) => ord[p.sev] - ord[q.sev]);
  ISS_MAP = MW.problemMap(ISS);
  return ISS;
}
function wBadges(c) {
  c.list().forEach(i => {
    const g = c.rf && c.rf[i.id];
    if (g) fit(g, i, c);
  });
}
function wValToggle() {
  VPON = !VPON;
  if (!VPON) {
    $('vp').hidden = true;
    ISS = [];
    draw(wc());
    return;
  }
  wValRun();
  wValDraw();
  draw(wc());
}
function wValDraw() {
  let p = $('vp');
  if (!p) {
    p = document.createElement('div');
    p.id = 'vp';
    $('ed').appendChild(p);
  }
  p.hidden = !VPON;
  if (!VPON) return;
  p.innerHTML = '';
  const e = ISS.filter(i => i.sev === 'error').length,
    w = ISS.filter(i => i.sev === 'warn').length,
    n = ISS.filter(i => i.sev === 'info').length,
    rooms = MW.everyRoom(S).length;
  const hd = document.createElement('div');
  hd.className = 'vph';
  hd.innerHTML =
    '<b>World check</b><span class="hint">' +
    rooms +
    ' room' +
    (rooms === 1 ? '' : 's') +
    ', ' +
    e +
    ' error' +
    (e === 1 ? '' : 's') +
    ', ' +
    w +
    ' warning' +
    (w === 1 ? '' : 's') +
    ', ' +
    n +
    ' note' +
    (n === 1 ? '' : 's') +
    '</span>';
  const rc2 = document.createElement('button');
  rc2.textContent = 'Check again';
  rc2.onclick = () => {
    wValRun();
    wValDraw();
    draw(wc());
  };
  const cl = document.createElement('button');
  cl.textContent = 'Close';
  cl.onclick = () => wValToggle();
  hd.append(rc2, cl);
  p.appendChild(hd);
  const body = document.createElement('div');
  body.className = 'vpb';
  p.appendChild(body);
  if (!ISS.length) {
    body.innerHTML =
      '<p class="vpok">No problems found. Every room can be reached from the start and has a way out.</p>';
  }
  const lab = { error: 'Error', warn: 'Warning', info: 'Note' };
  ISS.forEach(it => {
    const r = document.createElement('div');
    r.className = 'vpi ' + it.sev;
    const ic = document.createElement('span');
    ic.className = 'vpd';
    ic.textContent = it.sev === 'error' ? '●' : it.sev === 'warn' ? '▲' : '○';
    const t = document.createElement('div');
    t.className = 'vpt';
    t.innerHTML =
      '<div>' +
      it.msg.replace(/</g, '&lt;') +
      '</div><small>' +
      (it.r ? (it.area ? it.area + ' › ' : '') + it.name : 'World') +
      '</small>';
    r.append(ic, t);
    if (it.r) {
      r.title = 'Open this room';
      r.onclick = () => wGoRoom(it.a, it.r, it.x, it.y);
      const mp = document.createElement('button');
      mp.textContent = 'On map';
      mp.title = 'Show it on the rooms map';
      mp.onclick = ev => {
        ev.stopPropagation();
        wGoMap(it.a, it.r);
      };
      r.appendChild(mp);
    }
    body.appendChild(r);
  });
}
let VT = 0;
function wValLater() {
  if (!VPON) return;
  clearTimeout(VT);
  VT = setTimeout(() => {
    if (!VPON) return;
    wValRun();
    wValDraw();
    if (V === 'ov' || V === 'ar') {
      const c = wc();
      wBadges(c);
      wBarSync(c);
    }
  }, 900);
}
