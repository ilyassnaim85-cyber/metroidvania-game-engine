// ---- room layers: Tiles, Scenery (sprites and background) and Gameplay objects (entities, bosses, lamps, transitions). Each can be hidden or locked while you edit. ----
const LY = { tiles: { v: 1, l: 0 }, scenery: { v: 1, l: 0 }, objects: { v: 1, l: 0 } },
  LYN = { tiles: 'Tiles', scenery: 'Scenery', objects: 'Gameplay objects' };
try {
  const q = JSON.parse(localStorage.getItem('mv_layers') || 'null');
  if (q) for (const k in LY) if (q[k]) LY[k] = { v: q[k].v ? 1 : 0, l: q[k].l ? 1 : 0 };
} catch (e) {}
let lyUI = () => {},
  lyT = 0;
function lyToast(t) {
  let d = document.getElementById('lyt');
  if (!d) {
    d = document.createElement('div');
    d.id = 'lyt';
    document.body.appendChild(d);
  }
  d.textContent = t;
  d.classList.add('on');
  clearTimeout(lyT);
  lyT = setTimeout(() => d.classList.remove('on'), 2200);
}
function lyOk(k, say) {
  const q = LY[k];
  if (q.v && !q.l) return true;
  if (say !== false)
    lyToast('The ' + LYN[k] + ' layer is ' + (q.v ? 'locked' : 'hidden') + '. Open Layers to change that.');
  return false;
}
const lyOf = t => (t === 'S' || t === 'X' ? 'scenery' : t === 'N' || t === 'M' || t === 'O' || t === 'D' ? 'objects' : 'tiles');
function lyApply() {
  try {
    localStorage.setItem('mv_layers', JSON.stringify(LY));
  } catch (e) {}
  const off = !lyOk('objects', false);
  ['enl', 'trl'].forEach(i => {
    const b = document.getElementById(i);
    if (b) b.classList.toggle('lylock', off);
  });
  lyUI();
  if (rc && V === 'rm') drawT();
}
function drawT() {
  const z = zUse('room'),
    g = rc.grid,
    W = rc.gw,
    H = rc.gh,
    sp = $('cvs'),
    wr = zWrap('room'),
    fw = Math.max(60, Math.round(W * TS * z)),
    c = fw / W,
    fh = Math.max(40, Math.round(c * H));
  sp.style.width = fw + 'px';
  sp.style.height = fh + 'px';
  const vw = Math.max(60, Math.min(fw, wr.clientWidth - 16)),
    vh = Math.max(40, Math.min(fh, wr.clientHeight - 16));
  cv.width = vw;
  cv.height = vh;
  {
    const a = cv.getBoundingClientRect(),
      b = sp.getBoundingClientRect();
    VO.x = Math.max(0, Math.min(fw - vw, a.left - b.left));
    VO.y = Math.max(0, Math.min(fh - vh, a.top - b.top));
  }
  if (LY.scenery.v)
    MV.Background.draw(ctx, rc.bg || MV.Background.def(), bgImg, fw, fh, vw, vh, VO.x, VO.y, false, 1, {
      k: c,
      exact: true,
      time: performance.now() / 1000
    });
  else {
    ctx.fillStyle = '#0c1722';
    ctx.fillRect(0, 0, vw, vh);
  }
  ctx.translate(-VO.x, -VO.y);
  const x0 = Math.max(0, Math.floor(VO.x / c)),
    x1 = Math.min(W, Math.ceil((VO.x + vw) / c)),
    y0 = Math.max(0, Math.floor(VO.y / c)),
    y1 = Math.min(H, Math.ceil((VO.y + vh) / c));
  ctx.strokeStyle = 'rgba(255,255,255,.07)';
  ctx.lineWidth = 1;
  for (let x = x0; x <= x1; x++) {
    ctx.beginPath();
    ctx.moveTo(x * c, VO.y);
    ctx.lineTo(x * c, VO.y + vh);
    ctx.stroke();
  }
  for (let y = y0; y <= y1; y++) {
    ctx.beginPath();
    ctx.moveTo(VO.x, y * c);
    ctx.lineTo(VO.x + vw, y * c);
    ctx.stroke();
  }
  ctx.font = Math.max(8, Math.min(12, c - 3)) + 'px system-ui,sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const cov = new Set();
  (LY.scenery.v ? rc.art : []).forEach(a => {
    for (let yy = a.y; yy < a.y + a.h; yy++) for (let xx = a.x; xx < a.x + a.w; xx++) cov.add(yy * W + xx);
  }); // a sprite replaces the look of the tiles under it (collision stays)
  for (let y = y0; y < y1; y++)
    for (let x = x0; x < x1; x++) {
      const ch = g[y][x];
      if (ch === '.' || (ch === 'D' ? !LY.objects.v : !LY.tiles.v)) continue;
      if (cov.has(y * W + x) && MV.Tiles.GROUND.includes(ch)) continue;
      if (
        MV.Tiles.draw(ctx, ch, x * c, y * c, c, {
          edit: true,
          tx: x,
          ty: y,
          at: (a, b) => g[b] && g[b][a],
          skins: S.tileSkins,
          sheet: sheetOf,
          time: performance.now() / 1000
        })
      )
        continue;
      const t = T.find(k => k[0] === ch);
      if (!t || !t[2]) continue;
      ctx.fillStyle = t[2];
      ctx.fillRect(x * c, y * c, c, c);
      if ('eBD*^'.includes(ch)) {
        ctx.fillStyle = '#fff';
        ctx.fillText(ch, x * c + c / 2, y * c + c / 2 + 1);
      }
    }
  ctx.imageSmoothingEnabled = false;
  (LY.scenery.v ? rc.art : []).forEach(a => {
    const s = sheet(a.s);
    if (!s) return;
    const m = img(s);
    if (m.complete && m.naturalWidth)
      ctx.drawImage(m, a.c * s.tw, a.r * s.th, a.w * s.tw, a.h * s.th, a.x * c, a.y * c, a.w * c, a.h * c);
  });
  // the bounds of this room's virtual cameras (Player > Camera), dashed
  (S.vcams || []).forEach(v => {
    if (v.room !== rc.id || !v.bounds) return;
    ctx.save();
    ctx.setLineDash([8, 5]);
    ctx.lineWidth = 2;
    ctx.strokeStyle = ctx.fillStyle = '#ffd54f';
    ctx.strokeRect(v.bounds[0] * c, v.bounds[1] * c, (v.bounds[2] - v.bounds[0]) * c, (v.bounds[3] - v.bounds[1]) * c);
    ctx.font = '12px sans-serif';
    ctx.fillText('camera "' + v.name + '"', v.bounds[0] * c + 4, v.bounds[1] * c + 14);
    ctx.restore();
  });
  drawOv(c);
}
function drawOv(c) {
  drawLightPreview(c);
  if (LY.scenery.v) {
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    MV.Background.draw(
      ctx,
      rc.bg || MV.Background.def(),
      bgImg,
      rc.gw * c,
      rc.gh * c,
      cv.width,
      cv.height,
      VO.x,
      VO.y,
      true,
      0.35,
      { k: c, exact: true, time: performance.now() / 1000 }
    );
    ctx.restore();
  }
  const E = MV.data.entities;
  ctx.font = Math.max(8, Math.min(12, c - 3)) + 'px system-ui,sans-serif';
  rc.ent.forEach(e => {
    const d = E[e.type];
    if (!d || !LY.objects.v) return;
    if (lampT(e.type)) {
      drawLamp(c, e);
      return;
    }
    if (e.type === 'animsprite') {
      drawAnimSpr(c, e);
      return;
    }
    if (skinPrev(c, e, d)) return;
    if (e.type === 'light') {
      const lr = MV.Light.fromEntities([e])[0];
      ctx.save();
      ctx.setLineDash([4, 3]);
      ctx.strokeStyle = 'rgba(255,224,138,.8)';
      ctx.beginPath();
      ctx.arc(lr.x * c, lr.y * c, lr.r * c, 0, 7);
      ctx.stroke();
      ctx.restore();
    }
    if (e.type === 'boss') {
      const bd = S.bosses.find(q => q.id === e.props.boss);
      if (bd) {
        ctx.globalAlpha = 0.8;
        ctx.fillStyle = d.color;
        ctx.fillRect((e.x + 0.5 - bd.w / 2) * c, (e.y + 1 - bd.h) * c, bd.w * c, bd.h * c);
        ctx.globalAlpha = 1;
        ctx.fillStyle = '#fff';
        ctx.fillText('Boss', (e.x + 0.5) * c, (e.y + 1 - bd.h / 2) * c);
        return;
      }
    }
    if (e.type === 'dashpad') {
      const w = Math.max(0.5, +e.props.width || 1);
      ctx.globalAlpha = 0.95;
      ctx.fillStyle = d.color;
      ctx.fillRect(e.x * c, (e.y + 0.7) * c, w * c, c * 0.3);
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#12324a';
      ctx.fillText(
        { right: '>>', left: '<<', up: '^^', down: 'vv' }[e.props.dir || 'right'] + ' Dash',
        (e.x + w / 2) * c,
        (e.y + 0.5) * c
      );
      return;
    }
    if (e.type === 'rail') {
      const x0 = (e.x + 0.5) * c,
        y0 = (e.y + 0.5) * c,
        x1 = x0 + (+e.props.dx || 0) * c,
        y1 = y0 + (+e.props.dy || 0) * c;
      ctx.strokeStyle = d.color;
      ctx.lineWidth = 3;
      ctx.setLineDash(e.props.hang === 'stand on top' ? [] : [8, 5]);
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.lineTo(x1, y1);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = d.color;
      ctx.beginPath();
      ctx.arc(x0, y0, 6, 0, 7);
      ctx.fill();
      ctx.fillRect(x1 - 5, y1 - 5, 10, 10);
      ctx.fillStyle = '#fff';
      ctx.fillText('Rail', x0, y0 - 10);
      return;
    }
    if (e.type === 'cannon') {
      const cx0 = (e.x + 0.5) * c,
        cy0 = (e.y + 0.5) * c,
        a = ((+e.props.angle || 0) * Math.PI) / 180,
        r = c * 0.7;
      ctx.fillStyle = d.color;
      ctx.beginPath();
      ctx.arc(cx0, cy0, r, 0, 7);
      ctx.fill();
      ctx.strokeStyle = '#222';
      ctx.lineWidth = c * 0.45;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(cx0, cy0);
      ctx.lineTo(cx0 + Math.cos(a) * r * 1.4, cy0 - Math.sin(a) * r * 1.4);
      ctx.stroke();
      ctx.lineCap = 'butt';
      ctx.fillStyle = '#fff';
      ctx.fillText('Cannon', cx0, cy0 + r + 10);
      return;
    }
    if (e.type === 'mount') {
      const w = Math.max(0.5, +e.props.width || 1.6),
        h = Math.max(0.5, +e.props.height || 1.2);
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = d.color;
      ctx.fillRect((e.x + 0.5 - w / 2) * c, (e.y + 1 - h) * c, w * c, h * c);
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#fff';
      ctx.fillText(e.props.name || 'Mount', (e.x + 0.5) * c, (e.y + 1 - h / 2) * c);
      return;
    }
    if (e.type === 'spring') {
      const w = Math.max(0.5, +e.props.width || 1);
      ctx.globalAlpha = 0.95;
      ctx.fillStyle = d.color;
      ctx.fillRect(e.x * c, (e.y + 0.6) * c, w * c, c * 0.4);
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#12324a';
      ctx.fillText('Bounce ' + (+e.props.power || 6), (e.x + w / 2) * c, (e.y + 0.35) * c);
      return;
    }
    if (
      e.type === 'breakable' ||
      e.type === 'collapse' ||
      e.type === 'conveyor' ||
      e.type === 'secret' ||
      e.type === 'ladder' ||
      e.type === 'stickwall' ||
      e.type === 'current' ||
      e.type === 'lowgrav' ||
      e.type === 'msgzone' ||
      e.type === 'blink' ||
      e.type === 'icezone' ||
      e.type === 'mudzone' ||
      e.type === 'airpocket' ||
      e.type === 'camzone' ||
      e.type === 'evzone'
    ) {
      const w = e.type === 'ladder' ? 1 : Math.max(1, Math.round(+e.props.width || 1)),
        h = e.type === 'conveyor' ? 1 : Math.max(1, Math.round(+e.props.height || (e.type === 'ladder' ? 3 : 1)));
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = d.color;
      ctx.fillRect(e.x * c, (e.y + 1 - h) * c, w * c, h * c);
      ctx.globalAlpha = 0.35;
      ctx.strokeStyle = '#000';
      for (let i = 0; i < w; i++)
        for (let j = 0; j < h; j++) ctx.strokeRect((e.x + i) * c + 0.5, (e.y + 1 - h + j) * c + 0.5, c - 1, c - 1);
      ctx.globalAlpha = 1;
      ctx.fillStyle = '#fff';
      ctx.fillText(
        e.type === 'collapse'
          ? 'Collapse'
          : e.type === 'conveyor'
            ? (e.props.speed < 0 ? '<<' : '>>') + ' Belt'
            : e.type === 'secret'
              ? 'Secret'
              : e.type === 'ladder'
                ? 'Ladder'
                : e.type === 'stickwall'
                  ? e.props.dir === 'down'
                    ? 'v Down wall'
                    : '^ Up wall'
                  : e.type === 'current'
                    ? 'Current ' + { right: '>>', left: '<<', up: '^^', down: 'vv' }[e.props.dir || 'right']
                    : e.type === 'lowgrav'
                      ? 'Low gravity'
                      : e.type === 'msgzone'
                        ? 'Message'
                        : e.type === 'icezone'
                          ? 'Ice'
                          : e.type === 'mudzone'
                            ? 'Mud'
                            : e.type === 'blink'
                              ? 'Blink'
                              : e.type === 'airpocket'
                                ? 'Air pocket'
                                : e.type === 'camzone'
                                  ? 'Camera: ' +
                                    camName(e.props.profile) +
                                    (e.props.bounds && e.props.bounds !== 'keep'
                                      ? ' (' +
                                        (e.props.bounds === 'break room limits' ? 'breaks limits' : 'box limit') +
                                        ')'
                                      : '')
                                  : 'Breakable',
        (e.x + w / 2) * c,
        (e.y + 1 - h / 2) * c
      );
      return;
    }
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = d.color;
    ctx.fillRect(e.x * c + c * 0.1, e.y * c + c * 0.1, c * 0.8, c * 0.8);
    ctx.globalAlpha = 1;
    ctx.fillStyle = '#12324a';
    ctx.fillText(d.label[0], e.x * c + c / 2, e.y * c + c / 2 + 1);
  });
  if ($('cdb').checked) {
    ctx.strokeStyle = '#ef9f27';
    ctx.lineWidth = 1.5;
    const dx0 = Math.max(0, Math.floor(VO.x / c)),
      dx1 = Math.min(rc.gw, Math.ceil((VO.x + cv.width) / c)),
      dy0 = Math.max(0, Math.floor(VO.y / c)),
      dy1 = Math.min(rc.gh, Math.ceil((VO.y + cv.height) / c));
    for (let y = dy0; y < dy1; y++)
      for (let x = dx0; x < dx1; x++) {
        const ch = rc.grid[y][x];
        if (MV.Tiles.BLOCKS.includes(ch) || ch === 'g') ctx.strokeRect(x * c, y * c, c, c);
        else if (ch === '=') ctx.strokeRect(x * c, y * c, c, c / 2);
        else if (MV.Light.PROFILES[ch]) {
          const pf = MV.Light.PROFILES[ch];
          ctx.beginPath();
          ctx.moveTo(x * c, (y + pf[0]) * c);
          ctx.lineTo((x + 1) * c, (y + pf[1]) * c);
          ctx.stroke();
        }
      }
  }
  bgOverlay(c);
  selOverlay(c);
  sprOverlay(c);
}
