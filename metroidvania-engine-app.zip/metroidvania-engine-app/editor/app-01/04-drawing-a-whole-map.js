// ---- drawing a whole map ----
function edgePt(i, tx, ty) {
  const cx = i.x + i.w / 2,
    cy = i.y + i.h / 2,
    dx = tx - cx,
    dy = ty - cy;
  if (!dx && !dy) return [cx, cy];
  const sx = dx ? i.w / 2 / Math.abs(dx) : 1e9,
    sy = dy ? i.h / 2 / Math.abs(dy) : 1e9,
    s = Math.min(sx, sy);
  return [cx + dx * s, cy + dy * s];
}
function arrow(g, x, y, ax, ay, col) {
  const a = Math.atan2(ay - y, ax - x),
    L = 9;
  el(
    'polygon',
    {
      points:
        x +
        ',' +
        y +
        ' ' +
        (x - L * Math.cos(a - 0.4)) +
        ',' +
        (y - L * Math.sin(a - 0.4)) +
        ' ' +
        (x - L * Math.cos(a + 0.4)) +
        ',' +
        (y - L * Math.sin(a + 0.4)),
      fill: col
    },
    g
  );
}
// door arrows: one line per pair of boxes, with arrowheads where a player can walk
function doorLines(c, g) {
  g.innerHTML = '';
  if (!WO.doors) return;
  const L = c.list(),
    f = id => L.find(r => r.id === id),
    pairs = new Map(),
    stubs = [],
    ids = new Set(L.map(r => r.id)),
    hi = c.ms.size === 1 ? [...c.ms][0] : null;
  const T = MW.transitions(S);
  T.forEach(t => {
    const fa = c === AC ? t.from.a === cur.id : true,
      fid = c === AC ? t.from.r : t.from.a,
      tid = c === AC ? (t.to.a === cur.id ? t.to.r : null) : t.to.a;
    if (!fa) return;
    if (!t.ok) {
      stubs.push({ id: fid, bad: 1 });
      return;
    }
    if (tid === null) {
      stubs.push({ id: fid, to: (S.areas.find(a => a.id === t.to.a) || {}).n || 'other area' });
      return;
    }
    if (!ids.has(fid) || !ids.has(tid) || fid === tid) return;
    const k = fid < tid ? fid + '|' + tid : tid + '|' + fid,
      p = pairs.get(k) || { a: fid < tid ? fid : tid, b: fid < tid ? tid : fid, ab: 0, ba: 0 };
    if (fid === p.a) p.ab++;
    else p.ba++;
    pairs.set(k, p);
  });
  pairs.forEach(p => {
    const A = f(p.a),
      B = f(p.b);
    if (!A || !B) return;
    const two = p.ab && p.ba,
      on = hi && (hi === p.a || hi === p.b),
      col = two ? '#22b8cf' : '#f0a030',
      [x1, y1] = edgePt(A, B.x + B.w / 2, B.y + B.h / 2),
      [x2, y2] = edgePt(B, A.x + A.w / 2, A.y + A.h / 2);
    el(
      'line',
      {
        x1,
        y1,
        x2,
        y2,
        stroke: col,
        'stroke-width': on ? 3.5 : 2,
        'stroke-opacity': on ? 1 : 0.8,
        'stroke-linecap': 'round'
      },
      g
    );
    if (p.ab || two) arrow(g, x2, y2, x1, y1, col);
    if (p.ba || two) arrow(g, x1, y1, x2, y2, col);
    if (p.ab + p.ba > 1) {
      const tx = el(
        'text',
        {
          x: (x1 + x2) / 2,
          y: (y1 + y2) / 2 - 4,
          'text-anchor': 'middle',
          'font-size': 10,
          fill: col,
          'font-weight': 700
        },
        g
      );
      tx.textContent = '×' + (p.ab + p.ba);
    }
  });
  const seen = new Set();
  stubs.forEach(s => {
    const i = f(s.id);
    if (!i) return;
    const key = s.id + (s.bad ? '!' : s.to),
      n = seen.has(key);
    seen.add(key);
    if (n) return;
    if (s.bad) {
      el(
        'circle',
        { cx: i.x + i.w - 4, cy: i.y + i.h - 4, r: 8, fill: '#e24b4a', stroke: '#fff', 'stroke-width': 1.5 },
        g
      );
      const tx = el(
        'text',
        {
          x: i.x + i.w - 4,
          y: i.y + i.h - 3,
          'text-anchor': 'middle',
          'dominant-baseline': 'central',
          'font-size': 11,
          'font-weight': 700,
          fill: '#fff'
        },
        g
      );
      tx.textContent = '!';
      el('title', {}, g).textContent = 'A transition here leads to a room that does not exist';
    } else {
      const tx = el('text', { x: i.x + i.w + 3, y: i.y + i.h + 10, 'font-size': 10, fill: '#22b8cf' }, g);
      tx.textContent = '→ ' + s.to;
    }
  });
}
function draw(c) {
  const dm = c.dim();
  c.sv.setAttribute('viewBox', '0 0 ' + dm.mw + ' ' + dm.mh);
  const zz = zUse(c.zn);
  c.sv.style.width = Math.round(dm.mw * zz) + 'px';
  c.sv.style.height = Math.round(dm.mh * zz) + 'px';
  c.sv.style.minWidth = '0';
  c.zw.value = dm.mw;
  c.zh.value = dm.mh;
  c.sv.innerHTML = '';
  ISS_MAP = VPON ? MW.problemMap(ISS) : new Map();
  c.rf = {};
  c.ln = [];
  c.hl = [];
  const bg = el('rect', { class: 'bgr', x: 0, y: 0, width: dm.mw, height: dm.mh, fill: 'transparent' }, c.sv);
  if (WO.grid) {
    const st = Math.max(WO.step, 5),
      gr = el('g', { class: 'wgrid' }, c.sv);
    for (let x = st; x < dm.mw; x += st)
      el('line', { x1: x, y1: 0, x2: x, y2: dm.mh, 'stroke-opacity': x % (st * 5) === 0 ? 0.22 : 0.09 }, gr);
    for (let y = st; y < dm.mh; y += st)
      el('line', { x1: 0, y1: y, x2: dm.mw, y2: y, 'stroke-opacity': y % (st * 5) === 0 ? 0.22 : 0.09 }, gr);
  }
  const lg = el('g', {}, c.sv);
  const near = c.ms.size === 1 ? new Set() : null;
  c.links().forEach((l, k) => {
    const x = c.mode === 'x',
      on = c.ms.has(l[0]) || c.ms.has(l[1]);
    c.ln.push(
      el(
        'line',
        x
          ? { stroke: '#e24b4a', 'stroke-opacity': '.85', 'stroke-width': '3' }
          : {
              stroke: 'currentColor',
              'stroke-opacity': on ? 0.8 : 0.4,
              'stroke-width': on ? 2.5 : 1.5,
              'stroke-dasharray': '5 4'
            },
        lg
      )
    );
    if (x) {
      const h = el('line', { stroke: 'transparent', 'stroke-width': '18', style: 'cursor:pointer' }, lg);
      h.onclick = () => {
        c.links().splice(k, 1);
        save();
        draw(c);
      };
      c.hl.push(h);
    }
  });
  c.dl = el('g', { class: 'wdoors', 'pointer-events': 'none' }, c.sv);
  // connected boxes of the single selected room light up
  if (c === AC && c.ms.size === 1) {
    const id = [...c.ms][0],
      nb = MW.neighbours(S, cur.id, id);
    nb.out.forEach(o => {
      if (o.a === cur.id) near.add(o.r);
    });
    nb.inn.forEach(o => {
      if (o.a === cur.id) near.add(o.r);
    });
  }
  c.list().forEach(i => {
    const g = box(c, i);
    c.rf[i.id] = g;
    wEvents(c, g, i);
    if (near && near.has(i.id)) g.classList.add('nb');
  });
  const hg = el('g', { class: 'whd' }, c.sv),
    pg = el('g', { class: 'wpins' }, c.sv);
  c.hd = hg;
  c.pg = pg;
  c.ov = el('g', { class: 'wov', 'pointer-events': 'none' }, c.sv);
  const h = c.pend;
  if (h && c.rf[h]) c.rf[h].firstChild.style.strokeWidth = 3;
  wPinsDraw(c);
  place(c);
  panel(c);
  wBarSync(c);
}
function place(c) {
  const f = id => c.list().find(r => r.id === id);
  c.list().forEach(r => c.rf[r.id] && c.rf[r.id].setAttribute('transform', 'translate(' + r.x + ' ' + r.y + ')'));
  c.links().forEach((l, i) => {
    const p = f(l[0]),
      q = f(l[1]);
    if (!p || !q) return;
    [c.ln[i], c.hl[i]].forEach(n => {
      if (!n) return;
      n.setAttribute('x1', p.x + p.w / 2);
      n.setAttribute('y1', p.y + p.h / 2);
      n.setAttribute('x2', q.x + q.w / 2);
      n.setAttribute('y2', q.y + q.h / 2);
    });
  });
  doorLines(c, c.dl);
  c.rz ? wHandlePos(c) : wHandles(c);
}
// selection handles (single box) and size label
const HDL = [
    ['nw', 0, 0],
    ['n', 0.5, 0],
    ['ne', 1, 0],
    ['e', 1, 0.5],
    ['se', 1, 1],
    ['s', 0.5, 1],
    ['sw', 0, 1],
    ['w', 0, 0.5]
  ],
  HCUR = {
    nw: 'nwse-resize',
    se: 'nwse-resize',
    ne: 'nesw-resize',
    sw: 'nesw-resize',
    n: 'ns-resize',
    s: 'ns-resize',
    e: 'ew-resize',
    w: 'ew-resize'
  };
function wHandlePos(c) {
  const s = selItems(c);
  if (s.length !== 1 || !c.hh) return;
  const i = s[0],
    z = zUse(c.zn),
    hs = Math.max(6, 9 / Math.max(z, 0.5));
  c.hh.forEach(h => {
    h.e.setAttribute('x', i.x + i.w * h.fx - hs / 2);
    h.e.setAttribute('y', i.y + i.h * h.fy - hs / 2);
  });
  if (c.hl2) {
    c.hl2.setAttribute('x', i.x + i.w / 2);
    c.hl2.setAttribute('y', i.y - 6);
    c.hl2.textContent = Math.round(i.w) + ' \u00D7 ' + Math.round(i.h);
  }
}
function wHandles(c) {
  const g = c.hd;
  if (!g) return;
  g.innerHTML = '';
  c.hh = [];
  c.hl2 = null;
  const s = selItems(c);
  if (c.mode !== 'm' || !s.length) return;
  const bx = {
    x: Math.min(...s.map(i => i.x)),
    y: Math.min(...s.map(i => i.y)),
    x2: Math.max(...s.map(i => i.x + i.w)),
    y2: Math.max(...s.map(i => i.y + i.h))
  };
  if (s.length > 1) {
    el(
      'rect',
      {
        x: bx.x - 3,
        y: bx.y - 3,
        width: bx.x2 - bx.x + 6,
        height: bx.y2 - bx.y + 6,
        fill: 'none',
        stroke: '#ef9f27',
        'stroke-dasharray': '5 3',
        'stroke-width': 1.5,
        'pointer-events': 'none',
        rx: 10
      },
      g
    );
    return;
  }
  const i = s[0],
    z = zUse(c.zn),
    hs = Math.max(6, 9 / Math.max(z, 0.5));
  const tx = el(
    'text',
    {
      x: i.x + i.w / 2,
      y: i.y - 6,
      'text-anchor': 'middle',
      'font-size': 11,
      fill: '#ef9f27',
      'font-weight': 600,
      'pointer-events': 'none'
    },
    g
  );
  tx.textContent = Math.round(i.w) + ' × ' + Math.round(i.h);
  c.hl2 = tx;
  HDL.forEach(([k, fx, fy]) => {
    const r = el(
      'rect',
      {
        x: i.x + i.w * fx - hs / 2,
        y: i.y + i.h * fy - hs / 2,
        width: hs,
        height: hs,
        fill: '#ef9f27',
        stroke: '#1f1e1d',
        'stroke-width': 1,
        rx: 1.5,
        style: 'cursor:' + HCUR[k]
      },
      g
    );
    c.hh.push({ fx, fy, e: r });
    r.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      e.stopPropagation();
      r.setPointerCapture(e.pointerId);
      c.rz = { k, i, o: { x: i.x, y: i.y, w: i.w, h: i.h }, s: pt(c.sv, e), m: false };
    });
    r.addEventListener('pointermove', e => {
      const d = c.rz;
      if (!d) return;
      d.m = true;
      const p = pt(c.sv, e),
        st = wstep(),
        dm = c.dim();
      let { x, y, w, h } = d.o;
      const dx = p.x - d.s.x,
        dy = p.y - d.s.y,
        mw = c.minW,
        mh = c.minH;
      if (d.k.includes('e')) w = Math.max(mw, MW.snapTo(d.o.w + dx, st));
      if (d.k.includes('s')) h = Math.max(mh, MW.snapTo(d.o.h + dy, st));
      if (d.k.includes('w')) {
        const nx = Math.min(d.o.x + d.o.w - mw, MW.snapTo(d.o.x + dx, st));
        x = Math.max(0, nx);
        w = d.o.x + d.o.w - x;
      }
      if (d.k.includes('n')) {
        const ny = Math.min(d.o.y + d.o.h - mh, MW.snapTo(d.o.y + dy, st));
        y = Math.max(0, ny);
        h = d.o.y + d.o.h - y;
      }
      w = Math.min(w, dm.mw - x);
      h = Math.min(h, dm.mh - y);
      i.x = x;
      i.y = y;
      i.w = w;
      i.h = h;
      fit(c.rf[i.id], i, c);
      place(c);
      wPanelSync(c);
    });
    r.addEventListener('pointerup', () => {
      const d = c.rz;
      c.rz = null;
      if (d && d.m) {
        save();
        panel(c);
      }
    });
  });
}
