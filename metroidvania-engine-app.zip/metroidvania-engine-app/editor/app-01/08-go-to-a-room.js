// ---- go to a room (or a tile in it) from anywhere ----
function wGoRoom(a, r, x, y) {
  const A = S.areas.find(q => q.id === a),
    R = A && A.rooms && A.rooms.find(q => q.id === r);
  if (!R) return false;
  leavePlay();
  if (TAB !== 'world') tab('world');
  openArea(A);
  openRoom(R);
  if (x != null)
    setTimeout(() => {
      try {
        window.mvGoTo && window.mvGoTo(x, y);
      } catch (e) {}
    }, 80);
  return true;
}
function wGoTile(a, r, x, y) {
  return wGoRoom(a, r, x, y);
}
function wGoMap(a, r) {
  const A = S.areas.find(q => q.id === a),
    R = A && A.rooms && A.rooms.find(q => q.id === r);
  if (!R) return;
  leavePlay();
  if (TAB !== 'world') tab('world');
  if (V !== 'ar' || cur !== A) {
    cur = A;
    openArea(A);
  }
  AC.ms = new Set([r]);
  AC.pinSel = null;
  draw(AC);
  wReveal(AC, R);
}
