// ---- the selection panel (left side) ----
function wPanelSync(c) {
  const p = c.pn,
    s = selItems(c);
  if (s.length !== 1) return;
  const i = s[0],
    q = k => p.querySelector(k);
  ['.pw', '.ph', '.px', '.py'].forEach((k, n) => {
    const e = q(k);
    if (e && document.activeElement !== e) e.value = Math.round([i.w, i.h, i.x, i.y][n]);
  });
}
// a labelled number box (built with the DOM: nothing here is ever parsed as HTML)
function wNum(lab, cls, min, max, step) {
  const l = document.createElement('label'),
    i = document.createElement('input');
  i.type = 'number';
  i.className = cls;
  i.min = min;
  i.max = max;
  i.step = step;
  l.append(lab + ' ', i);
  return l;
}
function panel(c) {
  const p = c.pn;
  p.innerHTML = '';
  const room = c === AC,
    s = selItems(c),
    word = room ? 'room' : 'area';
  const hint = document.createElement('p');
  hint.style.margin = '0';
  const pin = c.pinSel && pinsOf(c).find(q => q.id === c.pinSel);
  if (pin) {
    p.innerHTML =
      '<div class="wpn"><b>Pin</b><select class="pin-k"></select><input type="text" class="pin-t" maxlength="200" placeholder="Note text (shows next to the pin)"><div class="row"><button class="pin-d">Delete pin</button></div></div>';
    const k = p.querySelector('.pin-k');
    Object.keys(PINK).forEach(x => {
      const o = document.createElement('option');
      o.value = x;
      o.textContent = PINK[x].n;
      k.appendChild(o);
    });
    k.value = pin.k;
    k.onchange = () => {
      pin.k = k.value;
      save();
      wPinsDraw(c);
    };
    const t = p.querySelector('.pin-t');
    t.value = pin.t || '';
    t.oninput = () => {
      pin.t = t.value;
      save();
      wPinsDraw(c);
    };
    p.querySelector('.pin-d').onclick = () => {
      const L = pinsOf(c);
      L.splice(L.indexOf(pin), 1);
      c.pinSel = null;
      save();
      draw(c);
    };
    return;
  }
  if (!s.length) {
    hint.textContent =
      'Nothing selected. Click a ' +
      word +
      ' to select it, or Shift-drag the background to select several.' +
      (room ? ' Select two rooms to connect them with doors.' : '');
    p.appendChild(hint);
    return;
  }
  const w = document.createElement('div');
  w.className = 'wpn';
  p.appendChild(w);
  if (s.length > 1) {
    w.innerHTML =
      '<b>' +
      esc(s.length) +
      ' ' +
      esc(word) +
      's selected</b><div class="row wacts"></div><div class="row wal"></div>';
    wAct(c, w.querySelector('.wacts'), s);
    wAlignRow(c, w.querySelector('.wal'));
    return;
  }
  const i = s[0];
  w.innerHTML =
    '<input type="text" maxlength="30" class="pn" aria-label="Name"><div class="row r1"></div><div class="row r2"></div><textarea class="pc" rows="3" placeholder="Comment (shows when you hover the box)" style="width:100%"></textarea><select class="pt" aria-label="Type"><option value="t">Boss area</option><option value="g">Village or passage</option><option value="p">Endgame</option></select><div class="wmk"></div><div class="row wacts"></div><div class="wcn"></div>';
  w.querySelector('.r1').append(wNum('MW', 'pw', 40, 600, 10), wNum('H', 'ph', 28, 400, 10));
  w.querySelector('.r2').append(wNum('X', 'px', 0, 3000, 10), wNum('Y', 'py', 0, 3000, 10));
  if (!c.ty) w.querySelector('.pt').remove();
  if (!room) w.querySelector('.wmk').remove();
  const q = k => w.querySelector(k),
    g = c.rf[i.id],
    u = () => {
      fit(g, i, c);
      place(c);
      save();
    };
  q('.pn').value = i.n;
  q('.pc').value = i.note || '';
  wPanelSync(c);
  q('.pn').oninput = e => {
    i.n = e.target.value;
    u();
  };
  q('.pc').oninput = e => {
    i.note = e.target.value.slice(0, 2000);
    u();
  };
  const num = (k, fn) => {
    q(k).onchange = e => {
      const v = +e.target.value;
      if (isFinite(v)) {
        fn(v);
        const dm = c.dim();
        i.w = Math.max(c.minW, Math.min(dm.mw, i.w));
        i.h = Math.max(c.minH, Math.min(dm.mh, i.h));
        i.x = Math.max(0, Math.min(dm.mw - i.w, i.x));
        i.y = Math.max(0, Math.min(dm.mh - i.h, i.y));
        u();
        wPanelSync(c);
      }
    };
  };
  num('.pw', v => (i.w = Math.round(v)));
  num('.ph', v => (i.h = Math.round(v)));
  num('.px', v => (i.x = Math.round(v)));
  num('.py', v => (i.y = Math.round(v)));
  if (c.ty) {
    q('.pt').value = i.c;
    q('.pt').onchange = e => {
      i.c = e.target.value;
      g.setAttribute('class', 'k ' + i.c + (c.ms.has(i.id) ? ' sel' : ''));
      save();
    };
  }
  if (room) {
    const mk = q('.wmk');
    mk.innerHTML = '<span class="hint">Markers</span>';
    MW.MANUAL.forEach(k => {
      const d = MW.MARKS[k],
        l = document.createElement('label');
      l.className = 'chip';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = (i.mk || []).includes(k);
      cb.onchange = () => {
        const a = (i.mk || []).filter(x => x !== k);
        if (cb.checked) a.push(k);
        i.mk = a;
        fit(g, i, c);
        save();
      };
      const dot = document.createElement('span');
      dot.className = 'dot';
      dot.style.background = d.c;
      dot.textContent = d.t;
      l.append(cb, dot, document.createTextNode(d.n));
      mk.appendChild(l);
    });
    const a = document.createElement('p');
    a.className = 'hint';
    a.style.margin = '4px 0 0';
    a.textContent =
      'Start, checkpoint, boss, locked door and loot markers appear by themselves from what is in the room.';
    mk.appendChild(a);
  }
  wAct(c, q('.wacts'), [i]);
  wConn(c, q('.wcn'), i);
}
function wAct(c, row, s) {
  const room = c === AC,
    add = (t, f, ti, dis) => {
      const b = document.createElement('button');
      b.textContent = t;
      b.onclick = f;
      if (ti) b.title = ti;
      if (dis) b.disabled = true;
      row.appendChild(b);
      return b;
    };
  if (s.length === 1) add('Open', () => c.open(s[0]), 'Double-click also opens');
  add('Duplicate', () => wDup(c), 'Ctrl+D');
  add('Copy', () => wCopy(c), 'Ctrl+C');
  add('Paste', () => wPaste(c), 'Ctrl+V', !CLIPR);
  if (room) {
    add(
      'Copy contents',
      () => wCopyContent(c),
      'Copy the tiles, sprites, entities, background and settings of this room'
    );
    add(
      'Paste contents',
      () => wPasteContent(c),
      'Replace the contents of the selected room(s) with the copied contents',
      !CLIPC
    );
    if (s.length === 1)
      add(
        'Save as template',
        () => {
          const n = MW.toTemplate(s[0], s[0].n);
          (S.templates = S.templates || []).push(n);
          save();
          POPK = null;
          wPop('tpl');
        },
        'Keep this room as a reusable template'
      );
    if (s.length === 2) {
      add(
        'Connect with doors',
        () => wConnect(c, s[0], s[1]),
        'Add a transition door in each room that leads to the other'
      );
      add('Remove doors between', () => wDisconnect(c, s[0], s[1]));
    }
  }
  add('Delete', () => wDelete(c), 'Delete key');
}
function wAlignRow(c, row) {
  const A = [
    ['left', '⇤', 'Align left edges'],
    ['center', '↔', 'Align centers horizontally'],
    ['right', '⇥', 'Align right edges'],
    ['top', '⤒', 'Align top edges'],
    ['middle', '↕', 'Align centers vertically'],
    ['bottom', '⤓', 'Align bottom edges']
  ];
  A.forEach(a => {
    const b = document.createElement('button');
    b.textContent = a[1];
    b.title = a[2];
    b.className = 'wal-b';
    b.onclick = () => {
      const s = selItems(c);
      if (s.length < 2) return;
      MW.alignBoxes(s, a[0]);
      save();
      draw(c);
    };
    row.appendChild(b);
  });
  [
    ['h', 'Distribute H', 'Space the selected boxes evenly left to right (3 or more)'],
    ['v', 'Distribute V', 'Space the selected boxes evenly top to bottom (3 or more)']
  ].forEach(a => {
    const b = document.createElement('button');
    b.textContent = a[1];
    b.title = a[2];
    b.onclick = () => {
      const s = selItems(c);
      if (s.length < 3) return;
      MW.distribute(s, a[0]);
      save();
      draw(c);
    };
    row.appendChild(b);
  });
  const b1 = document.createElement('button');
  b1.textContent = 'Same size';
  b1.title = 'Give every selected box the size of the one you selected first';
  b1.onclick = () => {
    const s = selItems(c);
    if (s.length < 2) return;
    MW.sameSize(s, s[0]);
    save();
    draw(c);
  };
  row.appendChild(b1);
  const b2 = document.createElement('button');
  b2.textContent = 'Tidy up';
  b2.title = 'Lay the selected boxes out in a neat grid';
  b2.onclick = () => {
    const s = selItems(c);
    if (s.length < 2) return;
    const dm = c.dim(),
      x0 = Math.min(...s.map(i => i.x)),
      y0 = Math.min(...s.map(i => i.y));
    MW.arrange(s, wstep() > 1 ? wstep() : 10, x0, y0, dm.mw - 10);
    s.forEach(i => {
      i.x = Math.min(i.x, dm.mw - i.w);
      i.y = Math.min(i.y, dm.mh - i.h);
    });
    save();
    draw(c);
  };
  row.appendChild(b2);
}
// the connections of one box (rooms: its transitions with quick navigation, areas: links to other areas)
function wConn(c, box, i) {
  box.innerHTML = '';
  const h = document.createElement('b');
  h.textContent = 'Connections';
  h.style.fontSize = '13px';
  box.appendChild(h);
  const list = document.createElement('div');
  list.className = 'wcl';
  box.appendChild(list);
  const row = (txt, go, cls, btn) => {
    const r = document.createElement('div');
    r.className = 'wcr ' + (cls || '');
    const s = document.createElement('span');
    s.textContent = txt;
    r.appendChild(s);
    if (go) {
      const b = document.createElement('button');
      b.textContent = btn || 'Go';
      b.onclick = go;
      r.appendChild(b);
    }
    list.appendChild(r);
  };
  if (c === AC) {
    const nb = MW.neighbours(S, cur.id, i.id),
      areaName = a => (S.areas.find(x => x.id === a) || {}).n || '?',
      roomOf = (a, r) => {
        const A = S.areas.find(x => x.id === a);
        return A && A.rooms && A.rooms.find(x => x.id === r);
      };
    const seen = new Set();
    nb.out.forEach(o => {
      const k = o.a + '/' + o.r + o.ok;
      if (seen.has(k)) return;
      seen.add(k);
      const R = roomOf(o.a, o.r);
      if (!o.ok || !R) row('→ missing destination (a room that was deleted)', null, 'bad');
      else row('→ ' + (o.a === cur.id ? '' : areaName(o.a) + ': ') + R.n, () => wGoMap(o.a, o.r), '', 'Show');
    });
    const si = new Set();
    nb.inn.forEach(o => {
      const k = o.a + '/' + o.r;
      if (si.has(k)) return;
      si.add(k);
      const R = roomOf(o.a, o.r);
      if (R) row('← ' + (o.a === cur.id ? '' : areaName(o.a) + ': ') + R.n, () => wGoMap(o.a, o.r), '', 'Show');
    });
    const miss = MW.dTiles(i).filter(d => !(i.tr || []).some(t => t.x === d.x && t.y === d.y));
    if (miss.length)
      row(
        miss.length + ' transition tile' + (miss.length > 1 ? 's' : '') + ' with no destination',
        () => wGoTile(cur.id, i.id, miss[0].x, miss[0].y),
        'bad',
        'Fix'
      );
    if (!list.children.length)
      row(
        'No transitions. Select two rooms and use "Connect with doors", or place a transition tile in the room.',
        null,
        'mu'
      );
  } else {
    const T = MW.transitions(S),
      out = {},
      inn = {};
    T.forEach(t => {
      if (t.from.a === i.id && t.to.a !== i.id) {
        out[t.to.a] = (out[t.to.a] || 0) + 1;
      }
      if (t.to.a === i.id && t.from.a !== i.id) inn[t.from.a] = (inn[t.from.a] || 0) + 1;
    });
    Object.keys(out).forEach(a => {
      const A = S.areas.find(x => x.id === a);
      row(
        '→ ' + (A ? A.n : 'missing area') + ' (' + out[a] + ' transition' + (out[a] > 1 ? 's' : '') + ')',
        A
          ? () => {
              WC.ms = new Set([a]);
              draw(WC);
              wReveal(WC, A);
            }
          : null,
        A ? '' : 'bad',
        'Show'
      );
    });
    Object.keys(inn).forEach(a => {
      const A = S.areas.find(x => x.id === a);
      if (A)
        row(
          '← ' + A.n + ' (' + inn[a] + ')',
          () => {
            WC.ms = new Set([a]);
            draw(WC);
            wReveal(WC, A);
          },
          '',
          'Show'
        );
    });
    if (!list.children.length) row('No transitions to other areas yet.', null, 'mu');
  }
}
