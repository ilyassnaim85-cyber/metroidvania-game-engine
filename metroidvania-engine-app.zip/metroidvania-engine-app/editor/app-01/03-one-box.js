// ---- one box ----
function wMarks(c, i) {
  if (c === AC) return MW.marksOf(i, WO.auto);
  const o = [];
  (i.rooms || []).forEach(r =>
    MW.marksOf(r, WO.auto).forEach(k => {
      if (!o.includes(k)) o.push(k);
    })
  );
  return o;
}
function fit(g, i, c) {
  const k = g.children,
    r = k[0],
    t = k[1],
    s = k[2],
    ttl = k[3],
    nb = k[4],
    bm = g.querySelector('.bm'),
    n = Math.max(3, Math.floor((i.w - 16) / 7.5)),
    sub = i.h >= 44;
  r.setAttribute('width', i.w);
  r.setAttribute('height', i.h);
  t.textContent = i.n.length > n ? i.n.slice(0, n - 1) + '…' : i.n;
  const sb =
    c === AC
      ? i.s || i.gw + '×' + i.gh
      : i.s || (i.rooms ? i.rooms.length + (i.rooms.length === 1 ? ' room' : ' rooms') : 'not built yet');
  t.setAttribute('x', i.w / 2);
  t.setAttribute('y', i.h / 2 - (sub ? 9 : 0));
  s.textContent = sub ? sb : '';
  s.setAttribute('x', i.w / 2);
  s.setAttribute('y', i.h / 2 + (i.h >= 60 ? 5 : 11));
  const cn = c === AC ? MW.contents(i) : null;
  ttl.textContent =
    i.n +
    (i.note ? '\n' + i.note : '') +
    (cn ? '\n' + cn.enemy + ' enemies, ' + cn.item + ' items, ' + cn.trans + ' transitions' : '');
  nb.textContent = i.note ? '✎' : '';
  nb.setAttribute('x', i.w - 10);
  nb.setAttribute('y', 12);
  bm.innerHTML = '';
  const ms = wMarks(c, i),
    room = c === AC,
    room2 = room
      ? ISS_MAP.get(i.id)
      : (i.rooms || []).map(r => ISS_MAP.get(r.id)).includes('error')
        ? 'error'
        : (i.rooms || []).some(r => ISS_MAP.has(r.id))
          ? 'warn'
          : null;
  let x = 9;
  const y = i.h - 9,
    mx = Math.floor((i.w - 16) / 15);
  ms.slice(0, Math.max(0, mx)).forEach(m => {
    const d = MW.MARKS[m],
      gg = el('g', { transform: 'translate(' + x + ' ' + y + ')' }, bm);
    el('circle', { r: 6.5, fill: d.c, 'fill-opacity': 0.95 }, gg);
    const tx = el(
      'text',
      { 'text-anchor': 'middle', 'dominant-baseline': 'central', 'font-size': 9, 'font-weight': 700, fill: '#10161c' },
      gg
    );
    tx.textContent = d.t;
    el('title', {}, gg).textContent = d.n;
    x += 15;
  });
  if (ms.length > mx && mx > 0) {
    const tx = el('text', { x: x - 3, y: y + 3, 'font-size': 9, fill: 'currentColor' }, bm);
    tx.textContent = '+' + (ms.length - mx);
  }
  if (room && cn && cn.trans) {
    const tx = el('text', { x: i.w - 8, y: i.h - 6, 'text-anchor': 'end', 'font-size': 10, opacity: 0.75 }, bm);
    tx.textContent = '↔' + cn.trans;
  }
  if (room2) {
    el(
      'circle',
      { cx: 8, cy: 8, r: 5, fill: room2 === 'error' ? '#e24b4a' : '#ef9f27', stroke: '#fff', 'stroke-width': 1 },
      bm
    );
  }
}
function box(c, i) {
  const g = el('g', { class: 'k ' + c.cls(i) }, c.sv);
  el('rect', { rx: 8 }, g);
  const m = { 'text-anchor': 'middle', 'dominant-baseline': 'central' };
  el('text', m, g);
  const s = el('text', m, g);
  s.setAttribute('class', 'sb');
  el('title', {}, g);
  const nb = el('text', {}, g);
  nb.setAttribute('class', 'mk');
  el('g', { class: 'bm' }, g);
  fit(g, i, c);
  if (c.ms.has(i.id)) g.classList.add('sel');
  if (WO.q || WO.fl.length) {
    const ok = c === AC ? MW.matchRoom(i, WO.q, WO.fl) : MW.matchArea(i, WO.q, WO.fl);
    if (!ok) g.classList.add('dim');
  }
  return g;
}
