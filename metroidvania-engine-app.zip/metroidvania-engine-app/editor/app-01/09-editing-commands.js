// ---- editing commands ----
function wDelete(c) {
  const pin = c.pinSel && pinsOf(c).find(q => q.id === c.pinSel);
  if (pin) {
    const L = pinsOf(c);
    L.splice(L.indexOf(pin), 1);
    c.pinSel = null;
    save();
    draw(c);
    return;
  }
  const s = selItems(c);
  if (!s.length) return;
  s.forEach(i => c.del(i));
  c.ms = new Set();
  save();
  draw(c);
}
function wDup(c) {
  const s = selItems(c);
  if (!s.length) return;
  const room = c === AC,
    ids = new Set((room ? cur.rooms : S.areas).map(r => r.id)),
    map = {},
    made = [];
  s.forEach(i => {
    const n = room ? MW.cloneRoom(i, { id: MW.newId('r', ids) }) : MW.cloneArea(i, { id: MW.newId('a', ids) });
    ids.add(n.id);
    map[i.id] = n.id;
    made.push(n);
  });
  if (room) {
    made.forEach(n => {
      (n.tr || []).forEach(t => {
        if (t.a === cur.id && map[t.r]) t.r = map[t.r];
      });
      cur.rooms.push(n);
    });
    cur.links.forEach(l => {
      if (map[l[0]] && map[l[1]]) cur.links.push([map[l[0]], map[l[1]]]);
    });
  } else {
    made.forEach(n => {
      S.areas.push(n);
    });
    S.links.forEach(l => {
      if (map[l[0]] && map[l[1]]) S.links.push([map[l[0]], map[l[1]]]);
    });
  }
  const dm = c.dim();
  made.forEach(n => {
    n.x = Math.min(n.x, dm.mw - n.w);
    n.y = Math.min(n.y, dm.mh - n.h);
  });
  c.ms = new Set(made.map(n => n.id));
  c.pinSel = null;
  save();
  draw(c);
  wReveal(c, made[0]);
}
function wCopy(c) {
  const s = selItems(c);
  if (!s.length) return;
  const room = c === AC;
  CLIPR = {
    room,
    items: JSON.parse(ser(s)),
    links: c
      .links()
      .filter(l => c.ms.has(l[0]) && c.ms.has(l[1]))
      .map(l => l.slice()),
    from: room ? cur.id : null
  };
  PASTEN = 0;
  panel(c);
  wBarSync(c);
}
function wPaste(c) {
  if (!CLIPR || CLIPR.room !== (c === AC)) return;
  PASTEN++;
  const room = c === AC,
    ids = new Set((room ? cur.rooms : S.areas).map(r => r.id)),
    map = {},
    made = [],
    off = 20 * PASTEN;
  CLIPR.items.forEach(raw => {
    const o = des(JSON.stringify(raw)),
      n = room
        ? MW.cloneRoom(o, { id: MW.newId('r', ids), name: o.n, dx: off, dy: off })
        : MW.cloneArea(o, { id: MW.newId('a', ids), name: o.n, dx: off, dy: off });
    if (room && !(CLIPR.from === cur.id)) n.n = o.n;
    ids.add(n.id);
    map[o.id] = n.id;
    made.push(n);
  });
  if (room) {
    made.forEach(n => {
      (n.tr || []).forEach(t => {
        if (t.a === CLIPR.from && map[t.r]) {
          t.a = cur.id;
          t.r = map[t.r];
        } else if (t.a === CLIPR.from && CLIPR.from !== cur.id) {
          t.r = '\u0000';
        }
      });
      n.tr = (n.tr || []).filter(t => t.r !== '\u0000');
      cur.rooms.push(n);
    });
    CLIPR.links.forEach(l => {
      if (map[l[0]] && map[l[1]]) cur.links.push([map[l[0]], map[l[1]]]);
    });
  } else {
    made.forEach(n => S.areas.push(n));
    CLIPR.links.forEach(l => {
      if (map[l[0]] && map[l[1]]) S.links.push([map[l[0]], map[l[1]]]);
    });
  }
  const dm = c.dim();
  made.forEach(n => {
    n.x = Math.min(n.x, dm.mw - n.w);
    n.y = Math.min(n.y, dm.mh - n.h);
  });
  c.ms = new Set(made.map(n => n.id));
  c.pinSel = null;
  save();
  draw(c);
  wReveal(c, made[0]);
}
function wCopyContent(c) {
  const s = selItems(c);
  if (c !== AC || s.length !== 1) return;
  CLIPC = MW.contentOf(s[0]);
  CLIPC.__from = s[0].n;
  panel(c);
  wBarSync(c);
}
function wPasteContent(c) {
  if (c !== AC || !CLIPC) return;
  const s = selItems(c);
  if (!s.length) return;
  s.forEach(r => MW.applyContent(r, CLIPC));
  save();
  draw(c);
}
function wConnect(c, A, B) {
  if (c !== AC || !A || !B) return;
  const ok = MW.connect(cur.id, A, B);
  if (!ok) {
    wBarMsg('Those rooms are already connected with doors.');
    return;
  }
  save();
  draw(c);
}
function wDisconnect(c, A, B) {
  const n = MW.disconnect(cur.id, A, B);
  wBarMsg(n ? 'Removed ' + n + ' transition' + (n > 1 ? 's' : '') + '.' : 'No doors between those rooms.');
  save();
  draw(c);
}
