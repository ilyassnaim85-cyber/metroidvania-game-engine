// Part 1 of the editor script (split from index.html; the parts run in order and share one scope, exactly like the old single script).
// Text from a project file (names, notes, messages) is data, never markup: put it in the page with textContent, or run it through esc() first.
const esc = v =>
  String(v === undefined || v === null ? '' : v).replace(/[&<>"'`]/g, c => '&#' + c.charCodeAt(0) + ';');
const A = [
  ['serpent', 'Sea Serpent', 'Ride current', 't', 40, 30],
  ['sword', 'Swordfish village', 'Sword smith', 'g', 255, 30],
  ['palace', 'Poseidon palace', 'Final boss', 'p', 490, 30],
  ['basin', 'Kraken Basin', 'Wall climb', 't', 40, 140],
  ['hub', 'Giant Turtle hub', 'Dash', 't', 255, 140],
  ['door', 'Six-key door', 'Guard gauntlet', 'p', 490, 140],
  ['ship', 'Shipwreck (start)', 'Two early bosses', 't', 40, 250],
  ['tunnel', 'Tunnel', 'Strong currents', 'g', 255, 250],
  ['hydra', 'Hydra', 'Hydra form', 't', 40, 360],
  ['abyss', 'Abyss start', 'Hard zone', 'g', 275, 360],
  ['shark', 'Shark village', 'Megalodon sword', 'g', 450, 360],
  ['siren', 'Sirens Queen', 'Song sword', 't', 310, 470],
  ['levi', 'Leviathan', 'Double jump', 't', 490, 470]
];
const L = [
  ['serpent', 'basin'],
  ['sword', 'hub'],
  ['palace', 'door'],
  ['basin', 'hub'],
  ['hub', 'door'],
  ['basin', 'ship'],
  ['ship', 'tunnel'],
  ['tunnel', 'hub'],
  ['hub', 'abyss'],
  ['abyss', 'hydra'],
  ['abyss', 'shark'],
  ['shark', 'siren'],
  ['shark', 'levi']
];
const T = [
  ['#', 'Wall', '#5b6b7a'],
  ['=', 'Platform', '#a67c52'],
  ['^', 'Hazard', '#d85a30'],
  ['e', 'Enemy', '#e24b4a'],
  ['B', 'Boss', '#7f77dd'],
  ['D', 'Transition', '#ef9f27'],
  ['*', 'Pickup', '#5dcaa5'],
  ['.', 'Erase', null],
  ['S', 'Sprite', null],
  ['X', 'Erase sprite', null],
  ['N', 'Entity', null],
  ['O', 'Boss', null],
  ['~', 'Water', '#3b8bd4'],
  ['/', 'Slope up-right', '#5b6b7a'],
  ['\\', 'Slope up-left', '#5b6b7a'],
  ['g', 'Shade wall', '#7a6a9a']
];
const MODES = [
    ['m', 'Move or open'],
    ['c', 'Connect'],
    ['x', 'Disconnect'],
    ['e', 'Edit name and size'],
    ['d', 'Delete']
  ],
  HINT = {
    m: 'Drag to move. Click to open.',
    c: 'Click one box, then another, to connect or disconnect them.',
    x: 'Click a red line to remove that connection.',
    e: 'Click a box to rename or resize it.',
    d: 'Click a box to delete it.'
  };
const APP_VER = '3.44.3'; // keep in step with package.json: shown in the window so you can tell which build you are running
const NS = 'http://www.w3.org/2000/svg',
  $ = i => document.getElementById(i),
  rid = () => Math.random().toString(36).slice(2, 8);
const svg = $('svg'),
  sv2 = $('sv2'),
  cv = $('cv'),
  ctx = cv.getContext('2d');
let S = fresh(),
  cur = null,
  rc = null,
  tool = '#',
  painting = false,
  imgs = {},
  si = -1,
  ld = null;
function fresh() {
  return {
    areas: A.map(a => ({
      id: a[0],
      n: a[1],
      s: a[2],
      c: a[3],
      x: a[4],
      y: a[5],
      w: 170,
      h: 56,
      rooms: null,
      links: []
    })),
    links: L.map(l => l.slice()),
    sheets: [],
    mw: 680,
    mh: 700,
    player: {},
    moves: [],
    attacks: [],
    items: [],
    enemies: [],
    inv: MV.Inventory.cleanDesign(null),
    body: MV.Attacks.bodyClean(null),
    controls: MV.Controls.clean(null),
    camProfiles: [],
    events: [],
    scripts: [],
    vcams: [],
    sounds: [],
    sfx: {},
    vol: MV.Audio.cleanVol(),
    sprite: MV.PlayerSprite.def(),
    bosses: [],
    anims: [],
    dialog: MV.Dialog.def(),
    ui: MV.UI.def(),
    fonts: [],
    tileSkins: {},
    stamps: [],
    name: '',
    templates: [],
    pins: []
  };
}
const IDX = 'mv_projects';
let PID = null,
  PFILE = null,
  lastTouch = 0;
function idxGet() {
  try {
    const a = JSON.parse(localStorage.getItem(IDX));
    return Array.isArray(a) ? a.filter(p => p && typeof p.id === 'string') : [];
  } catch (e) {
    return [];
  }
}
function idxSet(a) {
  try {
    localStorage.setItem(IDX, JSON.stringify(a));
  } catch (e) {}
}
function metaSet(patch) {
  const a = idxGet(),
    m = a.find(p => p.id === PID);
  if (m) {
    Object.assign(m, patch);
    idxSet(a);
  }
}
// Rooms over 1,000,000 tiles are saved run-length packed (a blank 10000 x 10000 room is a few bytes). Smaller rooms stay plain arrays, so exports of normal projects look as before.
const PKC = new Map();
function packRow(r) {
  if (r.length < 64) return r;
  let o = PKC.get(r);
  if (o !== undefined) return o;
  o = '';
  let i = 0;
  const n = r.length;
  while (i < n) {
    const ch = r[i];
    let j = i + 1;
    while (j < n && r[j] === ch) j++;
    const L = j - i;
    o += L > 3 ? '`' + ch + L + ';' : ch.repeat(L);
    i = j;
  }
  if (PKC.size > 6000) PKC.clear();
  PKC.set(r, o);
  return o;
}
function unpackRow(p) {
  if (p.indexOf('`') < 0) return p;
  let o = '',
    i = 0;
  while (i < p.length) {
    const ch = p[i];
    if (ch === '`') {
      const e = p.indexOf(';', i);
      o += p[i + 1].repeat(+p.slice(i + 2, e));
      i = e + 1;
    } else {
      o += ch;
      i++;
    }
  }
  return o;
}
function packGrid(g) {
  if (!g.length || typeof g[0] !== 'string' || g.length * g[0].length < 1e6) return g;
  const d = [];
  let i = 0;
  while (i < g.length) {
    const r = g[i];
    if (r.indexOf('`') >= 0) return g;
    let j = i + 1;
    while (j < g.length && g[j] === r) j++;
    d.push([packRow(r), j - i]);
    i = j;
  }
  return { z: 1, d };
}
function unpackGrid(v) {
  const g = [];
  v.d.forEach(q => {
    const r = unpackRow(q[0]);
    for (let i = 0; i < q[1]; i++) g.push(r);
  });
  return g;
}
const ser = (o, sp) => JSON.stringify(o, (k, v) => (k === 'grid' && Array.isArray(v) ? packGrid(v) : v), sp);
const des = t =>
  JSON.parse(t, (k, v) =>
    k === 'grid' && v && !Array.isArray(v) && v.z === 1 && Array.isArray(v.d) ? unpackGrid(v) : v
  );
function persist() {
  if (!PID) return;
  try {
    localStorage.setItem('mv_proj_' + PID, ser(S));
  } catch (e) {}
  const t = Date.now();
  if (t - lastTouch > 5000) {
    lastTouch = t;
    metaSet({ updated: t });
  }
}
function save() {
  hist();
  persist();
  wValLater();
}
function okGrid(g) {
  return (
    Array.isArray(g) &&
    g.length >= 6 &&
    g.length <= 10000 &&
    typeof g[0] === 'string' &&
    g[0].length >= 8 &&
    g[0].length <= 10000 &&
    g.every(r => typeof r === 'string' && r.length === g[0].length)
  );
}
const okTr = a =>
  Array.isArray(a)
    ? a
        .filter(
          v =>
            v &&
            typeof v.x === 'number' &&
            typeof v.y === 'number' &&
            typeof v.a === 'string' &&
            typeof v.r === 'string'
        )
        .map(v => {
          const o = { x: v.x, y: v.y, a: v.a, r: v.r };
          if (['none', 'fade', 'wipe', 'iris', 'slide', 'dissolve'].includes(v.fx)) o.fx = v.fx;
          if (+v.fxTime > 0) o.fxTime = Math.max(0.1, Math.min(3, +v.fxTime));
          if (v.mode === 'press') o.mode = 'press';
          if (v.key === 'down') o.key = 'down';
          if (+v.ride > 0) o.ride = Math.min(10, +v.ride);
          return o;
        })
    : [];
const okEnt = a =>
  Array.isArray(a)
    ? a
        .filter(
          v =>
            v &&
            typeof v.id === 'string' &&
            typeof v.type === 'string' &&
            typeof v.x === 'number' &&
            typeof v.y === 'number'
        )
        .map(v => ({
          id: v.id,
          type: v.type,
          x: v.x,
          y: v.y,
          props: v.props && typeof v.props === 'object' && !Array.isArray(v.props) ? v.props : {}
        }))
    : [];
const okCam = c =>
  c && (c.mode === 'follow' || c.mode === 'fixed' || typeof c.profile === 'string')
    ? {
        mode: c.mode === 'fixed' ? 'fixed' : 'follow',
        profile: typeof c.profile === 'string' && /^[a-z0-9_]{1,24}$/.test(c.profile) ? c.profile : '',
        follow: typeof c.follow === 'number' ? Math.max(0.02, Math.min(1, c.follow)) : null
      }
    : null; // follow null = use Player settings > Camera
const CL = v => Math.max(400, Math.min(3000, v));
const N = (v, d) => (typeof v === 'number' ? v : d);
function okL(a, ks) {
  return Array.isArray(a)
    ? a
        .filter(v => v && typeof v.s === 'string' && ks.every(k => typeof v[k] === 'number'))
        .map(v => {
          const o = { s: v.s };
          ks.forEach(k => (o[k] = v[k]));
          return o;
        })
    : [];
}
function okSheets(a) {
  return Array.isArray(a)
    ? a
        .filter(v => v && typeof v.id === 'string' && typeof v.url === 'string' && v.url.startsWith('data:image/'))
        .map(v => ({
          id: v.id,
          name: String(v.name || 'sprites').slice(0, 40),
          url: v.url,
          tw: Math.max(1, +v.tw || 16),
          th: Math.max(1, +v.th || 16)
        }))
    : [];
}
function okRoom(r) {
  const g = okGrid(r.grid) ? r.grid : null;
  return {
    id: r.id,
    n: r.n.slice(0, 30),
    s: '',
    x: N(r.x, 40),
    y: N(r.y, 40),
    w: N(r.w, 130),
    h: N(r.h, 44),
    note: typeof r.note === 'string' ? r.note : '',
    grid: g,
    gw: g ? g[0].length : 48,
    gh: g ? g.length : 24,
    art: okL(r.art, ['x', 'y', 'c', 'r', 'w', 'h']),
    table: okL(r.table, ['c', 'r', 'w', 'h']),
    tr: okTr(r.tr),
    ent: okEnt(r.ent),
    cam: okCam(r.cam),
    music: typeof r.music === 'string' && /^[\w-]{1,24}$/.test(r.music) ? r.music : '',
    bg: MV.Background.clean(r.bg),
    light: MV.Light.clean(r.light),
    stream: Math.max(0, Math.min(200, Math.round(+r.stream || 0))),
    mk: Array.isArray(r.mk) ? r.mk.filter(k => typeof k === 'string' && MV.World.MARKS[k]).slice(0, 12) : []
  };
}
const okPins = a =>
  Array.isArray(a)
    ? a
        .filter(
          p =>
            p &&
            typeof p.id === 'string' &&
            typeof p.x === 'number' &&
            typeof p.y === 'number' &&
            typeof p.k === 'string'
        )
        .slice(0, 400)
        .map(p => ({
          id: p.id.slice(0, 20),
          x: Math.max(0, Math.min(3000, p.x)),
          y: Math.max(0, Math.min(3000, p.y)),
          k: PINK_OK.includes(p.k) ? p.k : 'note',
          t: typeof p.t === 'string' ? p.t.slice(0, 200) : ''
        }))
    : [];
const PINK_OK = ['note', 'start', 'entrance', 'exit', 'save', 'goal', 'boss', 'secret', 'danger'];
const okTpl = a =>
  Array.isArray(a)
    ? a
        .filter(t => t && typeof t.id === 'string' && typeof t.name === 'string' && okGrid(t.grid))
        .slice(0, 60)
        .map(t => {
          const q = okRoom(Object.assign({}, t, { n: t.name }));
          q.id = t.id.slice(0, 20);
          q.name = t.name.slice(0, 30);
          q.tr = [];
          return q;
        })
    : [];
function merge(o) {
  if (!o || !o.areas) throw new Error('No areas found');
  if (!Array.isArray(o.areas)) {
    const f = fresh();
    f.areas.forEach(a => {
      const s = o.areas[a.id];
      if (s) Object.assign(a, { x: s.x, y: s.y, rooms: s.rooms, links: s.links });
    });
    o = { areas: f.areas, links: f.links };
  }
  const areas = [];
  o.areas.forEach(s => {
    if (!s || typeof s.id !== 'string' || typeof s.n !== 'string') return;
    const a = {
      id: s.id,
      n: s.n.slice(0, 30),
      s: typeof s.s === 'string' ? s.s.slice(0, 30) : '',
      c: ['t', 'g', 'p'].includes(s.c) ? s.c : 't',
      x: N(s.x, 40),
      y: N(s.y, 40),
      w: N(s.w, 170),
      h: N(s.h, 56),
      mw: CL(N(s.mw, 680)),
      mh: CL(N(s.mh, 520)),
      note: typeof s.note === 'string' ? s.note.slice(0, 2000) : '',
      pins: okPins(s.pins),
      rooms: null,
      links: []
    };
    if (Array.isArray(s.rooms)) {
      a.rooms = s.rooms.filter(r => r && typeof r.id === 'string' && typeof r.n === 'string').map(okRoom);
      const ids = a.rooms.map(r => r.id);
      a.links = Array.isArray(s.links)
        ? s.links.filter(l => Array.isArray(l) && ids.includes(l[0]) && ids.includes(l[1]))
        : [];
    }
    areas.push(a);
  });
  const ids = areas.map(a => a.id);
  S = {
    areas,
    links: (Array.isArray(o.links) ? o.links : []).filter(
      l => Array.isArray(l) && ids.includes(l[0]) && ids.includes(l[1])
    ),
    sheets: okSheets(o.sheets),
    mw: CL(N(o.mw, 680)),
    mh: CL(N(o.mh, 700)),
    player: MV.Tuning.clean(o.player),
    moves: MV.Moves.resolve(o.moves),
    attacks: MV.Attacks.resolve(o.attacks, o.player),
    items: MV.Inventory.resolve(o.items),
    enemies: MV.Enemies.resolve(o.enemies),
    inv: MV.Inventory.cleanDesign(o.inv),
    body: MV.Attacks.bodyClean(o.body),
    controls: MV.Controls.clean(o.controls),
    camProfiles: MV.Camera.cleanProfiles(o.camProfiles),
    events: MV.Events.clean(o.events),
    scripts: MV.Script.clean(o.scripts),
    vcams: MV.CameraVcams.clean(o.vcams),
    sounds: MV.Audio.cleanList(o.sounds),
    sfx: MV.Audio.cleanSfx(o.sfx),
    vol: MV.Audio.cleanVol(o.vol),
    sprite: MV.PlayerSprite.clean(o.sprite),
    bosses: MV.Boss.list(o.bosses),
    anims: MV.Anim.list(o.anims),
    dialog: MV.Dialog.clean(o.dialog),
    ui: MV.UI.clean(o.ui),
    fonts: MV.UI.cleanFonts(o.fonts),
    tileSkins: MV.Tiles.cleanSkins(o.tileSkins),
    stamps: MV.Tiles.cleanStamps(o.stamps),
    name: typeof o.name === 'string' ? o.name.slice(0, 40) : '',
    templates: okTpl(o.templates),
    pins: okPins(o.pins)
  };
}
function el(t, at, p) {
  const e = document.createElementNS(NS, t);
  for (const k in at) e.setAttribute(k, at[k]);
  if (p) p.appendChild(e);
  return e;
}
function pt(sv, e) {
  return new DOMPoint(e.clientX, e.clientY).matrixTransform(sv.getScreenCTM().inverse());
}
