// ---- entity properties: pick any key, pick a still sprite, and the animation skins ----
const KLAB = {
  ArrowUp: '↑',
  ArrowDown: '↓',
  ArrowLeft: '←',
  ArrowRight: '→',
  Space: 'Space',
  Enter: 'Enter',
  Tab: 'Tab',
  ShiftLeft: 'Shift',
  ShiftRight: 'Shift',
  Backspace: 'Backspace'
};
const keyLab = v => {
  v = String(v || 'E');
  return KLAB[v] || v.replace(/^(Key|Digit|Numpad)/, '');
};
function keyCap(e, k) {
  const lb = document.createElement('label'),
    b = document.createElement('button');
  b.type = 'button';
  b.className = 'keycap';
  b.title = 'Click, then press the key you want. Escape cancels.';
  lb.append(k + ' ', b);
  let on = null;
  const show = () => {
    b.textContent = keyLab(e.props[k] === undefined ? 'E' : e.props[k]) + '  (change)';
  };
  show();
  const stop = () => {
    if (on) {
      removeEventListener('keydown', on, true);
      on = null;
    }
    b.classList.remove('on');
    show();
  };
  b.onclick = () => {
    if (on) {
      stop();
      return;
    }
    b.classList.add('on');
    b.textContent = 'Press a key...';
    on = ev => {
      ev.preventDefault();
      ev.stopPropagation();
      if ((ev.code !== 'Escape' && !/^(Meta|Control|Alt|Shift)/.test(ev.key)) || (/^(Shift)/.test(ev.key) && false)) {
        const c = ev.code;
        e.props[k] = /^Key[A-Z]$/.test(c) ? c.slice(3) : /^Digit[0-9]$/.test(c) ? c.slice(5) : c;
        save();
      }
      stop();
    };
    addEventListener('keydown', on, true);
  };
  b.onblur = () => setTimeout(stop, 150);
  return lb;
}
function spriteOpts(inp, cur) {
  const o0 = document.createElement('option');
  o0.value = '';
  o0.textContent = '(no sprite)';
  inp.appendChild(o0);
  const seen = new Set(['']);
  (rc.table || []).forEach((t, i) => {
    const sh = sheet(t.s);
    if (!sh) return;
    const v = [t.s, t.c, t.r, t.w, t.h].join('|');
    if (seen.has(v)) return;
    seen.add(v);
    const o = document.createElement('option');
    o.value = v;
    o.textContent = sh.name + ' (' + t.c + ', ' + t.r + ')' + (t.w > 1 || t.h > 1 ? ' ' + t.w + 'x' + t.h : '');
    inp.appendChild(o);
  });
  if (cur && !seen.has(cur)) {
    const o = document.createElement('option');
    o.value = cur;
    o.textContent = 'saved sprite';
    inp.appendChild(o);
  }
}
const SKIN0 = null;
function skinPrev(c, e, d) {
  const SK = MV.data.skins || {},
    m = SK[e.type],
    still = (MV.data.spriteOnly || []).includes(e.type);
  if (!m && !still) return false;
  const pr = e.props,
    tiled = (MV.data.skinTiled || []).includes(e.type);
  let w, h, cx;
  if (tiled) {
    w = e.type === 'ladder' ? 1 : Math.max(1, Math.round(+pr.width || d.w));
    h =
      e.type === 'ladder'
        ? Math.max(1, Math.round(+pr.height || 3))
        : e.type === 'conveyor'
          ? 1
          : Math.max(1, Math.round(+pr.height || 1));
    cx = e.x + w / 2;
  } else {
    const wide = e.type === 'spring' || e.type === 'dashpad';
    w = wide ? Math.max(0.5, +pr.width || 1) : d.w;
    h = d.h;
    cx = wide ? e.x + w / 2 : e.x + 0.5;
  }
  const cells = tiled
    ? Array.from({ length: w * h }, (_, n) => [
        cx - w / 2 + (n % w) + 0.5,
        e.y + 1 - h + Math.floor(n / w) + 1,
        1,
        1,
        1
      ])
    : [[cx, e.y + 1, w, h, 0]];
  let ok = false;
  if (still) {
    const q = String(pr.sprite || '').split('|');
    if (q.length < 5) return false;
    const sh = sheetOf(q[0]);
    if (!sh || !sh.img.complete || !sh.img.naturalWidth) return false;
    const sw = Math.max(1, +q[3]) * sh.tw,
      shh = Math.max(1, +q[4]) * sh.th;
    ctx.imageSmoothingEnabled = false;
    cells.forEach(g => {
      const f = g[4] ? Math.min((g[2] * c) / sw, (g[3] * c) / shh) : (g[2] * c) / sw;
      ctx.drawImage(
        sh.img,
        +q[1] * sh.tw,
        +q[2] * sh.th,
        sw,
        shh,
        g[0] * c - (sw * f) / 2,
        g[1] * c - shh * f,
        sw * f,
        shh * f
      );
      ok = true;
    });
  } else {
    const id = pr[m[Object.keys(m)[0]]],
      cl = MV.Anim.find(S.anims, id);
    if (!cl || !cl.frames.length) return false;
    const sh = sheetOf(cl.frames[0].sheet);
    if (!sh || !sh.img.complete || !sh.img.naturalWidth) return false;
    const sm = MV.Anim.sample(cl, performance.now() / 1000);
    cells.forEach(g => {
      const f = g[4] ? Math.min((g[2] * c) / sh.tw, (g[3] * c) / sh.th) : (g[2] * c) / sh.tw;
      ok = MV.Anim.draw(ctx, cl, sm, sheetOf, g[0] * c, g[1] * c, { scale: f }) || ok;
    });
  }
  if (!ok) return false;
  ctx.save();
  ctx.setLineDash([3, 3]);
  ctx.strokeStyle = 'rgba(255,255,255,.55)';
  ctx.strokeRect((cx - w / 2) * c + 0.5, (e.y + 1 - h) * c + 0.5, w * c - 1, h * c - 1);
  ctx.restore();
  return true;
}
setInterval(() => {
  try {
    if (
      rc &&
      cv.offsetParent &&
      !painting &&
      !LD &&
      !BD &&
      rc.ent.some(
        e =>
          (e.type === 'animsprite' && e.props.clip) ||
          ((MV.data.skins || {})[e.type] && Object.values(MV.data.skins[e.type]).some(pn => e.props[pn]))
      )
    )
      drawT();
  } catch (e) {}
}, 100);
let BGE = -1,
  BD = null;
const bgL = () => {
  const b = rc && rc.bg;
  return b && BGE >= 0 ? b.layers[BGE] : null;
};
function bgRect(L) {
  const m = L.sheet ? bgImg(L.sheet) : null,
    ar = m && m.naturalWidth ? m.naturalHeight / m.naturalWidth : 1;
  return {
    x: +L.x || 0,
    y: +L.y || 0,
    w: +L.w || 0,
    h: +L.h > 0 ? +L.h : (+L.w || 0) * ar,
    ar: +L.h > 0 && +L.w > 0 ? +L.h / +L.w : ar
  };
}
function bgOverlay(c) {
  const L = bgL();
  if (!L || L.mode !== 'free' || !(L.w > 0)) return;
  const r = bgRect(L);
  ctx.save();
  ctx.setLineDash([6, 4]);
  ctx.lineWidth = 2;
  ctx.strokeStyle = '#ffd24a';
  ctx.strokeRect(r.x * c, r.y * c, r.w * c, r.h * c);
  ctx.setLineDash([]);
  ctx.fillStyle = '#ffd24a';
  [
    [0, 0],
    [1, 0],
    [0, 1],
    [1, 1]
  ].forEach(q => ctx.fillRect((r.x + q[0] * r.w) * c - 5, (r.y + q[1] * r.h) * c - 5, 10, 10));
  ctx.restore();
}
function bgDown(e) {
  const L = bgL();
  if (!L || L.mode !== 'free' || !lyOk('scenery', false)) return false;
  if (!(L.w > 0)) return true;
  const p = tpt(e),
    r = bgRect(L),
    tol = 10 / p.pp;
  for (const q of [
    [0, 0],
    [1, 0],
    [0, 1],
    [1, 1]
  ]) {
    if (Math.abs(p.x - (r.x + q[0] * r.w)) < tol && Math.abs(p.y - (r.y + q[1] * r.h)) < tol) {
      BD = { m: 'size', ax: r.x + (1 - q[0]) * r.w, ay: r.y + (1 - q[1]) * r.h, qx: q[0], qy: q[1], ar: r.ar };
      return true;
    }
  }
  if (p.x >= r.x && p.x <= r.x + r.w && p.y >= r.y && p.y <= r.y + r.h)
    BD = { m: 'move', dx: p.x - r.x, dy: p.y - r.y };
  return true;
}
function bgMove(e) {
  const L = bgL();
  if (!L || !BD) return;
  const p = tpt(e),
    q = v => Math.round(v * 100) / 100;
  if (BD.m === 'move') {
    L.x = q(p.x - BD.dx);
    L.y = q(p.y - BD.dy);
  } else {
    let w = Math.max(0.5, Math.abs(p.x - BD.ax)),
      h = e.shiftKey ? Math.max(0.5, Math.abs(p.y - BD.ay)) : w * BD.ar;
    L.w = q(w);
    L.h = q(h);
    L.x = q(BD.qx ? BD.ax : BD.ax - w);
    L.y = q(BD.qy ? BD.ay : BD.ay - h);
  }
  drawT();
}
function bgUp() {
  BD = null;
  rc.bg = MV.Background.clean(rc.bg);
  save();
  bgUI();
  drawT();
}
