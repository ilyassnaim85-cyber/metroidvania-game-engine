// ---- pointer handling on a box ----
function wEvents(c, g, i) {
  let last = 0;
  g.addEventListener('pointerdown', e => {
    if (e.button !== 0 || SPACE) return;
    g.setPointerCapture(e.pointerId);
    const p = pt(c.sv, e),
      multi = e.shiftKey || e.ctrlKey || e.metaKey;
    if (c.mode === 'm') {
      c.pinSel = null;
      if (multi) {
        c.ms.has(i.id) ? c.ms.delete(i.id) : c.ms.add(i.id);
      } else if (!c.ms.has(i.id)) c.ms = new Set([i.id]);
      selVis(c);
    }
    const sel = c.mode === 'm' ? selItems(c) : [i];
    c.dr = { i, s: p, sx: e.clientX, sy: e.clientY, m: false, multi, items: sel.map(q => ({ q, x: q.x, y: q.y })) };
  });
  g.addEventListener('pointermove', e => {
    const d = c.dr;
    if (!d || d.i !== i) return;
    if (!d.m && Math.hypot(e.clientX - d.sx, e.clientY - d.sy) > 4) d.m = true;
    if (!d.m) return;
    const p = pt(c.sv, e),
      dm = c.dim(),
      st = wstep();
    let dx = p.x - d.s.x,
      dy = p.y - d.s.y;
    const o = d.items.find(t => t.q === i);
    let nx = MW.snapTo(o.x + dx, st),
      ny = MW.snapTo(o.y + dy, st);
    c.gd = [];
    if (WO.guides) {
      const thr = 7 / Math.max(zUse(c.zn), 0.3),
        oth = c.list().filter(q => !d.items.some(t => t.q === q)),
        X = [nx, nx + i.w / 2, nx + i.w],
        Y = [ny, ny + i.h / 2, ny + i.h];
      let bx = null,
        by = null;
      oth.forEach(q => {
        [q.x, q.x + q.w / 2, q.x + q.w].forEach(v =>
          X.forEach((u, k) => {
            const df = v - u;
            if (Math.abs(df) <= thr && (bx === null || Math.abs(df) < Math.abs(bx.df))) bx = { df, v };
          })
        );
        [q.y, q.y + q.h / 2, q.y + q.h].forEach(v =>
          Y.forEach((u, k) => {
            const df = v - u;
            if (Math.abs(df) <= thr && (by === null || Math.abs(df) < Math.abs(by.df))) by = { df, v };
          })
        );
      });
      if (bx) {
        nx += bx.df;
        c.gd.push({ x1: bx.v, y1: 0, x2: bx.v, y2: dm.mh });
      }
      if (by) {
        ny += by.df;
        c.gd.push({ x1: 0, y1: by.v, x2: dm.mw, y2: by.v });
      }
    }
    dx = nx - o.x;
    dy = ny - o.y;
    const minX = Math.min(...d.items.map(t => t.x)),
      minY = Math.min(...d.items.map(t => t.y)),
      maxX = Math.max(...d.items.map(t => t.x + t.q.w)),
      maxY = Math.max(...d.items.map(t => t.y + t.q.h));
    dx = Math.max(-minX, Math.min(dm.mw - maxX, dx));
    dy = Math.max(-minY, Math.min(dm.mh - maxY, dy));
    d.items.forEach(t => {
      t.q.x = t.x + dx;
      t.q.y = t.y + dy;
    });
    place(c);
    wGuides(c);
    wPanelSync(c);
  });
  g.addEventListener('pointerup', e => {
    const d = c.dr;
    if (!d || d.i !== i) return;
    c.dr = null;
    c.gd = [];
    wGuides(c);
    if (d.m) {
      save();
      draw(c);
      return;
    }
    if (c.mode === 'm') {
      const now = Date.now();
      if (now - last < 400 && !d.multi) {
        last = 0;
        c.open(i);
        return;
      }
      last = now;
      if (!d.multi && c.ms.size > 1 && c.ms.has(i.id)) {
        c.ms = new Set([i.id]);
        draw(c);
        return;
      }
      panel(c);
      wBarSync(c);
      return;
    }
    click(c, i);
  });
}
function wGuides(c) {
  const g = c.ov;
  if (!g) return;
  g.innerHTML = '';
  (c.gd || []).forEach(l =>
    el(
      'line',
      { x1: l.x1, y1: l.y1, x2: l.x2, y2: l.y2, stroke: '#ef9f27', 'stroke-width': 1, 'stroke-dasharray': '4 3' },
      g
    )
  );
  const m = c.mq;
  if (m)
    el(
      'rect',
      {
        x: Math.min(m.x, m.x2),
        y: Math.min(m.y, m.y2),
        width: Math.abs(m.x2 - m.x),
        height: Math.abs(m.y2 - m.y),
        fill: 'rgba(239,159,39,.12)',
        stroke: '#ef9f27',
        'stroke-dasharray': '4 3'
      },
      g
    );
}
function selVis(c) {
  c.list().forEach(i => {
    const g = c.rf[i.id];
    if (g) g.classList.toggle('sel', c.ms.has(i.id));
  });
  wHandles(c);
  panel(c);
  wBarSync(c);
}
function click(c, i) {
  if (c.mode === 'd') {
    c.del(i);
    c.ms.delete(i.id);
    save();
  } else if (c.mode === 'c') {
    if (!c.pend) c.pend = i.id;
    else if (c.pend !== i.id) {
      const L2 = c.links(),
        k = L2.findIndex(l => (l[0] === c.pend && l[1] === i.id) || (l[1] === c.pend && l[0] === i.id));
      if (k >= 0) L2.splice(k, 1);
      else L2.push([c.pend, i.id]);
      c.pend = null;
      save();
    } else c.pend = null;
  }
  draw(c);
}
