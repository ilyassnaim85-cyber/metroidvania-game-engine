// ---- pins (notes and markers you place on the map) ----
function wPinsDraw(c) {
  const g = c.pg;
  if (!g) return;
  g.innerHTML = '';
  pinsOf(c).forEach(p => {
    const d = PINK[p.k] || PINK.note,
      gg = el(
        'g',
        {
          class: 'pin' + (c.pinSel === p.id ? ' sel' : ''),
          transform: 'translate(' + p.x + ' ' + p.y + ')',
          style: 'cursor:grab'
        },
        g
      );
    el(
      'circle',
      {
        r: 9,
        fill: d.c,
        stroke: c.pinSel === p.id ? '#ef9f27' : '#10161c',
        'stroke-width': c.pinSel === p.id ? 3 : 1.5
      },
      gg
    );
    const t = el(
      'text',
      { 'text-anchor': 'middle', 'dominant-baseline': 'central', 'font-size': 11, 'font-weight': 700, fill: '#10161c' },
      gg
    );
    t.textContent = d.t;
    if (p.t && WO.notes) {
      const w = Math.min(160, p.t.length * 6.2 + 10),
        bg = el(
          'rect',
          { x: 13, y: -9, width: w, height: 18, rx: 5, fill: 'rgba(16,22,28,.82)', stroke: d.c, 'stroke-width': 0.8 },
          gg
        ),
        tt = el('text', { x: 18, y: 0, 'dominant-baseline': 'central', 'font-size': 10.5, fill: '#e8e6df' }, gg);
      tt.textContent = p.t.length > 26 ? p.t.slice(0, 25) + '…' : p.t;
      bg.setAttribute(
        'width',
        Math.min(w, tt.getComputedTextLength ? Math.max(30, tt.getComputedTextLength() + 10) : w)
      );
    }
    el('title', {}, gg).textContent = d.n + (p.t ? ': ' + p.t : '');
    let drag = null;
    gg.addEventListener('pointerdown', e => {
      if (e.button !== 0 || SPACE) return;
      e.stopPropagation();
      gg.setPointerCapture(e.pointerId);
      drag = { s: pt(c.sv, e), ox: p.x, oy: p.y, m: false, sx: e.clientX, sy: e.clientY };
      c.pinSel = p.id;
      c.ms = new Set();
      c.list().forEach(i => c.rf[i.id] && c.rf[i.id].classList.remove('sel'));
      wHandles(c);
      panel(c);
    });
    gg.addEventListener('pointermove', e => {
      if (!drag) return;
      if (Math.hypot(e.clientX - drag.sx, e.clientY - drag.sy) > 3) drag.m = true;
      if (!drag.m) return;
      const q = pt(c.sv, e),
        dm = c.dim();
      p.x = Math.max(0, Math.min(dm.mw, Math.round(drag.ox + q.x - drag.s.x)));
      p.y = Math.max(0, Math.min(dm.mh, Math.round(drag.oy + q.y - drag.s.y)));
      gg.setAttribute('transform', 'translate(' + p.x + ' ' + p.y + ')');
    });
    gg.addEventListener('pointerup', () => {
      if (drag && drag.m) save();
      drag = null;
      wPinsDraw(c);
      panel(c);
    });
  });
}
// background: click clears the selection (or drops an armed pin), Shift-drag selects a rectangle
function wBg(c) {
  const wr = c.sv.closest('.cvw');
  wr.addEventListener('click', e => {
    if (zWasPan) {
      zWasPan = false;
      return;
    }
    const bgHit =
      e.target === wr ||
      e.target === c.sv ||
      (e.target.classList && (e.target.classList.contains('bgr') || (e.target.closest && e.target.closest('.wgrid'))));
    if (!bgHit || V !== (c === WC ? 'ov' : 'ar')) return;
    if (c.addPin) {
      const p = pt(c.sv, e),
        pins = pinsOf(c),
        id = MW.newId('p', new Set(pins.map(q => q.id)));
      pins.push({ id, x: Math.round(p.x), y: Math.round(p.y), k: c.addPin, t: '' });
      c.addPin = null;
      c.pinSel = id;
      c.ms = new Set();
      save();
      draw(c);
      const t = document.querySelector('.pin-t');
      if (t) t.focus();
      return;
    }
    if (c.mode === 'm' && (c.ms.size || c.pinSel)) {
      c.ms = new Set();
      c.pinSel = null;
      draw(c);
    }
  });
  c.sv.addEventListener('pointerdown', e => {
    if (e.button !== 0 || !e.shiftKey || c.mode !== 'm' || SPACE) return;
    const bgHit = e.target === c.sv || (e.target.classList && e.target.classList.contains('bgr'));
    if (!bgHit) return;
    e.preventDefault();
    c.sv.setPointerCapture(e.pointerId);
    const p = pt(c.sv, e);
    c.mq = { x: p.x, y: p.y, x2: p.x, y2: p.y, add: e.ctrlKey || e.metaKey };
  });
  c.sv.addEventListener('pointermove', e => {
    const m = c.mq;
    if (!m) return;
    const p = pt(c.sv, e);
    m.x2 = p.x;
    m.y2 = p.y;
    wGuides(c);
  });
  c.sv.addEventListener('pointerup', e => {
    const m = c.mq;
    if (!m) return;
    c.mq = null;
    const x0 = Math.min(m.x, m.x2),
      x1 = Math.max(m.x, m.x2),
      y0 = Math.min(m.y, m.y2),
      y1 = Math.max(m.y, m.y2);
    zWasPan = true;
    setTimeout(() => {
      zWasPan = false;
    }, 60);
    if (x1 - x0 < 4 && y1 - y0 < 4) {
      wGuides(c);
      return;
    }
    const hit = c
      .list()
      .filter(i => i.x < x1 && i.x + i.w > x0 && i.y < y1 && i.y + i.h > y0)
      .map(i => i.id);
    c.ms = m.add ? new Set([...c.ms, ...hit]) : new Set(hit);
    c.pinSel = null;
    draw(c);
  });
}
