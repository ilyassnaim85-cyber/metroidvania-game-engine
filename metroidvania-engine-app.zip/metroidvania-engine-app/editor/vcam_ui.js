// Virtual cameras (editor), shown under Player > Camera. A list of cameras and an inspector for the selected one.
// Needs the editor globals: S (the project), $, save(), buildCam(). The runtime is engine/camera_vcam.js.
(() => {
  const VC = MV.CameraVcams;
  let SEL = '';
  const E = (t, c, x) => {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };
  const list = () => S.vcams || (S.vcams = []);
  const cur = () => list().find(c => c.id === SEL) || null;
  const commit = rebuild => {
    const keep = SEL;
    S.vcams = VC.clean(S.vcams);
    SEL = S.vcams.some(c => c.id === keep) ? keep : S.vcams[0] ? S.vcams[0].id : '';
    save();
    if (rebuild !== false) vcUI();
  };
  const rooms = () => {
    const out = [];
    (S.areas || []).forEach(a =>
      (a.rooms || []).forEach(r => out.push({ id: r.id, n: (a.n || '') + ' / ' + (r.n || r.id), r }))
    );
    return out;
  };
  const num = (label, get, set, o) => {
    o = o || {};
    const l = E('label', '', label + ' '),
      i = E('input');
    i.type = 'number';
    if (o.step) i.step = o.step;
    if (o.min !== undefined) i.min = o.min;
    if (o.max !== undefined) i.max = o.max;
    const v = get();
    i.value = v === undefined || v === null ? '' : v;
    if (o.ph !== undefined) i.placeholder = o.ph;
    i.style.width = '80px';
    i.onchange = () => set(i.value === '' ? undefined : +i.value);
    l.appendChild(i);
    if (o.title) l.title = o.title;
    return l;
  };
  const sel = (label, opts, val, set, title) => {
    const l = E('label', '', label + ' '),
      s = E('select');
    opts.forEach(o => {
      const op = E('option', '', o[1]);
      op.value = o[0];
      s.appendChild(op);
    });
    if (!opts.some(o => o[0] === val)) {
      const op = E('option', '', '(missing) ' + val);
      op.value = val;
      s.appendChild(op);
    }
    s.value = val;
    s.onchange = () => set(s.value);
    l.appendChild(s);
    if (title) l.title = title;
    return l;
  };
  const row = (...k) => {
    const r = E('div', 'row');
    r.style.cssText = 'gap:10px;flex-wrap:wrap;align-items:center;margin:6px 0';
    r.append(...k);
    return r;
  };
  const live = () =>
    !!(
      window.MV &&
      MV.Game &&
      MV.Game.camera &&
      MV.Game.camera.vcamActive !== undefined &&
      MV.Game.player &&
      MV.Game.player()
    );
  const say = (host, t) => {
    const m = host.querySelector('.vcmsg');
    if (m) m.textContent = t;
  };
  const download = (name, text) => {
    const a = E('a');
    a.href = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
    a.download = name;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  };

  window.vcUI = function () {
    const host = $('vcg');
    if (!host) return;
    host.textContent = '';
    const box = E('div', 'eh');
    box.style.cssText = 'margin-top:14px;border-top:1px solid var(--bd);padding-top:10px';
    host.appendChild(box);
    const h = E('h3', '', 'Virtual cameras');
    h.style.margin = '0 0 4px';
    box.append(
      h,
      E(
        'p',
        'hint',
        'A virtual camera is a saved camera setup with a priority. The highest-priority one that is on (and belongs to the current room) is live; the camera blends to it when it changes. With none, the room and Camera zones work as before.'
      )
    );
    if (!SEL || !cur()) SEL = list()[0] ? list()[0].id : '';
    // list + actions
    const top = E('div', 'row');
    top.style.cssText = 'gap:6px;flex-wrap:wrap;align-items:center;margin:6px 0';
    const b = (t, f, title) => {
      const x = E('button', '', t);
      x.onclick = f;
      if (title) x.title = title;
      return x;
    };
    top.append(
      b('+ New camera', () => {
        const c = VC.blank('Camera ' + (list().length + 1), list());
        const r = typeof rc !== 'undefined' && rc ? rc.id : '';
        c.room = r || '';
        list().push(c);
        SEL = c.id;
        commit();
      }),
      b('Duplicate', () => {
        const c = cur();
        if (!c) return;
        list().push(Object.assign(JSON.parse(JSON.stringify(c)), { id: c.id + '_copy', name: c.name + ' copy' }));
        SEL = c.id + '_copy';
        commit();
      }),
      b('Delete', () => {
        const c = cur();
        if (!c || !confirm('Delete the virtual camera "' + c.name + '"?')) return;
        S.vcams = list().filter(x => x !== c);
        SEL = '';
        commit();
      }),
      b(
        'Export',
        () => download('virtual-cameras.json', JSON.stringify(VC.clean(S.vcams), null, 2)),
        'Save the cameras to a file so another project can import them'
      ),
      b(
        'Import',
        () => {
          const f = E('input');
          f.type = 'file';
          f.accept = '.json,application/json';
          f.onchange = () => {
            const fr = new FileReader();
            fr.onload = () => {
              try {
                const imp = JSON.parse(fr.result);
                S.vcams = VC.clean(list().concat(Array.isArray(imp) ? imp : imp.vcams || []));
                SEL = S.vcams.length ? S.vcams[S.vcams.length - 1].id : '';
                save();
                vcUI();
              } catch (e) {
                say(host, 'That file is not a list of virtual cameras.');
              }
            };
            if (f.files[0]) fr.readAsText(f.files[0]);
          };
          f.click();
        },
        'Add the cameras from a file saved with Export'
      )
    );
    box.appendChild(top);
    const ls = E('div');
    ls.style.cssText = 'display:flex;flex-direction:column;gap:3px;max-width:520px;margin-bottom:8px';
    if (!list().length) ls.appendChild(E('p', 'hint', 'No virtual cameras yet.'));
    list()
      .slice()
      .sort((a, c) => c.priority - a.priority)
      .forEach(c => {
        const it = E(
          'button',
          'item' + (c.id === SEL ? ' on' : ''),
          c.priority + '   ' + c.name + (c.room ? '   (' + c.room + ')' : '   (any room)') + (c.on ? '' : '   [off]')
        );
        it.style.textAlign = 'left';
        if (!c.on) it.style.opacity = '.55';
        it.onclick = () => {
          SEL = c.id;
          vcUI();
        };
        ls.appendChild(it);
      });
    box.appendChild(ls);
    const c = cur();
    if (!c) {
      box.appendChild(E('p', 'vcmsg hint'));
      return;
    }
    const set = (k, v) => {
      c[k] = v;
      commit();
    };
    const pv = k => c.p[k];
    const setP = (k, v) => {
      if (v === undefined) delete c.p[k];
      else c.p[k] = v;
      commit();
    };
    const rm = rooms();
    const nm = E('input');
    nm.type = 'text';
    nm.value = c.name;
    nm.onchange = () => set('name', nm.value.trim() || c.id);
    const nl = E('label', '', 'Name ');
    nl.appendChild(nm);
    const on = E('label'),
      cb = E('input');
    cb.type = 'checkbox';
    cb.checked = c.on;
    cb.onchange = () => set('on', cb.checked);
    on.append(cb, ' On');
    box.appendChild(
      row(
        nl,
        on,
        num(
          'Priority',
          () => c.priority,
          v => set('priority', v === undefined ? 10 : v),
          { step: 1, title: 'Higher wins. Ties: the one lower in the list.' }
        )
      )
    );
    box.appendChild(
      row(
        sel(
          'Room',
          [['', 'Any room']].concat(rm.map(r => [r.id, r.n])),
          c.room,
          v => set('room', v),
          'Only live while the player is in this room'
        ),
        sel(
          'Follows',
          [
            ['player', 'The player'],
            ['point', 'A fixed spot'],
            ['entity', 'A placed entity (this room)'],
            ['boss', 'The awake boss']
          ],
          c.follow.kind,
          v => {
            c.follow.kind = v;
            commit();
          }
        )
      )
    );
    if (c.follow.kind === 'point')
      box.appendChild(
        row(
          num(
            'Spot x',
            () => c.follow.x,
            v => {
              c.follow.x = v === undefined ? 0 : v;
              commit();
            },
            { step: 0.5 }
          ),
          num(
            'Spot y',
            () => c.follow.y,
            v => {
              c.follow.y = v === undefined ? 0 : v;
              commit();
            },
            { step: 0.5 }
          )
        )
      );
    if (c.follow.kind === 'entity') {
      const r = rm.find(q => q.id === c.room),
        ents = r ? (r.r.ent || []).map(e => [e.id, e.type + ' (' + e.x + ', ' + e.y + ')']) : [];
      box.appendChild(
        row(
          ents.length
            ? sel('Entity', [['', '(pick one)']].concat(ents), c.follow.id, v => {
                c.follow.id = v;
                commit();
              })
            : E('span', 'hint', 'Pick a Room above to choose one of its entities.')
        )
      );
    }
    box.appendChild(
      row(
        num(
          'Offset x',
          () => c.offset.x,
          v => {
            c.offset.x = v === undefined ? 0 : v;
            commit();
          },
          { step: 0.25, title: 'Tiles the view is shifted from what it follows' }
        ),
        num(
          'Offset y',
          () => c.offset.y,
          v => {
            c.offset.y = v === undefined ? 0 : v;
            commit();
          },
          { step: 0.25 }
        ),
        num(
          'Zoom',
          () => c.zoom,
          v => set('zoom', v === undefined ? 1 : v),
          { step: 0.1, min: 0.25, max: 4 }
        ),
        num(
          'Tilt (deg)',
          () => c.rot,
          v => set('rot', v === undefined ? 0 : v),
          { step: 1, min: -180, max: 180 }
        )
      )
    );
    box.appendChild(
      row(
        sel(
          'Mode',
          [
            ['', 'Profile decides'],
            ['follow', 'Follow'],
            ['side', 'Side-scrolling'],
            ['topdown', 'Top-down'],
            ['fixed', 'Fixed']
          ],
          c.mode,
          v => set('mode', v)
        ),
        sel(
          'Based on profile',
          [['', "(room's own)"]].concat(MV.Camera.all(S.camProfiles).map(p => [p.id, p.name || p.id])),
          c.profile,
          v => set('profile', v)
        )
      )
    );
    const dm = (k, label, o) =>
      num(
        label,
        () => pv(k),
        v => setP(k, v),
        Object.assign({ ph: 'profile' }, o)
      );
    box.appendChild(E('strong', '', 'Follow settings (empty = taken from the profile)'));
    box.appendChild(
      row(
        dm('camSmoothX', 'Damping X', { step: 0.05, min: 0.02, max: 1, title: 'Lower = floatier' }),
        dm('camSmoothY', 'Damping Y', { step: 0.05, min: 0.02, max: 1 }),
        dm('camLookAhead', 'Look-ahead', { step: 0.25, min: 0, max: 8, title: 'Tiles the view leans the way you go' }),
        dm('camLookSpeed', 'Look-ahead smoothing', { step: 0.05 })
      )
    );
    box.appendChild(
      row(
        dm('camDeadX', 'Dead zone X', {
          step: 0.25,
          min: 0,
          max: 8,
          title: 'Move freely this far without moving the camera'
        }),
        dm('camDeadY', 'Dead zone Y', { step: 0.25, min: 0, max: 5 }),
        dm('camSoftX', 'Soft zone X', {
          step: 0.25,
          min: 0,
          max: 15,
          title: 'Past the dead zone: the most you may go before the camera is pushed. 0 = no limit'
        }),
        dm('camSoftY', 'Soft zone Y', { step: 0.25, min: 0, max: 10 })
      )
    );
    // bounds
    box.appendChild(E('strong', '', 'Bounds (the area the view may show, in tiles)'));
    const bd = c.bounds || ['', '', '', ''];
    const bn = (i, lab) =>
      num(
        lab,
        () => (c.bounds ? c.bounds[i] : undefined),
        v => {
          const b2 = (c.bounds || [0, 0, 0, 0]).slice();
          b2[i] = v === undefined ? 0 : v;
          c.bounds = b2;
          const ok = b2[2] > b2[0] && b2[3] > b2[1];
          commit(ok);
          if (!ok)
            say(host, 'Right and bottom must be bigger than left and top; the bounds are ignored until they are.');
        },
        { step: 1 }
      );
    const br = row(bn(0, 'Left'), bn(1, 'Top'), bn(2, 'Right'), bn(3, 'Bottom'));
    const room = rm.find(q => q.id === c.room);
    br.append(
      b('Whole room', () => {
        if (!room) return say(host, 'Pick a Room first.');
        c.bounds = [0, 0, room.r.gw, room.r.gh];
        commit();
      }),
      b('Clear', () => {
        c.bounds = null;
        commit();
      })
    );
    box.appendChild(br);
    const zones = room ? (room.r.ent || []).filter(e => e.type === 'camzone') : [];
    if (zones.length) {
      const zs = sel(
        'Take the box from a Camera zone',
        [['', '(pick a zone)']].concat(zones.map(z => [z.id, 'zone at ' + z.x + ', ' + z.y])),
        '',
        v => {
          const z = zones.find(q => q.id === v);
          if (!z) return;
          const w = +((z.props && z.props.width) || 4),
            hh = +((z.props && z.props.height) || 3);
          c.bounds = [z.x, z.y + 1 - hh, z.x + w, z.y + 1];
          commit();
        },
        'Draw the box with a Camera zone in the World tab, then pick it here'
      );
      box.appendChild(row(zs));
    } else
      box.appendChild(
        E(
          'p',
          'hint',
          'To draw the bounds: put a Camera zone in the room in the World tab, resize it, then pick it here (needs a Room).'
        )
      );
    // blend
    box.appendChild(E('strong', '', 'Blend (when this camera becomes live)'));
    const eased = Array.isArray(c.blend.ease);
    box.appendChild(
      row(
        num(
          'Time (s)',
          () => c.blend.time,
          v => {
            c.blend.time = v === undefined ? 0.8 : v;
            commit();
          },
          { step: 0.1, min: 0, max: 10 }
        ),
        sel(
          'Curve',
          VC.EASES.map(e => [e, e]).concat([['custom', 'Custom bezier']]),
          eased ? 'custom' : c.blend.ease,
          v => {
            c.blend.ease = v === 'custom' ? [0.4, 0, 0.2, 1] : v;
            commit();
          }
        )
      )
    );
    if (eased)
      box.appendChild(
        row(
          ...[0, 1, 2, 3].map(i =>
            num(
              'Bezier ' + (i + 1),
              () => c.blend.ease[i],
              v => {
                c.blend.ease[i] = v === undefined ? 0 : v;
                commit();
              },
              { step: 0.05, title: 'x1, y1, x2, y2 like a CSS cubic-bezier' }
            )
          )
        )
      );
    // preview
    box.appendChild(E('strong', '', 'Preview (the Camera preview window at the top shows it)'));
    const dbg = E('label'),
      dc = E('input');
    dc.type = 'checkbox';
    dc.checked = !!window.__vcDbg;
    dc.onchange = () => {
      window.__vcDbg = dc.checked;
      if (live()) MV.Game.camera.debug(dc.checked);
    };
    dbg.append(dc, ' Show the camera (view, dead zone, soft zone, look-ahead, bounds, zones)');
    box.appendChild(
      row(
        b('Make this camera live', () => {
          if (!live()) return say(host, 'Start the test room first.');
          MV.Game.camera.vcamSolo(c.id);
          MV.Game.camera.debug(!!window.__vcDbg);
          say(host, 'Live: "' + c.name + '". Press "Back to normal" to release it.');
        }),
        b(
          'Preview the blend',
          () => {
            if (!live()) return say(host, 'Start the test room first.');
            MV.Game.camera.vcamSolo(null);
            MV.Game.camera.debug(!!window.__vcDbg);
            setTimeout(() => {
              MV.Game.camera.vcamSolo(c.id);
              setTimeout(() => MV.Game.camera.vcamSolo(null), 2500 + c.blend.time * 1000);
            }, 600);
            say(host, 'Blending to "' + c.name + '" and back...');
          },
          'Switches to this camera, waits, and switches back so you can watch the blend'
        ),
        b('Back to normal', () => {
          if (live()) MV.Game.camera.vcamSolo(null);
          say(host, '');
        }),
        dbg
      )
    );
    const msg = E('p', 'vcmsg hint');
    box.appendChild(msg);
    VC.validate(S)
      .filter(i => i.text.includes('"' + c.name + '"'))
      .forEach(i => box.appendChild(E('div', i.level === 'error' ? 'cwarn' : 'hint', i.text)));
  };
})();
