// ---- clips: new, duplicate, delete ----
