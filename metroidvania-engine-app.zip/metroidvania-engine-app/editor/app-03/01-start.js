// Part 3 of the editor script (split from index.html; the parts run in order and share one scope, exactly like the old single script).
let CPI = 'default';
const camName = id => {
  const q = MV.Camera.all(S.camProfiles).find(q => q.id === id);
  return id ? (q ? q.name : id + ' (missing)') : "the room's own";
};
function fillMusic(r) {
  const s = $('rmu');
  if (!s) return;
  s.innerHTML = '';
  [['', '(no music)']].concat((S.sounds || []).filter(q => q.music).map(q => [q.id, q.name])).forEach(q => {
    const o = document.createElement('option');
    o.value = q[0];
    o.textContent = q[1];
    s.appendChild(o);
  });
  const v = (r && r.music) || '';
  if (v && ![...s.options].some(o => o.value === v)) {
    const o = document.createElement('option');
    o.value = v;
    o.textContent = '(missing) ' + v;
    s.appendChild(o);
  }
  s.value = v;
}
$('rmu').onchange = () => {
  if (rc) {
    rc.music = $('rmu').value;
    save();
  }
};
function fillCamSel(r) {
  fillMusic(r);
  const sel = $('cm');
  sel.innerHTML = '';
  const all = MV.Camera.all(S.camProfiles);
  all.forEach(q => {
    const o = document.createElement('option');
    o.value = q.id;
    o.textContent = q.name;
    sel.appendChild(o);
  });
  const c = r && r.cam;
  let v = c && c.profile ? c.profile : c && c.mode === 'fixed' ? 'locked' : 'default';
  if (!all.some(q => q.id === v)) v = 'default';
  sel.value = v;
}
function camEdit(fn) {
  const q = S.camProfiles.find(q => q.id === CPI);
  if (!q) return;
  fn(q);
  S.camProfiles = MV.Camera.cleanProfiles(S.camProfiles);
  save();
  if (rc) fillCamSel(rc);
}
function buildCam() {
  const host = $('pcb');
  if (!host) return;
  host.innerHTML = '';
  const E = (t, c, x) => {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };
  const all = MV.Camera.all(S.camProfiles);
  if (!all.some(q => q.id === CPI)) CPI = 'default';
  const eh = E('div', 'eh');
  eh.append(
    E('strong', '', 'Camera'),
    E(
      'span',
      'hint',
      'The default camera is below. A profile changes some of its settings, and a room, a Camera zone or a script picks which profile is used. Saved with your map.'
    )
  );
  host.appendChild(eh);
  const dh = E('h2', '', 'Default camera');
  dh.style.cssText = 'margin:.6rem 0 .2rem;font-size:1rem';
  host.appendChild(dh);
  const hs = E('div');
  host.appendChild(hs);
  tuneBuild(hs, g => g === 'Camera', null);
  const ph = E('h2', '', 'Camera profiles');
  ph.style.cssText = 'margin:1rem 0 .2rem;font-size:1rem';
  host.appendChild(ph);
  host.appendChild(
    E(
      'p',
      'hint',
      "A profile only holds the settings you tick; everything else comes from the default camera above. Built-in profiles cannot be changed, but you can copy one. Pick a room's profile in the World editor under Level Settings > Camera profile."
    )
  );
  const bar = E('div', 'row'),
    sel = document.createElement('select');
  all.forEach(q => {
    const o = document.createElement('option');
    o.value = q.id;
    o.textContent = q.name + (MV.data.camPresets.some(z => z.id === q.id) ? '  (built in)' : '  (' + q.id + ')');
    sel.appendChild(o);
  });
  sel.value = CPI;
  sel.onchange = () => {
    CPI = sel.value;
    buildCam();
  };
  bar.appendChild(sel);
  const addP = p0 => {
    let n = 1;
    while (all.concat(S.camProfiles).some(q => q.id === 'cam' + n)) n++;
    S.camProfiles.push({ id: 'cam' + n, name: 'Camera ' + n, p: MV.Camera.cleanP(p0 || {}) });
    S.camProfiles = MV.Camera.cleanProfiles(S.camProfiles);
    CPI = 'cam' + n;
    save();
    if (rc) fillCamSel(rc);
    buildCam();
  };
  bar.appendChild(btn('New profile', () => addP({})));
  const cur = all.find(q => q.id === CPI),
    mine = S.camProfiles.some(q => q.id === CPI);
  bar.appendChild(btn('Copy of this', () => addP(cur.p)));
  if (mine)
    bar.appendChild(
      btn('Delete', () => {
        if (
          !confirm(
            'Delete the profile "' + cur.name + '"? Rooms and zones that use it go back to the room\'s own camera.'
          )
        )
          return;
        S.camProfiles = S.camProfiles.filter(q => q.id !== CPI);
        CPI = 'default';
        save();
        if (rc) fillCamSel(rc);
        buildCam();
      })
    );
  bar.appendChild(btn('Test movement', mtOpen));
  host.appendChild(bar);
  const fb = E('div', 'pgroup');
  host.appendChild(fb);
  if (!mine) {
    const keys = Object.keys(cur.p);
    fb.appendChild(
      E(
        'p',
        'hint',
        keys.length
          ? cur.name +
              ' changes: ' +
              keys
                .map(k =>
                  MV.data.camExtra[k]
                    ? MV.data.camExtra[k].label + ' = ' + ((MV.data.camExtra[k].names || {})[cur.p[k]] || cur.p[k])
                    : k + ' = ' + cur.p[k]
                )
                .join(', ') +
              '.'
          : cur.name + ' changes nothing: it is the default camera.'
      )
    );
    host.appendChild(E('p', 'hint', "To use it in a script: MV.Game.camera.set('" + cur.id + "')"));
  } else {
    const nm = mkText('Name', cur.name, v => {
      camEdit(q => {
        q.name = v.trim() || q.id;
      });
      buildCam();
    });
    fb.appendChild(nm);
    fb.appendChild(
      E(
        'p',
        'hint',
        'Id: ' +
          cur.id +
          "  (used by Camera zones and scripts: MV.Game.camera.set('" +
          cur.id +
          "')). Tick a setting to change it in this profile."
      )
    );
    const sc = MV.data.playerSchema,
      ex = MV.data.camExtra,
      keys = [
        'view',
        'modeX',
        'modeY',
        'lockX',
        'lockY',
        'bounds',
        'pad',
        'biasSrc',
        'zoom',
        'zoomSpeed',
        'rot',
        'edge',
        'softPad',
        'manualPan',
        'panRange',
        'bossFrame',
        'framePad',
        'frameMin',
        'doorFx',
        'doorTime',
        'roomFade'
      ].concat(MV.Camera.fields().filter(k => sc[k]));
    keys.forEach(k => {
      const d = sc[k] || ex[k],
        on = cur.p[k] !== undefined,
        row = E('div', 'prow'),
        lb = document.createElement('label'),
        cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = on;
      cb.style.width = 'auto';
      const nm2 = E('span', '', sc[k] ? d.label + (d.unit ? ' (' + d.unit + ')' : '') : d.label);
      let inp;
      if (d.t === 'select') {
        inp = document.createElement('select');
        d.o.forEach(v => {
          const o = document.createElement('option');
          o.value = v;
          o.textContent = (d.names && d.names[v]) || v;
          inp.appendChild(o);
        });
        inp.value = on ? cur.p[k] : d.def;
      } else {
        inp = document.createElement('input');
        inp.type = 'number';
        inp.min = d.min;
        inp.max = d.max;
        inp.step = d.step;
        const dv = sc[k] ? (S.player[k] !== undefined ? S.player[k] : d.def) : d.def === null ? '' : d.def;
        inp.value = on ? cur.p[k] : dv;
      }
      inp.disabled = !on;
      const wr = () =>
        camEdit(q => {
          if (cb.checked) {
            const v = inp.value;
            q.p[k] = d.t === 'select' ? v : v === '' ? undefined : +v;
            if (q.p[k] === undefined) delete q.p[k];
          } else delete q.p[k];
        });
      cb.onchange = () => {
        inp.disabled = !cb.checked;
        wr();
      };
      inp.onchange = wr;
      const hp = E(
        'div',
        'hint',
        (d.help || '') + (sc[k] ? ' Default camera: ' + (S.player[k] !== undefined ? S.player[k] : d.def) + '.' : '')
      );
      lb.append(cb, nm2, inp);
      row.append(lb, hp);
      fb.appendChild(row);
    });
  }
  const dt = document.createElement('details');
  dt.innerHTML =
    '<summary>How do I set up...?</summary><p class="hint"><b>Direction bias:</b> in the default camera (or a profile) set Look ahead (tiles) and Look-ahead speed; the view leans the way you face. Direction bias delay stops it flipping when you tap back and forth, Bias grows with speed makes it lean only while you run, and in a profile "Direction bias follows" picks facing, movement or the keys you hold. <b>Vertical speed:</b> Look down when falling and Look up when rising grow smoothly (eased) from "Speed where it starts" to "Speed for the full amount"; Vertical smoothing at top speed makes the camera catch up faster in a long fall. <b>Bounds:</b> by default the view stays inside the room. A profile can set Room limits to "extra room" (pad tiles past each edge) or "no limit". <b>Breaking the bounds:</b> place a Camera zone and set Bounds to "break room limits" (the view may leave the room while you are inside it), or to "limit view to this box" (the view is kept inside the zone, good for a boss arena or a small secret). <b>Ledge hint:</b> set Ledge hint: look down (tiles). When you stand still at the edge of a drop (the way you face or push) that is at least "smallest drop" tiles deep, or a pit with no floor, the view slides down after the wait time. <b>Look up or down on demand:</b> Look up and down (hold the key). <b>Different cameras per room:</b> make profiles here (built-ins: Vertically centered, Vertically locked, Horizontally locked, Fully locked, No bounds) and pick one per room in Level Settings. <b>Swapping while playing:</b> a Camera zone swaps to its profile while you are inside it (smallest zone wins) and the view glides there over its Blend time; from a script use MV.Game.camera.set(id, blendSeconds) and MV.Game.camera.reset().</p>';
  host.appendChild(dt);
  if (window.vcUI) vcUI();
  if (window.cpvUI) cpvUI();
}
function buildCt() {
  const host = $('ctb');
  if (!host) return;
  const C = S.controls;
  for (const k in C.pad)
    if (
      (/^m:/.test(k) && !S.moves.some(m => 'm:' + m.id === k)) ||
      (/^a:/.test(k) && !S.attacks.some(a => 'a:' + a.id === k))
    )
      delete C.pad[k];
  host.innerHTML = '';
  const mk = (t, c, x) => {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };
  const tab = (head, rows) => {
    const t = mk('table', 'ctt'),
      h = mk('tr');
    head.forEach(x => h.appendChild(mk('th', '', x)));
    t.appendChild(h);
    rows.forEach(r => {
      const tr = mk('tr');
      r.forEach(c => {
        const td = mk('td');
        if (typeof c === 'string') td.textContent = c;
        else td.appendChild(c);
        tr.appendChild(td);
      });
      t.appendChild(tr);
    });
    return t;
  };
  host.appendChild(mk('strong', '', 'Basic actions'));
  const names = {
    Left: 'Move left',
    Right: 'Move right',
    Up: 'Up (look up, climb)',
    Down: 'Down (crouch, climb)',
    Jump: 'Jump'
  };
  const rows = MV.Controls.CORE.map(k => {
    const keys = C.keys[k],
      cell = mk('span');
    cell.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap';
    for (let i = 0; i < 3; i++) {
      const cur = keys[i];
      cell.appendChild(
        learnKeyBtn(cur ? MV.Controls.nice(cur) : '-', code =>
          ctlSet(c => {
            const l = c.keys[k].slice();
            if (code === null) l.splice(i, 1);
            else l[i] = code;
            c.keys[k] = l.filter(x => x);
          })
        )
      );
    }
    return [
      names[k],
      cell,
      k === 'Jump'
        ? padPick(C.pad.Jump, v =>
            ctlSet(c => {
              c.pad.Jump = v;
            })
          )
        : 'Left stick or D-pad'
    ];
  });
  rows.push([
    'Interact (talk, open, checkpoint)',
    'The key set on each sign, chest, checkpoint or character',
    padPick(C.pad.Interact, v =>
      ctlSet(c => {
        c.pad.Interact = v;
      })
    )
  ]);
  host.appendChild(tab(['Action', 'Keyboard (up to 3 keys; click one, then press a key)', 'Gamepad'], rows));
  host.appendChild(mk('strong', '', 'Moves and attacks'));
  const rr = [],
    after = () => ctlWarn();
  S.moves
    .filter(m => m.type !== 'swim')
    .forEach(m => {
      const k = keyField(MV.data.moveFields.key, m, 'key', after),
        w = keyField(MV.data.moveFields.with, m, 'with', after);
      k.removeChild(k.firstChild);
      w.removeChild(w.firstChild);
      rr.push([
        m.label + '  (move)',
        k,
        w,
        padPick(C.pad['m:' + m.id], v =>
          ctlSet(c => {
            if (v < 0) delete c.pad['m:' + m.id];
            else c.pad['m:' + m.id] = v;
          })
        )
      ]);
    });
  const cl = m => {
    Object.assign(m, MV.Attacks.clean1(m));
    abSync();
  };
  S.attacks.forEach(a => {
    const k = keyField(MV.Attacks.FIELDS.key, a, 'key', after, cl),
      w = keyField(MV.Attacks.FIELDS.with, a, 'with', after, cl);
    k.removeChild(k.firstChild);
    w.removeChild(w.firstChild);
    rr.push([
      a.label + '  (attack)',
      k,
      w,
      padPick(C.pad['a:' + a.id], v =>
        ctlSet(c => {
          if (v < 0) delete c.pad['a:' + a.id];
          else c.pad['a:' + a.id] = v;
        })
      )
    ]);
  });
  if (rr.length) host.appendChild(tab(['Name', 'Key', 'Also hold', 'Gamepad button'], rr));
  else host.appendChild(mk('p', 'hint', 'No moves or attacks yet. Build them in their tabs; they show up here.'));
  const r = mk('div', 'row');
  r.append(
    btn('Reset to defaults', () => {
      S.controls = MV.Controls.clean(null);
      save();
      buildCt();
    }),
    btn('Test movement', mtOpen)
  );
  host.appendChild(r);
  ctlWarn();
  if (!CTT)
    CTT = setInterval(() => {
      const g = $('ctg');
      if (!g || $('pct').hidden) return;
      const p = navigator.getGamepads ? [...navigator.getGamepads()].find(x => x && x.connected) : null;
      g.textContent = p
        ? 'Gamepad found: ' + p.id.slice(0, 60)
        : 'No gamepad found. Connect one and press a button on it; the browser only sees it after that.';
    }, 700);
}
