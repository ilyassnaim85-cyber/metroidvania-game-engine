function bossForm() {
  const b = cb(),
    F = $('bform'),
    sc = $('bsl').scrollTop;
  F.innerHTML = '';
  if (!b) return;
  const det = (t, o) => {
    const d = document.createElement('details'),
      su = document.createElement('summary');
    d.open = t in BOPEN ? BOPEN[t] : !!o;
    d.ontoggle = () => {
      BOPEN[t] = d.open;
    };
    su.textContent = t;
    d.appendChild(su);
    F.appendChild(d);
    return d;
  };
  if (BSUB === 'patterns') patForm(det('Pattern hitboxes', true), b, cpat());
  const d1 = det('Boss', BSUB === 'arena'),
    g = document.createElement('div');
  g.className = 'mvf';
  for (const k in MV.data.bossFields) {
    if (k === 'ai' || k === 'brain') continue; // chosen in the Patterns tab under Boss AI
    const f = MV.data.bossFields[k];
    g.appendChild(
      f.t === 'sound'
        ? sndSel(f.label, b[k], v =>
            bedit(x => {
              x[k] = v;
            })
          )
        : f.t === 'select'
          ? mkSel(
              f.label,
              f.o.map(o => [o, o]),
              b[k],
              v =>
                bedit(x => {
                  x[k] = v;
                })
            )
          : f.t === 'number'
            ? mkNum(f.label, b[k], f.min, f.max, f.step, v =>
                bedit(x => {
                  x[k] = v;
                })
              )
            : mkText(f.label, b[k], v =>
                bedit(x => {
                  x[k] = v;
                })
              )
    );
  }
  g.appendChild(
    mkNum('Sprite width (tiles)', b.sprite.w, 0.5, 12, 0.1, v =>
      bedit(x => {
        x.sprite.w = v;
      })
    )
  );
  g.appendChild(
    mkNum('Sprite height (tiles)', b.sprite.h, 0.5, 12, 0.1, v =>
      bedit(x => {
        x.sprite.h = v;
      })
    )
  );
  d1.appendChild(g);
  const d2 = det('Phases'),
    hp = document.createElement('p');
  hp.className = 'hint';
  hp.textContent =
    'A phase starts when health drops to its percentage. With no phases the boss cycles through all patterns.';
  d2.appendChild(hp);
  b.phases.forEach((ph, i) => {
    const box = document.createElement('div'),
      f = document.createElement('div'),
      pl = document.createElement('div');
    box.className = 'mv';
    f.className = 'mvf';
    pl.className = 'row';
    f.appendChild(
      mkNum('Starts at or below health (%)', ph.below, 1, 100, 1, v =>
        bedit(x => {
          x.phases[i].below = +v;
        })
      )
    );
    f.appendChild(
      mkNum('Pause between patterns (s)', ph.idle, 0, 10, 0.1, v =>
        bedit(x => {
          x.phases[i].idle = +v;
        })
      )
    );
    f.appendChild(
      mkNum('Speed (1 = normal)', ph.speed, 0.2, 3, 0.1, v =>
        bedit(x => {
          x.phases[i].speed = +v;
        })
      )
    );
    f.appendChild(
      mkNum('Phase change time (s)', ph.enter, 0, 10, 0.1, v =>
        bedit(x => {
          x.phases[i].enter = +v;
        })
      )
    );
    box.appendChild(f);
    b.patterns.forEach(q => {
      const l = document.createElement('label'),
        c = document.createElement('input');
      c.type = 'checkbox';
      c.checked = ph.patterns.includes(q.id);
      c.onchange = () =>
        bedit(x => {
          const a = x.phases[i].patterns,
            k = a.indexOf(q.id);
          if (c.checked && k < 0) a.push(q.id);
          if (!c.checked && k >= 0) a.splice(k, 1);
        });
      l.append(c, ' ' + q.name);
      pl.appendChild(l);
    });
    box.appendChild(pl);
    box.appendChild(
      btn('Remove phase', () =>
        bedit(x => {
          x.phases.splice(i, 1);
        })
      )
    );
    d2.appendChild(box);
  });
  d2.appendChild(
    btn('Add phase', () =>
      bedit(x => {
        if (x.phases.length < 6)
          x.phases.push({
            below: x.phases.length ? 50 : 100,
            idle: 1.2,
            speed: 1,
            enter: x.phases.length ? 1 : 0,
            patterns: []
          });
      })
    )
  );
  const dW = det('Body shape and weak spots'),
    wh = document.createElement('p');
  wh.className = 'hint';
  wh.textContent =
    'The shape your attacks must touch. Weak spots are boxes on the boss (they flip when it turns) that take more damage. Positions are tiles from the middle of the body.';
  dW.appendChild(wh);
  if (b.shape === 'polygon') {
    b.pts.forEach((q, i) => {
      const r = document.createElement('div'),
        g2 = document.createElement('div');
      r.className = 'mv';
      g2.className = 'mvf';
      g2.appendChild(
        mkNum('Corner ' + (i + 1) + ' x (-1 to 1)', q.x, -1, 1, 0.05, v =>
          bedit(x => {
            x.pts[i].x = +v;
          })
        )
      );
      g2.appendChild(
        mkNum('y', q.y, -1, 1, 0.05, v =>
          bedit(x => {
            x.pts[i].y = +v;
          })
        )
      );
      r.appendChild(g2);
      r.appendChild(
        btn('Remove corner', () =>
          bedit(x => {
            if (x.pts.length > 3) x.pts.splice(i, 1);
          })
        )
      );
      dW.appendChild(r);
    });
    dW.appendChild(
      btn('Add corner', () =>
        bedit(x => {
          if (x.pts.length < 16) x.pts.push({ x: 0, y: 0.5 });
        })
      )
    );
  }
  b.weak.forEach((q, i) => {
    const r = document.createElement('div'),
      g2 = document.createElement('div');
    r.className = 'mv';
    g2.className = 'mvf';
    g2.appendChild(
      mkText('Weak spot name', q.name, v =>
        bedit(x => {
          x.weak[i].name = v;
        })
      )
    );
    [
      ['x', 'x', -8, 8, 0.1],
      ['y', 'y', -8, 8, 0.1],
      ['w', 'Width', 0.1, 8, 0.1],
      ['h', 'Height', 0.1, 8, 0.1],
      ['mult', 'Damage x', 0, 10, 0.25]
    ].forEach(a =>
      g2.appendChild(
        mkNum(a[1], q[a[0]], a[2], a[3], a[4], v =>
          bedit(x => {
            x.weak[i][a[0]] = +v;
          })
        )
      )
    );
    r.appendChild(g2);
    r.appendChild(
      btn('Remove weak spot', () =>
        bedit(x => {
          x.weak.splice(i, 1);
        })
      )
    );
    dW.appendChild(r);
  });
  dW.appendChild(
    btn('Add weak spot', () =>
      bedit(x => {
        if (x.weak.length < 6)
          x.weak.push({ name: 'Weak spot ' + (x.weak.length + 1), x: 0, y: -b.h * 0.5, w: 0.6, h: 0.6, mult: 2 });
      })
    )
  );
  const d3 = det('Boss animations (from the Animations tab)'),
    ht = document.createElement('p');
  ht.className = 'hint';
  ht.textContent =
    'Pick one animation clip per state. Make the clips in the Animations tab (frames can be any size). Awakened should play once: the boss cannot attack or be hurt until it ends, and its length is the clip length. A pattern can use its own clip (Patterns tab); anything left empty uses Normal.';
  d3.appendChild(ht);
  MV.Boss.CLIPS.forEach(c =>
    d3.appendChild(
      clipSel(c[1], b.clips[c[0]], v =>
        bedit(x => {
          if (v) x.clips[c[0]] = v;
          else delete x.clips[c[0]];
        })
      )
    )
  );
  {
    const pv = document.createElement('canvas');
    pv.id = 'bap';
    pv.width = 190;
    pv.height = 140;
    d3.appendChild(pv);
    d3.appendChild(
      mkSel(
        'Preview',
        MV.Boss.CLIPS.map(c => [c[0], c[1].replace(/ \(.*\)/, '')]),
        BAN,
        v => {
          BAN = v;
          BAT = 0;
        }
      )
    );
    const old = Object.keys(b.sprite.anims || {}).length;
    if (old) {
      const o = document.createElement('p');
      o.className = 'hint';
      o.textContent =
        'This boss still has ' +
        old +
        ' old-style animation' +
        (old > 1 ? 's' : '') +
        ' (made before clips). They only show where no clip is set above.';
      d3.appendChild(o);
      d3.appendChild(
        btn('Remove the old animations', () =>
          bedit(x => {
            x.sprite.anims = {};
          })
        )
      );
    }
  }
  $('bsl').scrollTop = sc;
}
function arenaSize(nw, nh) {
  bedit(b => {
    const A = b.arena;
    nw = Math.max(8, Math.min(80, nw || A.gw));
    nh = Math.max(6, Math.min(50, nh || A.gh));
    const g = [];
    for (let y = 0; y < nh; y++) {
      const r = A.grid[y - (nh - A.gh)];
      g.push(r === undefined ? '.'.repeat(nw) : r.slice(0, nw).padEnd(nw, /^#+$/.test(r) ? '#' : '.'));
    }
    A.by = Math.max(0, Math.min(nh - 1, A.by + nh - A.gh));
    A.bx = Math.min(A.bx, nw - 1);
    A.gw = nw;
    A.gh = nh;
    A.grid = g;
  });
}
function bossTools() {
  const t = $('btool'),
    b = cb();
  t.innerHTML = '';
  $('bpat').hidden = BSUB !== 'patterns' || !b;
  if (!b) return;
  if (BSUB === 'arena') {
    [
      ['#', 'Wall'],
      ['=', 'Platform'],
      ['^', 'Hazard'],
      ['/', 'Slope up-right'],
      ['\\', 'Slope up-left'],
      ['~', 'Water'],
      ['.', 'Erase'],
      ['P', 'Boss spawn']
    ].forEach(a => {
      const x = btn(a[1], () => {
        BTOOL = a[0];
        bossTools();
      });
      if (BTOOL === a[0]) x.className = 'on';
      t.appendChild(x);
    });
    t.appendChild(mkNum('Arena width', b.arena.gw, 8, 80, 1, v => arenaSize(+v, b.arena.gh)));
    t.appendChild(mkNum('Arena height', b.arena.gh, 6, 50, 1, v => arenaSize(b.arena.gw, +v)));
  } else {
    const s = document.createElement('span');
    s.className = 'hint';
    s.textContent =
      'Move the time slider, then drag a hitbox (or the boss) to where it should be at that moment. Each drag makes a keyframe.';
    t.appendChild(s);
  }
}
function bossPatUI() {
  const b = cb(),
    c = $('bpc');
  c.innerHTML = '';
  if (!b || BSUB !== 'patterns') return;
  const p = cpat();
  c.appendChild(
    mkSel(
      'Pattern',
      b.patterns.length ? b.patterns.map((q, i) => [String(i), q.name]) : [['', '(none)']],
      String(PI),
      v => {
        PI = +v;
        HI = 'body';
        BT = 0;
        KSEL = null;
        bossUI();
      }
    )
  );
  c.appendChild(
    btn('Add pattern', () =>
      bedit(x => {
        if (x.patterns.length >= 16) return;
        x.patterns.push({ name: 'Pattern ' + (x.patterns.length + 1), duration: 2, hitboxes: [], body: [] });
        PI = x.patterns.length - 1;
        HI = 'body';
        BT = 0;
      })
    )
  );
  if (!p) return;
  c.appendChild(
    btn('Duplicate', () =>
      bedit(x => {
        if (x.patterns.length >= 16) return;
        const q = JSON.parse(JSON.stringify(x.patterns[PI]));
        q.id = '';
        q.name += ' copy';
        q.hitboxes.forEach(h => {
          h.id = '';
        });
        x.patterns.push(q);
        PI = x.patterns.length - 1;
      })
    )
  );
  c.appendChild(
    btn('Delete pattern', () => {
      if (confirm('Delete the pattern "' + p.name + '"?'))
        bedit(x => {
          x.patterns.splice(PI, 1);
          PI = Math.max(0, PI - 1);
          HI = 'body';
          BT = 0;
        });
    })
  );
  c.appendChild(
    mkText('Name', p.name, v =>
      bedit(x => {
        x.patterns[PI].name = v;
      })
    )
  );
  c.appendChild(
    mkNum('Length (s)', p.duration, 0.2, 20, 0.1, v =>
      bedit(x => {
        x.patterns[PI].duration = +v;
        if (BT > +v) BT = +v;
      })
    )
  );
  c.appendChild(
    clipSel('Boss animation during the attack', p.clip, v =>
      bedit(x => {
        x.patterns[PI].clip = v;
      })
    )
  );
  c.appendChild(
    mkNum('Warning before it starts (s)', p.warn, 0, 5, 0.05, v =>
      bedit(x => {
        x.patterns[PI].warn = +v;
      })
    )
  );
  c.appendChild(
    sndSel('Sound at the start', p.snd, v =>
      bedit(x => {
        x.patterns[PI].snd = v;
      })
    )
  );
  {
    const hd = document.createElement('strong');
    hd.textContent = 'Boss AI';
    c.appendChild(hd);
  }
  c.appendChild(
    mkSel(
      'AI',
      [
        ['built-in', 'Built-in: walks toward you and picks patterns (in order or by rules)'],
        ['script', 'Script: a JavaScript function decides everything']
      ],
      b.ai,
      v =>
        bedit(x => {
          x.ai = v;
        })
    )
  );
  if (b.ai === 'script') {
    const ids = b.patterns.map(q => q.id),
      fnName = (b.brain || (b.id + 'Brain').replace(/[^\w-]/g, '')).slice(0, 24),
      have = MV.Script.fnNames(S.scripts).has(b.brain);
    const h = document.createElement('p');
    h.className = 'hint';
    h.textContent =
      'The script runs every frame while the boss is idle. It can walk, jump, shoot, make its own attack boxes and start your patterns with me.attack("id"). Patterns you made here: ' +
      (ids.length ? ids.join(', ') : '(none yet)') +
      '. The old rules below do not apply while AI is Script.';
    c.appendChild(h);
    c.appendChild(
      mkText('AI script function', b.brain, v =>
        bedit(x => {
          x.brain = v.trim();
        })
      )
    );
    const st = document.createElement('p');
    st.className = have ? 'hint' : 'cwarn';
    st.textContent = !b.brain
      ? 'Name the function, or press Create script below.'
      : have
        ? 'A script defines "' + b.brain + '".'
        : 'No script defines fn("' + b.brain + '", ...) yet.';
    c.appendChild(st);
    const row = document.createElement('div');
    row.className = 'row';
    row.append(
      btn(have ? 'Open the Scripts tab' : 'Create the script', () => {
        if (!have) {
          const first = ids[0],
            code =
              '// AI for ' +
              b.name +
              '. Runs every frame while the boss is idle. See SCRIPTING.md.\n' +
              "fn('" +
              fnName +
              "', me => {\n  me.turn(me.dx);                      // face the player\n  if (me.dist > 4) me.walk(me.dx, 3);   // walk toward them\n" +
              (first
                ? "  else if (me.ready('" + first + "')) me.attack('" + first + "');   // start one of your patterns\n"
                : '') +
              '});\n';
          S.scripts = MV.Script.clean(S.scripts.concat([{ name: 'AI: ' + b.name, on: true, code }]));
          bedit(x => {
            x.ai = 'script';
            x.brain = fnName;
          });
        }
        tab('scripts');
      })
    );
    c.appendChild(row);
  }
  if (b.ai !== 'script' && b.select !== 'rules') {
    const h = document.createElement('p');
    h.className = 'hint';
    h.textContent = 'This boss picks its attacks in order, so these rules are ignored.';
    c.appendChild(h);
    c.appendChild(
      btn('Pick attacks by rules', () =>
        bedit(x => {
          x.select = 'rules';
        })
      )
    );
  }
  if (b.ai !== 'script' && b.select === 'rules') {
    const h = document.createElement('p');
    h.className = 'hint';
    h.textContent =
      'The boss only picks this pattern when all of these are true. Distance is measured from the middle of the boss to the middle of you. Example: a close slash 0 to 4 tiles, a projectile 5 to 20 with a cooldown; weight sets how often each is chosen.';
    c.appendChild(h);
    c.appendChild(
      mkSel(
        'Only when you are',
        [
          ['any', 'Anywhere (up or down)'],
          ['player above', 'Above the boss'],
          ['player level', 'Level with the boss'],
          ['player below', 'Below the boss']
        ],
        p.vert,
        v =>
          bedit(x => {
            x.patterns[PI].vert = v;
          })
      )
    );
    c.appendChild(
      mkNum('Most times in a row', p.repeat, 1, 8, 1, v =>
        bedit(x => {
          x.patterns[PI].repeat = +v;
        })
      )
    );
    c.appendChild(
      mkNum('Only when you are at least this far (tiles)', p.min, 0, 200, 0.5, v =>
        bedit(x => {
          x.patterns[PI].min = +v;
        })
      )
    );
    c.appendChild(
      mkNum('Only when you are at most this far (tiles)', p.max, 0, 200, 0.5, v =>
        bedit(x => {
          x.patterns[PI].max = +v;
        })
      )
    );
    c.appendChild(
      mkSel(
        'Only when',
        [
          ['any', 'Always'],
          ['player on ground', 'You are on the ground'],
          ['player in air', 'You are in the air']
        ],
        p.at,
        v =>
          bedit(x => {
            x.patterns[PI].at = v;
          })
      )
    );
    c.appendChild(
      mkNum('Only when boss health is below (%)', p.hpBelow, 1, 100, 1, v =>
        bedit(x => {
          x.patterns[PI].hpBelow = +v;
        })
      )
    );
    c.appendChild(
      mkNum('Only when boss health is above (%)', p.hpAbove, 0, 99, 1, v =>
        bedit(x => {
          x.patterns[PI].hpAbove = +v;
        })
      )
    );
    c.appendChild(
      mkNum('Cooldown after use (s)', p.cd, 0, 120, 0.5, v =>
        bedit(x => {
          x.patterns[PI].cd = +v;
        })
      )
    );
    c.appendChild(
      mkNum('Weight (higher = chosen more often)', p.weight, 0, 20, 0.5, v =>
        bedit(x => {
          x.patterns[PI].weight = +v;
        })
      )
    );
  }
  c.appendChild(
    mkSel(
      'During the warning',
      [
        ['no', 'Stays facing the same way'],
        ['yes', 'Keeps turning to face you']
      ],
      p.track,
      v =>
        bedit(x => {
          x.patterns[PI].track = v;
        })
    )
  );
  c.appendChild(
    mkSel(
      'Aim',
      [
        ['fixed', 'Along the path as drawn (mirrored to face you)'],
        ['at player', 'Turn the whole path toward you (also turns while warning)']
      ],
      p.aim,
      v =>
        bedit(x => {
          x.patterns[PI].aim = v;
        })
    )
  );
  c.appendChild(
    mkNum('Aim: most it may turn (degrees)', p.aimMax, 0, 180, 5, v =>
      bedit(x => {
        x.patterns[PI].aimMax = +v;
      })
    )
  );
  c.appendChild(
    mkSel(
      'Body movement reaches',
      [
        ['fixed', 'The path as drawn'],
        ['to player', 'Stretched to end where you stand (up to 2x)']
      ],
      p.reach,
      v =>
        bedit(x => {
          x.patterns[PI].reach = v;
        })
    )
  );
  c.appendChild(
    btn(BPLAY ? 'Pause' : 'Play', () => {
      BPLAY = !BPLAY;
      if (BPLAY && BT >= p.duration - 0.01) BT = 0;
      bossPatUI();
      bossTickStart();
    })
  );
  const sl = document.createElement('input');
  sl.type = 'range';
  sl.id = 'bts';
  sl.min = 0;
  sl.max = p.duration;
  sl.step = 0.01;
  sl.value = BT;
  sl.style.minWidth = '200px';
  sl.oninput = () => {
    BT = +sl.value;
    BPLAY = false;
    syncBt();
    drawBoss();
    drawTl();
  };
  c.appendChild(sl);
  const tl = document.createElement('span');
  tl.id = 'btl';
  tl.className = 'hint';
  c.appendChild(tl);
  c.appendChild(btn('Delete keyframe', delKey));
  const iv = document.createElement('div');
  iv.className = 'row';
  iv.appendChild(
    Object.assign(document.createElement('strong'), { textContent: 'Cannot be hurt (invincible moments): ' })
  );
  p.inv.forEach((w, i) => {
    iv.appendChild(
      mkNum('from (s)', w.from, 0, p.duration, 0.05, v =>
        bedit(x => {
          x.patterns[PI].inv[i].from = +v;
        })
      )
    );
    iv.appendChild(
      mkNum('until (s)', w.to, 0, p.duration, 0.05, v =>
        bedit(x => {
          x.patterns[PI].inv[i].to = +v;
        })
      )
    );
    iv.appendChild(
      btn('Remove', () =>
        bedit(x => {
          x.patterns[PI].inv.splice(i, 1);
        })
      )
    );
  });
  iv.appendChild(
    btn('Add invincible moment', () =>
      bedit(x => {
        const pp = x.patterns[PI];
        if (pp.inv.length < 8) pp.inv.push({ from: 0, to: Math.min(pp.duration, 0.5) });
      })
    )
  );
  c.appendChild(iv);
  syncBt();
}
