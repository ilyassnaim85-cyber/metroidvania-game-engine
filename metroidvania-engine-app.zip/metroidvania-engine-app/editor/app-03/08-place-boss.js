// Stamp the boss's arena into the room (centered on the drop point) and add the boss itself.
function placeBoss(bid, cx, cy) {
  const b = S.bosses.find(q => q.id === bid);
  if (!b || !rc) return;
  const A = b.arena;
  if (A.gw > rc.gw || A.gh > rc.gh) {
    $('rw').value = Math.max(rc.gw, A.gw);
    $('rh').value = Math.max(rc.gh, A.gh);
    rsz();
  }
  const x0 = Math.max(0, Math.min(rc.gw - A.gw, cx - Math.floor(A.gw / 2))),
    y0 = Math.max(0, Math.min(rc.gh - A.gh, cy - Math.floor(A.gh / 2)));
  for (let y = 0; y < A.gh; y++)
    rc.grid[y0 + y] = rc.grid[y0 + y].slice(0, x0) + A.grid[y] + rc.grid[y0 + y].slice(x0 + A.gw);
  const inside = (px, py) => px >= x0 && px < x0 + A.gw && py >= y0 && py < y0 + A.gh;
  rc.tr = rc.tr.filter(t => !inside(t.x, t.y));
  rc.ent = rc.ent.filter(q => !inside(q.x, q.y));
  rc.ent.push({
    id: 'e' + rid(),
    type: 'boss',
    x: x0 + A.bx,
    y: y0 + A.by,
    props: { boss: bid, arena: x0 + ',' + y0 + ',' + (x0 + A.gw) + ',' + (y0 + A.gh) }
  });
  save();
  drawT();
  drawEn();
  drawTr();
}
$('cv').ondragover = e => e.preventDefault();
$('cv').ondrop = e => {
  e.preventDefault();
  const t = e.dataTransfer.getData('text/plain');
  if (!rc || !(t.startsWith('boss:') || t === 'lamp:' || t === 'dark:')) return;
  const r = rr(),
    x = Math.floor(((e.clientX - r.left) / r.width) * rc.gw),
    y = Math.floor(((e.clientY - r.top) / r.height) * rc.gh);
  if (t === 'lamp:' || t === 'dark:')
    newLamp(
      Math.max(0, Math.min(rc.gw - 1, x)),
      Math.max(0, Math.min(rc.gh - 1, y)),
      t === 'dark:' ? 'darkness' : 'lamp'
    );
  else placeBoss(t.slice(5), x, y);
};
$('lampchip').ondragstart = e => {
  e.dataTransfer.setData('text/plain', 'lamp:');
};
$('lampchip').onclick = () => {
  $('ety').value = 'lamp';
  setTool('N');
};
$('darkchip').ondragstart = e => {
  e.dataTransfer.setData('text/plain', 'dark:');
};
$('darkchip').onclick = () => {
  $('ety').value = 'darkness';
  setTool('N');
};

