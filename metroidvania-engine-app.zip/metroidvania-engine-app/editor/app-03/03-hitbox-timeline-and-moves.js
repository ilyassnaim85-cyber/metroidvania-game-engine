// The hitbox timeline. o.T() is the attack or move; o.list its hitbox list ('hitboxes' or 'hit'); o.curve adds the speed curve; o.vel(t) is the base forward speed (to show the player move in the preview); o.an() its animation; o.ch(fn) changes it, cleans it and saves.
function tlBuild(host, key, o) {
  const st = TLS[key] || (TLS[key] = { t: 0, hi: 0, ks: null, play: false });
  host.innerHTML = '';
  const SH = o.sh || { hits: true, path: true, curve: true },
    T = () => o.T(),
    HB = () => (SH.hits ? T()[o.list] : []),
    D = () => Math.max(0.05, o.dur()),
    CV = !!o.curve,
    PA = !!o.path,
    CVU = CV && SH.curve,
    PAU = PA && SH.path,
    lstOf = (x, id) =>
      id === 'curve' ? x.curve : id === 'path' ? x.path : id === 'body' ? x.body.kf : (x[o.list][id] || {}).kf,
    kfOf = id => lstOf(T(), id),
    mk = (tag, cls) => {
      const e = document.createElement(tag);
      if (cls) e.className = cls;
      return e;
    };
  const BO = () => !!o.body && !!T().body;
  if (st.hi === 'body' && !BO()) st.hi = 0;
  if (st.hi === 'curve' && !CVU) st.hi = 0;
  if (st.hi === 'path' && !PAU) st.hi = 0;
  if (typeof st.hi === 'number' && st.hi >= HB().length)
    st.hi = HB().length ? HB().length - 1 : PAU ? 'path' : CVU ? 'curve' : 0;
  if (st.t > D()) st.t = D();
  const rb = () => tlBuild(host, key, o),
    fin = () => {
      o.ch(() => {});
      rb();
    };
  const lead = mk('strong');
  lead.textContent = o.title || 'Timeline';
  host.appendChild(lead);
  const c1 = mk('div', 'row'),
    sl = mk('input'),
    tlb = mk('span', 'hint');
  sl.type = 'range';
  sl.min = 0;
  sl.max = D();
  sl.step = 0.01;
  sl.value = st.t;
  sl.style.minWidth = '200px';
  const lab = () => {
    tlb.textContent = st.t.toFixed(2) + ' s' + (st.ks ? '  -  keyframe selected, press Delete' : '');
  };
  lab();
  function delKf() {
    if (!st.ks) {
      tlb.textContent = 'Click a diamond in the timeline (or drag an attack box) to select a keyframe first.';
      return;
    }
    let blocked = false;
    o.ch(x => {
      const l = lstOf(x, st.ks.track);
      if (!l || !l[st.ks.idx]) return;
      if (st.ks.track !== 'curve' && st.ks.track !== 'path' && st.ks.track !== 'body' && l.length <= 1) {
        blocked = true;
        return;
      }
      l.splice(st.ks.idx, 1);
    });
    st.ks = null;
    rb();
    if (blocked) $('pmsg').textContent = 'An attack box needs at least one keyframe. Delete the attack box instead.';
  }
  c1.append(
    btn(st.play ? 'Pause' : 'Play', () => {
      st.play = !st.play;
      if (st.play && st.t >= D() - 0.01) st.t = 0;
      rb();
    }),
    sl,
    tlb,
    btn('Delete keyframe', delKf)
  );
  host.appendChild(c1);
  if (o.hint) {
    const lg = mk('p', 'hint');
    lg.textContent = o.hint;
    host.appendChild(lg);
  }
  const c2 = mk('div', 'row');
  if (BO()) {
    const q = btn('Body hitbox', () => {
      st.hi = 'body';
      st.ks = null;
      rb();
    });
    if (st.hi === 'body') q.className = 'on';
    c2.appendChild(q);
  }
  HB().forEach((h, i) => {
    const q = btn(h.name, () => {
      st.hi = i;
      st.ks = null;
      rb();
    });
    if (st.hi === i) q.className = 'on';
    c2.appendChild(q);
  });
  if (PAU) {
    const q = btn('Player movement', () => {
      st.hi = 'path';
      st.ks = null;
      rb();
    });
    if (st.hi === 'path') q.className = 'on';
    c2.appendChild(q);
  }
  if (CVU) {
    const q = btn('Speed curve', () => {
      st.hi = 'curve';
      st.ks = null;
      rb();
    });
    if (st.hi === 'curve') q.className = 'on';
    c2.appendChild(q);
  }
  if (SH.hits)
    c2.appendChild(
      btn('Add attack box', () => {
        if (HB().length >= 8) {
          $('pmsg').textContent = 'Up to 8 attack boxes.';
          return;
        }
        o.ch(x => {
          x[o.list].push({
            name: 'Attack box ' + (x[o.list].length + 1),
            shape: 'rect',
            w: 1,
            h: 1,
            from: 0,
            to: D(),
            kf: [{ t: 0, x: 1, y: -0.75 }]
          });
        });
        st.hi = HB().length - 1;
        st.ks = null;
        rb();
      })
    );
  if (typeof st.hi === 'number' && HB()[st.hi]) {
    c2.appendChild(
      btn('Duplicate', () => {
        if (HB().length >= 8) return;
        o.ch(x => {
          const q = JSON.parse(JSON.stringify(x[o.list][st.hi]));
          q.id = '';
          q.name += ' copy';
          x[o.list].push(q);
        });
        st.hi = HB().length - 1;
        rb();
      })
    );
    c2.appendChild(
      btn('Delete attack box', () => {
        o.ch(x => {
          x[o.list].splice(st.hi, 1);
        });
        st.hi = Math.max(0, st.hi - 1);
        st.ks = null;
        rb();
      })
    );
  }
  host.appendChild(c2);
  // preview
  let X0 = 150;
  {
    const xs = [0].concat(
        ((PA && T().path) || []).map(q => q.x),
        HB().flatMap(h => h.kf.map(q => q.x))
      ),
      mn = Math.min(...xs),
      mx = Math.max(...xs);
    X0 = Math.max(150, Math.min(430, 48 + -mn * TLZ + 20));
    if (mx * TLZ + X0 > 600) X0 = Math.max(60, 600 - mx * TLZ);
  }
  const W0 = 640,
    H0 = 250,
    FY = 190,
    pc = mk('canvas');
  pc.width = W0;
  pc.height = H0;
  pc.style.cssText =
    'width:100%;max-width:640px;border:1px solid var(--bd);border-radius:8px;touch-action:none;display:block;margin:4px 0';
  host.appendChild(pc);
  const tc = mk('canvas');
  tc.width = W0;
  tc.style.cssText = 'width:100%;max-width:640px;display:block';
  host.appendChild(tc);
  const tauAt = t => {
    if (!CV || !T().curve.length) return t;
    let u = 0;
    for (let s = 0; s < t; s += 0.01) {
      const d = Math.min(0.01, t - s);
      u += MV.Attacks.curveAt(T().curve, s) * d;
    }
    return u;
  };
  const hasPath = () => PA && T().path && T().path.length > 0;
  const ppy = t => (hasPath() ? MV.Attacks.sample(T().path, tauAt(t)).y : 0);
  const ppos = t => {
    if (hasPath()) return MV.Attacks.sample(T().path, tauAt(t)).x;
    let x = 0;
    for (let s = 0; s < t; s += 0.01) {
      const d = Math.min(0.01, t - s);
      x += o.vel(s) * MV.Attacks.curveAt(T().curve, s) * d;
    }
    return x;
  };
  const bshape = (h, cx, cy) => ({
      sh: h.shape || 'rect',
      cx,
      cy,
      w: h.w,
      h: h.h,
      r: h.r,
      pts: (h.pts || []).map(q => ({ x: cx + q.x, y: cy + q.y }))
    }),
    sn = v => Math.round(v * 20) / 20;
  const TX = 110,
    TR = 24,
    CH = 70,
    rows = () =>
      (BO() ? [{ n: 'Body hitbox', id: 'body', k: T().body.kf || [], from: 0, to: D() }] : [])
        .concat(HB().map((h, i) => ({ n: h.name, id: i, k: h.kf, from: h.from, to: h.to })))
        .concat(PAU ? [{ n: 'Player movement', id: 'path', k: T().path, from: 0, to: D() }] : []),
    cTop = () => 20 + rows().length * TR,
    vyOf = v => cTop() + CH - 10 - (v / 3) * (CH - 20),
    vOfY = y => ((cTop() + CH - 10 - y) / (CH - 20)) * 3;
  const tx = t => TX + (t / D()) * (W0 - TX - 10),
    xT = px => Math.max(0, Math.min(D(), ((px - TX) / (W0 - TX - 10)) * D()));
  function draw() {
    const t = T(),
      hs = HB(),
      x = pc.getContext('2d'),
      Z = TLZ,
      px = ppos(st.t),
      fx = X0 + px * Z,
      FYp = FY + ppy(st.t) * Z;
    x.fillStyle = '#12324a';
    x.fillRect(0, 0, W0, H0);
    x.strokeStyle = 'rgba(255,255,255,.07)';
    x.lineWidth = 1;
    for (let g = X0 % Z; g < W0; g += Z) {
      x.beginPath();
      x.moveTo(g + 0.5, 0);
      x.lineTo(g + 0.5, H0);
      x.stroke();
    }
    for (let g = FY % Z; g < H0; g += Z) {
      x.beginPath();
      x.moveTo(0, g + 0.5);
      x.lineTo(W0, g + 0.5);
      x.stroke();
    }
    x.fillStyle = 'rgba(255,255,255,.12)';
    x.fillRect(0, FY, W0, H0 - FY);
    if (hasPath()) {
      const pth = T().path,
        sel = st.hi === 'path';
      x.strokeStyle = sel ? '#7fe3ff' : 'rgba(127,227,255,.5)';
      x.lineWidth = sel ? 2.5 : 1.5;
      x.setLineDash([6, 4]);
      x.beginPath();
      for (let s2 = 0, i2 = 0; s2 <= D() + 1e-6; s2 += 0.02, i2++) {
        const q = MV.Attacks.sample(pth, s2),
          qx = X0 + q.x * Z,
          qy = FY + q.y * Z;
        i2 ? x.lineTo(qx, qy) : x.moveTo(qx, qy);
      }
      x.stroke();
      x.setLineDash([]);
      x.lineWidth = 1;
      x.fillStyle = sel ? '#7fe3ff' : 'rgba(127,227,255,.6)';
      pth.forEach(q => {
        x.beginPath();
        x.arc(X0 + q.x * Z, FY + q.y * Z, 4, 0, 7);
        x.fill();
      });
    }
    const pr = MV.Tuning.resolve(S.player),
      sp = S.sprite,
      an = o.an && o.an();
    let ok = false;
    if (an)
      ok = MV.PlayerSprite.frame(
        x,
        { w: sp.w, h: sp.h, anims: { a: Object.assign({}, an, an.fit && o.fit ? { fps: an.frames / D() } : {}) } },
        sheetOf,
        'a',
        st.t,
        fx,
        FYp,
        1,
        Z
      );
    if (!ok) ok = MV.PlayerSprite.frame(x, sp, sheetOf, 'idle', 0, fx, FYp, 1, Z);
    if (!ok) {
      x.fillStyle = 'rgba(93,202,165,.8)';
      x.fillRect(fx - (pr.w * Z) / 2, FYp - pr.h * Z, pr.w * Z, pr.h * Z);
    }
    x.strokeStyle = 'rgba(255,255,255,.3)';
    x.lineWidth = 1;
    x.setLineDash([2, 3]);
    x.strokeRect(fx - (pr.w * Z) / 2, FYp - pr.h * Z, pr.w * Z, pr.h * Z);
    x.setLineDash([]);
    if (BO()) {
      const off = MV.Attacks.isOff(T().body, st.t),
        bw = MV.Attacks.bodyWorld(S.body, pr, fx / Z, FYp / Z, 1, 1, MV.Attacks.bodyKf(T().body, st.t));
      x.lineWidth = st.hi === 'body' ? 2.5 : 1.5;
      x.strokeStyle = off ? 'rgba(180,178,169,.9)' : '#5dcaa5';
      x.fillStyle = off ? 'rgba(0,0,0,.25)' : 'rgba(93,202,165,.18)';
      x.setLineDash(off ? [4, 3] : []);
      MV.Attacks.trace(x, bw, Z);
      x.fill();
      x.stroke();
      x.setLineDash([]);
      x.lineWidth = 1;
      if (off) {
        x.fillStyle = '#b4b2a9';
        x.font = '11px system-ui,sans-serif';
        x.textAlign = 'left';
        x.fillText('body hitbox off', fx - 36, FYp - pr.h * Z - 6);
      }
    }
    hs.forEach((h, i) => {
      const k = MV.Attacks.sample(h.kf, st.t),
        act = st.t >= h.from && st.t <= h.to,
        sel = st.hi === i,
        cx = fx + k.x * Z,
        cy = FYp + k.y * Z;
      x.strokeStyle = sel ? '#fff' : 'rgba(255,255,255,.35)';
      x.setLineDash([3, 3]);
      x.beginPath();
      h.kf.forEach((q, j) => {
        const qx = X0 + (ppos(q.t) + q.x) * Z,
          qy = FY + (ppy(q.t) + q.y) * Z;
        j ? x.lineTo(qx, qy) : x.moveTo(qx, qy);
      });
      x.stroke();
      x.setLineDash([]);
      x.fillStyle = sel ? '#fff' : 'rgba(255,255,255,.5)';
      h.kf.forEach(q => {
        x.beginPath();
        x.arc(X0 + (ppos(q.t) + q.x) * Z, FY + (ppy(q.t) + q.y) * Z, 3, 0, 7);
        x.fill();
      });
      const art =
        h.vis &&
        MV.PlayerSprite.frame(
          x,
          { w: h.w, h: h.h, anims: { idle: h.vis } },
          sheetOf,
          'idle',
          Math.max(0, st.t - h.from),
          cx,
          cy + (h.h * Z) / 2,
          1,
          Z
        );
      const bs = bshape(h, cx / Z, cy / Z);
      if (!art) {
        x.fillStyle = act ? 'rgba(226,75,74,.55)' : 'rgba(226,75,74,.2)';
        MV.Attacks.trace(x, bs, Z);
        x.fill();
      }
      x.strokeStyle = sel ? '#fff' : '#e24b4a';
      x.lineWidth = sel ? 2.5 : 1;
      MV.Attacks.trace(x, bs, Z);
      x.stroke();
      if (sel && h.shape === 'polygon') {
        x.fillStyle = '#fff';
        h.pts.forEach(q => {
          x.beginPath();
          x.arc(cx + q.x * Z, cy + q.y * Z, 5, 0, 7);
          x.fill();
        });
      }
    });
    x.fillStyle = '#b4b2a9';
    x.font = '11px system-ui,sans-serif';
    x.textAlign = 'left';
    x.fillText('The player faces right. Grid squares are tiles.', 8, H0 - 8);
  }
  function drawTL() {
    const rs = rows(),
      x = tc.getContext('2d');
    tc.height = 20 + rs.length * TR + (CVU ? CH + 4 : 0) + 6;
    x.fillStyle = '#2c2c2a';
    x.fillRect(0, 0, tc.width, tc.height);
    x.font = '11px system-ui,sans-serif';
    x.textBaseline = 'middle';
    x.fillStyle = '#b4b2a9';
    x.textAlign = 'center';
    for (let s = 0; s <= D() + 0.001; s += D() > 3 ? 0.5 : 0.1) x.fillText(s.toFixed(D() > 3 ? 1 : 2), tx(s), 9);
    rs.forEach((r, i) => {
      const y = 20 + i * TR;
      if (st.hi === r.id) {
        x.fillStyle = 'rgba(255,255,255,.08)';
        x.fillRect(0, y, tc.width, TR);
      }
      x.textAlign = 'left';
      x.fillStyle = '#d3d1c7';
      x.fillText(r.n.slice(0, 16), 6, y + TR / 2);
      if (r.id === 'body') {
        x.fillStyle = 'rgba(93,202,165,.35)';
        x.fillRect(TX, y + 4, tc.width - TX - 10, TR - 8);
        (T().body.off || []).forEach(w => {
          const a = tx(w.from),
            b = Math.max(a + 2, tx(w.to));
          x.fillStyle = '#1b1b19';
          x.fillRect(a, y + 4, b - a, TR - 8);
          x.strokeStyle = '#b4b2a9';
          x.strokeRect(a + 0.5, y + 4.5, b - a - 1, TR - 9);
          if (b - a > 34) {
            x.fillStyle = '#b4b2a9';
            x.fillText('off', a + 5, y + TR / 2);
          }
        });
      } else if (r.id !== 'path') {
        x.fillStyle = 'rgba(226,75,74,.3)';
        x.fillRect(tx(r.from), y + 4, Math.max(2, tx(r.to) - tx(r.from)), TR - 8);
      } else {
        x.fillStyle = 'rgba(127,227,255,.18)';
        x.fillRect(TX, y + 4, tc.width - TX - 10, TR - 8);
      }
      r.k.forEach((k, j) => {
        x.save();
        x.translate(tx(k.t), y + TR / 2);
        x.rotate(Math.PI / 4);
        x.fillStyle = st.ks && st.ks.track === r.id && st.ks.idx === j ? '#ef9f27' : '#fff';
        x.fillRect(-4, -4, 8, 8);
        x.restore();
      });
    });
    if (CVU) {
      const y0 = cTop();
      if (st.hi === 'curve') {
        x.fillStyle = 'rgba(255,255,255,.08)';
        x.fillRect(0, y0, tc.width, CH);
      }
      x.textAlign = 'left';
      x.fillStyle = '#d3d1c7';
      x.fillText('Speed curve', 6, y0 + 12);
      x.fillStyle = '#b4b2a9';
      x.fillText('1 = full speed', 6, y0 + 26);
      x.strokeStyle = 'rgba(255,255,255,.2)';
      x.setLineDash([3, 3]);
      x.beginPath();
      x.moveTo(TX, vyOf(1));
      x.lineTo(tc.width - 10, vyOf(1));
      x.stroke();
      x.setLineDash([]);
      const c = T().curve;
      x.strokeStyle = '#5dcaa5';
      x.lineWidth = 2;
      x.beginPath();
      if (c.length) {
        x.moveTo(tx(0), vyOf(c[0].v));
        c.forEach(k => x.lineTo(tx(k.t), vyOf(k.v)));
        x.lineTo(tx(D()), vyOf(c[c.length - 1].v));
      } else {
        x.moveTo(tx(0), vyOf(1));
        x.lineTo(tx(D()), vyOf(1));
      }
      x.stroke();
      x.lineWidth = 1;
      c.forEach((k, j) => {
        x.save();
        x.translate(tx(k.t), vyOf(k.v));
        x.rotate(Math.PI / 4);
        x.fillStyle = st.ks && st.ks.track === 'curve' && st.ks.idx === j ? '#ef9f27' : '#fff';
        x.fillRect(-4, -4, 8, 8);
        x.restore();
      });
    }
    x.strokeStyle = '#e24b4a';
    x.lineWidth = 2;
    x.beginPath();
    x.moveTo(tx(st.t), 14);
    x.lineTo(tx(st.t), tc.height);
    x.stroke();
  }
  const move = q => {
    if (st.hi === 'path') {
      const h0 = MV.Tuning.resolve(S.player).h;
      st.ks = {
        track: 'path',
        idx: setKey(T().path, tauAt(st.t), snap4((q.x - X0) / TLZ), snap4((q.y - FY + (h0 * TLZ) / 2) / TLZ))
      };
      lab();
      draw();
      drawTL();
      return;
    }
    const h = HB()[st.hi];
    if (!h) return;
    const fx = X0 + ppos(st.t) * TLZ,
      fy = FY + ppy(st.t) * TLZ;
    st.ks = { track: st.hi, idx: setKey(h.kf, st.t, snap4((q.x - fx) / TLZ), snap4((q.y - fy) / TLZ)) };
    lab();
    draw();
    drawTL();
  };
  const ppt = e => {
    const r = pc.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * W0, y: ((e.clientY - r.top) / r.height) * H0 };
  };
  let drag = false,
    vdrag = null;
  pc.onpointerdown = e => {
    TLACT = key;
    const q = ppt(e),
      hs = HB(),
      fx = X0 + ppos(st.t) * TLZ,
      fy = FY + ppy(st.t) * TLZ;
    let hit = -1;
    if (typeof st.hi === 'number' && hs[st.hi] && hs[st.hi].shape === 'polygon') {
      const h = hs[st.hi],
        k = MV.Attacks.sample(h.kf, st.t),
        cx = fx + k.x * TLZ,
        cy = fy + k.y * TLZ,
        vi = h.pts.findIndex(v => Math.hypot(q.x - (cx + v.x * TLZ), q.y - (cy + v.y * TLZ)) <= 9);
      if (vi >= 0) {
        if (e.shiftKey || e.altKey) {
          if (h.pts.length > 3) {
            const hi = st.hi;
            o.ch(x => {
              x[o.list][hi].pts.splice(vi, 1);
            });
            rb();
          }
          return;
        }
        pc.setPointerCapture(e.pointerId);
        st.play = false;
        vdrag = { h, i: vi, cx, cy };
        return;
      }
    }
    for (let i = hs.length - 1; i >= 0 && hit < 0; i--) {
      const h = hs[i],
        k = MV.Attacks.sample(h.kf, st.t);
      if (Math.abs(q.x - (fx + k.x * TLZ)) <= (h.w * TLZ) / 2 && Math.abs(q.y - (fy + k.y * TLZ)) <= (h.h * TLZ) / 2)
        hit = i;
    }
    if (hit < 0 && PAU) {
      const p0 = MV.Tuning.resolve(S.player);
      if (Math.abs(q.x - fx) <= (p0.w * TLZ) / 2 + 8 && q.y <= fy + 4 && q.y >= fy - p0.h * TLZ - 4) hit = 'path';
    }
    if (hit < 0) return;
    pc.setPointerCapture(e.pointerId);
    st.hi = hit;
    st.play = false;
    drag = true;
    move(q);
  };
  pc.onpointermove = e => {
    if (vdrag) {
      const q = ppt(e);
      vdrag.h.pts[vdrag.i] = { x: sn((q.x - vdrag.cx) / TLZ), y: sn((q.y - vdrag.cy) / TLZ) };
      draw();
      return;
    }
    if (drag) move(ppt(e));
  };
  pc.onpointerup = () => {
    if (vdrag) {
      vdrag = null;
      fin();
      return;
    }
    if (drag) {
      drag = false;
      fin();
    }
  };
  const tpt = e => {
    const r = tc.getBoundingClientRect();
    return { x: ((e.clientX - r.left) / r.width) * tc.width, y: ((e.clientY - r.top) / r.height) * tc.height };
  };
  let td = null,
    hi0 = 0;
  tc.onpointerdown = e => {
    TLACT = key;
    const q = tpt(e);
    tc.setPointerCapture(e.pointerId);
    st.play = false;
    hi0 = st.hi;
    const rs = rows();
    if (CVU && q.y >= cTop()) {
      st.hi = 'curve';
      const c = T().curve,
        j = c.findIndex(k => Math.abs(tx(k.t) - q.x) < 8 && Math.abs(vyOf(k.v) - q.y) < 9);
      if (j >= 0) {
        st.ks = { track: 'curve', idx: j };
        st.t = c[j].t;
        td = { list: c, idx: j, curve: true };
      } else {
        st.ks = null;
        if (q.x >= TX) st.t = xT(q.x);
      }
    } else {
      const ri = Math.floor((q.y - 20) / TR);
      if (ri >= 0 && ri < rs.length) {
        const rid2 = rs[ri].id;
        st.hi = rid2;
        if (rid2 === 'body') {
          const bi = T().body.off.findIndex(w => Math.abs(tx(w.from) - q.x) < 6 || Math.abs(tx(w.to) - q.x) < 6);
          if (bi >= 0) {
            const w = T().body.off[bi];
            td = { edge: 1, w, side: Math.abs(tx(w.from) - q.x) <= Math.abs(tx(w.to) - q.x) ? 'from' : 'to' };
            sl.value = st.t;
            lab();
            draw();
            drawTL();
            return;
          }
        }
        const kf = rs[ri].k,
          j = kf.findIndex(k => Math.abs(tx(k.t) - q.x) < 7);
        if (q.x >= TX && j >= 0) {
          st.ks = { track: rid2, idx: j };
          st.t = kf[j].t;
          td = { list: kf, idx: j };
        } else {
          st.ks = null;
          if (q.x >= TX) st.t = xT(q.x);
        }
      } else if (q.x >= TX) st.t = xT(q.x);
    }
    sl.value = st.t;
    lab();
    draw();
    drawTL();
  };
  tc.onpointermove = e => {
    if (!td) return;
    if (td.edge) {
      td.w[td.side] = xT(tpt(e).x);
      draw();
      drawTL();
      return;
    }
    const q = tpt(e),
      k = td.list[td.idx];
    k.t = xT(q.x);
    if (td.curve) k.v = Math.max(0, Math.min(3, Math.round(vOfY(q.y) * 20) / 20));
    st.t = k.t;
    sl.value = st.t;
    lab();
    draw();
    drawTL();
  };
  tc.onpointerup = () => {
    if (td && td.edge) {
      td = null;
      o.ch(() => {});
      rb();
      return;
    }
    if (td) {
      const t0 = td.list[td.idx].t,
        tr = st.ks && st.ks.track;
      td = null;
      o.ch(() => {});
      const l = kfOf(tr),
        j = l ? l.findIndex(k => Math.abs(k.t - t0) < 1e-6) : -1;
      st.ks = j >= 0 ? { track: tr, idx: j } : null;
      rb();
    } else if (st.hi !== hi0) rb();
  };
  sl.oninput = () => {
    st.t = +sl.value;
    st.play = false;
    lab();
    draw();
    drawTL();
  };
  // the form of the selected track
  const fm = mk('div');
  host.appendChild(fm);
  if (st.hi === 'curve') {
    const hp = mk('p', 'hint');
    hp.textContent =
      'The speed curve multiplies the speed during the timeline: 1 = full speed, 0 = stopped, 2 = twice as fast. Drag a diamond to change when and how fast. With no points the speed stays constant. Points: ' +
      T().curve.length +
      '.';
    fm.appendChild(hp);
    const r = mk('div', 'row');
    r.append(
      btn('Add speed point at this time', () => {
        o.ch(x => {
          x.curve.push({ t: st.t, v: MV.Attacks.curveAt(x.curve, st.t) });
        });
        rb();
      }),
      btn('Clear curve', () => {
        o.ch(x => {
          x.curve = [];
        });
        st.ks = null;
        rb();
      })
    );
    fm.appendChild(r);
  } else if (st.hi === 'path') {
    const hp = mk('p', 'hint');
    hp.textContent =
      'Player movement: where the player is at each moment, relative to where it started. Drag the player in the preview to the place it should be at the current time; each drag adds a point, and the player glides between points. The speed curve then changes how fast this path plays. With no points the move uses the speed settings below instead. Points: ' +
      T().path.length +
      '.';
    fm.appendChild(hp);
    const r = mk('div', 'row');
    r.append(
      btn('Add point here (current time)', () => {
        o.ch(x => {
          const q = MV.Attacks.sample(x.path, tauAt(st.t));
          setKey(x.path, tauAt(st.t), q.x, q.y);
        });
        rb();
      }),
      btn('Clear path', () => {
        o.ch(x => {
          x.path = [];
        });
        st.ks = null;
        rb();
      })
    );
    fm.appendChild(r);
  } else if (st.hi === 'body') {
    const B = T().body,
      hp = mk('p', 'hint'),
      base = MV.Attacks.body(S.body, MV.Tuning.resolve(S.player)),
      cur = MV.Attacks.bodyKf(B, st.t) || { w: base.w, h: base.h, x: 0, y: 0 },
      v = { w: +cur.w.toFixed(2), h: +cur.h.toFixed(2), x: +cur.x.toFixed(2), y: +cur.y.toFixed(2) };
    hp.textContent =
      'The body hitbox is the part of the player that gets hurt (its basic shape is set in the Hitbox section: choose "The normal hitbox" in the Editing menu). Here you change it over time. Resize: move the time slider, type the size you want at that moment and click "Set size here"; each one is a diamond on the Body hitbox row, and the box glides between them (drag a diamond to move it in time, select it and press Delete to remove it). Switch off: nothing can hurt the player during an off period (no enemy, boss attack or spikes), like the shade dash in Hollow Knight; drag the edges of a dark bar, or type the times. Size keyframes: ' +
      B.kf.length +
      '. Off periods: ' +
      B.off.length +
      '.';
    fm.appendChild(hp);
    const sz = mk('div', 'mvf');
    sz.append(
      mkSel(
        'Shape while this plays',
        [
          ['', 'Normal (the player hitbox)'],
          ['rect', 'Rectangle'],
          ['circle', 'Circle'],
          ['polygon', 'Polygon (corners of the normal hitbox)']
        ],
        B.shape || '',
        v => {
          o.ch(x => {
            x.body.shape = v;
          });
          rb();
        }
      ),
      mkNum('Width at ' + st.t.toFixed(2) + ' s (tiles)', v.w, 0.1, 30, 0.05, x => {
        v.w = +x;
      }),
      mkNum('Height (tiles)', v.h, 0.1, 30, 0.05, x => {
        v.h = +x;
      }),
      mkNum('Offset sideways (tiles)', v.x, -10, 10, 0.05, x => {
        v.x = +x;
      }),
      mkNum('Offset up/down (tiles)', v.y, -10, 10, 0.05, x => {
        v.y = +x;
      })
    );
    fm.appendChild(sz);
    const sr = mk('div', 'row');
    sr.append(
      btn('Set size here', () => {
        o.ch(x => {
          const k = x.body.kf,
            j = k.findIndex(q => Math.abs(q.t - st.t) < 0.006),
            q = { t: st.t, w: v.w, h: v.h, x: v.x, y: v.y };
          if (j >= 0) k[j] = q;
          else k.push(q);
        });
        rb();
      }),
      btn('Remove all size keyframes', () => {
        o.ch(x => {
          x.body.kf = [];
        });
        st.ks = null;
        rb();
      })
    );
    fm.appendChild(sr);
    const g = mk('div', 'mvf');
    B.off.forEach((w, i) => {
      g.append(
        mkNum('Off from (s) #' + (i + 1), w.from, 0, 10, 0.01, x => {
          o.ch(y => {
            y.body.off[i].from = +x;
            fitDur(y);
          });
          rb();
        }),
        mkNum('Off until (s) #' + (i + 1), w.to, 0, 10, 0.01, x => {
          o.ch(y => {
            y.body.off[i].to = +x;
            fitDur(y);
          });
          rb();
        })
      );
    });
    fm.appendChild(g);
    const r = mk('div', 'row');
    r.append(
      btn('Switch off from here', () => {
        if (B.off.length >= 8) {
          $('pmsg').textContent = 'Up to 8 periods.';
          return;
        }
        o.ch(x => {
          x.body.off.push({ from: st.t, to: Math.min(D(), st.t + 0.15) });
        });
        rb();
      }),
      btn('Off the whole time', () => {
        o.ch(x => {
          x.body.off = [{ from: 0, to: D() }];
        });
        rb();
      })
    );
    B.off.forEach((w, i) =>
      r.appendChild(
        btn('Remove period ' + (i + 1), () => {
          o.ch(x => {
            x.body.off.splice(i, 1);
          });
          rb();
        })
      )
    );
    fm.appendChild(r);
  } else {
    const h = HB()[st.hi];
    if (h) {
      const E = f => v => {
          o.ch(x => {
            f(x[o.list][st.hi], v);
            fitDur(x);
          });
          rb();
        },
        g = mk('div', 'mvf'),
        shp = h.shape || 'rect';
      g.append(
        mkText(
          'Name',
          h.name,
          E((q, v) => {
            q.name = v;
          })
        ),
        mkSel(
          'Shape',
          [
            ['rect', 'Rectangle'],
            ['circle', 'Circle'],
            ['polygon', 'Polygon']
          ],
          shp,
          E((q, v) => {
            if (v === 'polygon' && q.shape !== 'polygon') {
              const w = q.w / 2,
                hh = q.h / 2;
              q.pts = [
                { x: -w, y: hh },
                { x: -w, y: -hh },
                { x: w, y: -hh },
                { x: w, y: hh }
              ];
            }
            if (v === 'circle' && q.shape !== 'circle') q.r = Math.max(0.05, Math.min(15, Math.max(q.w, q.h) / 2));
            q.shape = v;
          })
        )
      );
      if (shp === 'rect')
        g.append(
          mkNum(
            'Width (tiles)',
            h.w,
            0.1,
            30,
            0.1,
            E((q, v) => {
              q.w = +v;
            })
          ),
          mkNum(
            'Height (tiles)',
            h.h,
            0.1,
            30,
            0.1,
            E((q, v) => {
              q.h = +v;
            })
          )
        );
      else if (shp === 'circle')
        g.append(
          mkNum(
            'Radius (tiles)',
            h.r,
            0.05,
            15,
            0.05,
            E((q, v) => {
              q.r = +v;
            })
          )
        );
      g.append(
        mkNum(
          'Hurts from (s)',
          h.from,
          0,
          10,
          0.01,
          E((q, v) => {
            q.from = +v;
          })
        ),
        mkNum(
          'Hurts until (s)',
          h.to,
          0,
          10,
          0.01,
          E((q, v) => {
            q.to = +v;
          })
        )
      );
      fm.appendChild(g);
      if (shp === 'polygon') {
        const ph = mk('p', 'hint');
        ph.textContent =
          'Polygon: drag the white dots in the preview to move the corners (Shift+click a dot removes it). Corners: ' +
          h.pts.length +
          ' (3 to 16).';
        fm.appendChild(ph);
        const pr2 = mk('div', 'row');
        pr2.append(
          btn('Add corner', () => {
            o.ch(x => {
              const P = x[o.list][st.hi].pts;
              if (P.length >= 16) return;
              let bi = 0,
                bl = -1;
              P.forEach((a, i) => {
                const b = P[(i + 1) % P.length],
                  l = Math.hypot(a.x - b.x, a.y - b.y);
                if (l > bl) {
                  bl = l;
                  bi = i;
                }
              });
              const a = P[bi],
                b = P[(bi + 1) % P.length];
              P.splice(bi + 1, 0, { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
            });
            rb();
          }),
          btn('Remove last corner', () => {
            o.ch(x => {
              const P = x[o.list][st.hi].pts;
              if (P.length > 3) P.pop();
            });
            rb();
          })
        );
        fm.appendChild(pr2);
      }
      const lt = mk('p', 'hint');
      lt.textContent =
        'Look: the picture drawn on this attack box, for example a slash effect. Without one it shows as a white box in the game.';
      fm.appendChild(lt);
      fm.appendChild(
        animForm(
          h.vis,
          patch => {
            o.ch(x => {
              const hh = x[o.list][st.hi],
                a = Object.assign({}, ANIM0, hh.vis || {}, patch);
              hh.vis = a.sheet ? a : null;
            });
            rb();
          },
          rb
        )
      );
    } else {
      const hp = mk('p', 'hint');
      hp.textContent = 'No attack boxes yet. Click Add attack box.';
      fm.appendChild(hp);
    }
  }
  TLE[key] = { st, pc, sl, lab, draw, drawTL, D, del: delKf };
  draw();
  drawTL();
}
