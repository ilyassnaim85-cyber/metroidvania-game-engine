function tlLoop(t) {
  if (TAB !== 'player') {
    TLON = false;
    return;
  }
  requestAnimationFrame(tlLoop);
  const dt = Math.min(0.1, Math.max(0, (t - TLLAST) / 1000));
  TLLAST = t;
  for (const k in TLE) {
    const r = TLE[k];
    if (!r || !r.st.play || !r.pc.isConnected || r.pc.offsetParent === null) continue;
    r.st.t += dt;
    if (r.st.t > r.D()) r.st.t = 0;
    r.sl.value = r.st.t;
    r.lab();
    r.draw();
    r.drawTL();
  }
}
function tlStart() {
  if (TLON) return;
  TLON = true;
  TLLAST = performance.now();
  requestAnimationFrame(tlLoop);
}
addEventListener('keydown', e => {
  if (TAB !== 'player' || e.key !== 'Delete' || inText(e.target) || !TLACT) return;
  const r = TLE[TLACT];
  if (r && r.pc.isConnected && r.pc.offsetParent !== null) {
    e.preventDefault();
    r.del();
  }
});
MV.PlayerSprite.clips = () => (typeof S !== 'undefined' && S && S.anims) || [];
function setSprite(p) {
  S.sprite = MV.PlayerSprite.clean(Object.assign({}, S.sprite, p));
  save();
  buildSprite();
}
function setAnim(patch) {
  const a = Object.assign(
      { sheet: '', clip: '', col: 0, row: 0, frames: 1, fps: 8, loop: !MV.PlayerSprite.once.includes(ASEL) },
      S.sprite.anims[ASEL] || {},
      patch
    ),
    an = Object.assign({}, S.sprite.anims);
  if (a.sheet || a.clip) an[ASEL] = a;
  else delete an[ASEL];
  setSprite({ anims: an });
}
const STHINT = {
  land: 'Plays once when you land after a fall.',
  hurt: 'Plays once when you take damage (see Damage in Settings).',
  die: 'Plays once when your health reaches 0, then you respawn at the last checkpoint.',
  pickup: 'Plays once when you pick up an item or ability.',
  checkpoint: 'Plays once when you activate an interactive checkpoint (the press-a-key ones).',
  chest: 'Plays once when you open a chest.',
  sign: 'Plays once when you read an interactive sign (the press-a-key ones).',
  talk: 'Loops while you are in a conversation with a character.',
  attack: 'Used by attacks that have no animation of their own. Each attack can have its own in the Attacks tab.',
  dash: 'Used by dashes that have no animation of their own. Each move can have its own in the Moves tab.'
};
function buildSprite() {
  const sp = S.sprite;
  $('spw').value = sp.w;
  $('sph2').value = sp.h;
  const bar = $('ans');
  bar.innerHTML = '';
  MV.PlayerSprite.states.forEach(st => {
    const b = document.createElement('button');
    b.textContent = st + (sp.anims[st] ? ' \u25cf' : '');
    if (st === ASEL) b.className = 'on';
    b.onclick = () => {
      ASEL = st;
      pvT = 0;
      buildSprite();
    };
    bar.appendChild(b);
  });
  const ed = $('ane');
  ed.innerHTML = '';
  const a = sp.anims[ASEL],
    sh = a && S.sheets.find(x => x.id === a.sheet),
    f = document.createElement('div');
  f.className = 'mvf';
  f.appendChild(
    mkSel(
      'Animation Studio clip',
      [['', '(none: use a sprite sheet)'], ...S.anims.map(v => [v.id, v.name])],
      a && a.clip ? a.clip : '',
      v => setAnim({ clip: v })
    )
  );
  const n0 = f.children.length;
  f.appendChild(
    mkSel('Sprite sheet', [['', '(none)'], ...S.sheets.map(v => [v.id, v.name])], a ? a.sheet : '', v =>
      setAnim({ sheet: v })
    )
  );
  const il = document.createElement('label'),
    fi = document.createElement('input');
  fi.type = 'file';
  fi.accept = 'image/png,image/gif,image/webp';
  fi.onchange = () => {
    const fl = fi.files[0];
    fi.value = '';
    if (!fl) return;
    const fr = new FileReader();
    fr.onload = () => {
      const q = { id: 's' + rid(), name: fl.name.slice(0, 40), url: fr.result, tw: 16, th: 16 };
      S.sheets.push(q);
      setAnim({ sheet: q.id });
    };
    fr.readAsDataURL(fl);
  };
  il.append('Import image', fi);
  f.appendChild(il);
  f.appendChild(
    mkNum(
      'Frame width (px)',
      sh ? sh.tw : 16,
      1,
      512,
      1,
      v => {
        sh.tw = Math.max(1, Math.min(512, +v || 16));
        save();
        buildSprite();
      },
      !sh
    )
  );
  f.appendChild(
    mkNum(
      'Frame height (px)',
      sh ? sh.th : 16,
      1,
      512,
      1,
      v => {
        sh.th = Math.max(1, Math.min(512, +v || 16));
        save();
        buildSprite();
      },
      !sh
    )
  );
  f.appendChild(mkNum('First column', a ? a.col : 0, 0, 255, 1, v => setAnim({ col: +v }), !a));
  f.appendChild(mkNum('Row', a ? a.row : 0, 0, 255, 1, v => setAnim({ row: +v }), !a));
  f.appendChild(mkNum('Frames', a ? a.frames : 1, 1, 64, 1, v => setAnim({ frames: +v }), !a));
  f.appendChild(mkNum('Frames per second', a ? a.fps : 8, 1, 60, 1, v => setAnim({ fps: +v }), !a));
  if (a && a.clip) for (let q = n0; q < f.children.length; q++) f.children[q].style.display = 'none'; // a clip brings its own frames and timing
  const ll = document.createElement('label'),
    lc = document.createElement('input');
  lc.type = 'checkbox';
  lc.checked = !a || a.loop;
  lc.disabled = !a;
  lc.onchange = () => setAnim({ loop: lc.checked });
  ll.append('Loop', lc);
  f.appendChild(ll);
  if (MV.PlayerSprite.once.includes(ASEL)) {
    const fl = document.createElement('label'),
      fc = document.createElement('input');
    fc.type = 'checkbox';
    fc.checked = !!(a && a.freeze);
    fc.disabled = !a;
    fc.onchange = () => setAnim({ freeze: fc.checked });
    fl.append('Hold the player still while it plays', fc);
    f.appendChild(fl);
  }
  ed.appendChild(f);
  const sh0 = document.createElement('p');
  sh0.className = 'hint';
  sh0.textContent = STHINT[ASEL] || '';
  if (sh0.textContent) ed.appendChild(sh0);
  const r = document.createElement('div');
  r.className = 'row';
  const cl = document.createElement('button');
  cl.textContent = 'Clear this animation';
  cl.disabled = !a;
  cl.onclick = () => setAnim({ sheet: '', clip: '' });
  r.appendChild(cl);
  ed.appendChild(r);
  const hn = document.createElement('p');
  hn.className = 'hint';
  hn.textContent =
    'In Aseprite use File > Export Sprite Sheet. Frames are read left to right, then down. Set the frame size to one frame, the first column and row of this animation, and how many frames it has. States without an animation use Idle.';
  ed.appendChild(hn);
}
function pvStart() {
  if (pvOn) return;
  pvOn = true;
  pvLast = performance.now();
  requestAnimationFrame(pvTick);
}
function pvTick(t) {
  if (!pvOn || TAB !== 'player') {
    pvOn = false;
    return;
  }
  requestAnimationFrame(pvTick);
  pvT += Math.min(0.1, Math.max(0, (t - pvLast) / 1000));
  pvLast = t;
  drawPv();
}
function drawPv() {
  const c = $('pvc'),
    x = c.getContext('2d'),
    sp = S.sprite,
    pr = MV.Tuning.resolve(S.player),
    Zp = Math.min((c.height * 0.62) / Math.max(sp.h, pr.h), (c.width * 0.7) / Math.max(sp.w, pr.w)),
    fx = c.width / 2,
    fy = c.height * 0.82;
  x.fillStyle = '#12324a';
  x.fillRect(0, 0, c.width, c.height);
  x.fillStyle = 'rgba(255,255,255,.12)';
  x.fillRect(0, fy, c.width, c.height - fy);
  const pa = sp.anims[ASEL],
    ok = MV.PlayerSprite.frame(
      x,
      sp,
      sheetOf,
      ASEL,
      pa && !pa.loop ? pvT % (MV.PlayerSprite.len(pa) + 0.6) : pvT,
      fx,
      fy,
      1,
      Zp
    );
  x.fillStyle = '#fff';
  x.font = '12px system-ui,sans-serif';
  x.textAlign = 'center';
  if (!ok) {
    x.fillStyle = '#5dcaa5';
    x.fillRect(fx - (pr.w * Zp) / 2, fy - pr.h * Zp, pr.w * Zp, pr.h * Zp);
    x.fillStyle = '#fff';
    x.fillText('No sprite image yet - add one below', fx, fy + 22);
  } else if (!sp.anims[ASEL]) x.fillText('No ' + ASEL + ' animation yet - the game uses Idle', fx, fy + 22);
  if ($('pvb').checked) {
    x.strokeStyle = '#ef9f27';
    x.setLineDash([4, 3]);
    x.strokeRect(fx - (pr.w * Zp) / 2, fy - pr.h * Zp, pr.w * Zp, pr.h * Zp);
    x.setLineDash([]);
  }
}
$('spw').onchange = () => setSprite({ w: +$('spw').value });
$('sph2').onchange = () => setSprite({ h: +$('sph2').value });

let BAT = 0,
  BI = 0,
  BSUB = 'arena',
  PI = 0,
  HI = 'body',
  BT = 0,
  BPLAY = false,
  BTOOL = '#',
  BAN = 'idle',
  KSEL = null,
  BDRAG = null,
  BPICK = '',
  BLAST = 0,
  BON = false;
const cb = () => S.bosses[BI] || null,
  cpat = () => {
    const b = cb();
    return (b && b.patterns[PI]) || null;
  },
  snap4 = v => Math.round(v * 4) / 4;
const btn = (t, f) => {
  const b = document.createElement('button');
  b.textContent = t;
  b.onclick = f;
  return b;
};
const mkText = (lab, val, cb2) => {
  const l = document.createElement('label'),
    q = document.createElement('input');
  q.type = 'text';
  q.value = val;
  q.onchange = () => cb2(q.value);
  l.append(lab, q);
  return l;
};
const clipSel = (lab, val, cb2) =>
  mkSel(
    lab,
    [['', '(none)']]
      .concat((S.anims || []).map(a => [a.id, a.name || a.id]))
      .concat(val && !(S.anims || []).some(a => a.id === val) ? [[val, val + ' (missing)']] : []),
    val || '',
    cb2
  );
const bclip = (x, id, t, px, py, k, flip) => {
  const cl = id && MV.Anim.find(S.anims, id);
  if (!cl || !cl.frames.length) return false;
  const sh = sheetOf(cl.frames[0].sheet);
  if (!sh) return false;
  return MV.Anim.draw(x, cl, MV.Anim.sample(cl, t), sheetOf, px, py, { scale: k / sh.tw, flipX: flip });
};
const sndSel = (lab, val, cb2) =>
  mkSel(
    lab,
    [['', '(none)']]
      .concat((S.sounds || []).filter(z => !z.music).map(a => [a.id, a.name || a.id]))
      .concat(val && !(S.sounds || []).some(a => a.id === val) ? [[val, val + ' (missing)']] : []),
    val || '',
    cb2
  );
function bedit(fn) {
  const b = cb();
  if (!b) return;
  fn(b);
  S.bosses[BI] = MV.Boss.clean(b);
  save();
  bossUI();
}
function paintGrid(x, g, gw, gh, Z) {
  for (let ty = 0; ty < gh; ty++)
    for (let tx = 0; tx < gw; tx++) {
      const ch = g[ty][tx];
      if (ch === '.') continue;
      x.fillStyle = ch === '=' ? '#a67c52' : ch === '^' ? '#d85a30' : ch === '~' ? '#3b8bd4' : '#5b6b7a';
      if (ch === '=') {
        x.fillRect(tx * Z, ty * Z, Z, Z / 2);
      } else if (ch === '~') {
        x.globalAlpha = 0.45;
        x.fillRect(tx * Z, ty * Z, Z, Z);
        x.globalAlpha = 1;
      } else if (ch === '^') {
        x.beginPath();
        x.moveTo(tx * Z, (ty + 1) * Z);
        x.lineTo((tx + 0.5) * Z, (ty + 0.4) * Z);
        x.lineTo((tx + 1) * Z, (ty + 1) * Z);
        x.fill();
      } else if (ch === '/' || ch === '\\') {
        x.beginPath();
        if (ch === '/') {
          x.moveTo(tx * Z, (ty + 1) * Z);
          x.lineTo((tx + 1) * Z, ty * Z);
        } else {
          x.moveTo(tx * Z, ty * Z);
          x.lineTo(tx * Z, (ty + 1) * Z);
        }
        x.lineTo((tx + 1) * Z, (ty + 1) * Z);
        x.fill();
      } else x.fillRect(tx * Z, ty * Z, Z, Z);
    }
}
function bpos(b, p) {
  const A = b.arena,
    fx = A.bx + 0.5,
    fy = A.by + 1,
    o = p && p.body.length ? MV.Boss.sample(p.body, BT) : { x: 0, y: 0 };
  return { fx, fy, bx: fx + o.x, by: fy + o.y };
}
function setKey(list, t, x, y) {
  const i = list.findIndex(k => Math.abs(k.t - t) < 0.03);
  if (i >= 0) {
    list[i].x = x;
    list[i].y = y;
    return i;
  }
  const n = { t, x, y };
  list.push(n);
  list.sort((a, b) => a.t - b.t);
  return list.indexOf(n);
}
function syncBt() {
  const a = document.getElementById('bts'),
    l = document.getElementById('btl');
  if (a) a.value = BT;
  if (l) l.textContent = BT.toFixed(2) + ' s' + (KSEL ? '  -  keyframe selected, press Delete' : '');
}
function animForm(a, set, refresh) {
  const f = document.createElement('div'),
    sh = a && S.sheets.find(x => x.id === a.sheet);
  f.className = 'mvf';
  f.appendChild(
    mkSel('Sprite sheet', [['', '(none)'], ...S.sheets.map(v => [v.id, v.name])], a ? a.sheet : '', v =>
      set({ sheet: v })
    )
  );
  const il = document.createElement('label'),
    fi = document.createElement('input');
  fi.type = 'file';
  fi.accept = 'image/png,image/gif,image/webp';
  fi.onchange = () => {
    const fl = fi.files[0];
    fi.value = '';
    if (!fl) return;
    const fr = new FileReader();
    fr.onload = () => {
      const q = { id: 's' + rid(), name: fl.name.slice(0, 40), url: fr.result, tw: 16, th: 16 };
      S.sheets.push(q);
      set({ sheet: q.id });
    };
    fr.readAsDataURL(fl);
  };
  il.append('Import image', fi);
  f.appendChild(il);
  f.appendChild(
    mkNum(
      'Frame width (px)',
      sh ? sh.tw : 16,
      1,
      512,
      1,
      v => {
        sh.tw = Math.max(1, Math.min(512, +v || 16));
        save();
        (refresh || bossUI)();
      },
      !sh
    )
  );
  f.appendChild(
    mkNum(
      'Frame height (px)',
      sh ? sh.th : 16,
      1,
      512,
      1,
      v => {
        sh.th = Math.max(1, Math.min(512, +v || 16));
        save();
        (refresh || bossUI)();
      },
      !sh
    )
  );
  f.appendChild(mkNum('First column', a ? a.col : 0, 0, 255, 1, v => set({ col: +v }), !a));
  f.appendChild(mkNum('Row', a ? a.row : 0, 0, 255, 1, v => set({ row: +v }), !a));
  f.appendChild(mkNum('Frames', a ? a.frames : 1, 1, 64, 1, v => set({ frames: +v }), !a));
  f.appendChild(mkNum('Frames per second', a ? a.fps : 8, 1, 60, 1, v => set({ fps: +v }), !a));
  const ll = document.createElement('label'),
    lc = document.createElement('input');
  lc.type = 'checkbox';
  lc.checked = !a || a.loop;
  lc.disabled = !a;
  lc.onchange = () => set({ loop: lc.checked });
  ll.append('Loop', lc);
  f.appendChild(ll);
  return f;
}
const ANIM0 = { sheet: '', col: 0, row: 0, frames: 1, fps: 8, loop: true };
function bossUI() {
  const L = $('blist');
  L.innerHTML = '';
  if (BI >= S.bosses.length) BI = Math.max(0, S.bosses.length - 1);
  S.bosses.forEach((q, i) => {
    const c = document.createElement('div');
    c.className = 'bcard' + (i === BI ? ' on' : '');
    c.textContent = q.name + ' (' + q.hp + ' hp)';
    c.onclick = () => {
      BI = i;
      PI = 0;
      HI = 'body';
      BT = 0;
      KSEL = null;
      bossUI();
    };
    L.appendChild(c);
  });
  if (!S.bosses.length) L.textContent = 'No bosses yet. Click New boss.';
  $('bsa').classList.toggle('on', BSUB === 'arena');
  $('bsq').classList.toggle('on', BSUB === 'patterns');
  bossForm();
  bossTools();
  bossPatUI();
  drawBoss();
  drawTl();
  bossCards();
}
function patForm(d, b, p) {
  if (!p) {
    d.appendChild(document.createTextNode('Add a pattern with the controls under the arena.'));
    return;
  }
  const row = document.createElement('div');
  row.className = 'row';
  const mb = btn('Boss movement', () => {
    HI = 'body';
    bossUI();
  });
  if (HI === 'body') mb.className = 'on';
  row.appendChild(mb);
  p.hitboxes.forEach((h, i) => {
    const q = btn(h.name, () => {
      HI = i;
      bossUI();
    });
    if (HI === i) q.className = 'on';
    row.appendChild(q);
  });
  d.appendChild(row);
  const r2 = document.createElement('div');
  r2.className = 'row';
  r2.appendChild(
    btn('Add hitbox', () =>
      bedit(x => {
        const pp = x.patterns[PI];
        if (pp.hitboxes.length >= 12) return;
        pp.hitboxes.push({
          name: 'Hitbox ' + (pp.hitboxes.length + 1),
          shape: 'rect',
          dmg: 1,
          w: 1,
          h: 1,
          from: 0,
          to: pp.duration,
          kf: [{ t: 0, x: 1.5, y: -1 }]
        });
        HI = pp.hitboxes.length - 1;
      })
    )
  );
  if (HI !== 'body') {
    r2.appendChild(
      btn('Duplicate', () =>
        bedit(x => {
          const pp = x.patterns[PI];
          if (pp.hitboxes.length >= 12) return;
          const c = JSON.parse(JSON.stringify(pp.hitboxes[HI]));
          c.id = '';
          c.name += ' copy';
          pp.hitboxes.push(c);
          HI = pp.hitboxes.length - 1;
        })
      )
    );
    r2.appendChild(
      btn('Delete hitbox', () =>
        bedit(x => {
          x.patterns[PI].hitboxes.splice(HI, 1);
          HI = 'body';
        })
      )
    );
  }
  d.appendChild(r2);
  if (HI === 'body') {
    const t = document.createElement('p');
    t.className = 'hint';
    t.textContent =
      'Boss movement: scrub the time and drag the boss to make it jump, charge or slide during this pattern. No keyframes = it stays put.';
    d.appendChild(t);
    return;
  }
  const h = p.hitboxes[HI];
  if (!h) {
    HI = 'body';
    return;
  }
  const g = document.createElement('div');
  g.className = 'mvf';
  const E = f => v =>
    bedit(x => {
      f(x.patterns[PI].hitboxes[HI], v);
    });
  g.appendChild(
    mkText(
      'Name',
      h.name,
      E((q, v) => {
        q.name = v;
      })
    )
  );
  const tri = q => {
    q.pts = [
      { x: -q.w / 2, y: q.h / 2 },
      { x: 0, y: -q.h / 2 },
      { x: q.w / 2, y: q.h / 2 }
    ];
  };
  g.appendChild(
    mkSel(
      'Shape',
      [
        ['rect', 'Rectangle'],
        ['circle', 'Circle'],
        ['polygon', 'Triangle']
      ],
      h.shape || 'rect',
      E((q, v) => {
        q.shape = v;
        if (v === 'polygon') tri(q);
      })
    )
  );
  if (h.shape === 'circle')
    g.appendChild(
      mkNum(
        'Radius (tiles)',
        h.r,
        0.05,
        15,
        0.05,
        E((q, v) => {
          q.r = +v;
        })
      )
    );
  else {
    g.appendChild(
      mkNum(
        'Width (tiles)',
        h.w,
        0.1,
        30,
        0.1,
        E((q, v) => {
          q.w = +v;
          if (q.shape === 'polygon') tri(q);
        })
      )
    );
    g.appendChild(
      mkNum(
        'Height (tiles)',
        h.h,
        0.1,
        30,
        0.1,
        E((q, v) => {
          q.h = +v;
          if (q.shape === 'polygon') tri(q);
        })
      )
    );
  }
  g.appendChild(
    mkNum(
      'Damage (hits)',
      h.dmg,
      0,
      30,
      1,
      E((q, v) => {
        q.dmg = +v;
      })
    )
  );
  g.appendChild(
    mkNum(
      'Hurts from (s)',
      h.from,
      0,
      p.duration,
      0.05,
      E((q, v) => {
        q.from = +v;
      })
    )
  );
  g.appendChild(
    mkNum(
      'Hurts until (s)',
      h.to,
      0,
      p.duration,
      0.05,
      E((q, v) => {
        q.to = +v;
      })
    )
  );
  g.appendChild(
    mkSel(
      'Moves with the boss',
      [
        ['no', 'No (flies on its own)'],
        ['yes', 'Yes (follows the boss)']
      ],
      h.follow ? 'yes' : 'no',
      E((q, v) => {
        q.follow = v === 'yes';
      })
    )
  );
  d.appendChild(g);
  const lt = document.createElement('p');
  lt.className = 'hint';
  lt.textContent =
    'Look: an animation from the Animations tab drawn on this hitbox, for example a thrown rock. Without one it shows as a red shape.';
  d.appendChild(lt);
  d.appendChild(
    clipSel('Look (animation)', h.clip, v =>
      bedit(x => {
        x.patterns[PI].hitboxes[HI].clip = v;
      })
    )
  );
}
const BOPEN = {},
  MOPEN = {};
