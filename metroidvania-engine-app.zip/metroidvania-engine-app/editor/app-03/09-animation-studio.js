// ================= Animation Studio =================
let AXMODE = 'grid',
  AXI = 0,
  AXF = -1,
  AXP = null,
  AXON = false,
  AXLAST = 0,
  AXSH = '',
  AXD = null,
  AXDUR = 100,
  AXSKIP = true,
  AXSEL = null,
  AXSPD = 1,
  AXLOG = [],
  AXG = null;
const axClip = () => S.anims[AXI] || null,
  slug = q =>
    String(q || 'x')
      .replace(/[^\w.-]+/g, '_')
      .slice(0, 40);
const axMsg = t => {
  const e = document.getElementById('axm');
  if (e) e.textContent = t;
};
function axEdit(fn) {
  const c = axClip();
  if (!c) return;
  fn(c);
  S.anims[AXI] = MV.Anim.clean(c);
  save();
  axUI();
}
function axUI() {
  if (AXI >= S.anims.length) AXI = Math.max(0, S.anims.length - 1);
  const n = axClip() ? axClip().frames.length : 0;
  if (AXF >= n) AXF = n ? n - 1 : -1;
  axList();
  axForm();
  axSheetBar();
  axPlayer();
  axCtl();
  axDrawAll();
}
function axPlayer() {
  const c = axClip();
  if (!c) {
    AXP = null;
    return;
  }
  if (!AXP)
    AXP = MV.Anim.createPlayer(c, {
      onEvent: n => {
        AXLOG.push(n);
        if (AXLOG.length > 6) AXLOG.shift();
        axLog();
      }
    });
  else {
    if (AXP.clip.id !== c.id) {
      AXP.reset();
      AXLOG = [];
    }
    AXP.clip = c;
  }
  AXP.speed = AXSPD;
}
function axLog() {
  const e = document.getElementById('axev');
  if (e) e.textContent = 'Events: ' + (AXLOG.length ? AXLOG.join(', ') : 'none yet');
}
function axList() {
  const L = $('axlist');
  L.innerHTML = '';
  S.anims.forEach((c, i) => {
    const d = document.createElement('div'),
      t = MV.Anim.compile(c).cycle;
    d.className = 'bcard' + (i === AXI ? ' on' : '');
    d.textContent =
      c.name +
      ' - ' +
      c.frames.length +
      ' frames, ' +
      t.toFixed(2) +
      ' s, ' +
      { loop: 'loop', once: 'play once', pingpong: 'ping pong' }[c.mode];
    d.onclick = () => {
      AXI = i;
      AXF = -1;
      axUI();
    };
    L.appendChild(d);
  });
  if (!S.anims.length) L.textContent = 'No animation clips yet. Click New clip.';
}
function axForm() {
  const c = axClip(),
    F = $('axf');
  F.innerHTML = '';
  if (!c) return;
  const g = document.createElement('div');
  g.className = 'mvf';
  g.appendChild(
    mkText('Name', c.name, v =>
      axEdit(x => {
        x.name = v || 'Animation';
      })
    )
  );
  g.appendChild(
    mkSel(
      'Playback',
      [
        ['loop', 'Loop'],
        ['once', 'Play once'],
        ['pingpong', 'Ping pong']
      ],
      c.mode,
      v =>
        axEdit(x => {
          x.mode = v;
        })
    )
  );
  g.appendChild(
    mkNum('Default speed (1 = normal)', c.speed, 0.1, 4, 0.1, v =>
      axEdit(x => {
        x.speed = +v;
      })
    )
  );
  g.appendChild(
    mkNum('Pivot X (0 left, 1 right)', c.pivot.x, -2, 3, 0.05, v =>
      axEdit(x => {
        x.pivot.x = +v;
      })
    )
  );
  g.appendChild(
    mkNum('Pivot Y (0 top, 1 bottom)', c.pivot.y, -2, 3, 0.05, v =>
      axEdit(x => {
        x.pivot.y = +v;
      })
    )
  );
  F.appendChild(g);
  const pr = document.createElement('div');
  pr.className = 'row';
  [
    ['Bottom centre', 0.5, 1],
    ['Centre', 0.5, 0.5],
    ['Top left', 0, 0],
    ['Bottom left', 0, 1]
  ].forEach(a =>
    pr.appendChild(
      btn(a[0], () =>
        axEdit(x => {
          x.pivot.x = a[1];
          x.pivot.y = a[2];
        })
      )
    )
  );
  F.appendChild(pr);
  const f = AXF >= 0 ? c.frames[AXF] : null,
    h = document.createElement('strong');
  h.textContent = f ? 'Frame ' + (AXF + 1) + ' of ' + c.frames.length : 'Frame';
  F.appendChild(h);
  if (!f) {
    const t = document.createElement('p');
    t.className = 'hint';
    t.textContent = 'Select a frame in the timeline to set its length and event marker.';
    F.appendChild(t);
    return;
  }
  const g2 = document.createElement('div');
  g2.className = 'mvf';
  g2.appendChild(
    mkNum('Length (ms)', f.dur, 10, 10000, 10, v =>
      axEdit(x => {
        x.frames[AXF].dur = +v;
      })
    )
  );
  g2.appendChild(
    mkText('Event marker', f.event, v =>
      axEdit(x => {
        x.frames[AXF].event = v;
      })
    )
  );
  F.appendChild(g2);
  {
    const sh = S.sheets.find(q => q.id === f.sheet),
      cu = MV.Anim.customRect(f),
      g3 = document.createElement('div');
    g3.className = 'mvf';
    if (cu) {
      [
        ['x', 'Source x (px)', 0],
        ['y', 'Source y (px)', 0],
        ['w', 'Width (px)', 1],
        ['h', 'Height (px)', 1]
      ].forEach(a =>
        g3.appendChild(
          mkNum(a[1], f[a[0]], a[2], 4096, 1, v =>
            axEdit(x => {
              x.frames[AXF][a[0]] = Math.max(a[2], Math.round(+v) || a[2]);
            })
          )
        )
      );
      F.appendChild(g3);
    }
    const rr = document.createElement('div');
    rr.className = 'row';
    rr.appendChild(
      btn(cu ? 'Back to a grid cell' : 'Use a free rectangle (own size)', () =>
        axEdit(x => {
          const q = x.frames[AXF];
          if (cu) {
            delete q.x;
            delete q.y;
            delete q.w;
            delete q.h;
          } else if (sh) {
            q.x = q.col * sh.tw;
            q.y = q.row * sh.th;
            q.w = sh.tw;
            q.h = sh.th;
          }
        })
      )
    );
    F.appendChild(rr);
    const hh = document.createElement('p');
    hh.className = 'hint';
    hh.textContent = cu
      ? 'This frame is its own size. All frames draw at the same pixel scale and share the pivot, as a fraction of each frame, so a 16x16 frame followed by a 10x20 one keeps their real proportions and the same bottom-centre point.'
      : 'This frame is one grid cell. Use a free rectangle to give it its own size, or pick "Free rectangle" in the sheet bar and drag over the sheet.';
    F.appendChild(hh);
  }
  const t2 = document.createElement('p');
  t2.className = 'hint';
  t2.textContent = 'The event fires when this frame starts, for example "footstep" or "hit". Leave it empty for none.';
  F.appendChild(t2);
  const r = document.createElement('div');
  r.className = 'row';
  r.appendChild(
    btn('Same length for all frames', () =>
      axEdit(x => {
        const d = x.frames[AXF].dur;
        x.frames.forEach(q => {
          q.dur = d;
        });
      })
    )
  );
  r.appendChild(
    btn('Duplicate', () =>
      axEdit(x => {
        if (x.frames.length < 256) x.frames.splice(AXF + 1, 0, { ...x.frames[AXF] });
      })
    )
  );
  r.appendChild(btn('Move left', () => axMove(-1)));
  r.appendChild(btn('Move right', () => axMove(1)));
  r.appendChild(btn('Delete', axDelFrame));
  F.appendChild(r);
}
function axMove(d) {
  const c = axClip(),
    j = AXF + d;
  if (!c || AXF < 0 || j < 0 || j >= c.frames.length) return;
  axEdit(x => {
    const q = x.frames.splice(AXF, 1)[0];
    x.frames.splice(j, 0, q);
  });
  AXF = j;
  axUI();
}
function axDelFrame() {
  if (AXF < 0) return;
  axEdit(x => {
    x.frames.splice(AXF, 1);
  });
}
function axSheetBar() {
  const b = $('axsb');
  b.innerHTML = '';
  if (!S.sheets.some(q => q.id === AXSH)) AXSH = S.sheets[0] ? S.sheets[0].id : '';
  const sh = S.sheets.find(q => q.id === AXSH);
  b.appendChild(
    mkSel('Sheet', [['', '(none)'], ...S.sheets.map(v => [v.id, v.name])], AXSH, v => {
      AXSH = v;
      axSheetBar();
      axDrawSheet();
    })
  );
  const il = document.createElement('label'),
    fi = document.createElement('input');
  fi.type = 'file';
  fi.accept = 'image/png,image/gif,image/webp,image/jpeg';
  fi.onchange = () => {
    const fl = fi.files[0];
    fi.value = '';
    if (!fl) return;
    const fr = new FileReader();
    fr.onload = () => {
      const q = { id: 's' + rid(), name: fl.name.slice(0, 40), url: fr.result, tw: 16, th: 16 };
      S.sheets.push(q);
      AXSH = q.id;
      save();
      axUI();
    };
    fr.readAsDataURL(fl);
  };
  il.append('Import sprite sheet', fi);
  b.appendChild(il);
  b.appendChild(
    mkNum(
      'Frame width (px)',
      sh ? sh.tw : 16,
      1,
      512,
      1,
      v => {
        sh.tw = Math.max(1, Math.min(512, Math.round(+v) || 16));
        save();
        axUI();
      },
      !sh
    )
  );
  b.appendChild(
    mkNum(
      'Frame height (px)',
      sh ? sh.th : 16,
      1,
      512,
      1,
      v => {
        sh.th = Math.max(1, Math.min(512, Math.round(+v) || 16));
        save();
        axUI();
      },
      !sh
    )
  );
  b.appendChild(
    mkNum('New frame length (ms)', AXDUR, 10, 10000, 10, v => {
      AXDUR = Math.max(10, Math.min(10000, Math.round(+v) || 100));
    })
  );
  b.appendChild(
    mkSel(
      'Pick frames by',
      [
        ['grid', 'Grid cells (all the same size)'],
        ['free', 'Free rectangle (any size)']
      ],
      AXMODE,
      v => {
        AXMODE = v;
        axSheetBar();
      }
    )
  );
  const sl = document.createElement('label'),
    sc = document.createElement('input');
  sc.type = 'checkbox';
  sc.checked = AXSKIP;
  sc.onchange = () => {
    AXSKIP = sc.checked;
  };
  sl.append(sc, ' Skip empty cells when dragging');
  b.appendChild(sl);
}
function axCtl() {
  const c = $('axctl');
  c.innerHTML = '';
  c.appendChild(
    btn(AXP && AXP.paused ? 'Play' : 'Pause', () => {
      if (!AXP) return;
      AXP.paused = !AXP.paused;
      if (!AXP.paused && AXP.done) AXP.reset();
      axCtl();
    })
  );
  c.appendChild(
    btn('Restart', () => {
      if (AXP) {
        AXP.reset();
        AXP.paused = false;
        axCtl();
      }
    })
  );
  c.appendChild(btn('Step back', () => axStep(-1)));
  c.appendChild(btn('Step forward', () => axStep(1)));
  const sl = document.createElement('input');
  sl.type = 'range';
  sl.min = 0.1;
  sl.max = 4;
  sl.step = 0.1;
  sl.value = AXSPD;
  sl.style.minWidth = '140px';
  const lb = document.createElement('span');
  lb.className = 'hint';
  lb.textContent = 'Preview speed ' + AXSPD.toFixed(1) + 'x';
  sl.oninput = () => {
    AXSPD = +sl.value;
    if (AXP) AXP.speed = AXSPD;
    lb.textContent = 'Preview speed ' + AXSPD.toFixed(1) + 'x';
  };
  c.append(sl, lb);
}
function axStep(d) {
  const c = axClip();
  if (!c || !AXP || !c.frames.length) return;
  AXP.paused = true;
  const P = MV.Anim.compile(c),
    s = MV.Anim.sample(c, AXP.t),
    u = s.time * 1000 + 1e-6;
  let k = P.seq.findIndex(q => u >= q.sMs && u < q.eMs);
  if (k < 0) k = P.seq.length - 1;
  const nk = c.mode === 'once' ? Math.max(0, Math.min(P.seq.length - 1, k + d)) : (k + d + P.seq.length) % P.seq.length;
  AXP.t = (c.mode === 'once' ? 0 : s.cycle * P.cycle) + P.seq[nk].start + 0.0005;
  AXP._last = AXP.t;
  AXP.done = false;
  axCtl();
}
function axTick(t) {
  if (TAB !== 'anim') {
    AXON = false;
    return;
  }
  requestAnimationFrame(axTick);
  const dt = Math.min(0.1, Math.max(0, (t - AXLAST) / 1000));
  AXLAST = t;
  if (AXP) AXP.update(dt);
  axDrawPrev();
  axDrawTl();
}
function axTickStart() {
  if (AXON) return;
  AXON = true;
  AXLAST = performance.now();
  requestAnimationFrame(axTick);
}
function axDrawAll() {
  axDrawPrev();
  axDrawTl();
  axDrawSheet();
}
function axDrawPrev() {
  const cv = $('axc'),
    x = cv.getContext('2d'),
    c = axClip();
  for (let i = 0; i < cv.width; i += 20)
    for (let j = 0; j < cv.height; j += 20) {
      x.fillStyle = ((i + j) / 20) % 2 ? '#26323a' : '#1d2830';
      x.fillRect(i, j, 20, 20);
    }
  x.font = '12px system-ui,sans-serif';
  x.fillStyle = '#d3d1c7';
  x.textAlign = 'center';
  AXG = null;
  const st = document.getElementById('axp');
  if (!c || !c.frames.length) {
    x.fillText(
      c ? 'Add frames from the sprite sheet below.' : 'Create a clip with New clip.',
      cv.width / 2,
      cv.height / 2
    );
    if (st) st.textContent = '';
    return;
  }
  const s = AXP ? AXP.sample() : MV.Anim.sample(c, 0),
    sh = sheetOf(s.frame.sheet);
  if (!sh) {
    x.fillText('Sprite sheet missing', cv.width / 2, cv.height / 2);
    return;
  }
  const R0 = MV.Anim.rectOf(s.frame, sh),
    k = Math.max(1, Math.floor(Math.min((cv.width - 40) / R0.sw, (cv.height - 60) / R0.sh))),
    w = R0.sw * k,
    h = R0.sh * k,
    tx = Math.round((cv.width - w) / 2),
    ty = Math.round((cv.height - h) / 2 - 6),
    px = tx + c.pivot.x * w,
    py = ty + c.pivot.y * h;
  MV.Anim.draw(x, c, s, sheetOf, px, py, { scale: k });
  x.strokeStyle = 'rgba(255,255,255,.35)';
  x.setLineDash([4, 3]);
  x.strokeRect(tx + 0.5, ty + 0.5, w, h);
  x.setLineDash([]);
  x.strokeStyle = '#ef9f27';
  x.lineWidth = 1.5;
  x.beginPath();
  x.moveTo(px - 8, py);
  x.lineTo(px + 8, py);
  x.moveTo(px, py - 8);
  x.lineTo(px, py + 8);
  x.stroke();
  x.beginPath();
  x.arc(px, py, 4, 0, 7);
  x.stroke();
  AXG = { tx, ty, w, h, tw: R0.sw, th: R0.sh };
  if (st)
    st.textContent =
      'Frame ' +
      (s.index + 1) +
      ' of ' +
      c.frames.length +
      '   ' +
      s.frame.dur +
      ' ms   ' +
      (s.done ? 'finished' : AXP && AXP.paused ? 'paused' : 'playing');
}
function axSetPivot(e) {
  const c = axClip();
  if (!c || !AXG) return;
  const cv = $('axc'),
    r = cv.getBoundingClientRect(),
    mx = ((e.clientX - r.left) / r.width) * cv.width,
    my = ((e.clientY - r.top) / r.height) * cv.height;
  c.pivot.x = Math.max(-2, Math.min(3, Math.round(((mx - AXG.tx) / AXG.w) * AXG.tw) / AXG.tw));
  c.pivot.y = Math.max(-2, Math.min(3, Math.round(((my - AXG.ty) / AXG.h) * AXG.th) / AXG.th));
  axDrawPrev();
}
$('axc').onpointerdown = e => {
  if (!axClip() || !AXG) return;
  $('axc').setPointerCapture(e.pointerId);
  AXD = { m: 'pivot' };
  axSetPivot(e);
};
$('axc').onpointermove = e => {
  if (AXD && AXD.m === 'pivot') axSetPivot(e);
};
$('axc').onpointerup = () => {
  if (AXD && AXD.m === 'pivot') {
    AXD = null;
    axEdit(() => {});
  }
};
const axTlLayout = c => {
  let x = 8;
  return c.frames.map(f => {
    const w = Math.max(56, Math.min(260, Math.round((f.dur / 1000) * 300))),
      r = { x, w };
    x += w + 4;
    return r;
  });
};
function axDrawTl() {
  const cv = $('axt'),
    x = cv.getContext('2d'),
    c = axClip(),
    L = c ? axTlLayout(c) : [],
    W = Math.max(640, (L.length ? L[L.length - 1].x + L[L.length - 1].w : 0) + 16);
  if (cv.width !== W) {
    cv.width = W;
    cv.style.width = W + 'px';
  }
  cv.height = 110;
  x.fillStyle = '#2c2c2a';
  x.fillRect(0, 0, W, 110);
  x.font = '11px system-ui,sans-serif';
  x.textBaseline = 'middle';
  if (!c || !c.frames.length) {
    x.fillStyle = '#8a8880';
    x.textAlign = 'left';
    x.fillText('No frames yet. Click cells in the sprite sheet below.', 12, 55);
    return;
  }
  const s = AXP ? AXP.sample() : null,
    P = MV.Anim.compile(c);
  c.frames.forEach((f, i) => {
    const r = L[i],
      sh = sheetOf(f.sheet),
      y = 20,
      h = 84;
    x.fillStyle = i === AXF ? '#3a3a37' : '#33332f';
    x.fillRect(r.x, y, r.w, h);
    if (sh && sh.img.complete && sh.img.naturalWidth) {
      const R = MV.Anim.rectOf(f, sh),
        bw = r.w - 8,
        bh = h - 30,
        k = Math.min(bw / R.sw, bh / R.sh),
        dw = R.sw * k,
        dh = R.sh * k;
      x.imageSmoothingEnabled = false;
      x.drawImage(sh.img, R.sx, R.sy, R.sw, R.sh, r.x + (r.w - dw) / 2, y + 4 + (bh - dh) / 2, dw, dh);
    }
    x.textAlign = 'left';
    x.fillStyle = '#d3d1c7';
    x.fillText(String(i + 1), r.x + 4, y + h - 16);
    x.textAlign = 'right';
    x.fillText(f.dur + ' ms', r.x + r.w - 4, y + h - 6);
    if (f.event) {
      x.fillStyle = '#ef9f27';
      x.beginPath();
      x.moveTo(r.x + 2, 4);
      x.lineTo(r.x + 12, 9);
      x.lineTo(r.x + 2, 14);
      x.fill();
      x.textAlign = 'left';
      x.fillText(f.event, r.x + 16, 9);
    }
    x.strokeStyle = i === AXF ? '#fff' : s && s.index === i ? '#ef9f27' : 'rgba(255,255,255,.2)';
    x.lineWidth = i === AXF || (s && s.index === i) ? 2 : 1;
    x.strokeRect(r.x + 0.5, y + 0.5, r.w - 1, h - 1);
  });
  if (s && s.frame) {
    const q = P.seq.find(z => z.i === s.index && s.time * 1000 + 1e-6 >= z.sMs && s.time * 1000 + 1e-6 < z.eMs);
    if (q && L[s.index]) {
      const r = L[s.index],
        px = r.x + r.w * Math.min(1, (s.time * 1000 - q.sMs) / (q.eMs - q.sMs));
      x.strokeStyle = '#e24b4a';
      x.lineWidth = 2;
      x.beginPath();
      x.moveTo(px, 18);
      x.lineTo(px, 106);
      x.stroke();
    }
  }
}
const axPx = (e, cv) => {
  const r = cv.getBoundingClientRect();
  return { x: ((e.clientX - r.left) / r.width) * cv.width, y: ((e.clientY - r.top) / r.height) * cv.height };
};
$('axt').onpointerdown = e => {
  const c = axClip();
  if (!c) return;
  const L = axTlLayout(c),
    px = axPx(e, $('axt')).x,
    i = L.findIndex(r => px >= r.x && px < r.x + r.w);
  if (i < 0) {
    AXF = -1;
    axForm();
    axDrawTl();
    return;
  }
  AXF = i;
  AXD = { m: 'frame', i, x0: px, moved: false };
  $('axt').setPointerCapture(e.pointerId);
  axForm();
  axDrawTl();
};
$('axt').onpointermove = e => {
  if (!AXD || AXD.m !== 'frame') return;
  const c = axClip(),
    L = axTlLayout(c),
    px = axPx(e, $('axt')).x;
  if (Math.abs(px - AXD.x0) > 5) AXD.moved = true;
  if (!AXD.moved) return;
  const j = L.filter((r, k) => k !== AXD.i && px >= r.x + r.w / 2).length; // where it lands among the other frames
  if (j !== AXD.i) {
    const f = c.frames.splice(AXD.i, 1)[0];
    c.frames.splice(j, 0, f);
    AXD.i = j;
    AXF = j;
    axDrawTl();
  }
};
$('axt').onpointerup = () => {
  if (AXD && AXD.m === 'frame') {
    const mv = AXD.moved;
    AXD = null;
    if (mv) axEdit(() => {});
    else axForm();
  }
};
function axDrawSheet() {
  const cv = $('axs'),
    x = cv.getContext('2d'),
    sh = S.sheets.find(q => q.id === AXSH);
  const msg = t => {
    cv.width = 640;
    cv.height = 40;
    cv.style.width = '640px';
    x.fillStyle = '#2c2c2a';
    x.fillRect(0, 0, 640, 40);
    x.fillStyle = '#8a8880';
    x.font = '12px system-ui,sans-serif';
    x.textAlign = 'left';
    x.textBaseline = 'middle';
    x.fillText(t, 10, 20);
  };
  if (!sh) {
    msg('Import a sprite sheet to start.');
    return;
  }
  const m = img(sh);
  if (!m.complete || !m.naturalWidth) {
    msg('Loading the sprite sheet...');
    return;
  }
  const k = Math.max(1, Math.min(8, Math.floor(640 / m.naturalWidth)));
  cv.width = m.naturalWidth * k;
  cv.height = m.naturalHeight * k;
  cv.style.width = cv.width + 'px';
  x.fillStyle = '#12324a';
  x.fillRect(0, 0, cv.width, cv.height);
  x.imageSmoothingEnabled = false;
  x.drawImage(m, 0, 0, cv.width, cv.height);
  x.strokeStyle = 'rgba(255,255,255,.25)';
  x.lineWidth = 1;
  for (let a = 0; a <= m.naturalWidth; a += sh.tw) {
    x.beginPath();
    x.moveTo(a * k + 0.5, 0);
    x.lineTo(a * k + 0.5, cv.height);
    x.stroke();
  }
  for (let b = 0; b <= m.naturalHeight; b += sh.th) {
    x.beginPath();
    x.moveTo(0, b * k + 0.5);
    x.lineTo(cv.width, b * k + 0.5);
    x.stroke();
  }
  const c = axClip();
  if (c) {
    x.strokeStyle = '#ef9f27';
    c.frames.forEach(f => {
      if (f.sheet !== sh.id) return;
      const R = MV.Anim.rectOf(f, sh);
      x.strokeRect(R.sx * k + 1.5, R.sy * k + 1.5, R.sw * k - 3, R.sh * k - 3);
    });
  }
  if (AXSEL && AXSEL.free) {
    const a = AXSEL,
      fx = Math.min(a.x0, a.x1),
      fy = Math.min(a.y0, a.y1),
      fw = Math.abs(a.x1 - a.x0) + 1,
      fh = Math.abs(a.y1 - a.y0) + 1;
    x.fillStyle = 'rgba(239,159,39,.4)';
    x.fillRect(fx * k, fy * k, fw * k, fh * k);
    x.fillStyle = '#fff';
    x.font = '11px system-ui,sans-serif';
    x.textAlign = 'left';
    x.textBaseline = 'top';
    x.fillText(fw + ' x ' + fh + ' px', fx * k + 3, fy * k + 3);
  } else if (AXSEL) {
    const a = AXSEL;
    x.fillStyle = 'rgba(239,159,39,.4)';
    x.fillRect(
      Math.min(a.c0, a.c1) * sh.tw * k,
      Math.min(a.r0, a.r1) * sh.th * k,
      (Math.abs(a.c1 - a.c0) + 1) * sh.tw * k,
      (Math.abs(a.r1 - a.r0) + 1) * sh.th * k
    );
  }
}
function axCell(e) {
  const sh = S.sheets.find(q => q.id === AXSH),
    m = img(sh),
    cv = $('axs'),
    r = cv.getBoundingClientRect(),
    k = cv.width / m.naturalWidth,
    nc = Math.ceil(m.naturalWidth / sh.tw),
    nr = Math.ceil(m.naturalHeight / sh.th);
  return {
    c: Math.max(0, Math.min(nc - 1, Math.floor((((e.clientX - r.left) / r.width) * cv.width) / k / sh.tw))),
    r: Math.max(0, Math.min(nr - 1, Math.floor((((e.clientY - r.top) / r.height) * cv.height) / k / sh.th)))
  };
}
$('axs').onpointerdown = e => {
  const sh = S.sheets.find(q => q.id === AXSH);
  if (!axClip()) {
    axMsg('Create a clip first with New clip.');
    return;
  }
  if (!sh) {
    axMsg('Import a sprite sheet first.');
    return;
  }
  if (!img(sh).naturalWidth) return;
  if (AXMODE === 'free') {
    const q = axPix(e);
    AXSEL = { free: 1, x0: q.x, y0: q.y, x1: q.x, y1: q.y };
    AXD = { m: 'sheet' };
    $('axs').setPointerCapture(e.pointerId);
    axDrawSheet();
    return;
  }
  const q = axCell(e);
  AXSEL = { c0: q.c, r0: q.r, c1: q.c, r1: q.r };
  AXD = { m: 'sheet' };
  $('axs').setPointerCapture(e.pointerId);
  axDrawSheet();
};
$('axs').onpointermove = e => {
  if (!AXSEL) return;
  if (AXSEL.free) {
    const q = axPix(e);
    AXSEL.x1 = q.x;
    AXSEL.y1 = q.y;
    axDrawSheet();
    return;
  }
  const q = axCell(e);
  AXSEL.c1 = q.c;
  AXSEL.r1 = q.r;
  axDrawSheet();
};
$('axs').onpointerup = () => {
  if (!AXSEL) return;
  const a = AXSEL;
  AXSEL = null;
  AXD = null;
  if (a.free) axAddFree(a);
  else axAddFrames(a);
};
function axPix(e) {
  const sh = S.sheets.find(q => q.id === AXSH),
    m = img(sh),
    cv = $('axs'),
    r = cv.getBoundingClientRect(),
    k = cv.width / m.naturalWidth;
  return {
    x: Math.max(0, Math.min(m.naturalWidth - 1, Math.floor((((e.clientX - r.left) / r.width) * cv.width) / k))),
    y: Math.max(0, Math.min(m.naturalHeight - 1, Math.floor((((e.clientY - r.top) / r.height) * cv.height) / k)))
  };
}
function axAddFree(a) {
  const sh = S.sheets.find(q => q.id === AXSH),
    c = axClip();
  if (!sh || !c) return;
  if (c.frames.length >= 256) {
    axMsg('A clip can have up to 256 frames.');
    axDrawSheet();
    return;
  }
  const x = Math.min(a.x0, a.x1),
    y = Math.min(a.y0, a.y1),
    w = Math.abs(a.x1 - a.x0) + 1,
    h = Math.abs(a.y1 - a.y0) + 1;
  axMsg('Added a ' + w + ' x ' + h + ' px frame.');
  axEdit(z => {
    z.frames.push({ sheet: sh.id, col: 0, row: 0, x, y, w, h, dur: AXDUR, event: '' });
  });
  AXF = axClip().frames.length - 1;
  axUI();
}
function axAddFrames(a) {
  const sh = S.sheets.find(q => q.id === AXSH),
    c = axClip();
  if (!sh || !c) return;
  const one = a.c0 === a.c1 && a.r0 === a.r1,
    add = [];
  for (let r = Math.min(a.r0, a.r1); r <= Math.max(a.r0, a.r1); r++)
    for (let k = Math.min(a.c0, a.c1); k <= Math.max(a.c0, a.c1); k++) {
      if (AXSKIP && !one && blankT(sh, k, r)) continue;
      add.push({ sheet: sh.id, col: k, row: r, dur: AXDUR, event: '' });
    }
  if (!add.length) {
    axMsg('Those cells are empty.');
    axDrawSheet();
    return;
  }
  if (c.frames.length + add.length > 256) {
    axMsg('A clip can have up to 256 frames.');
    axDrawSheet();
    return;
  }
  axMsg('');
  axEdit(x => {
    x.frames.push(...add);
  });
  AXF = axClip().frames.length - 1;
  axUI();
}
