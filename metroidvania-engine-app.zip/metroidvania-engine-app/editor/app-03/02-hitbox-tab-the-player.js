// ===== Hitbox tab: the player's body hitbox (the part that gets hurt). Always: its shape and size. For a move or attack: keyframes (move/resize at any time) and invincible periods. The picture stays put. =====
let AFILT = '*',
  MSEC = 'move',
  ASEC = 'attack',
  HBD = null,
  HBM = null,
  HBS = { sel: 'base', t: 0, kt: null, play: false, raf: 0, last: 0, redraw: null };
function hbSet(fn, rebuild) {
  const b = Object.assign({}, S.body);
  fn(b);
  S.body = MV.Attacks.bodyClean(b);
  save();
  if (rebuild !== false) buildHb(HBM);
}
function hbObj() {
  const s = HBS.sel;
  if (s === 'base') return null;
  const id = s.slice(2),
    o = s[0] === 'm' ? S.moves.find(m => m.id === id) : S.attacks.find(a => a.id === id);
  if (!o) HBS.sel = 'base';
  return o || null;
}
// A time typed past the end of a move or attack makes it longer instead of being cut off (0.5 to 0.6 on a 0.3 s attack becomes a 0.6 s attack). Not for multi-step moves, whose length comes from their steps.
function fitDur(x) {
  if (!x || x.type === 'sequence' || x.duration === undefined) return;
  let t = 0;
  const kf = a =>
    (a || []).forEach(q => {
      if (q && isFinite(+q.t)) t = Math.max(t, +q.t);
    });
  if (x.body) {
    (x.body.off || []).forEach(q => {
      t = Math.max(t, +q.to || 0, +q.from || 0);
    });
    kf(x.body.kf);
  }
  (x.hitboxes || []).forEach(h => {
    if (h.to < h.from) h.to = h.from + 0.1;
    t = Math.max(t, +h.to || 0, +h.from || 0);
    kf(h.kf);
  });
  if (t > x.duration) x.duration = Math.ceil(t * 100) / 100;
}
function hbChg(o, fn) {
  fn(o);
  fitDur(o);
  if (HBS.sel[0] === 'm') {
    Object.assign(o, MV.Moves.clean1(o));
    mvSync();
  } else {
    Object.assign(o, MV.Attacks.clean1(o));
    abSync();
  }
  save();
}
function hbKf(o, t, v) {
  const l = o.body.kf;
  let k = l.find(q => Math.abs(q.t - t) < 0.005);
  if (k) Object.assign(k, v);
  else {
    k = Object.assign({ t }, v);
    l.push(k);
    l.sort((a, b) => a.t - b.t);
  }
  HBS.kt = k.t;
  return k;
}
function hbStop() {
  HBS.play = false;
  if (HBS.raf) cancelAnimationFrame(HBS.raf);
  HBS.raf = 0;
}
function hbLoop(ts) {
  if (!HBS.play || !(HBM && HBM.c && HBM.c.offsetParent)) {
    hbStop();
    return;
  }
  const o = hbObj();
  if (!o) {
    hbStop();
    return;
  }
  const D = Math.max(0.05, o.duration),
    dt = Math.min(0.1, (ts - (HBS.last || ts)) / 1000);
  HBS.last = ts;
  HBS.t += dt;
  if (HBS.t > D) HBS.t = 0;
  if (HBS.redraw) HBS.redraw();
  HBS.raf = requestAnimationFrame(hbLoop);
}
// Builds the hitbox editor inside any element: host gets the controls, the picture, the time strip and the form. lock = 'm:id' or 'a:id' edits only that move or attack.
function hbMount(host, lock) {
  host.innerHTML = '';
  const mk = (t, st) => {
      const e = document.createElement(t);
      if (st) e.style.cssText = st;
      return e;
    },
    cs = 'width:100%;max-width:640px;border:1px solid var(--bd);border-radius:8px;touch-action:none;display:block';
  const sr = mk('div');
  sr.className = 'row';
  const c = mk('canvas', cs),
    tc = mk('canvas', cs + ';margin-top:6px'),
    h = mk('p'),
    f = mk('div');
  c.width = 640;
  c.height = 400;
  tc.width = 640;
  tc.height = 64;
  h.className = 'hint';
  host.append(sr, c, tc, h, f);
  buildHb({ c, tc, f, sr, h, lock });
}
function buildHb(mt) {
  const M = mt || { c: $('hbc'), tc: $('hbt'), f: $('hbf'), sr: $('hbs'), h: $('hbh') };
  HBM = M;
  if (M.lock) {
    if (!M.cur) M.cur = M.lock;
    if (HBS.sel !== M.cur) {
      HBS.t = 0;
      HBS.kt = null;
    }
    HBS.sel = M.cur;
  }
  const c = M.c,
    tc = M.tc,
    f = M.f,
    sr = M.sr;
  if (!c || !f || !sr) return;
  hbStop();
  const pr = MV.Tuning.resolve(S.player),
    sp = S.sprite,
    o = hbObj(),
    D = o ? Math.max(0.05, o.duration) : 0;
  if (HBS.t > D) HBS.t = D;
  const B0 = MV.Attacks.body(S.body, pr),
    fx = c.width / 2,
    fy = c.height * 0.84,
    KF = o ? o.body.kf : [];
  let ex = Math.max(sp.w / 2, pr.w / 2, B0.w / 2, B0.r || 0),
    eu = Math.max(sp.h, pr.h, B0.h / 2 + pr.h / 2 + Math.abs(B0.oy));
  KF.forEach(k => {
    ex = Math.max(ex, Math.abs(B0.ox + k.x) + k.w / 2);
    eu = Math.max(eu, pr.h / 2 - (B0.oy + k.y) + k.h / 2);
  });
  const Z = Math.max(12, Math.min(150, (c.width / 2 - 24) / (ex + 0.2), (fy - 14) / (eu + 0.2))),
    px = fx / Z,
    py = fy / Z;
  const cur = t => MV.Attacks.bodyKf(o.body, t) || { w: B0.w, h: B0.h, x: 0, y: 0 };
  const ovAt = () => {
      if (!o) return null;
      const k = KF.length ? cur(HBS.t) : null;
      return o.body.shape ? Object.assign({ w: B0.w, h: B0.h, x: 0, y: 0 }, k || {}, { shape: o.body.shape }) : k;
    },
    offNow = () => !!o && MV.Attacks.isOff(o.body, HBS.t);
  const geo = () => {
    const ov = ovAt(),
      bw = MV.Attacks.bodyWorld(S.body, pr, px, py, 1, 1, ov);
    return { ov, bw };
  };
  const draw = () => {
    const x = c.getContext('2d'),
      { ov, bw } = geo(),
      off = offNow();
    x.fillStyle = '#12324a';
    x.fillRect(0, 0, c.width, c.height);
    x.strokeStyle = 'rgba(255,255,255,.07)';
    for (let g = fx % Z; g < c.width; g += Z) {
      x.beginPath();
      x.moveTo(g + 0.5, 0);
      x.lineTo(g + 0.5, c.height);
      x.stroke();
    }
    for (let g = fy % Z; g < c.height; g += Z) {
      x.beginPath();
      x.moveTo(0, g + 0.5);
      x.lineTo(c.width, g + 0.5);
      x.stroke();
    }
    x.fillStyle = 'rgba(255,255,255,.12)';
    x.fillRect(0, fy, c.width, c.height - fy);
    x.save();
    if (off) x.globalAlpha = 0.45;
    const ok = MV.PlayerSprite.frame(x, sp, sheetOf, 'idle', 0, fx, fy, 1, Z);
    if (!ok) {
      x.fillStyle = 'rgba(93,202,165,.45)';
      x.fillRect(fx - (pr.w * Z) / 2, fy - pr.h * Z, pr.w * Z, pr.h * Z);
    }
    x.restore();
    x.strokeStyle = 'rgba(255,255,255,.3)';
    x.setLineDash([3, 3]);
    x.strokeRect(fx - (pr.w * Z) / 2, fy - pr.h * Z, pr.w * Z, pr.h * Z);
    x.setLineDash([]);
    x.fillStyle = off ? 'rgba(180,178,169,.22)' : 'rgba(93,202,165,.25)';
    x.strokeStyle = off ? '#b4b2a9' : '#5dcaa5';
    x.lineWidth = 2;
    x.setLineDash(off ? [5, 4] : []);
    MV.Attacks.trace(x, bw, Z);
    x.fill();
    x.stroke();
    x.setLineDash([]);
    x.lineWidth = 1;
    if (!o && B0.shape === 'polygon') {
      x.fillStyle = '#fff';
      B0.pts.forEach(q => {
        x.beginPath();
        x.arc(bw.cx * Z + q.x * Z, bw.cy * Z + q.y * Z, 5, 0, 7);
        x.fill();
      });
    }
    if (o || B0.shape !== 'polygon') {
      x.fillStyle = '#fff';
      x.strokeStyle = '#12324a';
      hbCorners(bw).forEach(q => {
        x.fillRect(q.x * Z - 5, q.y * Z - 5, 10, 10);
        x.strokeRect(q.x * Z - 5, q.y * Z - 5, 10, 10);
      });
    }
    x.fillStyle = '#b4b2a9';
    x.font = '11px system-ui,sans-serif';
    x.textAlign = 'left';
    x.fillText(
      o
        ? 'Time ' +
            HBS.t.toFixed(2) +
            ' s' +
            (off ? '  -  INVINCIBLE now (grey, dashed)' : '') +
            '   Green = body hitbox, dashed = plain walking size'
        : 'Green = body hitbox (gets hurt). Dashed = the plain body size used for walking. Grid squares are tiles.',
      8,
      c.height - 8
    );
  };
  const SX = 16,
    tx = t => SX + (t / Math.max(D, 0.05)) * (tc.width - 2 * SX),
    tt = px2 => Math.max(0, Math.min(D, Math.round(((px2 - SX) / (tc.width - 2 * SX)) * D * 100) / 100));
  const drawT = () => {
    const x = tc.getContext('2d');
    x.fillStyle = '#0d2233';
    x.fillRect(0, 0, tc.width, tc.height);
    if (!o) {
      x.fillStyle = '#b4b2a9';
      x.font = '12px system-ui,sans-serif';
      x.textAlign = 'left';
      x.fillText('Pick a move or attack above to edit the hitbox through time.', 10, 36);
      return;
    }
    x.font = '10px system-ui,sans-serif';
    x.textAlign = 'center';
    const st = D > 2 ? 0.5 : D > 1 ? 0.2 : 0.1;
    for (let t = 0; t <= D + 0.0001; t += st) {
      x.fillStyle = 'rgba(255,255,255,.25)';
      x.fillRect(tx(t), 6, 1, 8);
      x.fillStyle = '#b4b2a9';
      x.fillText(t.toFixed(t % 1 ? 1 : 0), tx(t), 24);
    }
    x.textAlign = 'right';
    x.fillStyle = '#8fa3b3';
    x.fillText('Size/place keyframes', tc.width - 8, 36);
    o.body.kf.forEach(k => {
      const sel = HBS.kt !== null && Math.abs(k.t - HBS.kt) < 0.005,
        X = tx(k.t);
      x.fillStyle = sel ? '#fff' : '#5dcaa5';
      x.beginPath();
      x.moveTo(X, 38);
      x.lineTo(X + 6, 44);
      x.lineTo(X, 50);
      x.lineTo(X - 6, 44);
      x.fill();
    });
    x.fillStyle = '#8fa3b3';
    x.fillText('Invincible periods', tc.width - 8, 58);
    o.body.off.forEach(q => {
      x.fillStyle = 'rgba(239,159,39,.75)';
      x.fillRect(tx(q.from), 52, Math.max(3, tx(q.to) - tx(q.from)), 8);
      x.fillStyle = '#fff';
      x.fillRect(tx(q.from) - 1, 50, 3, 12);
      x.fillRect(tx(q.to) - 1, 50, 3, 12);
    });
    x.fillStyle = '#fff';
    x.fillRect(tx(HBS.t) - 1, 2, 2, tc.height - 4);
  };
  HBS.redraw = () => {
    draw();
    drawT();
    if (HBS.sl) {
      HBS.sl.value = HBS.t;
      HBS.lab.textContent = HBS.t.toFixed(2) + ' s / ' + D.toFixed(2) + ' s';
    }
  };
  // the four corner squares of a shape's bounding box (world tiles): 0 top-left, 1 top-right, 2 bottom-left, 3 bottom-right
  function hbCorners(bw) {
    const w = bw.w / 2,
      h = bw.h / 2;
    return [
      { x: bw.cx - w, y: bw.cy - h },
      { x: bw.cx + w, y: bw.cy - h },
      { x: bw.cx - w, y: bw.cy + h },
      { x: bw.cx + w, y: bw.cy + h }
    ];
  }
  const pt = (e, cv) => {
      const r = cv.getBoundingClientRect();
      return { x: ((e.clientX - r.left) / r.width) * cv.width, y: ((e.clientY - r.top) / r.height) * cv.height };
    },
    sn = v => Math.round(v * 20) / 20;
  // The hitbox as a centre (cx, cy) in tiles and a size, turned into the stored numbers.
  const apply = (cx, cy, w, h) => {
    if (o) {
      const { ov, bw } = geo(),
        cu = ov || { w: B0.w, h: B0.h, x: 0, y: 0 };
      let fw = w / bw.w,
        fh = h / bw.h;
      if (bw.sh === 'circle') fw = fh = (fw + fh) / 2;
      hbKf(o, HBS.t, {
        w: Math.max(0.1, cu.w * fw),
        h: Math.max(0.1, cu.h * fh),
        x: Math.max(-10, Math.min(10, sn(cx - px - B0.ox))),
        y: Math.max(-10, Math.min(10, sn(cy - (py - pr.h / 2) - B0.oy)))
      });
      if (KF.length === 1 && KF[0].t > 0.01) o.body.kf.unshift({ t: 0, w: B0.w, h: B0.h, x: 0, y: 0 });
    } else {
      const b = {};
      b.ox = sn(cx - px);
      b.oy = sn(cy - (py - pr.h / 2));
      if (B0.shape === 'rect') {
        b.w = Math.max(0.1, sn(w));
        b.h = Math.max(0.1, sn(h));
      } else if (B0.shape === 'circle') b.r = Math.max(0.05, sn(Math.max(w, h) / 2));
      S.body = MV.Attacks.bodyClean(Object.assign({}, S.body, b));
    }
  };
  c.onpointerdown = e => {
    hbStop();
    const q = pt(e, c),
      { bw } = geo(),
      X = q.x / Z,
      Y = q.y / Z;
    if (!o && B0.shape === 'polygon') {
      const vi = B0.pts.findIndex(v => Math.hypot(q.x - (bw.cx * Z + v.x * Z), q.y - (bw.cy * Z + v.y * Z)) <= 9);
      if (vi < 0) return;
      if (e.shiftKey || e.altKey) {
        if (B0.pts.length > 3)
          hbSet(x => {
            x.pts = B0.pts.filter((v, i) => i !== vi);
          });
        return;
      }
      HBD = { vi };
      c.setPointerCapture(e.pointerId);
      return;
    }
    const ci = hbCorners(bw).findIndex(v => Math.hypot(q.x - v.x * Z, q.y - v.y * Z) <= 10);
    if (ci >= 0) HBD = { co: ci, bw: Object.assign({}, bw) };
    else if (Math.abs(X - bw.cx) <= bw.w / 2 && Math.abs(Y - bw.cy) <= bw.h / 2)
      HBD = { mv: 1, dx: X - bw.cx, dy: Y - bw.cy, bw: Object.assign({}, bw) };
    else return;
    c.setPointerCapture(e.pointerId);
  };
  c.onpointermove = e => {
    if (!HBD) return;
    const q = pt(e, c),
      X = q.x / Z,
      Y = q.y / Z;
    if (HBD.vi !== undefined) {
      const cx = px + B0.ox,
        cy = py - pr.h / 2 + B0.oy,
        P = B0.pts.map(v => ({ x: v.x, y: v.y }));
      P[HBD.vi] = { x: sn(X - cx), y: sn(Y - cy) };
      S.body = MV.Attacks.bodyClean(Object.assign({}, S.body, { pts: P }));
    } else if (HBD.mv) apply(X - HBD.dx, Y - HBD.dy, HBD.bw.w, HBD.bw.h);
    else {
      const b = HBD.bw,
        oc = hbCorners(b)[3 - HBD.co],
        w = Math.max(0.1, Math.abs(X - oc.x)),
        h = Math.max(0.1, Math.abs(Y - oc.y));
      apply((X + oc.x) / 2, (Y + oc.y) / 2, w, h);
    }
    draw();
    drawT();
  };
  c.onpointerup = () => {
    if (HBD) {
      HBD = null;
      if (o) hbChg(o, () => {});
      else save();
      buildHb(M);
    }
  };
  // the time strip: click or drag to scrub, drag a diamond to move a keyframe in time, drag an orange bar (or its ends) to change an invincible period
  tc.onpointerdown = e => {
    if (!o) return;
    hbStop();
    const q = pt(e, tc);
    let h = null;
    if (q.y >= 34 && q.y <= 50)
      o.body.kf.forEach(k => {
        if (Math.abs(tx(k.t) - q.x) <= 8) h = { k };
      });
    else if (q.y > 50)
      o.body.off.forEach(z => {
        const a = tx(z.from),
          b = tx(z.to);
        if (Math.abs(q.x - a) <= 6) h = { z, end: 'from' };
        else if (Math.abs(q.x - b) <= 6) h = { z, end: 'to' };
        else if (q.x > a && q.x < b) h = { z, end: 'both', g: tt(q.x) - z.from };
      });
    if (h && h.k) {
      HBS.kt = h.k.t;
      HBS.t = h.k.t;
      HBD = { tk: h.k };
    } else if (h) HBD = { tz: h.z, end: h.end, g: h.g };
    else {
      HBD = { sc: 1 };
      HBS.t = tt(q.x);
    }
    tc.setPointerCapture(e.pointerId);
    HBS.redraw();
  };
  tc.onpointermove = e => {
    if (!HBD || !o) return;
    const t = tt(pt(e, tc).x);
    if (HBD.sc) HBS.t = t;
    else if (HBD.tk) {
      HBD.tk.t = t;
      o.body.kf.sort((a, b) => a.t - b.t);
      HBS.kt = t;
      HBS.t = t;
    } else if (HBD.tz) {
      const z = HBD.tz;
      if (HBD.end === 'from') z.from = Math.min(t, z.to);
      else if (HBD.end === 'to') z.to = Math.max(t, z.from);
      else {
        const len = z.to - z.from,
          a = Math.max(0, Math.min(D - len, Math.round((t - HBD.g) * 100) / 100));
        z.from = a;
        z.to = a + len;
      }
    }
    HBS.redraw();
  };
  tc.onpointerup = () => {
    if (HBD && o) {
      const sc = HBD.sc;
      HBD = null;
      if (!sc) hbChg(o, () => {});
      buildHb(M);
    }
  };
  // the controls above the picture: what to edit, play and the time slider
  sr.innerHTML = '';
  const opts = [['base', 'Normal body (always)']].concat(
    S.moves.filter(m => !['hold', 'swim', 'surface'].includes(m.type)).map(m => ['m:' + m.id, 'Move: ' + m.label]),
    S.attacks.map(a => ['a:' + a.id, 'Attack: ' + a.label])
  );
  if (!M.lock)
    sr.append(
      mkSel('Edit the hitbox for', opts, HBS.sel, v => {
        HBS.sel = v;
        HBS.kt = null;
        HBS.t = 0;
        buildHb(M);
      })
    );
  else
    sr.append(
      mkSel(
        'Editing',
        [
          [M.lock, 'The hitbox during this ' + (M.lock[0] === 'm' ? 'move' : 'attack') + ' (keyframes, invincible)'],
          ['base', 'The normal hitbox (shape and size, all the time)']
        ],
        M.cur,
        v => {
          M.cur = v;
          HBS.kt = null;
          HBS.t = 0;
          buildHb(M);
        }
      )
    );
  HBS.sl = null;
  if (o) {
    const sl = document.createElement('input');
    sl.type = 'range';
    sl.min = 0;
    sl.max = D;
    sl.step = 0.01;
    sl.value = HBS.t;
    sl.style.minWidth = '180px';
    const lab = document.createElement('span');
    lab.className = 'hint';
    lab.textContent = HBS.t.toFixed(2) + ' s / ' + D.toFixed(2) + ' s';
    HBS.sl = sl;
    HBS.lab = lab;
    sl.oninput = () => {
      hbStop();
      HBS.t = +sl.value;
      draw();
      drawT();
      lab.textContent = HBS.t.toFixed(2) + ' s / ' + D.toFixed(2) + ' s';
      const k = KF.find(q => Math.abs(q.t - HBS.t) < 0.005);
      HBS.kt = k ? k.t : null;
    };
    sl.onchange = () => buildHb(M);
    sr.append(
      btn('Play', () => {
        if (HBS.play) {
          hbStop();
          return;
        }
        HBS.play = true;
        HBS.last = 0;
        HBS.raf = requestAnimationFrame(hbLoop);
      }),
      sl,
      lab
    );
  }
  M.h.textContent = o
    ? 'Scrub the time, then drag the green box to move it and its white corner squares to resize it. Each change at a time makes a keyframe (a diamond on the strip) and the box glides between keyframes.  Here the picture stays put; in Test movement it follows the hitbox.'
    : B0.shape === 'polygon'
      ? 'Drag a white dot to move a corner. Shift+click a dot removes it. Drag the green shape to move it.'
      : 'Drag the shape to move it, drag a white corner square to resize it.';
  f.innerHTML = '';
  if (o) {
    const cu = cur(HBS.t),
      g = document.createElement('div');
    g.className = 'mvf';
    const sel = KF.find(q => Math.abs(q.t - HBS.t) < 0.005);
    const st = (k, v) => {
      hbChg(o, () => {
        hbKf(o, HBS.t, Object.assign({ w: cu.w, h: cu.h, x: cu.x, y: cu.y }, { [k]: +v }));
        if (o.body.kf.length === 1 && o.body.kf[0].t > 0.01) o.body.kf.unshift({ t: 0, w: B0.w, h: B0.h, x: 0, y: 0 });
      });
      buildHb(M);
    };
    const hp = document.createElement('p');
    hp.className = 'hint';
    hp.textContent =
      'At ' +
      HBS.t.toFixed(2) +
      ' s' +
      (sel
        ? ' (a keyframe is here)'
        : KF.length
          ? ' (between keyframes)'
          : ' (no keyframes yet: the plain hitbox is used)') +
      '. Typing a number here makes a keyframe at this time. The shape (rectangle, circle, polygon) and normal size are set by choosing "The normal hitbox" in the Editing menu above the picture. The timeline is as long as the move or attack lasts (change the duration in its Move or Attack section).';
    f.appendChild(hp);
    g.append(
      mkSel(
        'Shape while this plays',
        [
          ['', 'Normal (the player hitbox)'],
          ['rect', 'Rectangle'],
          ['circle', 'Circle'],
          ['polygon', 'Polygon (corners of the normal hitbox)']
        ],
        o.body.shape || '',
        v => {
          hbChg(o, x => {
            x.body.shape = v;
          });
          buildHb(M);
        }
      ),
      mkNum('Width (tiles)', +cu.w.toFixed(2), 0.1, 30, 0.05, v => st('w', v)),
      mkNum('Height (tiles)', +cu.h.toFixed(2), 0.1, 30, 0.05, v => st('h', v)),
      mkNum('Move sideways (tiles)', +cu.x.toFixed(2), -10, 10, 0.05, v => st('x', v)),
      mkNum('Move up/down (tiles)', +cu.y.toFixed(2), -10, 10, 0.05, v => st('y', v))
    );
    f.appendChild(g);
    const r = document.createElement('div');
    r.className = 'row';
    r.append(
      btn('Add keyframe here', () => {
        hbChg(o, () => {
          hbKf(o, HBS.t, { w: cu.w, h: cu.h, x: cu.x, y: cu.y });
          if (o.body.kf.length === 1 && o.body.kf[0].t > 0.01)
            o.body.kf.unshift({ t: 0, w: B0.w, h: B0.h, x: 0, y: 0 });
        });
        buildHb(M);
      }),
      btn('Delete keyframe', () => {
        const k = KF.find(q => HBS.kt !== null && Math.abs(q.t - HBS.kt) < 0.005) || sel;
        if (!k) {
          $('pmsg').textContent = 'Scrub to a keyframe (or click its diamond) first.';
          return;
        }
        hbChg(o, x => {
          x.body.kf = x.body.kf.filter(q => q.t !== k.t);
        });
        HBS.kt = null;
        buildHb(M);
      }),
      btn('Delete all keyframes', () => {
        hbChg(o, x => {
          x.body.kf = [];
        });
        HBS.kt = null;
        buildHb(M);
      })
    );
    f.appendChild(r);
    const s2 = document.createElement('strong');
    s2.textContent = 'Invincible periods';
    f.appendChild(s2);
    const p2 = document.createElement('p');
    p2.className = 'hint';
    p2.textContent =
      'In these time ranges (seconds from the start) nothing can hurt the player. Drag the orange bars on the strip or type the times.';
    f.appendChild(p2);
    o.body.off.forEach((z, i) => {
      const row = document.createElement('div');
      row.className = 'row';
      row.append(
        mkNum('From (s)', z.from, 0, 10, 0.01, v => {
          hbChg(o, x => {
            x.body.off[i].from = +v;
            if (x.body.off[i].to < +v) x.body.off[i].to = +v;
          });
          buildHb(M);
        }),
        mkNum('To (s)', z.to, 0, 10, 0.01, v => {
          hbChg(o, x => {
            x.body.off[i].to = +v;
            if (x.body.off[i].from > +v) x.body.off[i].from = +v;
          });
          buildHb(M);
        }),
        btn('Remove', () => {
          hbChg(o, x => {
            x.body.off.splice(i, 1);
          });
          buildHb(M);
        })
      );
      f.appendChild(row);
    });
    const r2 = document.createElement('div');
    r2.className = 'row';
    r2.append(
      btn('Add invincible period', () => {
        if (o.body.off.length >= 8) {
          $('pmsg').textContent = 'Up to 8 invincible periods.';
          return;
        }
        const a = HBS.t >= D - 0.02 ? Math.max(0, D - 0.1) : HBS.t;
        hbChg(o, x => {
          x.body.off.push({ from: a, to: Math.min(D, a + 0.1) });
        });
        buildHb(M);
      }),
      btn('Test movement', mtOpen)
    );
    f.appendChild(r2);
  } else {
    const g = document.createElement('div');
    g.className = 'mvf';
    g.append(
      mkSel(
        'Shape',
        [
          ['rect', 'Rectangle'],
          ['circle', 'Circle'],
          ['polygon', 'Polygon']
        ],
        B0.shape,
        v =>
          hbSet(b => {
            const o2 = MV.Attacks.body(b, pr);
            if (v === 'polygon' && b.shape !== 'polygon') {
              const w = o2.w / 2,
                h = o2.h / 2;
              b.pts = [
                { x: -w, y: h },
                { x: -w, y: -h },
                { x: w, y: -h },
                { x: w, y: h }
              ];
            }
            if (v === 'circle' && b.shape !== 'circle') b.r = Math.max(o2.w, o2.h) / 2;
            b.shape = v;
          })
      )
    );
    if (B0.shape === 'rect') {
      g.append(
        mkNum('Width (tiles)', B0.w, 0.1, 30, 0.05, v =>
          hbSet(b => {
            b.w = +v;
          })
        ),
        mkNum('Height (tiles)', B0.h, 0.1, 30, 0.05, v =>
          hbSet(b => {
            b.h = +v;
          })
        )
      );
    } else if (B0.shape === 'circle')
      g.append(
        mkNum('Radius (tiles)', B0.r, 0.05, 15, 0.05, v =>
          hbSet(b => {
            b.r = +v;
          })
        )
      );
    g.append(
      mkNum('Offset sideways (tiles)', B0.ox, -10, 10, 0.05, v =>
        hbSet(b => {
          b.ox = +v;
        })
      ),
      mkNum('Offset up/down (tiles)', B0.oy, -10, 10, 0.05, v =>
        hbSet(b => {
          b.oy = +v;
        })
      )
    );
    f.appendChild(g);
    const r = document.createElement('div');
    r.className = 'row';
    if (B0.shape === 'polygon')
      r.append(
        btn('Add corner', () =>
          hbSet(b => {
            const P = MV.Attacks.body(b, pr).pts.map(v => ({ x: v.x, y: v.y }));
            if (P.length >= 16) return;
            let bi = 0,
              bl = -1;
            P.forEach((a, i) => {
              const n = P[(i + 1) % P.length],
                l = Math.hypot(a.x - n.x, a.y - n.y);
              if (l > bl) {
                bl = l;
                bi = i;
              }
            });
            const a = P[bi],
              n = P[(bi + 1) % P.length];
            P.splice(bi + 1, 0, { x: (a.x + n.x) / 2, y: (a.y + n.y) / 2 });
            b.pts = P;
          })
        ),
        btn('Remove last corner', () =>
          hbSet(b => {
            const P = MV.Attacks.body(b, pr).pts.map(v => ({ x: v.x, y: v.y }));
            if (P.length > 3) P.pop();
            b.pts = P;
          })
        )
      );
    r.append(
      btn('Reset to the player size', () => {
        S.body = MV.Attacks.bodyClean(null);
        save();
        buildHb(M);
      }),
      btn('Test movement', mtOpen)
    );
    f.appendChild(r);
  }
  HBS.redraw();
}
