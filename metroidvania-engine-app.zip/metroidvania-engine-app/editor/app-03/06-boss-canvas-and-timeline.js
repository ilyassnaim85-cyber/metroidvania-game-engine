function delKey() {
  const l = document.getElementById('btl');
  if (!KSEL) {
    if (l) l.textContent = 'Click a diamond in the timeline (or drag a hitbox) to select a keyframe first.';
    return;
  }
  let blocked = false;
  bedit(x => {
    const pp = x.patterns[PI],
      list = KSEL.track === 'body' ? pp.body : (pp.hitboxes[KSEL.track] || {}).kf;
    if (!list || !list[KSEL.idx]) return;
    if (KSEL.track !== 'body' && list.length <= 1) {
      blocked = true;
      return;
    }
    list.splice(KSEL.idx, 1);
    KSEL = null;
  });
  const l2 = document.getElementById('btl');
  if (blocked && l2) l2.textContent = 'A hitbox needs at least one keyframe. Delete the hitbox instead.';
}
addEventListener('keydown', e => {
  if (TAB !== 'boss' || (e.key !== 'Delete' && e.key !== 'Backspace') || inText(e.target)) return;
  e.preventDefault();
  delKey();
});
function drawBoss() {
  const b = cb(),
    c = $('bcv'),
    x = c.getContext('2d');
  if (!b) {
    c.height = 200;
    x.fillStyle = '#12324a';
    x.fillRect(0, 0, c.width, 200);
    x.fillStyle = '#fff';
    x.font = '14px system-ui,sans-serif';
    x.fillText('Create a boss to start.', 20, 40);
    return;
  }
  {
    const vw = Math.max(60, Math.round(b.arena.gw * TS * zUse('boss')));
    if (c.width !== vw) c.width = vw;
    c.style.width = vw + 'px';
  }
  const A = b.arena,
    Z = c.width / A.gw;
  c.height = Math.round(Z * A.gh);
  x.fillStyle = '#12324a';
  x.fillRect(0, 0, c.width, c.height);
  x.strokeStyle = 'rgba(255,255,255,.07)';
  x.lineWidth = 1;
  for (let i = 0; i <= A.gw; i++) {
    x.beginPath();
    x.moveTo(i * Z, 0);
    x.lineTo(i * Z, c.height);
    x.stroke();
  }
  for (let i = 0; i <= A.gh; i++) {
    x.beginPath();
    x.moveTo(0, i * Z);
    x.lineTo(c.width, i * Z);
    x.stroke();
  }
  paintGrid(x, A.grid, A.gw, A.gh, Z);
  const p = BSUB === 'patterns' ? cpat() : null,
    P = bpos(b, p);
  const drawn =
    bclip(
      x,
      (p && p.clip) || (p && b.clips.attack) || b.clips.idle,
      p ? BT : BAT,
      P.bx * Z,
      P.by * Z,
      b.sprite.w * Z
    ) ||
    MV.PlayerSprite.frame(
      x,
      { w: b.sprite.w, h: b.sprite.h, anims: b.sprite.anims },
      sheetOf,
      'idle',
      BT,
      P.bx * Z,
      P.by * Z,
      1,
      Z
    );
  if (!drawn) {
    x.fillStyle = 'rgba(127,119,221,.85)';
    x.fillRect((P.bx - b.w / 2) * Z, (P.by - b.h) * Z, b.w * Z, b.h * Z);
  }
  const bsh = MV.Enemies.bodyShape({ cx: P.bx, by: P.by, w: b.w, h: b.h, dir: 1 }, b);
  x.strokeStyle = '#7f77dd';
  x.lineWidth = HI === 'body' && p ? 3 : 1.5;
  MV.Attacks.trace(x, bsh, Z);
  x.stroke();
  x.strokeStyle = '#ffe08a';
  x.lineWidth = 2;
  MV.Enemies.weakWorld({ cx: P.bx, by: P.by, w: b.w, h: b.h, dir: 1 }, b).forEach(w => {
    x.fillStyle = 'rgba(255,224,138,.35)';
    MV.Attacks.trace(x, w, Z);
    x.fill();
    x.stroke();
  });
  x.strokeStyle = '#fff';
  x.lineWidth = 1;
  x.setLineDash([4, 3]);
  x.strokeRect(A.bx * Z, A.by * Z, Z, Z);
  x.setLineDash([]);
  if (p)
    p.hitboxes.forEach((hb, i) => {
      const k = MV.Boss.sample(hb.kf, BT),
        act = BT >= hb.from && BT <= hb.to,
        sel = HI === i,
        og = hb.follow ? [P.bx, P.by] : [P.fx, P.fy],
        cx = og[0] + k.x,
        cy = og[1] + k.y;
      x.strokeStyle = sel ? '#fff' : 'rgba(255,255,255,.35)';
      x.setLineDash([3, 3]);
      x.beginPath();
      hb.kf.forEach((q, j) => {
        const px = (og[0] + q.x) * Z,
          py = (og[1] + q.y) * Z;
        j ? x.lineTo(px, py) : x.moveTo(px, py);
      });
      x.stroke();
      x.setLineDash([]);
      x.fillStyle = sel ? '#fff' : 'rgba(255,255,255,.5)';
      hb.kf.forEach(q => {
        x.beginPath();
        x.arc((og[0] + q.x) * Z, (og[1] + q.y) * Z, 3, 0, 7);
        x.fill();
      });
      const art =
        bclip(x, hb.clip, Math.max(0, BT - hb.from), cx * Z, cy * Z, Math.max(hb.w, (hb.r || 0) * 2) * Z) ||
        (hb.vis &&
          MV.PlayerSprite.frame(
            x,
            { w: hb.w, h: hb.h, anims: { idle: hb.vis } },
            sheetOf,
            'idle',
            Math.max(0, BT - hb.from),
            cx * Z,
            (cy + hb.h / 2) * Z,
            1,
            Z
          ));
      const sp = MV.Boss.hbShape({ face: 1, sx: P.fx, sy: P.fy }, { cx: P.bx, by: P.by }, hb, BT);
      if (!art) {
        x.fillStyle = act ? 'rgba(226,75,74,.55)' : 'rgba(226,75,74,.2)';
        MV.Attacks.trace(x, sp, Z);
        x.fill();
      }
      x.strokeStyle = sel ? '#fff' : '#e24b4a';
      x.lineWidth = sel ? 2.5 : 1;
      MV.Attacks.trace(x, sp, Z);
      x.stroke();
      if (!act && hb.dmg > 0) {
        const g = MV.Boss.hbShape({ face: 1, sx: P.fx, sy: P.fy }, { cx: P.bx, by: P.by }, hb, hb.from);
        x.setLineDash([4, 3]);
        x.strokeStyle = 'rgba(255,210,74,.85)';
        x.lineWidth = 1.5;
        MV.Attacks.trace(x, g, Z);
        x.stroke();
        x.setLineDash([]);
      }
    });
}
const bpt = e => {
  const c = $('bcv'),
    r = c.getBoundingClientRect(),
    Z = c.width / cb().arena.gw;
  return { x: (((e.clientX - r.left) / r.width) * c.width) / Z, y: (((e.clientY - r.top) / r.height) * c.height) / Z };
};
function bpaint(q) {
  const A = cb().arena,
    tx = Math.floor(q.x),
    ty = Math.floor(q.y);
  if (tx < 0 || ty < 0 || tx >= A.gw || ty >= A.gh) return;
  if (BTOOL === 'P') {
    A.bx = tx;
    A.by = ty;
  } else A.grid[ty] = A.grid[ty].slice(0, tx) + BTOOL + A.grid[ty].slice(tx + 1);
  drawBoss();
}
function bdragTo(q) {
  const b = cb(),
    p = cpat();
  if (!b || !p) return;
  const P = bpos(b, p);
  if (HI === 'body') KSEL = { track: 'body', idx: setKey(p.body, BT, snap4(q.x - P.fx), snap4(q.y + b.h / 2 - P.fy)) };
  else {
    const hb = p.hitboxes[HI];
    if (!hb) return;
    const og = hb.follow ? [P.bx, P.by] : [P.fx, P.fy];
    KSEL = { track: HI, idx: setKey(hb.kf, BT, snap4(q.x - og[0]), snap4(q.y - og[1])) };
  }
  syncBt();
  drawBoss();
  drawTl();
}
$('bcv').onpointerdown = e => {
  const b = cb();
  if (!b) return;
  $('bcv').setPointerCapture(e.pointerId);
  const q = bpt(e);
  if (BSUB === 'arena') {
    BDRAG = { m: 'paint' };
    bpaint(q);
    return;
  }
  const p = cpat();
  if (!p) return;
  const P = bpos(b, p);
  let hit = null;
  for (let i = p.hitboxes.length - 1; i >= 0 && hit === null; i--) {
    const hb = p.hitboxes[i],
      k = MV.Boss.sample(hb.kf, BT),
      og = hb.follow ? [P.bx, P.by] : [P.fx, P.fy];
    if (Math.abs(q.x - (og[0] + k.x)) <= hb.w / 2 && Math.abs(q.y - (og[1] + k.y)) <= hb.h / 2) hit = i;
  }
  if (hit === null && Math.abs(q.x - P.bx) <= b.w / 2 && q.y <= P.by && q.y >= P.by - b.h) hit = 'body';
  if (hit === null) return;
  HI = hit;
  BPLAY = false;
  BDRAG = { m: 'track' };
  bdragTo(q);
};
$('bcv').onpointermove = e => {
  if (!BDRAG || !cb() || BDRAG.m === 'kf') return;
  const q = bpt(e);
  BDRAG.m === 'paint' ? bpaint(q) : bdragTo(q);
};
$('bcv').onpointerup = () => {
  if (BDRAG && BDRAG.m !== 'kf') {
    BDRAG = null;
    bedit(() => {});
  }
};
const TLR = 24,
  TLX = 120;
function tlRows() {
  const p = cpat();
  return p
    ? [
        { n: 'Boss movement', k: p.body, id: 'body' },
        ...p.hitboxes.map((h, i) => ({ n: h.name, k: h.kf, id: i, from: h.from, to: h.to }))
      ]
    : [];
}
function drawTl() {
  drawTl0();
  drawAn();
}
function drawTl0() {
  const c = $('tlc'),
    p = cpat(),
    rows = tlRows(),
    x = c.getContext('2d');
  c.height = 20 + TLR * Math.max(1, rows.length) + 6;
  x.fillStyle = '#2c2c2a';
  x.fillRect(0, 0, c.width, c.height);
  if (!p) return;
  const W = c.width - TLX - 10,
    tx = t => TLX + (t / p.duration) * W;
  x.font = '11px system-ui,sans-serif';
  x.textBaseline = 'middle';
  x.fillStyle = '#b4b2a9';
  x.textAlign = 'center';
  for (let s = 0; s <= p.duration + 0.001; s += 0.5) x.fillText(s.toFixed(1), tx(s), 9);
  rows.forEach((r, i) => {
    const y = 20 + i * TLR;
    if (HI === r.id) {
      x.fillStyle = 'rgba(255,255,255,.08)';
      x.fillRect(0, y, c.width, TLR);
    }
    x.textAlign = 'left';
    x.fillStyle = '#d3d1c7';
    x.fillText(r.n.slice(0, 16), 6, y + TLR / 2);
    if (r.from !== undefined) {
      x.fillStyle = 'rgba(226,75,74,.3)';
      x.fillRect(tx(r.from), y + 4, Math.max(2, tx(r.to) - tx(r.from)), TLR - 8);
    }
    r.k.forEach((k, j) => {
      x.save();
      x.translate(tx(k.t), y + TLR / 2);
      x.rotate(Math.PI / 4);
      x.fillStyle = KSEL && KSEL.track === r.id && KSEL.idx === j ? '#ef9f27' : '#fff';
      x.fillRect(-4, -4, 8, 8);
      x.restore();
    });
  });
  x.fillStyle = 'rgba(90,176,232,.25)';
  (p.inv || []).forEach(w => {
    x.fillRect(tx(w.from), 16, Math.max(2, tx(w.to) - tx(w.from)), c.height - 16);
  });
  x.strokeStyle = '#e24b4a';
  x.lineWidth = 2;
  x.beginPath();
  x.moveTo(tx(BT), 14);
  x.lineTo(tx(BT), c.height);
  x.stroke();
}
const tlT = (e, p) => {
  const c = $('tlc'),
    r = c.getBoundingClientRect(),
    px = ((e.clientX - r.left) / r.width) * c.width,
    py = ((e.clientY - r.top) / r.height) * c.height,
    W = c.width - TLX - 10;
  return { px, py, t: Math.max(0, Math.min(p.duration, ((px - TLX) / W) * p.duration)), W };
};
$('tlc').onpointerdown = e => {
  const p = cpat();
  if (!p) return;
  const { px, py, t, W } = tlT(e, p),
    rows = tlRows(),
    ri = Math.floor((py - 20) / TLR);
  $('tlc').setPointerCapture(e.pointerId);
  BPLAY = false;
  if (ri >= 0 && ri < rows.length) {
    HI = rows[ri].id;
    const kf = rows[ri].k,
      j = kf.findIndex(k => Math.abs(TLX + (k.t / p.duration) * W - px) < 7);
    if (px >= TLX && j >= 0) {
      KSEL = { track: HI, idx: j };
      BT = kf[j].t;
      BDRAG = { m: 'kf', list: kf, idx: j };
    } else {
      KSEL = null;
      if (px >= TLX) BT = t;
    }
  } else if (px >= TLX) BT = t;
  syncBt();
  bossForm();
  drawBoss();
  drawTl();
};
$('tlc').onpointermove = e => {
  if (!BDRAG || BDRAG.m !== 'kf') return;
  const p = cpat();
  if (!p) return;
  const { t } = tlT(e, p);
  BDRAG.list[BDRAG.idx].t = t;
  BT = t;
  syncBt();
  drawBoss();
  drawTl();
};
$('tlc').onpointerup = () => {
  if (BDRAG && BDRAG.m === 'kf') {
    const t = BDRAG.list[BDRAG.idx].t,
      tr = KSEL ? KSEL.track : null;
    BDRAG = null;
    bedit(() => {});
    const p = cpat();
    if (p && tr !== null) {
      const l = tr === 'body' ? p.body : (p.hitboxes[tr] || {}).kf || [],
        j = l.findIndex(k => Math.abs(k.t - t) < 1e-6);
      KSEL = j >= 0 ? { track: tr, idx: j } : null;
      syncBt();
      drawTl();
    }
  }
};
function drawAn() {
  const c = $('tla'),
    p = cpat(),
    b = cb(),
    x = c.getContext('2d');
  if (!p || !b) {
    c.height = 8;
    return;
  }
  const bid = p.clip || b.clips.attack || b.clips.idle,
    rows = [
      { n: 'Boss: ' + (p.name || 'pattern'), id: bid, from: 0, to: p.duration },
      ...p.hitboxes.filter(h => h.clip).map(h => ({ n: h.name + ' (look)', id: h.clip, from: h.from, to: h.to }))
    ],
    RH = 44;
  c.height = 6 + RH * rows.length + 4;
  x.fillStyle = '#2c2c2a';
  x.fillRect(0, 0, c.width, c.height);
  const W = c.width - TLX - 10,
    tx = t => TLX + (t / p.duration) * W;
  x.textBaseline = 'middle';
  x.font = '11px system-ui,sans-serif';
  rows.forEach((r, i) => {
    const y = 6 + i * RH;
    x.textAlign = 'left';
    x.fillStyle = '#d3d1c7';
    x.fillText(r.n.slice(0, 17), 6, y + RH / 2 - 7);
    const cl = r.id && MV.Anim.find(S.anims, r.id);
    if (!cl || !cl.frames.length) {
      x.fillStyle = '#6b6a65';
      x.fillText(r.id ? 'animation has no frames' : 'no animation set', TLX + 6, y + RH / 2);
      return;
    }
    const P = MV.Anim.compile(cl),
      cur = BT >= r.from && BT <= r.to ? MV.Anim.sample(cl, BT - r.from).index : -1;
    x.fillStyle = '#b4b2a9';
    x.fillText(cur >= 0 ? 'frame ' + (cur + 1) + ' of ' + cl.frames.length : 'not playing', 6, y + RH / 2 + 8);
    let n = 0;
    for (let cyc = 0; cyc < 200 && n < 1500; cyc++) {
      const base = r.from + cyc * P.cycle;
      if (base >= r.to - 1e-6 || (cl.mode === 'once' && cyc > 0)) break;
      for (const q of P.seq) {
        const t0 = base + q.start,
          t1 = Math.min(base + q.end, r.to);
        if (t0 >= r.to || n++ > 1500) break;
        const x0 = tx(t0),
          x1 = tx(t1),
          here = BT >= t0 && BT < t1 + (t1 >= r.to ? 1e-6 : 0);
        x.strokeStyle = here ? '#ef9f27' : 'rgba(255,255,255,.18)';
        x.lineWidth = here ? 2 : 1;
        const f = cl.frames[q.i],
          sh = sheetOf(f.sheet);
        if (x1 - x0 >= 8 && sh && sh.img.complete && sh.img.naturalWidth) {
          const R = MV.Anim.rectOf(f, sh),
            bw = x1 - x0 - 2,
            bh = RH - 6,
            k2 = Math.min(bw / R.sw, bh / R.sh),
            dw = R.sw * k2,
            dh = R.sh * k2;
          x.imageSmoothingEnabled = false;
          x.drawImage(sh.img, R.sx, R.sy, R.sw, R.sh, x0 + 1 + (bw - dw) / 2, y + 3 + (bh - dh) / 2, dw, dh);
          if (x1 - x0 >= 24) {
            x.fillStyle = 'rgba(255,255,255,.65)';
            x.textAlign = 'left';
            x.fillText(String(q.i + 1), x0 + 3, y + 10);
          }
        }
        x.strokeRect(x0 + 0.5, y + 2.5, Math.max(1, x1 - x0 - 1), RH - 5);
      }
    }
  });
  x.strokeStyle = '#e24b4a';
  x.lineWidth = 2;
  x.beginPath();
  x.moveTo(tx(BT), 0);
  x.lineTo(tx(BT), c.height);
  x.stroke();
}
$('tla').onpointerdown = e => {
  const p = cpat();
  if (!p) return;
  const c = $('tla'),
    r = c.getBoundingClientRect(),
    px = ((e.clientX - r.left) / r.width) * c.width;
  if (px < TLX) return;
  BPLAY = false;
  BT = Math.max(0, Math.min(p.duration, ((px - TLX) / (c.width - TLX - 10)) * p.duration));
  syncBt();
  drawBoss();
  drawTl();
};
function bossTickStart() {
  if (BON) return;
  BON = true;
  BLAST = performance.now();
  requestAnimationFrame(bossTick);
}
function drawBap() {
  const c = document.getElementById('bap'),
    b = cb();
  if (!c || !b) return;
  const x = c.getContext('2d'),
    id =
      b.clips[BAN] ||
      (BAN === 'attack' || BAN === 'warn' || BAN === 'stun' || BAN === 'phase' ? b.clips.idle : '') ||
      b.clips.idle,
    cl = id && MV.Anim.find(S.anims, id),
    t = cl && cl.mode === 'once' ? BAT % (MV.Anim.compile(cl).cycle + 0.6) : BAT;
  x.fillStyle = '#12324a';
  x.fillRect(0, 0, c.width, c.height);
  x.fillStyle = 'rgba(255,255,255,.12)';
  x.fillRect(0, c.height - 14, c.width, 14);
  const Z = Math.min((c.height - 22) / Math.max(b.sprite.h, b.h), (c.width - 10) / Math.max(b.sprite.w, b.w)),
    fx = c.width / 2,
    fy = c.height - 14;
  if (!bclip(x, id, t, fx, fy, b.sprite.w * Z)) {
    x.fillStyle = 'rgba(127,119,221,.85)';
    x.fillRect(fx - (b.w * Z) / 2, fy - b.h * Z, b.w * Z, b.h * Z);
    if (!id) {
      x.fillStyle = '#fff';
      x.font = '11px system-ui,sans-serif';
      x.textAlign = 'center';
      x.fillText('no animation set', fx, fy - (b.h * Z) / 2);
    }
  }
}
function bossTick(t) {
  if (TAB !== 'boss') {
    BON = false;
    return;
  }
  requestAnimationFrame(bossTick);
  const dt = Math.min(0.1, Math.max(0, (t - BLAST) / 1000));
  BLAST = t;
  BAT += dt;
  drawBap();
  if (BPLAY) {
    const p = cpat();
    if (p) {
      BT += dt;
      if (BT > p.duration) BT = 0;
      syncBt();
      drawBoss();
      drawTl();
    }
  }
}
$('bnew').onclick = () => {
  if (S.bosses.length >= 24) return;
  S.bosses.push(MV.Boss.blank('Boss ' + (S.bosses.length + 1)));
  BI = S.bosses.length - 1;
  PI = 0;
  HI = 'body';
  BT = 0;
  KSEL = null;
  save();
  bossUI();
};
$('bdup').onclick = () => {
  const b = cb();
  if (!b || S.bosses.length >= 24) return;
  const c = JSON.parse(JSON.stringify(b));
  c.id = '';
  c.name = (b.name + ' copy').slice(0, 30);
  S.bosses.push(MV.Boss.clean(c));
  BI = S.bosses.length - 1;
  save();
  bossUI();
};
$('bdel').onclick = () => {
  const b = cb();
  if (!b || !confirm('Delete the boss "' + b.name + '"? Its placements in rooms are removed too.')) return;
  S.areas.forEach(a =>
    (a.rooms || []).forEach(v => {
      v.ent = (v.ent || []).filter(q => !(q.type === 'boss' && q.props.boss === b.id));
    })
  );
  S.bosses.splice(BI, 1);
  BI = Math.max(0, BI - 1);
  PI = 0;
  HI = 'body';
  save();
  bossUI();
};
$('bsa').onclick = () => {
  BSUB = 'arena';
  BPLAY = false;
  bossUI();
};
$('bsq').onclick = () => {
  BSUB = 'patterns';
  HI = 'body';
  bossUI();
};
