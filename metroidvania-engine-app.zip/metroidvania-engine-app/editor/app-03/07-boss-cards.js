function bossCards() {
  const box = $('bcards');
  box.innerHTML = '';
  if (!S.bosses.length) {
    box.textContent = 'No bosses yet. Make one in the Bosses tab.';
    return;
  }
  S.bosses.forEach(b => {
    const c = document.createElement('div'),
      cv2 = document.createElement('canvas'),
      t = document.createElement('strong'),
      m = document.createElement('span'),
      A = b.arena;
    c.className = 'bcard' + (BPICK === b.id && tool === 'O' ? ' on' : '');
    c.draggable = true;
    cv2.width = 120;
    cv2.height = Math.max(20, Math.round((120 * A.gh) / A.gw));
    const x = cv2.getContext('2d'),
      Z = 120 / A.gw;
    x.fillStyle = '#12324a';
    x.fillRect(0, 0, cv2.width, cv2.height);
    paintGrid(x, A.grid, A.gw, A.gh, Z);
    x.fillStyle = 'rgba(127,119,221,.9)';
    x.fillRect((A.bx + 0.5 - b.w / 2) * Z, (A.by + 1 - b.h) * Z, b.w * Z, b.h * Z);
    t.textContent = b.name;
    m.className = 'hint';
    m.textContent = A.gw + ' x ' + A.gh + ' tiles';
    c.append(cv2, t, m);
    c.ondragstart = e => {
      BPICK = b.id;
      e.dataTransfer.setData('text/plain', 'boss:' + b.id);
    };
    c.onclick = () => {
      BPICK = b.id;
      setTool('O');
      bossCards();
    };
    box.appendChild(c);
  });
}
