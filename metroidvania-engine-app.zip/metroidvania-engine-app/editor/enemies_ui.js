// Enemies tab (editor): build enemy types from scratch (body, movement, attack, damage, reactions, drops, look), see how far they see and attack,
// then place them in a room with the Enemy entity (its Type setting). The engine side is engine/enemies.js; the runtime is in engine/game.js.
// Needs the editor globals: S (the project), $, save().
(() => {
  const EN = MV.Enemies;
  let SEL = '';
  const css = document.createElement('style');
  css.textContent = `#eng{display:grid;grid-template-columns:240px minmax(0,1fr);gap:12px;align-items:start;padding:10px}
  #eng .enl{border:2px solid var(--bd);border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:6px;min-height:320px}
  #eng .enl .item{text-align:left;padding:5px 8px;font-size:13px;border-radius:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  #eng .enl .item.on{border-color:#ef9f27;font-weight:600}
  #eng .enc{border:1px solid var(--bd);border-radius:10px;padding:10px 12px;background:var(--cd);margin-bottom:10px}
  #eng .enc h3{margin:0 0 6px;font-size:14px}
  #eng .enr{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:6px 14px;align-items:start}
  #eng .enr label{display:flex;flex-direction:column;gap:3px;font-size:13px}
  #eng .enr label small{color:var(--mu,#8fa3b3);font-size:11px;line-height:1.3}
  #eng .enr input[type=number],#eng .enr input[type=text],#eng .enr select{width:100%}
  #eng canvas{width:100%;max-width:720px;border:1px solid var(--bd);border-radius:8px;background:#10161c;display:block}
  @media(max-width:900px){#eng{grid-template-columns:1fr}}`;
  document.head.appendChild(css);
  const E = (t, c, x) => {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };
  const bt = (t, f, title) => {
    const b = E('button', '', t);
    b.onclick = f;
    if (title) b.title = title;
    return b;
  };
  const lib = () => S.enemies || (S.enemies = []);
  const cur = () => lib().find(d => d.id === SEL) || null;
  const uniq = (id, skip) => {
    let n = id,
      k = 2;
    while (lib().some(q => q !== skip && q.id === n)) n = id + k++;
    return n;
  };
  const commit = redraw => {
    const keep = SEL;
    S.enemies = EN.resolve(S.enemies);
    if (!cur() && keep) SEL = (lib()[0] || {}).id || '';
    save();
    if (redraw !== false) enUI();
  };
  const set = (d, k, v) => {
    d[k] = v;
    Object.assign(d, EN.clean1(d));
    commit(false);
    drawPrev();
  };

  function field(box, d, k) {
    const f = EN.FIELDS[k],
      l = E('label');
    l.title = f.help || '';
    l.appendChild(E('span', '', f.label));
    let inp;
    if (f.t === 'select') {
      inp = E('select');
      f.o.forEach(v => {
        const o = E('option', '', (f.names && f.names[v]) || v);
        o.value = v;
        inp.appendChild(o);
      });
      inp.value = d[k];
      inp.onchange = () => {
        set(d, k, inp.value);
        if (k === 'move' || k === 'attack' || k === 'shape') enUI();
      };
    } else if (f.t === 'number') {
      inp = E('input');
      inp.type = 'number';
      inp.min = f.min;
      inp.max = f.max;
      inp.step = f.step;
      inp.value = d[k];
      inp.onchange = () => {
        set(d, k, inp.value);
        inp.value = d[k];
      };
    } else if (f.t === 'color') {
      inp = E('input');
      inp.type = 'color';
      inp.value = d[k];
      inp.onchange = () => set(d, k, inp.value);
    } else if (k === 'dropItem') {
      inp = E('select');
      [['', '(nothing)']]
        .concat((S.items || []).map(i => [i.id, i.name + ' (' + i.id + ')']))
        .concat(d[k] && !(S.items || []).some(i => i.id === d[k]) ? [[d[k], d[k] + ' (missing)']] : [])
        .forEach(x => {
          const o = E('option', '', x[1]);
          o.value = x[0];
          inp.appendChild(o);
        });
      inp.value = d[k];
      inp.onchange = () => set(d, k, inp.value);
    } else {
      inp = E('input');
      inp.type = 'text';
      inp.value = d[k];
      inp.maxLength = 30;
      inp.onchange = () => {
        set(d, k, inp.value);
        if (k === 'name') enUI();
      };
    }
    l.appendChild(inp);
    if (f.help) l.appendChild(E('small', '', f.help));
    box.appendChild(l);
  }
  const showIf = (d, k) => {
    if (['speed'].includes(k)) return d.move !== 'stand still';
    if (k === 'range') return d.move === 'patrol' || d.move === 'chase' || d.move === 'fly' || d.move === 'hop';
    if (k === 'sight') return ['chase', 'fly', 'hop'].includes(d.move) || d.attack !== 'none';
    if (k === 'edge') return d.move === 'patrol' || d.move === 'chase';
    if (k === 'hopEvery' || k === 'hopPower') return d.move === 'hop';
    if (/^atk/.test(k)) {
      if (d.attack === 'none') return false;
      if (k === 'atkDmg' || k === 'atkSize' || k === 'atkAim') return d.attack === 'shoot';
      if (k === 'atkSpeed') return d.attack === 'shoot' || d.attack === 'charge';
      if (k === 'atkDur') return d.attack === 'charge' || d.attack === 'strike';
    }
    return true;
  };

  // A picture of the enemy and how far it sees and attacks (drawn at 36 pixels per tile)
  let prev = null,
    PT = 0,
    PLAYING = false,
    PLAST = 0;
  function drawPrev() {
    const d = cur();
    if (!prev || !d) return;
    const x = prev.getContext('2d'),
      W = prev.width,
      H = prev.height,
      Z = 36,
      gy = H - 40,
      cx = W / 2;
    x.clearRect(0, 0, W, H);
    x.fillStyle = '#10161c';
    x.fillRect(0, 0, W, H);
    x.fillStyle = '#3a4350';
    x.fillRect(0, gy, W, 40);
    const cyE = gy - (d.h * Z) / 2;
    if ((d.sight > 0 && d.move !== 'stand still') || d.attack !== 'none') {
      x.setLineDash([5, 4]);
      x.lineWidth = 1.5;
      if (d.sight > 0) {
        x.strokeStyle = '#ef9f27';
        x.beginPath();
        x.arc(cx, cyE, d.sight * Z, 0, 7);
        x.stroke();
      }
      if (d.attack !== 'none') {
        x.strokeStyle = '#e24b4a';
        x.beginPath();
        x.arc(cx, cyE, d.atkRange * Z, 0, 7);
        x.stroke();
      }
      x.setLineDash([]);
    }
    if (d.move === 'patrol' || d.move === 'chase' || d.move === 'hop' || d.move === 'fly') {
      x.strokeStyle = '#5dcaa5';
      x.lineWidth = 3;
      x.beginPath();
      x.moveTo(cx - d.range * Z, gy + 8);
      x.lineTo(cx + d.range * Z, gy + 8);
      x.stroke();
    }
    const ee = { cx: cx / Z, by: gy / Z, w: d.w, h: d.h, dir: 1 },
      A = MV.Attacks;
    x.fillStyle = d.color;
    A.trace(x, EN.bodyShape(ee, d), Z);
    x.fill();
    x.strokeStyle = 'rgba(255,255,255,.5)';
    x.lineWidth = 1;
    x.stroke();
    if (d.shape === 'polygon') {
      x.fillStyle = '#fff';
      EN.bodyShape(ee, d).pts.forEach(q => {
        x.beginPath();
        x.arc(q.x * Z, q.y * Z, 4, 0, 7);
        x.fill();
      });
    }
    EN.weakWorld(ee, d).forEach(w => {
      x.fillStyle = 'rgba(255,224,138,.45)';
      A.trace(x, w, Z);
      x.fill();
      x.strokeStyle = '#ffe08a';
      x.lineWidth = 2;
      x.stroke();
    });
    if (d.attack === 'strike')
      (d.strike || []).forEach(h => {
        const live = PT >= h.from && PT <= h.to;
        A.rects([h], live ? PT : h.from, 1, ee.cx, ee.by - ee.h / 2, h.dmg).forEach(r => {
          if (live) {
            x.fillStyle = 'rgba(226,75,74,.55)';
            A.trace(x, r, Z);
            x.fill();
            x.strokeStyle = '#ff8a85';
            x.lineWidth = 2;
            x.stroke();
          } else {
            x.setLineDash([4, 3]);
            x.strokeStyle = 'rgba(226,75,74,.6)';
            x.lineWidth = 1.5;
            A.trace(x, r, Z);
            x.stroke();
            x.setLineDash([]);
          }
        });
      });
    const cl = d.clips.idle && MV.Anim && MV.Anim.find(S.anims, d.clips.idle);
    if (cl && cl.frames.length && window.sheetOf) {
      /* picture preview needs the sheet loader of the Animations tab */
    }
    x.font = '12px system-ui,sans-serif';
    x.textBaseline = 'top';
    let ly = 6;
    const key = (c, t) => {
      x.fillStyle = c;
      x.fillRect(8, ly + 3, 10, 3);
      x.fillStyle = '#c8d3dc';
      x.fillText(t, 24, ly);
      ly += 16;
    };
    key('#ffe08a', 'weak spot');
    key('#e24b4a', 'strike hitbox');
    key('#5dcaa5', 'patrol distance');
    key('#ef9f27', 'sees you from');
    key('#e24b4a', 'attacks from');
    x.fillStyle = '#8fa3b3';
    x.fillText('1 tile = ' + Z + ' px. The player is 0.7 wide and 1.5 tall.', W - 300, 6);
    x.fillStyle = 'rgba(93,202,165,.35)';
    x.fillRect(cx + 4 * Z - 0.35 * Z, gy - 1.5 * Z, 0.7 * Z, 1.5 * Z);
  }

  // Shape, weak spots and strike hitboxes
  const num = (box, label, v, mn, mx, st, f, help) => {
    const l = E('label');
    l.appendChild(E('span', '', label));
    const i = E('input');
    i.type = 'number';
    i.min = mn;
    i.max = mx;
    i.step = st;
    i.value = +(+v).toFixed(3);
    i.onchange = () => {
      f(+i.value);
    };
    if (help) l.title = help;
    l.appendChild(i);
    box.appendChild(l);
    return i;
  };
  const sel = (box, label, v, opts, f) => {
    const l = E('label');
    l.appendChild(E('span', '', label));
    const s2 = E('select');
    opts.forEach(o => {
      const q = E('option', '', o[1]);
      q.value = o[0];
      s2.appendChild(q);
    });
    s2.value = v;
    s2.onchange = () => f(s2.value);
    l.appendChild(s2);
    box.appendChild(l);
  };
  const upd = (d, redo) => {
    Object.assign(d, EN.clean1(d));
    commit(false);
    if (redo) enUI();
    else drawPrev();
  };
  const tri = h => [
    { x: -h.w / 2, y: h.h / 2 },
    { x: 0, y: -h.h / 2 },
    { x: h.w / 2, y: h.h / 2 }
  ];
  function shapeCards(R, d) {
    if (d.shape === 'polygon') {
      const c = E('div', 'enc');
      c.appendChild(E('h3', '', 'Polygon corners'));
      c.appendChild(
        E(
          'p',
          'hint',
          'Corners are relative to the enemy box: -0.5 is the left or top edge, 0.5 the right or bottom edge. Drag the white dots in the picture above, or type numbers. 3 to 16 corners.'
        )
      );
      d.pts.forEach((q, i) => {
        const r = E('div', 'enr');
        r.appendChild(E('b', '', 'Corner ' + (i + 1)));
        num(r, 'x', q.x, -1, 1, 0.05, v => {
          q.x = v;
          upd(d);
        });
        num(r, 'y', q.y, -1, 1, 0.05, v => {
          q.y = v;
          upd(d);
        });
        const b = bt('Remove', () => {
          if (d.pts.length > 3) {
            d.pts.splice(i, 1);
            upd(d, true);
          }
        });
        r.appendChild(b);
        c.appendChild(r);
      });
      c.appendChild(
        bt('Add corner', () => {
          if (d.pts.length < 16) {
            d.pts.push({ x: 0, y: 0.5 });
            upd(d, true);
          }
        })
      );
      R.appendChild(c);
    }
    const w = E('div', 'enc');
    w.appendChild(E('h3', '', 'Weak spots'));
    w.appendChild(
      E(
        'p',
        'hint',
        'A weak spot is a small box on the enemy (it flips when the enemy turns). Hits that touch it do more damage. With "Only weak spots hurt it" on, hits elsewhere do nothing. Positions are tiles from the middle of the enemy.'
      )
    );
    d.weak.forEach((q, i) => {
      const r = E('div', 'enr');
      const nm = E('label');
      nm.appendChild(E('span', '', 'Name'));
      const ni = E('input');
      ni.type = 'text';
      ni.value = q.name;
      ni.maxLength = 20;
      ni.onchange = () => {
        q.name = ni.value;
        upd(d);
      };
      nm.appendChild(ni);
      r.appendChild(nm);
      num(r, 'x', q.x, -8, 8, 0.1, v => {
        q.x = v;
        upd(d);
      });
      num(r, 'y', q.y, -8, 8, 0.1, v => {
        q.y = v;
        upd(d);
      });
      num(r, 'Width', q.w, 0.1, 8, 0.1, v => {
        q.w = v;
        upd(d);
      });
      num(r, 'Height', q.h, 0.1, 8, 0.1, v => {
        q.h = v;
        upd(d);
      });
      num(
        r,
        'Damage x',
        q.mult,
        0,
        10,
        0.25,
        v => {
          q.mult = v;
          upd(d);
        },
        '2 = double damage'
      );
      r.appendChild(
        bt('Remove', () => {
          d.weak.splice(i, 1);
          upd(d, true);
        })
      );
      w.appendChild(r);
    });
    w.appendChild(
      bt('Add weak spot', () => {
        if (d.weak.length < 6) {
          d.weak.push({ name: 'Weak spot ' + (d.weak.length + 1), x: 0, y: -0.2, w: 0.4, h: 0.4, mult: 2 });
          upd(d, true);
        }
      })
    );
    R.appendChild(w);
    if (d.attack !== 'strike') return;
    const c = E('div', 'enc');
    c.appendChild(E('h3', '', 'Strike hitboxes'));
    c.appendChild(
      E(
        'p',
        'hint',
        'Drawn like a boss pattern. After the warning, a timeline of ' +
          d.atkDur +
          ' s plays. Each hitbox hurts you only between "From" and "Until", for its own damage. Positions are tiles from the middle of the enemy and flip with the way it faces. A hitbox can slide from its start to an end position. Scrub or play the timeline to see it in the picture above.'
      )
    );
    const ctl = E('div', 'row');
    const pl = bt(PLAYING ? 'Pause' : 'Play', () => {
      PLAYING = !PLAYING;
      if (PLAYING && PT >= d.atkDur - 0.01) PT = 0;
      enUI();
      tickPrev();
    });
    const sl = E('input');
    sl.type = 'range';
    sl.min = 0;
    sl.max = d.atkDur;
    sl.step = 0.01;
    sl.value = PT;
    sl.style.minWidth = '220px';
    const lb = E('span', 'hint', PT.toFixed(2) + ' s');
    sl.oninput = () => {
      PT = +sl.value;
      PLAYING = false;
      lb.textContent = PT.toFixed(2) + ' s';
      drawPrev();
    };
    ctl.append(pl, sl, lb);
    c.appendChild(ctl);
    const timeline = E('canvas');
    timeline.width = 720;
    timeline.height = 14 + 22 * Math.max(1, d.strike.length);
    timeline.style.height = timeline.height + 'px';
    c.appendChild(timeline);
    const tx = timeline.getContext('2d');
    tx.fillStyle = '#10161c';
    tx.fillRect(0, 0, 720, timeline.height);
    const TX = 110,
      WW = 720 - TX - 10,
      X = t => TX + (t / d.atkDur) * WW;
    tx.font = '11px system-ui,sans-serif';
    tx.textBaseline = 'middle';
    d.strike.forEach((h, i) => {
      const y = 7 + i * 22;
      tx.fillStyle = '#c8d3dc';
      tx.fillText(h.name.slice(0, 14), 6, y + 10);
      tx.fillStyle = 'rgba(226,75,74,.6)';
      tx.fillRect(X(h.from), y + 3, Math.max(2, X(h.to) - X(h.from)), 14);
    });
    tx.strokeStyle = '#fff';
    tx.lineWidth = 2;
    tx.beginPath();
    tx.moveTo(X(PT), 0);
    tx.lineTo(X(PT), timeline.height);
    tx.stroke();
    timeline.onpointerdown = ev => {
      const r = timeline.getBoundingClientRect();
      PT = Math.max(0, Math.min(d.atkDur, ((((ev.clientX - r.left) / r.width) * 720 - TX) / WW) * d.atkDur));
      PLAYING = false;
      enUI();
    };
    d.strike.forEach((h, i) => {
      const r = E('div', 'enr');
      const nm = E('label');
      nm.appendChild(E('span', '', 'Name'));
      const ni = E('input');
      ni.type = 'text';
      ni.value = h.name;
      ni.maxLength = 24;
      ni.onchange = () => {
        h.name = ni.value;
        upd(d, true);
      };
      nm.appendChild(ni);
      r.appendChild(nm);
      sel(
        r,
        'Shape',
        h.shape,
        [
          ['rect', 'Rectangle'],
          ['circle', 'Circle'],
          ['polygon', 'Triangle']
        ],
        v => {
          h.shape = v;
          if (v === 'polygon') h.pts = tri(h);
          upd(d, true);
        }
      );
      if (h.shape === 'circle')
        num(r, 'Radius', h.r, 0.05, 8, 0.05, v => {
          h.r = v;
          upd(d);
        });
      else {
        num(r, 'Width', h.w, 0.1, 12, 0.1, v => {
          h.w = v;
          if (h.shape === 'polygon') h.pts = tri(h);
          upd(d);
        });
        num(r, 'Height', h.h, 0.1, 12, 0.1, v => {
          h.h = v;
          if (h.shape === 'polygon') h.pts = tri(h);
          upd(d);
        });
      }
      num(r, 'Hurts from (s)', h.from, 0, d.atkDur, 0.05, v => {
        h.from = v;
        upd(d, true);
      });
      num(r, 'Hurts until (s)', h.to, 0, d.atkDur, 0.05, v => {
        h.to = v;
        upd(d, true);
      });
      num(r, 'Damage (hits)', h.dmg, 0, 30, 1, v => {
        h.dmg = v;
        upd(d);
      });
      const k0 = h.kf[0],
        sl2 = h.kf.length > 1,
        k1 = h.kf[h.kf.length - 1];
      const setK = () => {
        h.kf = [{ t: h.from, x: k0.x, y: k0.y }];
        if (sl2) h.kf.push({ t: h.to, x: k1.x, y: k1.y });
      };
      num(r, 'Start x', k0.x, -12, 12, 0.1, v => {
        k0.x = v;
        h.kf[0] = { t: k0.t, x: v, y: k0.y };
        upd(d);
      });
      num(r, 'Start y', k0.y, -12, 12, 0.1, v => {
        h.kf[0] = { t: k0.t, x: k0.x, y: v };
        upd(d);
      });
      sel(
        r,
        'Slides',
        sl2 ? 'yes' : 'no',
        [
          ['no', 'No: stays put'],
          ['yes', 'Yes: moves to an end spot']
        ],
        v => {
          h.kf =
            v === 'yes'
              ? [
                  { t: h.from, x: k0.x, y: k0.y },
                  { t: h.to, x: k0.x + 1.5, y: k0.y }
                ]
              : [{ t: 0, x: k0.x, y: k0.y }];
          upd(d, true);
        }
      );
      if (sl2) {
        num(r, 'End x', k1.x, -12, 12, 0.1, v => {
          h.kf[h.kf.length - 1] = { t: k1.t, x: v, y: k1.y };
          upd(d);
        });
        num(r, 'End y', k1.y, -12, 12, 0.1, v => {
          h.kf[h.kf.length - 1] = { t: k1.t, x: k1.x, y: v };
          upd(d);
        });
      }
      r.appendChild(
        bt('Remove', () => {
          d.strike.splice(i, 1);
          upd(d, true);
        })
      );
      c.appendChild(r);
    });
    c.appendChild(
      bt('Add hitbox', () => {
        if (d.strike.length < 6) {
          d.strike.push({
            name: 'Swipe ' + (d.strike.length + 1),
            shape: 'rect',
            w: 1.2,
            h: 0.8,
            from: 0,
            to: Math.min(d.atkDur, 0.3),
            dmg: 1,
            kf: [{ t: 0, x: d.w / 2 + 0.6, y: 0 }]
          });
          upd(d, true);
        }
      })
    );
    R.appendChild(c);
  }
  function tickPrev() {
    if (!PLAYING) return;
    PLAST = performance.now();
    const f = t => {
      const dd = cur(),
        host = $('eng');
      if (!PLAYING || !dd || !host || !host.offsetParent) {
        PLAYING = false;
        return;
      }
      PT += Math.min(0.1, (t - PLAST) / 1000);
      PLAST = t;
      if (PT > dd.atkDur) PT = 0;
      drawPrev();
      requestAnimationFrame(f);
    };
    requestAnimationFrame(f);
  }
  // drag polygon corners and weak spots in the picture
  function dragSetup(cv) {
    let g = null;
    const pt = ev => {
      const r = cv.getBoundingClientRect();
      return { x: ((ev.clientX - r.left) / r.width) * cv.width, y: ((ev.clientY - r.top) / r.height) * cv.height };
    };
    cv.onpointerdown = ev => {
      const d = cur();
      if (!d) return;
      const q = pt(ev),
        Z = 36,
        cx = cv.width / 2,
        gy = cv.height - 40,
        mid = gy - (d.h * Z) / 2;
      let best = null,
        bd = 14;
      if (d.shape === 'polygon')
        d.pts.forEach((p, i) => {
          const k = Math.hypot(cx + p.x * d.w * Z - q.x, mid + p.y * d.h * Z - q.y);
          if (k < bd) {
            bd = k;
            best = { t: 'p', i };
          }
        });
      d.weak.forEach((w, i) => {
        const k = Math.hypot(cx + w.x * Z - q.x, mid + w.y * Z - q.y);
        if (k < bd + 6) {
          bd = k;
          best = { t: 'w', i };
        }
      });
      if (best) {
        g = best;
        cv.setPointerCapture(ev.pointerId);
      }
    };
    cv.onpointermove = ev => {
      if (!g) return;
      const d = cur(),
        q = pt(ev),
        Z = 36,
        cx = cv.width / 2,
        mid = cv.height - 40 - (d.h * Z) / 2;
      const rd = (v, s) => Math.round(v / s) * s;
      if (g.t === 'p') {
        d.pts[g.i] = {
          x: Math.max(-1, Math.min(1, rd((q.x - cx) / Z / d.w, 0.05))),
          y: Math.max(-1, Math.min(1, rd((q.y - mid) / Z / d.h, 0.05)))
        };
      } else {
        d.weak[g.i].x = Math.max(-8, Math.min(8, rd((q.x - cx) / Z, 0.05)));
        d.weak[g.i].y = Math.max(-8, Math.min(8, rd((q.y - mid) / Z, 0.05)));
      }
      Object.assign(d, EN.clean1(d));
      drawPrev();
    };
    cv.onpointerup = () => {
      if (g) {
        g = null;
        commit(false);
        enUI();
      }
    };
  }

  window.enUI = function () {
    const host = $('eng');
    host.innerHTML = '';
    if (!lib().some(d => d.id === SEL)) SEL = (lib()[0] || {}).id || '';
    const L = E('div', 'enl');
    L.appendChild(E('b', '', 'Enemy types'));
    lib().forEach(d => {
      const b = E('button', 'item' + (d.id === SEL ? ' on' : ''), d.name + '  (' + d.id + ')');
      b.onclick = () => {
        SEL = d.id;
        enUI();
      };
      L.appendChild(b);
    });
    if (!lib().length) L.appendChild(E('p', 'hint', 'No enemy types yet. Click New enemy type to build one.'));
    const row = E('div', 'row');
    row.append(
      bt('New enemy type', () => {
        if (lib().length >= 40) {
          $('pmsg').textContent = 'Up to 40 enemy types.';
          return;
        }
        const n = lib().length + 1,
          d = EN.clean1({ id: uniq('enemy' + n), name: 'Enemy ' + n });
        lib().push(d);
        SEL = d.id;
        save();
        enUI();
      }),
      bt('Duplicate', () => {
        const d = cur();
        if (!d || lib().length >= 40) return;
        const c = EN.clean1(
          Object.assign({}, JSON.parse(JSON.stringify(d)), { id: uniq(d.id + '_copy'), name: d.name + ' copy' })
        );
        lib().splice(lib().indexOf(d) + 1, 0, c);
        SEL = c.id;
        save();
        enUI();
      }),
      bt('Delete', () => {
        const d = cur();
        if (!d) return;
        const used = [];
        (S.areas || []).forEach(a =>
          (a.rooms || []).forEach(r =>
            (r.ent || []).forEach(e => {
              if (e.type === 'enemy' && e.props && e.props.kind === d.id) used.push(e);
            })
          )
        );
        if (
          !confirm(
            'Delete "' +
              d.name +
              '"?' +
              (used.length
                ? ' ' + used.length + ' enemies placed in rooms use it and will turn into simple enemies.'
                : '') +
              ' Undo can bring it back.'
          )
        )
          return;
        used.forEach(e => {
          e.props.kind = '';
        });
        S.enemies = lib().filter(q => q !== d);
        SEL = '';
        save();
        enUI();
      })
    );
    L.appendChild(row);
    host.appendChild(L);
    const R = E('div');
    host.appendChild(R);
    const d = cur();
    if (!d) {
      const c = E('div', 'enc');
      c.appendChild(E('h3', '', 'Enemies'));
      c.appendChild(
        E(
          'p',
          'hint',
          'An enemy type says how an enemy looks, moves, attacks, takes hits and what it drops. Build one here, then place it in a room: World editor > Entities > Enemy, and pick its Type. Every number can be changed; nothing is preset. The simple Enemy (no type) still works.'
        )
      );
      R.appendChild(c);
      return;
    }
    const pc = E('div', 'enc');
    pc.appendChild(E('h3', '', 'Size and ranges'));
    prev = E('canvas');
    prev.width = 720;
    prev.height = 220;
    pc.appendChild(prev);
    R.appendChild(pc);
    drawPrev();
    dragSetup(prev);
    shapeCards(R, d);
    const idc = E('div', 'enc');
    idc.appendChild(E('h3', '', 'Id'));
    const ir = E('div', 'enr');
    const il = E('label');
    il.appendChild(E('span', '', 'Id (rooms refer to it)'));
    const ii = E('input');
    ii.type = 'text';
    ii.value = d.id;
    ii.maxLength = 24;
    ii.onchange = () => {
      const old = d.id,
        nid = (ii.value || '').replace(/[^\w-]/g, '').slice(0, 24) || old;
      if (lib().some(q => q !== d && q.id === nid)) {
        ii.value = old;
        $('pmsg').textContent = 'That id is taken.';
        return;
      }
      d.id = nid;
      (S.areas || []).forEach(a =>
        (a.rooms || []).forEach(r =>
          (r.ent || []).forEach(e => {
            if (e.type === 'enemy' && e.props && e.props.kind === old) e.props.kind = nid;
          })
        )
      );
      (S.events || []).forEach(ev => {
        if (ev.trigger && ev.trigger.enemy === old) ev.trigger.enemy = nid;
      });
      SEL = nid;
      commit();
    };
    il.appendChild(ii);
    ir.appendChild(il);
    idc.appendChild(ir);
    R.appendChild(idc);
    const groups = [];
    Object.keys(EN.FIELDS).forEach(k => {
      const g = EN.FIELDS[k].g;
      if (!groups.includes(g)) groups.push(g);
    });
    groups.forEach(g => {
      const c = E('div', 'enc');
      c.appendChild(E('h3', '', g));
      const r = E('div', 'enr');
      let n = 0;
      Object.keys(EN.FIELDS).forEach(k => {
        if (EN.FIELDS[k].g === g && showIf(d, k)) {
          field(r, d, k);
          n++;
        }
      });
      if (g === 'Look') {
        EN.CLIPS.forEach(cp => {
          const l = E('label');
          l.appendChild(E('span', '', 'Animation: ' + cp[1]));
          const s = E('select');
          [['', '(none)']]
            .concat((S.anims || []).map(a => [a.id, a.name || a.id]))
            .concat(
              d.clips[cp[0]] && !(S.anims || []).some(a => a.id === d.clips[cp[0]])
                ? [[d.clips[cp[0]], d.clips[cp[0]] + ' (missing)']]
                : []
            )
            .forEach(x => {
              const o = E('option', '', x[1]);
              o.value = x[0];
              s.appendChild(o);
            });
          s.value = d.clips[cp[0]] || '';
          s.onchange = () => {
            if (s.value) d.clips[cp[0]] = s.value;
            else delete d.clips[cp[0]];
            commit(false);
          };
          l.appendChild(s);
          r.appendChild(l);
        });
        SND(r, d);
      }
      c.appendChild(r);
      if (n || g === 'Look') R.appendChild(c);
    });
    const hint = E(
      'p',
      'hint',
      'Place it: World editor > Entities > Enemy > Type. Animations come from the Animations tab; sounds from the Audio tab. Enemies fall with gravity unless they fly, and stand on blocks, half blocks and platforms.'
    );
    R.appendChild(hint);
  };
  function SND(r, d) {
    EN.SNDS.forEach(cp => {
      const l = E('label');
      l.appendChild(E('span', '', 'Sound: ' + cp[1]));
      const s = E('select');
      [['', '(none)']]
        .concat((S.sounds || []).filter(z => !z.music).map(a => [a.id, a.name || a.id]))
        .concat(
          d.snds[cp[0]] && !(S.sounds || []).some(a => a.id === d.snds[cp[0]])
            ? [[d.snds[cp[0]], d.snds[cp[0]] + ' (missing)']]
            : []
        )
        .forEach(x => {
          const o = E('option', '', x[1]);
          o.value = x[0];
          s.appendChild(o);
        });
      s.value = d.snds[cp[0]] || '';
      s.onchange = () => {
        if (s.value) d.snds[cp[0]] = s.value;
        else delete d.snds[cp[0]];
        commit(false);
      };
      l.appendChild(s);
      r.appendChild(l);
    });
  }
})();
