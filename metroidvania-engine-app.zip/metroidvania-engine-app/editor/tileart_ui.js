// Faster level building (editor): tile pictures from a sprite sheet (with auto-tiling and animation), stamps, fill border and room templates.
// The panels live in Level Settings > Room. Needs the editor globals: S, rc, save, $, mkSel, mkNum, sheetOf, drawT, drawEn, drawTr, lyOk, openRoom, tool, GT, LASTTILE, CLIP.
(() => {
  const E = (t, c, x) => {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };
  const btn = (t, f, title) => {
    const b = E('button', '', t);
    b.onclick = f;
    if (title) b.title = title;
    return b;
  };
  let TS = '#',
    open = {},
    pickCv = null,
    prevCv = null,
    msgEl = null;
  const say = t => {
    if (msgEl) msgEl.textContent = t;
  };
  const skins = () => S.tileSkins || (S.tileSkins = {});
  const redraw = () => {
    if (typeof rc !== 'undefined' && rc && typeof drawT === 'function' && $('rm') && !$('rm').hidden) drawT();
  };
  const putSkin = patch => {
    const cur = skins()[TS] || { sheet: '', mode: 'single', col: 0, row: 0, frames: 1, fps: 8, join: 'same' };
    const n = Object.assign({}, cur, patch);
    const all = Object.assign({}, skins());
    if (!n.sheet) delete all[TS];
    else all[TS] = n;
    S.tileSkins = MV.Tiles.cleanSkins(all);
    save();
    redraw();
    build();
  };

  // ---------- tile pictures ----------
  function picker(k, host) {
    const sh = S.sheets.find(x => x.id === k.sheet),
      im = sh && sheetOf(k.sheet);
    if (!sh || !im || !im.img.complete || !im.img.naturalWidth) {
      host.appendChild(E('p', 'hint', 'Pick a sprite sheet to see it here. Click a cell to choose it.'));
      return;
    }
    const sc = Math.max(1, Math.min(4, Math.floor(520 / im.img.naturalWidth) || 1)),
      W = im.img.naturalWidth * sc,
      H = im.img.naturalHeight * sc;
    const wrap = E('div', 'mp');
    wrap.style.maxHeight = '260px';
    wrap.style.overflow = 'auto';
    const cv = E('canvas');
    cv.width = W;
    cv.height = H;
    cv.style.width = W + 'px';
    cv.style.maxWidth = 'none';
    cv.style.cursor = 'pointer';
    cv.style.imageRendering = 'pixelated';
    const x = cv.getContext('2d');
    x.imageSmoothingEnabled = false;
    x.drawImage(im.img, 0, 0, W, H);
    const cw = im.tw * sc,
      ch = im.th * sc;
    x.strokeStyle = 'rgba(255,255,255,.25)';
    x.lineWidth = 1;
    for (let gx = 0; gx <= W; gx += cw) {
      x.beginPath();
      x.moveTo(gx + 0.5, 0);
      x.lineTo(gx + 0.5, H);
      x.stroke();
    }
    for (let gy = 0; gy <= H; gy += ch) {
      x.beginPath();
      x.moveTo(0, gy + 0.5);
      x.lineTo(W, gy + 0.5);
      x.stroke();
    }
    const bw = k.mode === 'auto16' ? 4 : k.frames,
      bh = k.mode === 'auto16' ? 4 : 1,
      bwAll = k.mode === 'auto16' ? 4 * k.frames : k.frames;
    x.strokeStyle = '#ef9f27';
    x.lineWidth = 2;
    x.strokeRect(k.col * cw + 1, k.row * ch + 1, Math.min(bwAll, 999) * cw - 2, bh * ch - 2);
    if (k.mode === 'auto16' && k.frames > 1) {
      x.strokeStyle = '#5dcaa5';
      x.strokeRect(k.col * cw + 1, k.row * ch + 1, bw * cw - 2, bh * ch - 2);
    }
    cv.onclick = e => {
      const r = cv.getBoundingClientRect();
      const px = ((e.clientX - r.left) / r.width) * W,
        py = ((e.clientY - r.top) / r.height) * H;
      putSkin({ col: Math.floor(px / cw), row: Math.floor(py / ch) });
    };
    wrap.appendChild(cv);
    host.appendChild(wrap);
    host.appendChild(
      E(
        'p',
        'hint',
        'The orange box is what the tile uses. Click a cell to move it. Cell size comes from "Frame width / height" of the sheet (Sprites section).'
      )
    );
  }
  function sample(ch, k) {
    // a little island of the tile: shows how the corners and edges look
    const rows = ['........', '.####...', '.#####..', '.#####.#', '..###..#', '........'].map(r => r.replace(/#/g, ch));
    return rows;
  }
  function drawPrev() {
    if (!prevCv || !prevCv.isConnected) return;
    const k = skins()[TS],
      x = prevCv.getContext('2d'),
      rows = sample(TS, k),
      c = 32;
    x.clearRect(0, 0, prevCv.width, prevCv.height);
    x.fillStyle = '#12324a';
    x.fillRect(0, 0, prevCv.width, prevCv.height);
    rows.forEach((r, ty) =>
      r.split('').forEach((ch, tx) => {
        if (ch === '.') return;
        MV.Tiles.draw(x, ch, tx * c, ty * c, c, {
          edit: true,
          tx,
          ty,
          at: (a, b) => (rows[b] ? rows[b][a] : undefined),
          skins: S.tileSkins,
          sheet: sheetOf,
          time: performance.now() / 1000
        });
      })
    );
  }
  function skinBox() {
    const d = E('details');
    d.open = !!open.skin;
    d.ontoggle = () => (open.skin = d.open);
    d.appendChild(E('summary', '', 'Tile pictures (auto-tiling, animated tiles)'));
    d.appendChild(
      E(
        'p',
        'hint',
        'Give a tile your own picture from a sprite sheet. "Auto-tile" picks the right edge and corner by itself: a 4 x 4 block of cells, numbered by which neighbours are joined (up = 1, right = 2, down = 4, left = 8; cell 0 is a lone tile, cell 15 is surrounded, read left to right and top to bottom). More frames make it animate (water, torches).'
      )
    );
    const row = E('div', 'mvf');
    row.appendChild(
      mkSel(
        'Tile',
        MV.Tiles.SKIN_CHARS.map(c => [c, MV.Tiles.nameOf(c) + (skins()[c] ? ' (picture)' : '')]),
        TS,
        v => {
          TS = v;
          build();
        }
      )
    );
    d.appendChild(row);
    const k = skins()[TS] || { sheet: '', mode: 'single', col: 0, row: 0, frames: 1, fps: 8, join: 'same' };
    const f = E('div', 'mvf');
    f.appendChild(
      mkSel('Sprite sheet', [['', '(none: plain colours)']].concat(S.sheets.map(v => [v.id, v.name])), k.sheet, v =>
        putSkin({ sheet: v })
      )
    );
    if (k.sheet) {
      f.appendChild(
        mkSel(
          'Look',
          [
            ['single', 'One picture (or an animation)'],
            ['auto16', 'Auto-tile (16 cells)']
          ],
          k.mode,
          v => putSkin({ mode: v })
        )
      );
      f.appendChild(mkNum('Cell column', k.col, 0, 999, 1, v => putSkin({ col: v })));
      f.appendChild(mkNum('Cell row', k.row, 0, 999, 1, v => putSkin({ row: v })));
      f.appendChild(mkNum('Frames (animation)', k.frames, 1, 32, 1, v => putSkin({ frames: v })));
      f.appendChild(mkNum('Speed (frames/s)', k.fps, 1, 60, 1, v => putSkin({ fps: v })));
      if (k.mode === 'auto16')
        f.appendChild(
          mkSel(
            'Joins',
            [
              ['same', 'Only the same tile'],
              ['solid', 'Any solid block']
            ],
            k.join,
            v => putSkin({ join: v })
          )
        );
    }
    d.appendChild(f);
    if (k.sheet) {
      picker(k, d);
      prevCv = E('canvas');
      prevCv.width = 256;
      prevCv.height = 192;
      prevCv.style.width = '256px';
      prevCv.style.imageRendering = 'pixelated';
      d.appendChild(prevCv);
      d.appendChild(btn('Remove this tile picture', () => putSkin({ sheet: '' })));
    }
    return d;
  }

  // ---------- fill border ----------
  function fillBorder(th) {
    if (typeof rc === 'undefined' || !rc || typeof lyOk !== 'function' || !lyOk('tiles')) return;
    const ch = typeof tool === 'string' && GT.includes(tool) && tool !== 'D' && tool !== '.' ? tool : LASTTILE || '#';
    th = Math.max(1, Math.min(20, Math.floor(th) || 1));
    for (let y = 0; y < rc.gh; y++) {
      const r = rc.grid[y].split('');
      for (let x = 0; x < rc.gw; x++)
        if ((x < th || y < th || x >= rc.gw - th || y >= rc.gh - th) && r[x] !== 'D') r[x] = ch;
      rc.grid[y] = r.join('');
    }
    save();
    redraw();
    say('Border filled with ' + MV.Tiles.nameOf(ch) + '.');
  }

  // ---------- stamps ----------
  const stamps = () => S.stamps || (S.stamps = []);
  function saveStamp(name) {
    if (!SEL) {
      say('Select some tiles first (Tiles > Select), then save them as a stamp.');
      return;
    }
    if (stamps().length >= 40) {
      say('Up to 40 stamps.');
      return;
    }
    selCopy();
    if (!CLIP) return;
    S.stamps = MV.Tiles.cleanStamps(
      stamps().concat([{ name: name || 'Stamp ' + (stamps().length + 1), rows: CLIP.rows }])
    );
    save();
    build();
  }
  function useStamp(st) {
    if (typeof sub === 'function' && !(typeof tool === 'string' && GT.includes(tool))) sub('tiles');
    CLIP = { w: st.w, h: st.h, rows: st.rows.slice() };
    startPaste();
    say('Click in the room to place "' + st.name + '".');
  }

  // ---------- room templates ----------
  const grid = (w, h) => Array.from({ length: h }, () => Array(w).fill('.'));
  const box = (g, x0, y0, x1, y1, c) => {
    for (let y = Math.max(0, y0); y <= Math.min(g.length - 1, y1); y++)
      for (let x = Math.max(0, x0); x <= Math.min(g[0].length - 1, x1); x++) g[y][x] = c;
  };
  // a closed room with a floor, a ceiling, walls, and a doorway gap (3 tiles high) on the chosen sides
  const shell = (w, h, gaps) => {
    const g = grid(w, h);
    box(g, 0, h - 2, w - 1, h - 1, '#');
    box(g, 0, 0, w - 1, 1, '#');
    box(g, 0, 0, 1, h - 1, '#');
    box(g, w - 2, 0, w - 1, h - 1, '#');
    if (gaps.includes('l')) box(g, 0, h - 5, 1, h - 3, '.');
    if (gaps.includes('r')) box(g, w - 2, h - 5, w - 1, h - 3, '.');
    return g;
  };
  const TEMPLATES = {
    boss: [
      'Boss arena',
      'A wide closed arena with a floor, a doorway on each side and two platforms. Drag a boss in from the Bosses section.',
      (w, h) => {
        const g = shell(w, h, 'lr');
        const px = Math.max(4, Math.floor(w * 0.2));
        box(g, px, h - 7, px + 4, h - 7, '=');
        box(g, w - px - 5, h - 7, w - px - 1, h - 7, '=');
        return { g, ents: [] };
      }
    ],
    save: [
      'Save room',
      'A small quiet room with a rest point in the middle: it saves, heals and restores energy when you press its key.',
      (w, h) => {
        const g = shell(w, h, 'lr');
        return {
          g,
          ents: [{ type: 'checkpointkey', x: Math.floor(w / 2), y: h - 3, props: { rest: 'yes' } }]
        };
      }
    ],
    shop: [
      'Shop',
      'A closed room with a shopkeeper in the middle. Edit what is for sale in the character\'s "Shop" setting.',
      (w, h) => {
        const g = shell(w, h, 'lr');
        return {
          g,
          ents: [
            {
              type: 'npc',
              x: Math.floor(w / 2),
              y: h - 4,
              props: { name: 'Shopkeeper', dialogue: 'Welcome! Take a look.', shop: '' }
            }
          ]
        };
      }
    ],
    corridor: [
      'Corridor',
      'A long, low tunnel open on both ends.',
      (w, h) => {
        const g = grid(w, h);
        box(g, 0, h - 3, w - 1, h - 1, '#');
        box(g, 0, h - 9, w - 1, h - 7, '#');
        return { g, ents: [] };
      }
    ],
    shaft: [
      'Vertical shaft',
      'Walls on both sides with one-way platforms zigzagging up. Use a tall room.',
      (w, h) => {
        const g = grid(w, h);
        box(g, 0, 0, 1, h - 1, '#');
        box(g, w - 2, 0, w - 1, h - 1, '#');
        box(g, 0, h - 2, w - 1, h - 1, '#');
        let left = true;
        for (let y = h - 6; y > 3; y -= 5) {
          if (left) box(g, 2, y, Math.min(w - 3, 7), y, '=');
          else box(g, Math.max(2, w - 8), y, w - 3, y, '=');
          left = !left;
        }
        return { g, ents: [] };
      }
    ],
    water: [
      'Flooded cave',
      'A room that is half full of water, with a current that pushes you across.',
      (w, h) => {
        const g = shell(w, h, 'lr');
        box(g, 2, Math.floor(h * 0.4), w - 3, h - 3, '~');
        return {
          g,
          ents: [
            {
              type: 'current',
              x: Math.floor(w / 3),
              y: Math.floor(h * 0.5),
              props: { width: Math.max(4, Math.floor(w / 3)), height: 3, dir: 'right', power: 5 }
            }
          ]
        };
      }
    ],
    pit: [
      'Spike pit',
      'A floor with a pit full of spikes in the middle: a jump to cross.',
      (w, h) => {
        const g = shell(w, h, 'lr');
        const a = Math.floor(w / 2) - 3,
          b = Math.floor(w / 2) + 3;
        box(g, a, h - 2, b, h - 1, '.');
        box(g, a, h - 1, b, h - 1, '#');
        return { g, ents: [{ type: 'hazard', x: a, y: h - 2, props: { width: b - a + 1, height: 1 } }] };
      }
    ]
  };
  function applyTemplate(key) {
    const t = TEMPLATES[key];
    if (!t || typeof rc === 'undefined' || !rc) return;
    if (!lyOk('tiles') || !lyOk('objects')) return;
    const empty = rc.grid.every(r => /^\.*$/.test(r)) && !(rc.ent || []).length;
    if (
      !empty &&
      !confirm(
        'Replace the tiles and entities of this room with the "' + t[0] + '" template? Undo can bring them back.'
      )
    )
      return;
    const r = t[2](rc.gw, rc.gh);
    rc.grid = r.g.map(row => row.join(''));
    rc.tr = [];
    rc.ent = r.ents.map(e => ({
      id: 'e' + Math.random().toString(36).slice(2, 7),
      type: e.type,
      x: e.x,
      y: e.y,
      props: e.props || {}
    }));
    save();
    if (typeof openRoom === 'function') openRoom(rc);
    say('"' + t[0] + '" applied. Add doorways where you need them.');
  }

  function quickBox() {
    const d = E('details');
    d.open = open.quick !== false;
    d.ontoggle = () => (open.quick = d.open);
    d.appendChild(E('summary', '', 'Quick room tools (border, templates, stamps)'));
    const r1 = E('div', 'row');
    const th = E('input');
    th.type = 'number';
    th.min = 1;
    th.max = 20;
    th.value = open.th || 2;
    th.style.width = '56px';
    th.onchange = () => (open.th = +th.value);
    const l1 = E('label');
    l1.append('Border thickness ', th);
    r1.append(
      l1,
      btn(
        'Fill the room border',
        () => fillBorder(+th.value),
        'Draw the chosen tile around the edge of the room (doorways stay).'
      )
    );
    d.appendChild(r1);
    const r2 = E('div', 'row');
    const ts = E('select');
    Object.keys(TEMPLATES).forEach(k => {
      const o = E('option', '', TEMPLATES[k][0]);
      o.value = k;
      ts.appendChild(o);
    });
    const info = E('p', 'hint', TEMPLATES[ts.value][1]);
    ts.onchange = () => (info.textContent = TEMPLATES[ts.value][1]);
    r2.append(
      E('span', '', 'Room template'),
      ts,
      btn('Apply to this room', () => applyTemplate(ts.value))
    );
    d.append(r2, info);
    const r3 = E('div', 'row');
    const nm = E('input');
    nm.type = 'text';
    nm.maxLength = 30;
    nm.placeholder = 'Stamp name';
    nm.style.width = '140px';
    r3.append(
      nm,
      btn(
        'Save the selection as a stamp',
        () => saveStamp(nm.value.trim()),
        'Select tiles first (Tiles > Select), then save them to paste again anywhere, in any room.'
      )
    );
    d.appendChild(r3);
    stamps().forEach(st => {
      const r = E('div', 'row');
      r.append(
        E('span', '', st.name + ' (' + st.w + ' x ' + st.h + ')'),
        btn('Place', () => useStamp(st)),
        btn('Delete', () => {
          S.stamps = stamps().filter(q => q.id !== st.id);
          save();
          build();
        })
      );
      d.appendChild(r);
    });
    if (!stamps().length)
      d.appendChild(E('p', 'hint', 'No stamps yet. Select some tiles, give them a name, and save them here.'));
    msgEl = E('p', 'hint', '');
    d.appendChild(msgEl);
    return d;
  }

  let host = null;
  function build() {
    if (!host || !host.isConnected) {
      const lsr = $('lsr');
      if (!lsr) return;
      host = E('div');
      host.id = 'tart';
      const first = lsr.children[0];
      lsr.insertBefore(host, first ? first.nextSibling : null);
    }
    host.textContent = '';
    host.append(quickBox(), skinBox());
    drawPrev();
  }
  // images load late and tiles can be animated, so repaint the room now and then while a picture is in use
  let lastKey = '';
  setInterval(() => {
    if (typeof rc === 'undefined' || !rc || !$('rm') || $('rm').hidden) return;
    const moving = ((rc.bg && rc.bg.layers) || []).some(
      L => L.sheet && L.vis !== false && (L.driftX || L.driftY || L.sway)
    );
    const sk = S.tileSkins || {},
      ks = Object.keys(sk);
    if (!ks.length) {
      if (moving) drawT();
      return;
    }
    const ready = ks
        .map(c => {
          const im = sheetOf(sk[c].sheet);
          return im && im.img.complete && im.img.naturalWidth ? 1 : 0;
        })
        .join(''),
      anim = ks.some(c => sk[c].frames > 1);
    if (anim || moving || ready !== lastKey) {
      lastKey = ready;
      drawT();
    }
    drawPrev();
  }, 160);
  window.tartUI = build;
})();
