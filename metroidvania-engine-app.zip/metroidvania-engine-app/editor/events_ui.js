// Events tab (editor). Builds the list of events and the form for the selected one from the schema in engine/events.js.
// Needs the editor globals: S (the project), $, save().
(() => {
  const EV = MV.Events;
  let SEL = '';
  const css = document.createElement('style');
  css.textContent = `#evg{display:grid;grid-template-columns:260px minmax(0,1fr);gap:12px;align-items:start;padding:10px}
  #evg .evl{border:2px solid var(--bd);border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:6px;min-height:320px}
  #evg .evl .item{text-align:left;padding:5px 8px;font-size:13px;border-radius:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  #evg .evl .item.on{border-color:#ef9f27;font-weight:600}#evg .evl .item.off{opacity:.55}
  #evg .evc{border:1px solid var(--bd);border-radius:10px;padding:10px 12px;background:var(--cd);margin-bottom:10px}
  #evg .evc h3{margin:0 0 6px;font-size:14px}#evg .evc .sub{font-size:12px;color:var(--mu,#8fa3b3);margin:0 0 8px}
  #evg .evr{display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:6px 0;border-top:1px solid var(--bd)}#evg .evr:first-of-type{border-top:0}
  #evg .evr .ty{font-weight:600;min-width:210px}#evg .evr label{display:flex;gap:5px;align-items:center;font-size:13px}
  #evg .evr textarea{width:320px;height:64px}#evg .evr input[type=text]{width:170px}#evg .evr input[type=number]{width:80px}
  #evg .bad{color:#ff8a80}#evg .warn{color:#ffd98a}#evg .ok{color:#8fe3c0}
  #evg .iss{margin:3px 0;font-size:13px}#evg .badge{float:right;font-size:11px;padding:0 6px;border-radius:9px;background:#5a2a2a;color:#ffb4ab}#evg .badge.w{background:#4d4020;color:#ffd98a}
  @media(max-width:900px){#evg{grid-template-columns:1fr}}`;
  document.head.appendChild(css);
  const E = (t, c, x) => {
    const e = document.createElement(t);
    if (c) e.className = c;
    if (x !== undefined) e.textContent = x;
    return e;
  };
  const bt = (t, f, title, dis) => {
    const b = E('button', '', t);
    b.onclick = f;
    if (title) b.title = title;
    b.disabled = !!dis;
    return b;
  };
  const evs = () => S.events || (S.events = []);
  const cur = () => evs().find(e => e.id === SEL) || null;
  const commit = () => {
    S.events = EV.clean(S.events);
    save();
    evUI();
  };
  const sources = () => EV.flagSources(S);

  // one input for one parameter. d = the schema entry, o = the object that holds the value
  function param(d, k, o, selfId) {
    const lab = E('label');
    if (d.label) lab.append(d.label + ' ');
    const set = v => {
      o[k] = v;
      commit();
    };
    const pick = (opts, anyLabel) => {
      const s = E('select');
      let list = opts.slice();
      if (anyLabel) list.unshift(['', anyLabel]);
      else list.unshift(['', '(pick one)']);
      if (o[k] && !list.some(x => x[0] === o[k])) list.push([o[k], '(missing) ' + o[k]]);
      list.forEach(x => {
        const op = E('option', '', x[1]);
        op.value = x[0];
        s.appendChild(op);
      });
      s.value = o[k] || '';
      if (o[k] && s.selectedOptions[0] && /^\(missing\)/.test(s.selectedOptions[0].textContent))
        s.style.outline = '2px solid #ff8a80';
      s.onchange = () => set(s.value);
      return s;
    };
    switch (d.t) {
      case 'room':
        lab.appendChild(
          pick(
            EV.roomsOf(S).map(r => [r.id, r.name]),
            d.any
          )
        );
        break;
      case 'item':
        lab.appendChild(
          pick(
            (S.items || []).map(i => [i.id, i.name]),
            d.any
          )
        );
        break;
      case 'ability':
        lab.appendChild(
          pick(
            [...EV.abilitiesOf(S)].sort().map(a => [a, (MV.data.abilities[a] && MV.data.abilities[a].label) || a]),
            d.any
          )
        );
        break;
      case 'enemy':
        lab.appendChild(
          pick(
            (S.enemies || []).map(b => [b.id, b.name || b.id]),
            d.any
          )
        );
        break;
      case 'boss':
        lab.appendChild(
          pick(
            (S.bosses || []).map(b => [b.id, b.name || b.id]),
            d.any
          )
        );
        break;
      case 'npc':
        lab.appendChild(
          pick(
            EV.npcsOf(S).map(n => [n.id, n.name]),
            d.any
          )
        );
        break;
      case 'event':
        lab.appendChild(
          pick(
            evs()
              .filter(e => e.id !== selfId)
              .map(e => [e.id, e.name])
          )
        );
        break;
      case 'camprofile':
        lab.appendChild(
          pick(
            MV.Camera.all(S.camProfiles).map(q => [q.id, q.name]),
            "The room's own"
          )
        );
        break;
      case 'select': {
        const s = E('select');
        d.o.forEach(x => {
          const op = E('option', '', x);
          op.value = x;
          s.appendChild(op);
        });
        s.value = o[k];
        s.onchange = () => set(s.value);
        lab.appendChild(s);
        break;
      }
      case 'number': {
        const i = E('input');
        i.type = 'number';
        i.min = d.min;
        i.max = d.max;
        i.step = d.step || 1;
        i.value = o[k] === null || o[k] === undefined ? '' : o[k];
        i.onchange = () => set(i.value === '' ? null : +i.value);
        lab.appendChild(i);
        break;
      }
      case 'longtext': {
        const t = E('textarea');
        t.value = o[k] || '';
        t.onchange = () => set(t.value);
        lab.appendChild(t);
        break;
      }
      case 'flag':
      case 'weapon':
      case 'sound':
      case 'key':
      case 'text':
      default: {
        if (d.t === 'key' && typeof keyCap === 'function') return keyCap({ props: o }, k); // click, then press the key (the same picker as everywhere else)
        const i = E('input');
        i.type = 'text';
        i.value = o[k] || '';
        i.maxLength = 80;
        i.onchange = () => set(i.value.trim());
        if (d.t === 'flag') {
          i.setAttribute('list', 'evflags');
          i.placeholder = d.any ? 'any flag' : 'flag name';
        }
        if (d.t === 'weapon') {
          i.setAttribute('list', 'evweapons');
          i.placeholder = 'weapon id';
        }
        if (d.t === 'key') {
          i.style.width = '90px';
          i.placeholder = 'E, Space, ArrowUp';
        }
        if (d.t === 'sound') {
          i.setAttribute('list', 'evsounds');
          i.placeholder = 'sound name';
        }
        lab.appendChild(i);
      }
    }
    return lab;
  }
  function flagNote(d, o, k) {
    if (d.t !== 'flag' || !o[k]) return null;
    const s = sources().get(o[k]);
    const n = E('span', 'sub');
    n.style.margin = '0';
    if (s) {
      n.className = 'sub ok';
      n.textContent = 'set by: ' + [...new Set(s)].slice(0, 3).join(', ') + (s.length > 3 ? '...' : '');
    } else if (EV.isBuiltinFlag(o[k])) {
      n.textContent = 'made by the game itself';
    } else {
      n.className = 'sub warn';
      n.textContent = 'nothing sets this flag yet';
    }
    return n;
  }
  function row(kind, o, i, arr, selfId) {
    const schema = EV.SCHEMA[kind],
      def = schema[o.type] || { label: o.type, p: {} },
      r = E('div', 'evr');
    if (kind === 'triggers') {
      const s = E('select');
      Object.keys(schema).forEach(t => {
        const op = E('option', '', schema[t].label);
        op.value = t;
        s.appendChild(op);
      });
      s.value = o.type;
      s.onchange = () => {
        Object.keys(o).forEach(k => delete o[k]);
        Object.assign(o, EV.blankPart('triggers', s.value));
        commit();
      };
      r.appendChild(s);
    } else {
      r.appendChild(E('span', 'ty', (kind === 'actions' ? i + 1 + '. ' : '') + def.label));
    }
    Object.keys(def.p).forEach(k => {
      r.appendChild(param(def.p[k], k, o, selfId));
      const n = flagNote(def.p[k], o, k);
      if (n) r.appendChild(n);
    });
    if (kind !== 'triggers') {
      const mv = j => {
        const t = arr[i];
        arr[i] = arr[j];
        arr[j] = t;
        commit();
      };
      if (kind === 'actions') {
        r.appendChild(bt('Up', () => mv(i - 1), 'Move this step earlier', i === 0));
        r.appendChild(bt('Down', () => mv(i + 1), 'Move this step later', i === arr.length - 1));
      }
      r.appendChild(
        bt('Remove', () => {
          arr.splice(i, 1);
          commit();
        })
      );
    }
    return r;
  }
  function adder(kind, arr) {
    const schema = EV.SCHEMA[kind],
      d = E('div', 'evr'),
      s = E('select');
    Object.keys(schema).forEach(t => {
      const op = E('option', '', schema[t].label);
      op.value = t;
      s.appendChild(op);
    });
    d.append(
      s,
      bt(kind === 'conds' ? 'Add condition' : 'Add step', () => {
        arr.push(EV.blankPart(kind, s.value));
        commit();
      })
    );
    return d;
  }
  const lists = () => {
    const ensure = (id, vals) => {
      let dl = $(id);
      if (!dl) {
        dl = E('datalist');
        dl.id = id;
        document.body.appendChild(dl);
      }
      dl.innerHTML = '';
      vals.forEach(v => {
        const o = E('option');
        o.value = v;
        dl.appendChild(o);
      });
    };
    ensure('evflags', [...sources().keys()].filter(f => !EV.isBuiltinFlag(f)).sort());
    ensure('evweapons', [...EV.weaponsOf(S)].sort());
    ensure(
      'evsounds',
      (S.sounds || []).map(x => x.id)
    );
  };

  window.evUI = function () {
    const host = $('evg');
    if (!host) return;
    host.innerHTML = '';
    lists();
    const L = evs();
    if (!cur()) SEL = L.length ? L[0].id : '';
    const issues = EV.validate(S),
      by = {};
    issues.forEach(x => (by[x.ev] = by[x.ev] || []).push(x));
    // left: the list
    const left = E('aside', 'evl');
    left.appendChild(E('strong', '', 'Events'));
    left.appendChild(
      E(
        'div',
        'sub',
        L.length
          ? L.length +
              ' event' +
              (L.length > 1 ? 's' : '') +
              (issues.length ? ', ' + issues.length + ' problem' + (issues.length > 1 ? 's' : '') : ', no problems')
          : 'None yet.'
      )
    );
    L.forEach(ev => {
      const b = E('button', 'item' + (ev.id === SEL ? ' on' : '') + (ev.on ? '' : ' off'), ev.name);
      const is = by[ev.id] || [],
        er = is.filter(x => x.level === 'error').length;
      if (is.length) {
        const bd = E(
          'span',
          'badge' + (er ? '' : ' w'),
          er ? er + ' error' + (er > 1 ? 's' : '') : is.length + ' warning' + (is.length > 1 ? 's' : '')
        );
        b.appendChild(bd);
      }
      b.onclick = () => {
        SEL = ev.id;
        evUI();
      };
      left.appendChild(b);
    });
    const add = E('div', 'row');
    add.append(
      bt('New event', () => {
        let n = L.length + 1;
        while (L.some(e => e.id === 'ev' + n)) n++;
        L.push(EV.blank(n));
        SEL = 'ev' + n;
        commit();
      }),
      bt('Copy', () => {
        const c = cur();
        if (!c) return;
        const j = JSON.parse(JSON.stringify(c));
        let n = 1;
        while (L.some(e => e.id === 'ev' + n)) n++;
        j.id = 'ev' + n;
        j.name = (c.name + ' copy').slice(0, 40);
        L.push(j);
        SEL = j.id;
        commit();
      }),
      bt('Delete', () => {
        const c = cur();
        if (!c || !confirm('Delete the event "' + c.name + '"?')) return;
        S.events = L.filter(e => e.id !== c.id);
        SEL = '';
        save();
        evUI();
      })
    );
    left.appendChild(add);
    host.appendChild(left);
    // right: the form
    const right = E('div');
    host.appendChild(right);
    const ev = cur();
    if (!ev) {
      right.appendChild(
        E(
          'p',
          'hint',
          'An event is something that happens in your game: WHEN something happens (the player enters a room, picks something up, defeats a boss, steps in a zone...), ONLY IF some conditions are true, THEN a list of steps runs (set a flag, give an item, show a message, start a conversation, move the player, change the camera...). Click New event to make one.'
        )
      );
      return;
    }
    const hd = E('div', 'evc');
    const nm = E('input');
    nm.type = 'text';
    nm.value = ev.name;
    nm.maxLength = 40;
    nm.style.cssText = 'font-weight:600;width:260px';
    nm.onchange = () => {
      ev.name = nm.value;
      commit();
    };
    const on = E('input');
    on.type = 'checkbox';
    on.checked = ev.on;
    on.onchange = () => {
      ev.on = on.checked;
      commit();
    };
    const onl = E('label', '', ' Turned on');
    onl.prepend(on);
    const once = E('select');
    [
      ['yes', 'Runs only once per save'],
      ['no', 'Runs every time']
    ].forEach(x => {
      const o = E('option', '', x[1]);
      o.value = x[0];
      once.appendChild(o);
    });
    once.value = ev.once;
    once.onchange = () => {
      ev.once = once.value;
      commit();
    };
    const idl = E('span', 'sub', 'id: ' + ev.id);
    hd.append(nm, ' ', onl, ' ', once, ' ', idl);
    right.appendChild(hd);
    const c1 = E('div', 'evc');
    c1.appendChild(E('h3', '', 'When'));
    c1.appendChild(E('p', 'sub', 'What starts this event.'));
    c1.appendChild(row('triggers', ev.trigger, 0, null, ev.id));
    right.appendChild(c1);
    const c2 = E('div', 'evc');
    c2.appendChild(E('h3', '', 'Only if'));
    c2.appendChild(
      E(
        'p',
        'sub',
        ev.conds.length
          ? 'Every condition must be true, otherwise nothing happens.'
          : 'No conditions: it always happens.'
      )
    );
    ev.conds.forEach((c, i) => c2.appendChild(row('conds', c, i, ev.conds, ev.id)));
    if (ev.conds.length < 12) c2.appendChild(adder('conds', ev.conds));
    right.appendChild(c2);
    const c3 = E('div', 'evc');
    c3.appendChild(E('h3', '', 'Then'));
    c3.appendChild(
      E('p', 'sub', 'These steps run in order. Wait and Start a conversation hold the list until they finish.')
    );
    ev.actions.forEach((a, i) => c3.appendChild(row('actions', a, i, ev.actions, ev.id)));
    if (ev.actions.length < 40) c3.appendChild(adder('actions', ev.actions));
    right.appendChild(c3);
    const c4 = E('div', 'evc');
    c4.appendChild(E('h3', '', 'Checks'));
    const mine = by[ev.id] || [];
    if (!mine.length) c4.appendChild(E('div', 'iss ok', 'No problems found: everything this event points to exists.'));
    mine.forEach(x =>
      c4.appendChild(
        E(
          'div',
          'iss ' + (x.level === 'error' ? 'bad' : 'warn'),
          (x.level === 'error' ? 'Error: ' : 'Warning: ') + x.text
        )
      )
    );
    c4.appendChild(
      E(
        'div',
        'sub',
        'To see what ran while you play, press Play in the World editor and tick "Show collision shapes": the last events that started (or were skipped, and why) are listed in the top right corner.'
      )
    );
    right.appendChild(c4);
  };
})();
