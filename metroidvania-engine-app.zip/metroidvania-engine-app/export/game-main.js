// The main process of an exported PC game (copied to resources/app/main.js by tools/pcexport.js).
// It opens one window with the game page and nothing else: no menu, no developer tools, no navigation, no permissions.
const { app, BrowserWindow, Menu, session } = require('electron');
const path = require('path');
const info = require('./package.json');
const title = info.productName || info.name || 'Game';

app.setName(title);
app.setPath('userData', path.join(app.getPath('appData'), title)); // saved games live here, next to the other games' saves
Menu.setApplicationMenu(null);
let win = null;

function create() {
  win = new BrowserWindow({
    width: 1280,
    height: 720,
    minWidth: 640,
    minHeight: 360,
    title,
    backgroundColor: '#0b1620',
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      webSecurity: true,
      devTools: false
    }
  });
  win.once('ready-to-show', () => win.show());
  win.webContents.on('will-navigate', e => e.preventDefault());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type === 'keyDown' && (i.key === 'F11' || (i.alt && i.key === 'Enter'))) {
      win.setFullScreen(!win.isFullScreen());
      e.preventDefault();
    }
  });
  win.on('closed', () => (win = null));
  win.loadFile(path.join(__dirname, 'game.html'));
}

if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });
  app.whenReady().then(() => {
    session.defaultSession.setPermissionRequestHandler((wc, permission, cb) => cb(false));
    create();
  });
  app.on('window-all-closed', () => app.quit());
}
