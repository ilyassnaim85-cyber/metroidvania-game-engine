// The player of an exported game: reads the project that was put in the page, shows a title screen and runs the engine.
// This file is copied into every exported game (see tools/export.js). It uses only what the engine files already define.
(() => {
  const $ = id => document.getElementById(id);
  const fail = e => {
    const p = $('mv-err');
    p.hidden = false;
    p.textContent = String((e && (e.stack || e.message)) || e).slice(0, 2000);
  };
  window.addEventListener('error', e => fail(e.error || e.message));
  window.addEventListener('unhandledrejection', e => fail(e.reason));

  // ---- the project (rooms are stored packed when they are big) ----
  const unpackRow = p => {
    if (p.indexOf('`') < 0) return p;
    let o = '',
      i = 0;
    while (i < p.length) {
      const ch = p[i];
      if (ch === '`') {
        const e = p.indexOf(';', i);
        o += p[i + 1].repeat(+p.slice(i + 2, e));
        i = e + 1;
      } else {
        o += ch;
        i++;
      }
    }
    return o;
  };
  const unpackGrid = v => {
    const g = [];
    v.d.forEach(q => {
      const r = unpackRow(q[0]);
      for (let i = 0; i < q[1]; i++) g.push(r);
    });
    return g;
  };
  let world;
  try {
    world = JSON.parse($('mv-project').textContent, (k, v) =>
      k === 'grid' && v && !Array.isArray(v) && v.z === 1 && Array.isArray(v.d) ? unpackGrid(v) : v
    );
  } catch (e) {
    fail('This game file is damaged: ' + e.message);
    return;
  }
  const name = (world.name || 'My game').slice(0, 40);
  const slug =
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .slice(0, 30) || 'game';
  MV.Progress.setKey('mv_game_' + slug);

  // ---- pictures ----
  const imgs = {};
  const sheet = id => (world.sheets || []).find(x => x.id === id);
  const img = s => {
    let m = imgs[s.id];
    if (!m) {
      m = new Image();
      m.src = s.url;
      imgs[s.id] = m;
    }
    return m;
  };
  const bgImg = id => {
    const q = sheet(id);
    return q ? img(q) : null;
  };
  const sheetOf = id => {
    const q = sheet(id);
    return q ? { img: img(q), tw: q.tw, th: q.th } : null;
  };
  const drawArt = (x, room, Z) => {
    (room.art || []).forEach(a => {
      const s = sheet(a.s);
      if (!s) return;
      const m = img(s);
      if (m.complete && m.naturalWidth)
        x.drawImage(m, a.c * s.tw, a.r * s.th, a.w * s.tw, a.h * s.th, a.x * Z, a.y * Z, a.w * Z, a.h * Z);
    });
  };
  (world.sheets || []).forEach(s => img(s)); // start loading them now
  MV.UI.loadFonts(world.fonts); // the fonts of the UI tab

  // ---- starting the game ----
  const everyRoom = () => MV.World.everyRoom(world);
  const startRoom = () => {
    const all = everyRoom();
    const s = all.find(q => (q.r.ent || []).some(e => e.type === 'spawn')) || all[0];
    return s ? s.r : null;
  };
  const hasSave = () => {
    try {
      const st = MV.Progress.load(world);
      return !!(
        st.cp ||
        Object.keys(st.flags).length ||
        Object.keys(st.abilities).length ||
        Object.keys(st.collected).length
      );
    } catch (e) {
      return false;
    }
  };
  function play(fresh) {
    if (fresh) MV.Progress.clear();
    const st = fresh ? MV.Progress.fresh() : MV.Progress.load(world);
    let room = startRoom();
    if (st.cp) room = MV.Progress.find(world, st.cp.a, st.cp.r) || room;
    if (!room) return fail('This game has no rooms.');
    $('mv-menu').hidden = true;
    $('mv-back').hidden = true;
    MV.Game.debug = false;
    MV.Game.boxes = false;
    MV.Game.start({
      enemies: () => world.enemies,
      bosses: () => world.bosses,
      canvas: $('mv-canvas'),
      world,
      room,
      state: st,
      persist: true,
      quit: menu, // Esc > Quit to title
      fullscreen: true,
      vol: curVol,
      onVol: saveVol,
      ctlUser: userKeys,
      onCtl: saveKeys,
      art: drawArt,
      tuning: () => world.player,
      image: bgImg,
      moves: () => world.moves,
      attacks: () => world.attacks,
      items: () => world.items,
      body: () => world.body,
      controls: () => world.controls,
      sprite: () => world.sprite || { w: 1.5, h: 1.5, anims: {} },
      sheet: sheetOf
    });
    $('mv-canvas').focus();
  }
  // The title screen is drawn on the game canvas with the same code as the editor's UI tab preview (MV.UI.menu).
  // the volumes the player chose are kept in the browser (or the PC game's own folder)
  const volKey = 'mv_vol_' + slug;
  let curVol = null;
  try {
    curVol = JSON.parse(localStorage.getItem(volKey));
  } catch (e) {
    curVol = null;
  }
  curVol = MV.Audio.cleanVol(curVol || world.vol);
  const saveVol = v => {
    curVol = MV.Audio.cleanVol(v);
    try {
      localStorage.setItem(volKey, JSON.stringify(curVol));
    } catch (e) {
      /* no storage: the choice lasts until the page closes */
    }
  };
  // the keys the player picked in the options (kept like the volumes)
  const ctlKey = 'mv_ctl_' + slug;
  let userKeys = null;
  try {
    const k = JSON.parse(localStorage.getItem(ctlKey));
    userKeys = k && typeof k === 'object' ? MV.Controls.clean({ keys: k }).keys : null;
  } catch (e) {
    userKeys = null;
  }
  const saveKeys = k => {
    userKeys = k;
    try {
      if (k) localStorage.setItem(ctlKey, JSON.stringify(k));
      else localStorage.removeItem(ctlKey);
    } catch (e) {
      /* no storage: the choice lasts until the page closes */
    }
  };
  const nowKeys = () => Object.assign({}, MV.Controls.clean(world.controls).keys, userKeys || {});
  let T = null;
  function stopTitle() {
    if (!T) return;
    cancelAnimationFrame(T.raf);
    removeEventListener('keydown', T.kd);
    const cv = $('mv-canvas');
    cv.removeEventListener('mousemove', T.mm);
    cv.removeEventListener('click', T.mc);
    T = null;
  }
  function menu() {
    MV.Game.stop();
    stopTitle();
    $('mv-back').hidden = true;
    $('mv-menu').hidden = true;
    const cv = $('mv-canvas'),
      sz = MV.Game.size(),
      x = cv.getContext('2d'),
      U = MV.UI.clean(world.ui);
    cv.width = sz.w;
    cv.height = sz.h;
    const items = [];
    if (hasSave()) items.push({ id: 'continue', label: U.titleContinue });
    items.push({ id: 'new', label: U.titleStart });
    if (U.optionsOn === 'yes') items.push({ id: 'options', label: U.optionsLabel });
    items.push({ id: 'full', label: U.titleFull });
    if (/Electron/.test(navigator.userAgent)) items.push({ id: 'quit', label: U.titleQuit });
    const t = (T = { sel: 0, hits: [], raf: 0, items, pad: {}, page: 'main' });
    const rows = () =>
        t.page === 'controls' ? MV.UI.ctlRows(U, nowKeys(), t.wait) : MV.UI.optRows(U, curVol, true, true),
      list = () => (t.page === 'options' || t.page === 'controls' ? rows() : items);
    const setVol = (id, v) => saveVol(Object.assign({}, curVol, { [id]: v }));
    const fullToggle = () => {
      if (document.fullscreenElement) document.exitFullscreen();
      else document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
    };
    const pick = id => {
      if (t.page === 'controls') {
        if (id === 'back') {
          t.page = 'options';
          t.sel = MV.UI.optRows(U, curVol, true, true).findIndex(q => q.id === 'controls');
        } else if (id === 'reset') saveKeys(null);
        else if (/^k:/.test(id)) t.wait = id.slice(2);
        return;
      }
      if (t.page === 'options') {
        if (id === 'controls') {
          t.page = 'controls';
          t.sel = 0;
        } else if (id === 'back') {
          t.page = 'main';
          t.sel = items.findIndex(q => q.id === 'options');
        } else if (id === 'full') fullToggle();
        return;
      }
      if (id === 'options') {
        t.page = 'options';
        t.sel = 0;
      } else if (id === 'continue') {
        stopTitle();
        play(false);
      } else if (id === 'new') {
        if (hasSave() && !confirm('Start over? Your saved game will be erased.')) return;
        stopTitle();
        play(true);
      } else if (id === 'full') fullToggle();
      else if (id === 'quit') window.close();
    };
    const move = d => (t.sel = (t.sel + d + list().length) % list().length);
    t.kd = e => {
      const row = list()[t.sel];
      if (t.wait) {
        // waiting for the new key of an action
        const w = t.wait;
        t.wait = null;
        if (e.code !== 'Escape') saveKeys(MV.UI.setKey(nowKeys(), w, e.code));
      } else if (/^(ArrowUp|KeyW)$/.test(e.code)) move(-1);
      else if (/^(ArrowDown|KeyS)$/.test(e.code)) move(1);
      else if (
        /^(ArrowLeft|KeyA|ArrowRight|KeyD)$/.test(e.code) &&
        t.page === 'options' &&
        row &&
        row.kind === 'slider'
      )
        setVol(row.id, MV.UI.stepVal(row.value, /Left|KeyA/.test(e.code) ? -1 : 1));
      else if (e.code === 'Escape' && (t.page === 'options' || t.page === 'controls')) pick('back');
      else if (/^(Enter|Space|NumpadEnter)$/.test(e.code)) pick(row.id);
      else return;
      e.preventDefault();
    };
    t.mm = e => {
      const p = MV.UI.point(cv, e),
        id = MV.UI.hitAt(t.hits, p.x, p.y),
        i = list().findIndex(q => q.id === id);
      if (i >= 0) t.sel = i;
      if (e.buttons & 1 && t.page === 'options') {
        const v = MV.UI.sliderAt(
          t.hits.find(q => q.id === id),
          p.x
        );
        if (v !== null) setVol(id, v);
      }
    };
    t.mc = e => {
      const p = MV.UI.point(cv, e),
        id = MV.UI.hitAt(t.hits, p.x, p.y);
      if (!id) return;
      if (t.page === 'options') {
        const v = MV.UI.sliderAt(
          t.hits.find(q => q.id === id),
          p.x
        );
        if (v !== null) {
          setVol(id, v);
          return;
        }
      }
      pick(id);
    };
    addEventListener('keydown', t.kd);
    cv.addEventListener('mousemove', t.mm);
    cv.addEventListener('click', t.mc);
    const frame = () => {
      if (T !== t) return;
      const gp = navigator.getGamepads && [...navigator.getGamepads()].find(g => g && g.connected);
      if (gp) {
        const now = {
          u: (gp.buttons[12] && gp.buttons[12].pressed) || gp.axes[1] < -0.6,
          d: (gp.buttons[13] && gp.buttons[13].pressed) || gp.axes[1] > 0.6,
          a: gp.buttons[0] && gp.buttons[0].pressed
        };
        if (now.u && !t.pad.u) move(-1);
        if (now.d && !t.pad.d) move(1);
        if (now.a && !t.pad.a) pick(list()[t.sel].id);
        t.pad = now;
      }
      const tm = performance.now() / 1000;
      t.hits =
        t.page === 'options' || t.page === 'controls'
          ? MV.UI.options(
              x,
              cv.width,
              cv.height,
              U,
              { kind: 'title', title: t.page === 'controls' ? U.optControls : '', rows: rows(), sel: t.sel },
              sheetOf,
              tm
            )
          : MV.UI.menu(
              x,
              cv.width,
              cv.height,
              U,
              { kind: 'title', title: U.titleText || name, subtitle: U.subtitle, items, sel: t.sel },
              sheetOf,
              tm
            );
      t.raf = requestAnimationFrame(frame);
    };
    frame();
    cv.focus();
  }
  window.__mvPlayer = {
    title: () => (T ? { sel: T.sel, page: T.page, items: T.items.map(i => i.id) } : null),
    vol: () => curVol,
    keys: () => nowKeys()
  };
  $('mv-back').onclick = menu;
  menu();
})();
