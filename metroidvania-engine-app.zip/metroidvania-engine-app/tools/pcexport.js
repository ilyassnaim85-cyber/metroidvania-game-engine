// Export a PC game: a folder with its own program file (MyGame.exe on Windows, MyGame.app on Mac, MyGame on Linux).
// It copies the Electron runtime the engine itself runs on, takes the engine's own app out of it and puts the game in.
// packagePc() is the whole job and is tested with a made-up Electron folder (tests/unit.js); main.js calls it from File > Export game.
const fs = require('fs'),
  path = require('path');

const safeName = n =>
  String(n || '')
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[. ]+$/, '')
    .slice(0, 40) || 'My game';
const slug = n =>
  String(n || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 30) || 'game';

// where the runtime's parts are, for the platform it runs on
function layout(execPath, platform) {
  if (platform === 'darwin') {
    const m = /^(.*?[\\/][^\\/]+\.app)[\\/]Contents[\\/]MacOS[\\/][^\\/]+$/.exec(execPath);
    if (!m) throw new Error('Could not find the application bundle.');
    return { root: m[1], res: path.join('Contents', 'Resources'), bundle: true };
  }
  return { root: path.dirname(execPath), res: 'resources', exe: path.basename(execPath), bundle: false };
}

// things from the engine's own install that a game must not carry
const leftovers = rel => {
  const r = rel.split(path.sep).join('/');
  return (
    /^resources\/(app\.asar|app|default_app\.asar|app-update\.yml|app\.asar\.unpacked)(\/|$)/.test(r) ||
    /^Contents\/Resources\/(app\.asar|app|default_app\.asar|app-update\.yml|app\.asar\.unpacked)(\/|$)/.test(r) ||
    /^Uninstall[^/]*$/i.test(r)
  );
};

function gameFiles(root, o) {
  const pkg = {
    name: slug(o.name),
    productName: safeName(o.name),
    version: o.version || '1.0.0',
    description: safeName(o.name),
    main: 'main.js',
    private: true
  };
  return {
    'package.json': JSON.stringify(pkg, null, 2) + '\n',
    'main.js': fs.readFileSync(path.join(root, 'export', 'game-main.js'), 'utf8'),
    'game.html': o.html
  };
}

// o: { root (the engine folder), execPath, platform, outParent, name, html, version?, fsx? }
async function packagePc(o) {
  const fsx = o.fsx || fs.promises,
    name = safeName(o.name),
    L = layout(o.execPath, o.platform);
  let dest = path.join(o.outParent, L.bundle ? name + '.app' : name),
    n = 1;
  while (fs.existsSync(dest)) dest = path.join(o.outParent, L.bundle ? name + ' (' + ++n + ').app' : name + ' (' + ++n + ')');
  await fsx.cp(L.root, dest, {
    recursive: true,
    filter: src => {
      const rel = path.relative(L.root, src);
      return !rel || !leftovers(rel);
    }
  });
  const files = gameFiles(o.root, o),
    app = path.join(dest, L.res, 'app');
  await fsx.mkdir(app, { recursive: true });
  for (const f in files) await fsx.writeFile(path.join(app, f), files[f]);
  let exe;
  if (L.bundle) {
    // the bundle keeps its inner program name; its visible name is the game's
    const plist = path.join(dest, 'Contents', 'Info.plist');
    if (fs.existsSync(plist)) {
      let t = fs.readFileSync(plist, 'utf8');
      const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
      ['CFBundleName', 'CFBundleDisplayName'].forEach(k => {
        t = t.replace(new RegExp('(<key>' + k + '</key>\\s*<string>)[^<]*(</string>)'), '$1' + esc(name) + '$2');
      });
      fs.writeFileSync(plist, t);
    }
    exe = dest;
  } else {
    const ext = path.extname(L.exe);
    exe = path.join(dest, name + ext);
    await fsx.rename(path.join(dest, L.exe), exe);
  }
  return { dir: dest, exe, name };
}
module.exports = { packagePc, layout, safeName, slug, leftovers };
