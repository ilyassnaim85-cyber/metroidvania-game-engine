// Export a finished game: one self-contained HTML file (engine, project and player, no other files, no network).
// Used by main.js (File > Export game) and by the tests. buildGame(root, projectText, opts) returns the HTML text.
const fs = require('fs'),
  path = require('path');

// the engine scripts, in the order index.html loads them (the editor's own files are left out)
function engineScripts(root) {
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8'),
    out = [],
    re = /<script src="((?:data|engine)\/[\w./-]+\.js)"><\/script>/g;
  let m;
  while ((m = re.exec(html))) out.push(m[1]);
  return out;
}
const safeScript = t =>
  String(t)
    .replace(/<\/(script)/gi, '<\\/$1')
    .replace(/<!--/g, '<\\!--');
const esc = v => String(v).replace(/[&<>"'`]/g, c => '&#' + c.charCodeAt(0) + ';');
const CSP =
  "default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval'; style-src 'unsafe-inline'; img-src data: blob:; media-src data: blob:; font-src data:";

function buildGame(root, projectText, opts) {
  opts = opts || {};
  let project;
  try {
    project = JSON.parse(projectText);
  } catch (e) {
    throw new Error('The project could not be read.');
  }
  if (!project || typeof project !== 'object' || !Array.isArray(project.areas))
    throw new Error('That is not a project.');
  const name = (typeof project.name === 'string' && project.name.trim()) || opts.name || 'My game';
  const files = engineScripts(root);
  if (!files.length) throw new Error('The engine files were not found.');
  const parts = [];
  parts.push('<!doctype html><html lang="en"><head><meta charset="utf-8">');
  parts.push('<meta http-equiv="Content-Security-Policy" content="' + esc(CSP) + '">');
  parts.push('<meta name="viewport" content="width=device-width,initial-scale=1">');
  parts.push(
    '<title>' +
      esc(name) +
      '</title><style>' +
      fs.readFileSync(path.join(root, 'export', 'player.css'), 'utf8') +
      '</style></head><body>'
  );
  parts.push(
    '<div id="mv-app"><canvas id="mv-canvas"></canvas><div id="mv-menu"></div><button id="mv-back" hidden>Menu</button><pre id="mv-err" hidden></pre></div>'
  );
  // the project: JSON, never run as code. "<" is written as < so nothing in it can close the tag.
  parts.push('<script type="application/json" id="mv-project">' + projectText.replace(/</g, '\\u003c') + '</script>');
  files.forEach(f =>
    parts.push('<script>/* ' + f + ' */\n' + safeScript(fs.readFileSync(path.join(root, f), 'utf8')) + '\n</script>')
  );
  parts.push(
    '<script>/* player */\n' +
      safeScript(fs.readFileSync(path.join(root, 'export', 'player.js'), 'utf8')) +
      '\n</script>'
  );
  parts.push('</body></html>');
  return parts.join('\n');
}
module.exports = { buildGame, engineScripts };
