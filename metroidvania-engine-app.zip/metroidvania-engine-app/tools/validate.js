#!/usr/bin/env node
// Check a saved project file (the .json the editor saves) without opening the editor:
//   node tools/validate.js path/to/project.json          (prints a report, exit code 1 if there are errors)
//   node tools/validate.js path/to/project.json --json   (the report as JSON, for other tools)
// It runs the same checks as the editor: rooms and transitions (World), events, sounds, and that every part of the file has the shape the engine expects.
const fs = require('fs'),
  path = require('path'),
  vm = require('vm');
const root = path.join(__dirname, '..');
function engine() {
  const sb = {
    console,
    setTimeout,
    clearTimeout,
    performance: { now: () => Date.now() },
    Math,
    JSON,
    Date,
    btoa: s => Buffer.from(s, 'binary').toString('base64'),
    atob: s => Buffer.from(s, 'base64').toString('binary')
  };
  sb.window = sb;
  vm.createContext(sb);
  [
    'data/config.js',
    'engine/progress.js',
    'engine/camera.js',
    'engine/camera_rig.js',
    'engine/camera_vcam.js',
    'engine/script.js',
    'engine/events.js',
    'engine/audio.js',
    'engine/tuning.js',
    'engine/boss.js',
    'engine/status.js',
    'engine/enemies.js',
    'engine/animation.js',
    'engine/light.js',
    'engine/tiles.js',
    'engine/inventory.js',
    'engine/attacks.js',
    'engine/controls.js',
    'engine/moves.js',
    'engine/sprite.js',
    'engine/background.js',
    'engine/dialog.js',
    'engine/ui.js',
    'engine/world.js'
  ].forEach(f => vm.runInContext(fs.readFileSync(path.join(root, f), 'utf8'), sb, { filename: f }));
  return sb.MV;
}
// grids may be stored packed (rows repeated, runs of one tile as `c12;)
const unpackRow = p => {
  if (p.indexOf('`') < 0) return p;
  let o = '',
    i = 0;
  while (i < p.length) {
    const ch = p[i];
    if (ch === '`') {
      const e = p.indexOf(';', i);
      o += p[i + 1].repeat(+p.slice(i + 2, e));
      i = e + 1;
    } else {
      o += ch;
      i++;
    }
  }
  return o;
};
const unpackGrid = v => {
  const g = [];
  v.d.forEach(q => {
    const r = unpackRow(q[0]);
    for (let i = 0; i < q[1]; i++) g.push(r);
  });
  return g;
};
const read = text =>
  JSON.parse(text, (k, v) =>
    k === 'grid' && v && !Array.isArray(v) && v.z === 1 && Array.isArray(v.d) ? unpackGrid(v) : v
  );

function check(MV, proj) {
  const out = [],
    add = (level, where, text) => out.push({ level, where, text });
  if (!proj || typeof proj !== 'object' || !Array.isArray(proj.areas)) {
    add('error', 'file', 'This is not a Metroidvania Engine project (no "areas" list).');
    return out;
  }
  const w = Object.assign({}, proj, {
    events: MV.Events.clean(proj.events),
    scripts: MV.Script.clean(proj.scripts),
    vcams: MV.CameraVcams.clean(proj.vcams),
    sounds: MV.Audio.cleanList(proj.sounds),
    sfx: MV.Audio.cleanSfx(proj.sfx),
    moves: MV.Moves.resolve(proj.moves),
    attacks: MV.Attacks.resolve(proj.attacks, proj.player),
    items: MV.Inventory.resolve(proj.items),
    enemies: MV.Enemies.resolve(proj.enemies),
    bosses: MV.Boss.list(proj.bosses),
    camProfiles: MV.Camera.cleanProfiles(proj.camProfiles),
    ui: MV.UI.clean(proj.ui),
    fonts: MV.UI.cleanFonts(proj.fonts),
    tileSkins: MV.Tiles.cleanSkins(proj.tileSkins),
    stamps: MV.Tiles.cleanStamps(proj.stamps)
  });
  // things that were dropped when the file was cleaned (a sign it was damaged or written by something else)
  const lost = (name, a, b) => {
    if (Array.isArray(a) && a.length > b.length)
      add(
        'warn',
        name,
        a.length -
          b.length +
          ' of ' +
          a.length +
          ' ' +
          name +
          ' were not valid and would be dropped when the project opens.'
      );
  };
  lost('events', proj.events, w.events);
  lost('scripts', proj.scripts, w.scripts);
  lost('vcams', proj.vcams, w.vcams);
  lost('sounds', proj.sounds, w.sounds);
  lost('items', proj.items, w.items);
  const ids = new Set();
  (proj.areas || []).forEach(a =>
    (a.rooms || []).forEach(r => {
      const k = a.id + '/' + r.id;
      if (ids.has(k)) add('error', k, 'Two rooms have the same id.');
      ids.add(k);
      if (
        !Array.isArray(r.grid) ||
        !r.grid.length ||
        r.grid.some(row => typeof row !== 'string' || row.length !== r.grid[0].length)
      )
        add('error', a.n + ' / ' + r.n, 'The room grid is missing or its rows are not all the same length.');
    })
  );
  MV.World.validate(w).forEach(i =>
    add(i.sev === 'info' ? 'info' : i.sev, (i.area ? i.area + ' / ' : '') + (i.name || ''), i.msg)
  );
  MV.Events.validate(w).forEach(i => add(i.level, 'event ' + i.ev, i.text));
  MV.Audio.validate(w).forEach(i => add(i.level, 'audio', i.text));
  MV.Script.validate(w).forEach(i => add(i.level, 'script', i.text));
  MV.CameraVcams.validate(w).forEach(i => add(i.level, 'camera', i.text));
  return out;
}
if (require.main === module) {
  const file = process.argv[2],
    asJson = process.argv.includes('--json');
  if (!file) {
    console.error('Usage: node tools/validate.js project.json [--json]');
    process.exit(2);
  }
  let rep;
  try {
    rep = check(engine(), read(fs.readFileSync(file, 'utf8')));
  } catch (e) {
    rep = [{ level: 'error', where: 'file', text: 'Could not read the project: ' + e.message }];
  }
  const n = l => rep.filter(x => x.level === l).length;
  if (asJson) console.log(JSON.stringify({ errors: n('error'), warnings: n('warn'), issues: rep }, null, 2));
  else {
    rep.forEach(x =>
      console.log(
        (x.level === 'error' ? 'ERROR ' : x.level === 'warn' ? 'warn  ' : 'info  ') + '[' + x.where + '] ' + x.text
      )
    );
    console.log('\n' + n('error') + ' error(s), ' + n('warn') + ' warning(s).');
  }
  process.exit(n('error') ? 1 : 0);
}
module.exports = { engine, read, check };
