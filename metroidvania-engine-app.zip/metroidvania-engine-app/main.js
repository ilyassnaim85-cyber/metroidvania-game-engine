const { app, BrowserWindow, Menu, dialog, ipcMain, nativeTheme, session, shell } = require('electron');
const fs = require('fs');
const path = require('path');
let win;
nativeTheme.themeSource = 'dark'; // dark menus, dialogs and scrollbars
// keep projects saved under the earlier app name
app.setPath('userData', path.join(app.getPath('appData'), 'Sea Map Editor'));
const filters = [{ name: 'JSON', extensions: ['json'] }];
const run = code => win.webContents.executeJavaScript(code);

// The page is not trusted with the file system. It can only write to a file the person picked in a Save or Open dialog (shown by this
// process), never to a path the page names itself. Picked paths are remembered so Save keeps writing to the same file next time.
const MAX_BYTES = 300 * 1024 * 1024;
let allowed = new Set();
const allowFile = () => path.join(app.getPath('userData'), 'approved-files.json');
const loadAllowed = () => {
  try {
    allowed = new Set(JSON.parse(fs.readFileSync(allowFile(), 'utf8')).filter(x => typeof x === 'string'));
  } catch (err) {
    allowed = new Set();
  }
};
const approve = p => {
  allowed.add(p);
  try {
    fs.writeFileSync(allowFile(), JSON.stringify([...allowed].slice(-200)));
  } catch (err) {
    /* remembering is a convenience: the next Save just asks again */
  }
};
const withJson = p => (/\.json$/i.test(p) ? p : p + '.json');
// only the app's own page may call these
const trusted = e => {
  try {
    return !!win && e.sender === win.webContents && new URL(e.senderFrame.url).protocol === 'file:';
  } catch (err) {
    return false;
  }
};
const okText = t => typeof t === 'string' && t.length <= MAX_BYTES;

function create() {
  win = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 900,
    minHeight: 600,
    title: 'Metroidvania Engine',
    backgroundColor: '#1f1e1d',
    webPreferences: {
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      webSecurity: true,
      allowRunningInsecureContent: false,
      preload: path.join(__dirname, 'preload.js')
    }
  });
  // the page never navigates away and never opens other windows
  win.webContents.on('will-navigate', e => e.preventDefault());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.loadFile('index.html');
}

// Save writes to the project's own file; the first save (or Save as) asks where.
ipcMain.handle('mv-save', async (e, json, asNew, filePath, defName) => {
  try {
    if (!trusted(e) || !okText(json)) return { ok: false, error: 'Not allowed.' };
    let target = typeof filePath === 'string' && allowed.has(filePath) ? filePath : '';
    if (!target || asNew) {
      const r = await dialog.showSaveDialog(win, {
        defaultPath: target || (typeof defName === 'string' && defName.slice(0, 80)) || 'project.json',
        filters
      });
      if (r.canceled) return { ok: false };
      target = withJson(r.filePath);
      approve(target);
    }
    fs.writeFileSync(target, json);
    return { ok: true, path: target, name: path.basename(target) };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// Save an animation clip or library (or any JSON) to a file the user picks.
ipcMain.handle('mv-export', async (e, json, defName) => {
  try {
    if (!trusted(e) || !okText(json)) return { ok: false, error: 'Not allowed.' };
    const r = await dialog.showSaveDialog(win, {
      defaultPath: (typeof defName === 'string' && defName.slice(0, 80)) || 'animation.json',
      filters
    });
    if (r.canceled) return { ok: false };
    const target = withJson(r.filePath);
    fs.writeFileSync(target, json);
    return { ok: true, path: target, name: path.basename(target) };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// Export the game: one HTML file with the engine, the project and a player (see tools/export.js).
ipcMain.handle('mv-export-game', async (e, json, defName) => {
  try {
    if (!trusted(e) || !okText(json)) return { ok: false, error: 'Not allowed.' };
    const html = require('./tools/export.js').buildGame(__dirname, json);
    const r = await dialog.showSaveDialog(win, {
      defaultPath: (typeof defName === 'string' && defName.replace(/[^\w.-]+/g, '_').slice(0, 80)) || 'game.html',
      filters: [{ name: 'Game (HTML)', extensions: ['html'] }]
    });
    if (r.canceled) return { ok: false };
    const target = /\.html?$/i.test(r.filePath) ? r.filePath : r.filePath + '.html';
    fs.writeFileSync(target, html);
    return { ok: true, path: target, name: path.basename(target), bytes: Buffer.byteLength(html) };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// Export a PC game: a folder with its own program (MyGame.exe, MyGame.app or MyGame). See tools/pcexport.js.
// It copies the Electron this app runs on, so a build only runs on the system it was made on.
ipcMain.handle('mv-export-pc', async (e, json, gameName) => {
  try {
    if (!trusted(e) || !okText(json)) return { ok: false, error: 'Not allowed.' };
    if (!process.versions.electron)
      return { ok: false, error: 'Exporting a PC game needs the desktop app.' };
    const x = require('./tools/export.js'),
      pc = require('./tools/pcexport.js');
    const name = pc.safeName(gameName);
    const html = x.buildGame(__dirname, json);
    const r = await dialog.showOpenDialog(win, {
      title: 'Choose where to put the game folder',
      buttonLabel: 'Export here',
      properties: ['openDirectory', 'createDirectory']
    });
    if (r.canceled || !r.filePaths[0]) return { ok: false };
    const out = await pc.packagePc({
      root: __dirname,
      execPath: process.execPath,
      platform: process.platform,
      outParent: r.filePaths[0],
      name,
      html,
      version: app.getVersion()
    });
    shell.showItemInFolder(out.exe);
    return { ok: true, path: out.dir, name: require('path').basename(out.exe) };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// Open a project file from disk; the page turns it into a project.
ipcMain.handle('mv-open', async e => {
  try {
    if (!trusted(e)) return { ok: false, error: 'Not allowed.' };
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters });
    if (r.canceled) return { ok: false };
    const p = r.filePaths[0];
    if (fs.statSync(p).size > MAX_BYTES) return { ok: false, error: 'That file is too big.' };
    approve(p);
    return { ok: true, path: p, name: path.basename(p), text: fs.readFileSync(p, 'utf8') };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

app.whenReady().then(() => {
  loadAllowed();
  session.defaultSession.setPermissionRequestHandler((wc, permission, cb) => cb(false)); // no camera, microphone, location or notifications
  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      ...(process.platform === 'darwin' ? [{ role: 'appMenu' }] : []),
      {
        label: 'File',
        submenu: [
          { label: 'New project...', accelerator: 'CmdOrCtrl+N', click: () => run('mvNew()') },
          { label: 'Open project file...', accelerator: 'CmdOrCtrl+O', click: () => run('mvOpenFile()') },
          { type: 'separator' },
          { label: 'Save', accelerator: 'CmdOrCtrl+S', click: () => run('mvSave(false)') },
          { label: 'Save as...', accelerator: 'CmdOrCtrl+Shift+S', click: () => run('mvSave(true)') },
          { label: 'Export game for PC...', accelerator: 'CmdOrCtrl+E', click: () => run('mvExportPc()') },
          { label: 'Export game as web page (.html)...', click: () => run('mvExportGame()') },
          { label: 'Close project', click: () => run('mvClose()') },
          { type: 'separator' },
          { role: 'quit' }
        ]
      },
      {
        label: 'Edit',
        submenu: [
          { label: 'Undo', accelerator: 'CmdOrCtrl+Z', click: () => run('mvUndo()') },
          { label: 'Redo', accelerator: 'CmdOrCtrl+Y', click: () => run('mvRedo()') },
          { type: 'separator' },
          { role: 'cut' },
          { role: 'copy' },
          { role: 'paste' },
          { role: 'selectAll' }
        ]
      },
      { role: 'viewMenu' }
    ])
  );
  create();
});
app.on('window-all-closed', () => app.quit());
