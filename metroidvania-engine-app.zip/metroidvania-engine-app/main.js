const { app, BrowserWindow, Menu, dialog, ipcMain, nativeTheme } = require('electron');
const fs = require('fs');
const path = require('path');
let win;
nativeTheme.themeSource = 'dark'; // dark menus, dialogs and scrollbars
// keep projects saved under the earlier app name
app.setPath('userData', path.join(app.getPath('appData'), 'Sea Map Editor'));
const filters = [{ name: 'JSON', extensions: ['json'] }];
const run = code => win.webContents.executeJavaScript(code);

function create() {
  win = new BrowserWindow({
    width: 1280,
    height: 860,
    minWidth: 900,
    minHeight: 600,
    title: 'Metroidvania Engine',
    backgroundColor: '#1f1e1d',
    webPreferences: { contextIsolation: true, preload: path.join(__dirname, 'preload.js') }
  });
  win.loadFile('index.html');
}

// Save writes to the project's own file; the first save (or Save as) asks where.
ipcMain.handle('mv-save', async (e, json, asNew, filePath, defName) => {
  try {
    let target = filePath;
    if (!target || asNew) {
      const r = await dialog.showSaveDialog(win, { defaultPath: target || defName || 'project.json', filters });
      if (r.canceled) return { ok: false };
      target = r.filePath;
    }
    fs.writeFileSync(target, json);
    return { ok: true, path: target, name: path.basename(target) };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// Save an animation clip or library (or any JSON) to a file the user picks.
ipcMain.handle('mv-export', async (e, json, defName) => {
  try {
    const r = await dialog.showSaveDialog(win, { defaultPath: defName || 'animation.json', filters });
    if (r.canceled) return { ok: false };
    fs.writeFileSync(r.filePath, json);
    return { ok: true, path: r.filePath, name: path.basename(r.filePath) };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// Open a project file from disk; the page turns it into a project.
ipcMain.handle('mv-open', async () => {
  try {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters });
    if (r.canceled) return { ok: false };
    const p = r.filePaths[0];
    return { ok: true, path: p, name: path.basename(p), text: fs.readFileSync(p, 'utf8') };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

app.whenReady().then(() => {
  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      ...(process.platform === 'darwin' ? [{ role: 'appMenu' }] : []),
      {
        label: 'File',
        submenu: [
          { label: 'New project...', accelerator: 'CmdOrCtrl+N', click: () => run('mvNew()') },
          { label: 'Open project file...', accelerator: 'CmdOrCtrl+O', click: () => run('mvOpenFile()') },
          { type: 'separator' },
          { label: 'Save', accelerator: 'CmdOrCtrl+S', click: () => run('mvSave(false)') },
          { label: 'Save as...', accelerator: 'CmdOrCtrl+Shift+S', click: () => run('mvSave(true)') },
          { label: 'Close project', click: () => run('mvClose()') },
          { type: 'separator' },
          { role: 'quit' }
        ]
      },
      {
        label: 'Edit',
        submenu: [
          { label: 'Undo', accelerator: 'CmdOrCtrl+Z', click: () => run('mvUndo()') },
          { label: 'Redo', accelerator: 'CmdOrCtrl+Y', click: () => run('mvRedo()') },
          { type: 'separator' },
          { role: 'cut' },
          { role: 'copy' },
          { role: 'paste' },
          { role: 'selectAll' }
        ]
      },
      { role: 'viewMenu' }
    ])
  );
  create();
});
app.on('window-all-closed', () => app.quit());
