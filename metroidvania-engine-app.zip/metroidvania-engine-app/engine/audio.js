// MV.Audio - sounds and music. The project holds a sound library (world.sounds), the sounds the player makes by itself (world.sfx: jump, land, step...),
// the volumes (world.vol) and a music id per room (room.music). Moves and attacks play sounds through an effect ("Do: Play a sound"), and Events have Play a sound / Change the music steps.
// Sounds are stored inside the project as small audio files (data URLs), so a saved map carries its own sound. Sounds are imported files only (there is no sound maker).
// Every play is written to MV.Audio.log (the test room shows it), so you can see a sound fire even with the speakers off.
window.MV = window.MV || {};
MV.Audio = (() => {
  // the sounds the player makes without any move: [slot, label]. The game calls play by slot name.
  const SLOTS = [
    ['jump', 'Jump'],
    ['land', 'Landing'],
    ['step', 'Footstep (one per step)'],
    ['hurt', 'Player is hurt'],
    ['die', 'Player dies'],
    ['pickup', 'Pickup collected'],
    ['checkpoint', 'Checkpoint touched'],
    ['chest', 'Chest opens'],
    ['splash', 'Enter water'],
    ['talk', 'Conversation line shown'],
    ['door', 'Go through a transition'],
    ['switch', 'Switch pressed']
  ];
  const MAX = 200,
    MAXBYTES = 3000000,
    TOTAL = 24000000;
  const nn = (v, a, b, d) => {
    v = +v;
    return isFinite(v) ? Math.max(a, Math.min(b, v)) : d;
  };
  const idOk = s => typeof s === 'string' && /^[\w-]{1,24}$/.test(s);
  const cleanList = l => {
    const seen = new Set(),
      out = [];
    let total = 0;
    (Array.isArray(l) ? l : []).slice(0, MAX).forEach((s, i) => {
      if (!s || typeof s !== 'object') return;
      const src =
        typeof s.src === 'string' &&
        /^data:audio\/[\w.+-]+;base64,[A-Za-z0-9+/=]+$/.test(s.src) &&
        s.src.length <= MAXBYTES * 1.4
          ? s.src
          : '';
      total += src.length;
      if (total > TOTAL) return;
      let id = idOk(s.id) ? s.id : 'snd' + (i + 1);
      while (seen.has(id)) id += 'x';
      seen.add(id);
      out.push({
        id,
        name: typeof s.name === 'string' && s.name.trim() ? s.name.slice(0, 40) : id,
        src,
        vol: nn(s.vol, 0, 1, 1),
        rate: nn(s.rate, 0.25, 4, 1),
        vary: nn(s.vary, 0, 0.5, 0),
        loop: s.loop === true,
        music: s.music === true
      });
    });
    return out;
  };
  const cleanSfx = m => {
    const out = {};
    if (m && typeof m === 'object')
      SLOTS.forEach(([k]) => {
        if (idOk(m[k])) out[k] = m[k];
      });
    return out;
  };
  const cleanVol = v => ({
    master: nn(v && v.master, 0, 1, 1),
    music: nn(v && v.music, 0, 1, 0.7),
    sfx: nn(v && v.sfx, 0, 1, 1)
  });

  // ---- playing ----
  let ctx = null,
    gm = null,
    gmu = null,
    gsf = null,
    world = { sounds: [], sfx: {}, vol: cleanVol() },
    muted = false,
    mus = null,
    musId = '',
    t0 = Date.now(),
    lastStep = 0;
  const buffers = new Map(),
    pending = new Map(),
    log = [];
  const find = id => world.sounds.find(s => s.id === id);
  function ensure() {
    if (ctx) return ctx;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    try {
      ctx = new AC();
    } catch (e) {
      return null;
    }
    gm = ctx.createGain();
    gmu = ctx.createGain();
    gsf = ctx.createGain();
    gmu.connect(gm);
    gsf.connect(gm);
    gm.connect(ctx.destination);
    vols();
    return ctx;
  }
  function vols() {
    if (!ctx) return;
    const v = world.vol;
    gm.gain.value = muted ? 0 : v.master;
    gmu.gain.value = v.music;
    gsf.gain.value = v.sfx;
  }
  function buffer(s, cb) {
    if (buffers.has(s.id + s.src.length)) return cb(buffers.get(s.id + s.src.length));
    const c = ensure();
    if (!c || !s.src) return;
    const k = s.id + s.src.length;
    if (pending.has(k)) {
      pending.get(k).push(cb);
      return;
    }
    pending.set(k, [cb]);
    try {
      const b = atob(s.src.split(',')[1]),
        u = new Uint8Array(b.length);
      for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i);
      c.decodeAudioData(
        u.buffer,
        buf => {
          buffers.set(k, buf);
          (pending.get(k) || []).forEach(f => f(buf));
          pending.delete(k);
        },
        () => pending.delete(k)
      );
    } catch (e) {
      pending.delete(k);
    }
  }
  function setup(w) {
    world = { sounds: cleanList(w && w.sounds), sfx: cleanSfx(w && w.sfx), vol: cleanVol(w && w.vol) };
    log.length = 0;
    t0 = Date.now();
    stopMusic(true);
    vols();
  }
  // the editor changed the project: take the new sounds without clearing the log or stopping what plays
  function sync(w) {
    world = { sounds: cleanList(w && w.sounds), sfx: cleanSfx(w && w.sfx), vol: cleanVol(w && w.vol) };
    vols();
  }
  // play a sound by id. o: { vol, rate, quiet } - quiet means do not write it to the log
  function play(id, o) {
    o = o || {};
    const s = find(id);
    if (!s) {
      if (id) note(id, 'missing');
      return false;
    }
    note(id, 'played');
    if (muted || !s.src) return true;
    const c = ensure();
    if (!c) return true;
    if (c.state === 'suspended') c.resume();
    buffer(s, buf => {
      const src = c.createBufferSource(),
        g = c.createGain();
      src.buffer = buf;
      src.playbackRate.value = s.rate * (o.rate || 1) * (1 + (Math.random() - 0.5) * 2 * s.vary);
      g.gain.value = s.vol * (o.vol === undefined ? 1 : o.vol);
      src.connect(g);
      g.connect(gsf);
      src.start();
    });
    return true;
  }
  const note = (id, what) => {
    log.push({ t: +((Date.now() - t0) / 1000).toFixed(2), id, what });
    if (log.length > 60) log.shift();
  };
  function slot(name, o) {
    const id = world.sfx[name];
    return id ? play(id, o) : false;
  }
  function music(id) {
    id = id || '';
    if (id === musId) return;
    musId = id;
    note(id || '(none)', 'music');
    const c = ensure();
    if (mus) {
      const m = mus;
      mus = null;
      try {
        m.g.gain.setTargetAtTime(0, c.currentTime, 0.25);
        setTimeout(() => {
          try {
            m.src.stop();
          } catch (e) {}
        }, 1200);
      } catch (e) {}
    }
    const s = id && find(id);
    if (!s || !s.src || muted || !c) return;
    if (c.state === 'suspended') c.resume();
    buffer(s, buf => {
      if (musId !== id) return;
      const src = c.createBufferSource(),
        g = c.createGain();
      src.buffer = buf;
      src.loop = true;
      src.playbackRate.value = s.rate;
      g.gain.value = 0;
      src.connect(g);
      g.connect(gmu);
      src.start();
      g.gain.setTargetAtTime(s.vol, c.currentTime, 0.4);
      mus = { src, g };
    });
  }
  function stopMusic(quiet) {
    musId = '';
    if (mus) {
      try {
        mus.src.stop();
      } catch (e) {}
      mus = null;
    }
    if (!quiet) note('(none)', 'music');
  }
  const unlock = () => {
    const c = ensure();
    if (c && c.state === 'suspended') c.resume();
  };
  const mute = f => {
    muted = !!f;
    vols();
    if (muted) stopMusic(true);
  };
  const setVol = v => {
    world.vol = cleanVol(v);
    vols();
  };
  // the footstep rhythm: the game calls this every frame while running on the ground
  function step(dt, moving, speedFrac) {
    if (!moving) {
      lastStep = 0;
      return;
    }
    lastStep += dt;
    const gap = 0.42 - 0.17 * Math.min(1, speedFrac);
    if (lastStep >= gap) {
      lastStep = 0;
      slot('step');
    }
  }
  // what points at a sound that is not in the library (or a sound that has no audio): [{level, text}]
  function validate(w) {
    const out = [],
      ids = new Set(((w && w.sounds) || []).map(s => s.id)),
      add = (level, text) => out.push({ level, text });
    ((w && w.sounds) || []).forEach(s => {
      if (!s.src) add('error', 'The sound "' + s.name + '" has no audio file (import it again or remove it).');
    });
    Object.keys((w && w.sfx) || {}).forEach(k => {
      if (!ids.has(w.sfx[k]))
        add('error', 'Player sound "' + k + '" uses the sound "' + w.sfx[k] + '", which does not exist.');
    });
    ((w && w.areas) || []).forEach(a =>
      (a.rooms || []).forEach(r => {
        if (r.music && !ids.has(r.music))
          add('error', 'The room "' + (r.n || r.id) + '" plays the music "' + r.music + '", which does not exist.');
        else if (r.music && !((w.sounds || []).find(s => s.id === r.music) || {}).music)
          add(
            'warn',
            'The room "' +
              (r.n || r.id) +
              '" plays "' +
              r.music +
              '" as music but it is not marked as music (it will still loop).'
          );
      })
    );
    ((w && w.events) || []).forEach(ev =>
      (ev.actions || []).forEach((a, i) => {
        if ((a.type === 'sound' || a.type === 'music') && a.sound && !ids.has(a.sound))
          add('error', 'Event "' + ev.name + '", step ' + (i + 1) + ': the sound "' + a.sound + '" does not exist.');
      })
    );
    [].concat((w && w.moves) || [], (w && w.attacks) || []).forEach(m =>
      (m.effects || []).forEach(f => {
        if (f.do === 'sound' && (!f.snd || !ids.has(f.snd)))
          add(
            f.snd ? 'error' : 'warn',
            '"' +
              (m.label || m.id) +
              '": an effect plays ' +
              (f.snd ? 'the sound "' + f.snd + '", which does not exist.' : 'no sound (none picked).')
          );
      })
    );
    return out;
  }
  return {
    sync,
    validate,
    SLOTS,
    cleanList,
    cleanSfx,
    cleanVol,
    setup,
    play,
    slot,
    music,
    stopMusic,
    unlock,
    mute,
    setVol,
    step,
    log,
    find,
    list: () => world.sounds,
    music_id: () => musId
  };
})();
