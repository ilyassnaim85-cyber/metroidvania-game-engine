// Damage types and status effects. A hit has a damage type (physical, fire, ice, poison, shock); a fighter can be weak to a type (x2), resist it (x0.5) or be immune (x0).
// A hit or a touch can also inflict a status: poison and burn hurt over time, slow makes the one that has it move and act slower.
// A status is kept in a small map { poison: { t: seconds left, a: time since the last tick } } on the player (G.status) and on every enemy and boss.
window.MV = window.MV || {};
MV.Status = (() => {
  const TYPES = ['physical', 'fire', 'ice', 'poison', 'shock'],
    KINDS = ['none', 'poison', 'burn', 'slow'],
    INFO = {
      poison: { label: 'Poison', color: '#7bd05a' },
      burn: { label: 'Burn', color: '#ef7a35' },
      slow: { label: 'Slow', color: '#6ab0e8' }
    };
  // the damage multiplier of a type against a fighter definition (an enemy type or a boss)
  const mult = (d, ty) => {
    if (!d || !ty) return 1;
    if (d.immuneTo === ty) return 0;
    if (d.weakTo === ty) return 2;
    if (d.resistTo === ty) return 0.5;
    return 1;
  };
  const add = (map, id, secs) => {
    if (!map || !INFO[id]) return;
    const t = Math.max(0.1, Math.min(60, +secs || 4)),
      c = map[id];
    if (c) c.t = Math.max(c.t, t);
    else map[id] = { t, a: 0 };
  };
  // advance the clocks by dt; returns the points of damage that fell due in this step
  const step = (map, dt, tune) => {
    let dmg = 0;
    if (!map) return 0;
    for (const id in map) {
      const s = map[id];
      s.t -= dt;
      if (id === 'poison' || id === 'burn') {
        const tick = Math.max(0.1, (id === 'poison' ? tune.poisonTick : tune.burnTick) || 1);
        s.a += dt;
        while (s.a >= tick) {
          s.a -= tick;
          dmg += Math.max(0, tune.statusDmg === undefined ? 1 : tune.statusDmg);
        }
      }
      if (s.t <= 0) delete map[id];
    }
    return Math.round(dmg);
  };
  const speedMul = (map, tune) => (map && map.slow ? Math.min(1, Math.max(0.1, tune.slowMul || 0.5)) : 1);
  const list = map =>
    Object.keys(map || {})
      .filter(id => INFO[id])
      .map(id => ({ id, label: INFO[id].label, color: INFO[id].color, t: map[id].t }));
  return { TYPES, KINDS, INFO, mult, add, step, speedMul, list };
})();
if (typeof module !== 'undefined' && module.exports) module.exports = MV.Status;
