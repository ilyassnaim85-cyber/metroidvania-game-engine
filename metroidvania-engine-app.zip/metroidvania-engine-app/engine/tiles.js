// Terrain tiles: the palette list and one painter used by both the editor and the playtest, so every tile looks the same in both.
// A tile is one character in a room's grid. Full blocks: '#' wall, 'g' shade wall, 'i' ice, 'm' mud, '>' and '<' conveyor belts, 'u' bounce, 'x' invisible wall.
// Partly solid tiles (their surface shape lives in MV.Light.PROFILES): '/' '\' steep slopes, '[' ']' gentle up-right, '{' '}' gentle up-left, '_' half block.
// Special: 'o' back wall (scenery), 'y' glass (solid, light passes).
// Others: '=' one-way platform, '~' water, 'D' transition, '.' empty. (Enemy, hazard, boss and pickup characters from older maps still load and play.)
(function (root) {
  const MV = (root.MV = root.MV || {});
  const STONE = '#5b6b7a';
  // group, character, name, swatch colour, help
  const PALETTE = [
    ['Blocks', '#', 'Wall', STONE, 'A solid block.'],
    ['Blocks', 'g', 'Shade wall', '#7a6a9a', 'Solid. Darkness passes through it.'],
    ['Blocks', '_', 'Half block', STONE, 'A solid block half a tile high. You step up onto it.'],
    ['Blocks', '=', 'Platform', '#a67c52', 'One-way: jump up through it, stand on it, press down to drop.'],
    ['Blocks', 'y', 'Glass', 'rgba(150,215,235,.55)', 'Solid but see-through: light passes through it.'],
    [
      'Blocks',
      'x',
      'Invisible wall',
      'rgba(255,255,255,.25)',
      'Solid but not drawn in the game, and light passes through it. Shown faintly in the editor.'
    ],
    ['Slopes', '/', 'Slope up-right', STONE, 'A 45 degree slope, high on the right.'],
    ['Slopes', '\\', 'Slope up-left', STONE, 'A 45 degree slope, high on the left.'],
    [
      'Slopes',
      '[',
      'Gentle up-right 1',
      STONE,
      'First half of a gentle slope that rises one tile over two. Put the second half to its right.'
    ],
    ['Slopes', ']', 'Gentle up-right 2', STONE, 'Second half of the gentle up-right slope.'],
    ['Slopes', '{', 'Gentle up-left 1', STONE, 'First (left) half of a gentle slope that rises to the left.'],
    ['Slopes', '}', 'Gentle up-left 2', STONE, 'Second (right) half of the gentle up-left slope.'],
    ['Surfaces', 'i', 'Ice', '#8fd0e8', 'Solid and slippery: you slide.'],
    ['Surfaces', 'm', 'Mud', '#6b4f33', 'Solid and sticky: you are slow.'],
    ['Surfaces', '>', 'Belt right', '#c9983a', 'Solid conveyor belt that carries you right.'],
    ['Surfaces', '<', 'Belt left', '#c9983a', 'Solid conveyor belt that carries you left.'],
    ['Surfaces', 'u', 'Bounce', '#2f9e78', 'Solid. Land on it from a fall and you are thrown up.'],
    [
      'Surfaces',
      's',
      'Soft ground',
      '#9a6f3f',
      'Solid like a wall, but a move that Passes through: soft ground (a burrow) can dig through it.'
    ],
    [
      'Blocks',
      'w',
      'Phase wall',
      '#6f5aa8',
      'Solid like a wall, but a move that Passes through: phase walls (a ghost or shadow form) can go through it. Put the ability on that move (Unlocked by).'
    ],
    ['Special', 'o', 'Back wall', '#2f3a47', 'Scenery only: drawn behind you, nothing collides with it.'],
    ['Other', '~', 'Water', '#3b8bd4', 'You swim in it.'],
    ['Other', 'D', 'Transition', '#ef9f27', 'A doorway to another room (pick where it goes below).'],
    ['Other', '.', 'Erase', null, 'Empty.']
  ];
  const BLOCKS = '#gim><uxysw'; // collide like a wall
  const hash = (a, b) => {
    let h = (a * 374761393 + b * 668265263) | 0;
    h = ((h ^ (h >>> 13)) * 1274126177) | 0;
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  };
  // Conveyor belt. Tread plates slide at the real belt speed (2 tiles a second), a belt that touches another belt joins it into one long belt, and the two ends of a run get rounded rollers.
  const BELT_SPEED = 2;
  function belt(ctx, ch, px, py, s, o) {
    const dir = ch === '>' ? 1 : -1,
      at = o.at,
      tx = o.tx | 0,
      ty = o.ty | 0,
      L = at ? at(tx - 1, ty) === ch : false,
      R = at ? at(tx + 1, ty) === ch : false;
    const per = s / 3,
      m = o.time === undefined ? 0 : (((o.time * BELT_SPEED * s) % per) + per) % per,
      ph = dir * m,
      r = Math.min(s * 0.3, s / 2),
      th = s * 0.34;
    // body: dark steel, rounded where the belt ends
    ctx.save();
    ctx.beginPath();
    ctx.rect(px, py, s, s);
    if (!L || !R) {
      ctx.beginPath();
      const x0 = px,
        x1 = px + s,
        y0 = py,
        y1 = py + s,
        rl = L ? 0 : r,
        rr = R ? 0 : r;
      ctx.moveTo(x0 + rl, y0);
      ctx.lineTo(x1 - rr, y0);
      if (rr) ctx.arcTo(x1, y0, x1, y0 + rr, rr);
      else ctx.lineTo(x1, y0);
      ctx.lineTo(x1, y1 - rr);
      if (rr) ctx.arcTo(x1, y1, x1 - rr, y1, rr);
      else ctx.lineTo(x1, y1);
      ctx.lineTo(x0 + rl, y1);
      if (rl) ctx.arcTo(x0, y1, x0, y1 - rl, rl);
      else ctx.lineTo(x0, y1);
      ctx.lineTo(x0, y0 + rl);
      if (rl) ctx.arcTo(x0, y0, x0 + rl, y0, rl);
      else ctx.lineTo(x0, y0);
      ctx.closePath();
    }
    ctx.fillStyle = '#323943';
    ctx.fill();
    ctx.clip();
    ctx.fillStyle = '#414a57';
    ctx.fillRect(px, py + th, s, Math.max(1, s * 0.06)); // frame rail under the tread
    // return strand underneath: dark dashes moving the other way, slower
    const per2 = s / 4,
      m2 = o.time === undefined ? 0 : (((o.time * BELT_SPEED * 0.5 * s) % per2) + per2) % per2;
    ctx.fillStyle = '#20252c';
    for (let k = -2; k < 6; k++)
      ctx.fillRect(px + k * per2 - dir * m2, py + s * 0.8, per2 * 0.55, Math.max(1.5, s * 0.08));
    // rivets
    ctx.fillStyle = '#5a6574';
    for (const f of [0.25, 0.75]) {
      ctx.beginPath();
      ctx.arc(px + s * f, py + s * 0.62, Math.max(1, s * 0.045), 0, 7);
      ctx.fill();
    }
    // tread: amber plates with a seam between them and a chevron on each, sliding with the belt
    ctx.save();
    ctx.beginPath();
    ctx.rect(px, py, s, th);
    ctx.clip();
    const gap = Math.max(1, s * 0.045);
    for (let k = -2; k < 5; k++) {
      const x0 = px + k * per + ph;
      ctx.fillStyle = '#d6aa45';
      ctx.fillRect(x0 + gap / 2, py, per - gap, th);
      ctx.fillStyle = 'rgba(255,240,190,.45)';
      ctx.fillRect(x0 + gap / 2, py, per - gap, Math.max(1, s * 0.06));
      ctx.strokeStyle = 'rgba(110,72,12,.7)';
      ctx.lineWidth = Math.max(1, s * 0.05);
      ctx.lineJoin = 'miter';
      const cx = x0 + per / 2,
        cy = py + th * 0.55,
        a = s * 0.06;
      ctx.beginPath();
      ctx.moveTo(cx - dir * a, cy - a);
      ctx.lineTo(cx + dir * a, cy);
      ctx.lineTo(cx - dir * a, cy + a);
      ctx.stroke();
    }
    ctx.restore();
    // rollers at the ends of a run
    for (const end of [!L ? 0 : -1, !R ? 1 : -1]) {
      if (end < 0) continue;
      const cx = end ? px + s - r : px + r,
        cy = py + s / 2;
      ctx.fillStyle = '#242a31';
      ctx.beginPath();
      ctx.arc(cx, cy, r * 0.62, 0, 7);
      ctx.fill();
      ctx.strokeStyle = '#6d7988';
      ctx.lineWidth = Math.max(1, s * 0.05);
      ctx.stroke();
      const ang = (o.time === undefined ? 0 : o.time * BELT_SPEED * dir * (s / Math.max(1, r * 0.62)) * 0.5) * 1 + 0;
      ctx.strokeStyle = '#8f9bab';
      ctx.lineWidth = Math.max(1, s * 0.045);
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(ang) * r * 0.45, cy + Math.sin(ang) * r * 0.45);
      ctx.lineTo(cx - Math.cos(ang) * r * 0.45, cy - Math.sin(ang) * r * 0.45);
      ctx.stroke();
    }
    ctx.restore();
  }
  // Tile pictures: a tile character can use a picture from a sprite sheet instead of the plain colours.
  // skin = { sheet, mode: 'single' | 'auto16', col, row, frames, fps, join: 'same' | 'solid' }
  //  single: the cell (col, row); with frames > 1 the next cells to the right play as an animation (water, torches).
  //  auto16: a block of 4 x 4 cells starting at (col, row). The cell is chosen by which neighbours are joined:
  //          up = 1, right = 2, down = 4, left = 8, so cell number = sum (0 = alone ... 15 = surrounded), read left to right, top to bottom.
  //          With frames > 1, each next frame is another 4-cell-wide block to the right.
  //  join: 'same' joins only the same tile; 'solid' joins any solid block. The edge of the room always counts as joined.
  const SOLIDS = '#gim><uxysw/\\[]{}_';
  const SKIN_CHARS = PALETTE.map(q => q[1]).filter(c => c !== '.' && c !== 'D' && c !== 'x');
  const cleanSkins = o => {
    const r = {};
    if (!o || typeof o !== 'object') return r;
    Object.keys(o)
      .slice(0, 40)
      .forEach(ch => {
        const k = o[ch];
        if (
          ch.length !== 1 ||
          !SKIN_CHARS.includes(ch) ||
          !k ||
          typeof k.sheet !== 'string' ||
          !/^[\w.-]{1,60}$/.test(k.sheet)
        )
          return;
        const n = (v, a, b, d) =>
          v === '' || v === null || v === undefined || !isFinite(+v) ? d : Math.min(b, Math.max(a, Math.floor(+v)));
        r[ch] = {
          sheet: k.sheet,
          mode: k.mode === 'auto16' ? 'auto16' : 'single',
          col: n(k.col, 0, 999, 0),
          row: n(k.row, 0, 999, 0),
          frames: n(k.frames, 1, 32, 1),
          fps: n(k.fps, 1, 60, 8),
          join: k.join === 'solid' ? 'solid' : 'same'
        };
      });
    return r;
  };
  // Stamps: a block of tiles you saved from a selection, to paste again. { id, name, w, h, rows }
  const cleanStamps = l => {
    const ok = new Set(PALETTE.map(q => q[1]));
    const seen = {};
    return (Array.isArray(l) ? l : [])
      .slice(0, 40)
      .map(q => {
        q = q || {};
        const rows = (Array.isArray(q.rows) ? q.rows : [])
          .slice(0, 64)
          .map(r => (typeof r === 'string' ? r.slice(0, 64) : ''))
          .map(r =>
            r
              .split('')
              .map(c => (ok.has(c) && c !== 'D' ? c : '.'))
              .join('')
          );
        const w = rows.reduce((m, r) => Math.max(m, r.length), 0);
        return {
          id:
            typeof q.id === 'string' && /^[\w-]{1,24}$/.test(q.id)
              ? q.id
              : 'st' + Math.random().toString(36).slice(2, 6),
          name: typeof q.name === 'string' && q.name.trim() ? q.name.trim().slice(0, 30) : 'Stamp',
          w,
          h: rows.length,
          rows: rows.map(r => r.padEnd(w, '.'))
        };
      })
      .filter(q => q.w > 0 && q.h > 0 && !seen[q.id] && (seen[q.id] = 1));
  };
  function drawSkin(ctx, ch, k, px, py, s, o) {
    const sh = o.sheet && o.sheet(k.sheet);
    if (!sh || !sh.img || !sh.img.complete || !sh.img.naturalWidth) return false;
    const cols = Math.floor(sh.img.naturalWidth / sh.tw),
      rows = Math.floor(sh.img.naturalHeight / sh.th),
      f = k.frames > 1 ? Math.floor((o.time || 0) * k.fps) % k.frames : 0;
    let cx, cy;
    if (k.mode === 'auto16') {
      const tx = o.tx | 0,
        ty = o.ty | 0,
        j = (dx, dy) => {
          const v = o.at ? o.at(tx + dx, ty + dy) : undefined;
          return v === undefined || v === null || v === '' ? true : k.join === 'solid' ? SOLIDS.includes(v) : v === ch;
        },
        m = (j(0, -1) ? 1 : 0) | (j(1, 0) ? 2 : 0) | (j(0, 1) ? 4 : 0) | (j(-1, 0) ? 8 : 0);
      cx = k.col + (m % 4) + f * 4;
      cy = k.row + Math.floor(m / 4);
    } else {
      const i = k.row * cols + k.col + f;
      cx = i % cols;
      cy = Math.floor(i / cols);
    }
    if (cx >= cols || cy >= rows) return false;
    const P = (MV.Light && MV.Light.PROFILES) || {};
    ctx.save();
    if (P[ch] || ch === '=' || ch === '_' || ch === '~') {
      ctx.beginPath();
      if (P[ch]) {
        ctx.moveTo(px, py + P[ch][0] * s);
        ctx.lineTo(px + s, py + P[ch][1] * s);
        ctx.lineTo(px + s, py + s);
        ctx.lineTo(px, py + s);
        ctx.closePath();
      } else if (ch === '=') ctx.rect(px, py, s, s / 2);
      else if (ch === '_') ctx.rect(px, py + s / 2, s, s / 2);
      else ctx.rect(px, py, s, s);
      ctx.clip();
    }
    if (ch === '~') ctx.globalAlpha = 0.7;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(sh.img, cx * sh.tw, cy * sh.th, sh.tw, sh.th, px, py, s + 0.5, s + 0.5);
    ctx.restore();
    return true;
  }
  // Paints tile ch into the square whose top-left pixel is (px, py) and side is s. o = { edit?: editor look, time?: seconds, tx?, ty?: tile position }. Returns false when it does not know the character.
  function draw(ctx, ch, px, py, s, o) {
    o = o || {};
    if (o.skins && o.skins[ch] && o.sheet && drawSkin(ctx, ch, o.skins[ch], px, py, s, o)) return true;
    const P = (MV.Light && MV.Light.PROFILES) || {},
      edit = !!o.edit,
      tx = o.tx | 0,
      ty = o.ty | 0;
    if (ch === '#' || (ch === 'g' && !edit)) {
      ctx.fillStyle = STONE;
      ctx.fillRect(px, py, s, s);
      return true;
    }
    if (ch === 'g') {
      ctx.fillStyle = '#7a6a9a';
      ctx.fillRect(px, py, s, s);
      return true;
    }
    if (P[ch]) {
      const p = P[ch];
      ctx.fillStyle = STONE;
      ctx.beginPath();
      ctx.moveTo(px, py + p[0] * s);
      ctx.lineTo(px + s, py + p[1] * s);
      ctx.lineTo(px + s, py + s);
      ctx.lineTo(px, py + s);
      ctx.closePath();
      ctx.fill();
      return true;
    }
    if (ch === '=') {
      ctx.fillStyle = '#a67c52';
      ctx.fillRect(px, py, s, s / 2);
      return true;
    }
    if (ch === '~') {
      ctx.fillStyle = '#3b8bd4';
      ctx.globalAlpha = edit ? 0.45 : 0.4;
      ctx.fillRect(px, py, s, s);
      ctx.globalAlpha = 1;
      return true;
    }
    if (ch === 'x') {
      if (!edit) return true;
      ctx.fillStyle = 'rgba(255,255,255,.07)';
      ctx.fillRect(px, py, s, s);
      ctx.strokeStyle = 'rgba(255,255,255,.35)';
      ctx.setLineDash([3, 3]);
      ctx.lineWidth = 1;
      ctx.strokeRect(px + 0.5, py + 0.5, s - 1, s - 1);
      ctx.setLineDash([]);
      return true;
    }
    if (ch === 'i') {
      ctx.fillStyle = '#8fd0e8';
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = 'rgba(255,255,255,.75)';
      ctx.fillRect(px, py, s, Math.max(1, s * 0.12));
      ctx.strokeStyle = 'rgba(255,255,255,.55)';
      ctx.lineWidth = Math.max(1, s * 0.06);
      ctx.beginPath();
      ctx.moveTo(px + s * 0.2, py + s * 0.7);
      ctx.lineTo(px + s * 0.4, py + s * 0.45);
      ctx.moveTo(px + s * 0.55, py + s * 0.85);
      ctx.lineTo(px + s * 0.8, py + s * 0.55);
      ctx.stroke();
      return true;
    }
    if (ch === 'm') {
      ctx.fillStyle = '#6b4f33';
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = '#4a3522';
      ctx.fillRect(px, py, s, Math.max(1, s * 0.14));
      for (let i = 0; i < 4; i++) {
        const a = hash(tx * 7 + i, ty * 13 + i),
          b = hash(ty * 5 + i, tx * 11 + i);
        ctx.beginPath();
        ctx.arc(
          px + s * (0.15 + 0.7 * a),
          py + s * (0.3 + 0.6 * b),
          Math.max(1, s * (0.05 + 0.05 * hash(i, tx + ty))),
          0,
          7
        );
        ctx.fill();
      }
      return true;
    }
    if (ch === '>' || ch === '<') {
      belt(ctx, ch, px, py, s, o);
      return true;
    }
    if (ch === 'u') {
      ctx.fillStyle = '#2f9e78';
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = '#7bf0d0';
      ctx.fillRect(px, py, s, Math.max(2, s * 0.2));
      ctx.strokeStyle = '#d8fff3';
      ctx.lineWidth = Math.max(1, s * 0.08);
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(px + s * 0.28, py + s * 0.8);
      ctx.lineTo(px + s * 0.5, py + s * 0.5);
      ctx.lineTo(px + s * 0.72, py + s * 0.8);
      ctx.stroke();
      return true;
    }
    if (ch === 'w') {
      ctx.fillStyle = '#4b3d7a';
      ctx.fillRect(px, py, s, s);
      ctx.strokeStyle = '#a99be0';
      ctx.lineWidth = Math.max(1, s * 0.06);
      ctx.setLineDash([s * 0.18, s * 0.12]);
      ctx.strokeRect(px + s * 0.08, py + s * 0.08, s * 0.84, s * 0.84);
      ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(210,200,255,.35)';
      for (let i = 0; i < 3; i++) {
        const a = hash(tx * 5 + i, ty * 7 + i);
        ctx.fillRect(px + s * (0.15 + 0.6 * a), py + s * (0.2 + i * 0.25), s * 0.22, Math.max(1, s * 0.05));
      }
      return true;
    }
    if (ch === 's') {
      ctx.fillStyle = '#8a6238';
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = '#6f4d2b';
      for (let i = 0; i < 6; i++) {
        const a = hash(tx * 3 + i, ty * 17 + i),
          b = hash(ty * 9 + i, tx * 5 + i);
        ctx.beginPath();
        ctx.arc(
          px + s * (0.1 + 0.8 * a),
          py + s * (0.1 + 0.8 * b),
          Math.max(1, s * (0.04 + 0.05 * hash(i, tx * 2 + ty))),
          0,
          7
        );
        ctx.fill();
      }
      ctx.fillStyle = '#a77a49';
      for (let i = 0; i < 3; i++) {
        const a = hash(tx * 11 + i, ty * 7),
          b = hash(ty * 13 + i, tx * 3);
        ctx.fillRect(px + s * (0.1 + 0.75 * a), py + s * (0.15 + 0.7 * b), Math.max(1, s * 0.1), Math.max(1, s * 0.06));
      }
      ctx.fillStyle = 'rgba(0,0,0,.18)';
      ctx.fillRect(px, py + s - Math.max(1, s * 0.06), s, Math.max(1, s * 0.06));
      return true;
    }
    if (ch === 'y') {
      ctx.fillStyle = 'rgba(150,215,235,.28)';
      ctx.fillRect(px, py, s, s);
      ctx.strokeStyle = 'rgba(225,248,255,.75)';
      ctx.lineWidth = Math.max(1, s * 0.06);
      ctx.strokeRect(px + s * 0.04, py + s * 0.04, s * 0.92, s * 0.92);
      ctx.beginPath();
      ctx.moveTo(px + s * 0.2, py + s * 0.55);
      ctx.lineTo(px + s * 0.55, py + s * 0.2);
      ctx.moveTo(px + s * 0.45, py + s * 0.8);
      ctx.lineTo(px + s * 0.8, py + s * 0.45);
      ctx.stroke();
      return true;
    }
    if (ch === 'o') {
      ctx.fillStyle = '#2f3a47';
      ctx.fillRect(px, py, s, s);
      ctx.fillStyle = 'rgba(0,0,0,.22)';
      ctx.fillRect(px, py + s * 0.5, s, Math.max(1, s * 0.06));
      ctx.fillRect(px + s * ((tx + ty) & 1 ? 0.3 : 0.7), py, Math.max(1, s * 0.06), s * 0.5);
      return true;
    }
    return false;
  }
  MV.Tiles = {
    cleanSkins,
    cleanStamps,
    SKIN_CHARS,
    SOLIDS,
    PALETTE,
    BLOCKS,
    draw,
    GROUND: '#g=/\\[]{}_im><uxysw', // ground a walking enemy can stand on
    nameOf: ch => {
      const t = PALETTE.find(q => q[1] === ch);
      return t ? t[2] : ch;
    },
    // the character a flipped copy of ch becomes when a room (or selection) is mirrored left-right
    mirror: ch => ({ '/': '\\', '\\': '/', '[': '}', '}': '[', ']': '{', '{': ']', '>': '<', '<': '>' })[ch] || ch
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = MV.Tiles;
})(typeof window !== 'undefined' ? window : globalThis);
