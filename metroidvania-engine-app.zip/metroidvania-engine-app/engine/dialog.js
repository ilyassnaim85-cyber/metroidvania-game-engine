// MV.Dialog - the talk box: a name on top, the words below. Used by the game (NPC conversations) and by the editor preview.
// Script format (one line per turn): a line starting with ">" is the player's character speaking, any other line is the other character.
window.MV = window.MV || {};
MV.Dialog = (() => {
  const col = (v, d) => (/^#[0-9a-f]{6}$/i.test(v) ? v : d);
  const num = (v, a, b, d) => {
    v = +v;
    return isFinite(v) ? Math.max(a, Math.min(b, v)) : d;
  };
  const def = () => ({
    name: 'Hero',
    sheet: '',
    slice: 8,
    scale: 2,
    tcolor: '#ffffff',
    ncolor: '#ffd24a',
    pcolor: '#8fe3c0',
    bcolor: '#0c1a28'
  });
  const clean = o => {
    o = o && typeof o === 'object' ? o : {};
    const d = def();
    return {
      name: typeof o.name === 'string' && o.name.trim() ? o.name.trim().slice(0, 24) : d.name,
      sheet: typeof o.sheet === 'string' ? o.sheet.slice(0, 32) : '',
      slice: Math.round(num(o.slice, 1, 64, d.slice)),
      scale: Math.round(num(o.scale, 1, 6, d.scale)),
      tcolor: col(o.tcolor, d.tcolor),
      ncolor: col(o.ncolor, d.ncolor),
      pcolor: col(o.pcolor, d.pcolor),
      bcolor: col(o.bcolor, d.bcolor)
    };
  };
  const parse = t =>
    String(t == null ? '' : t)
      .split('\n')
      .map(s => s.trim())
      .filter(Boolean)
      .map(s => (s[0] === '>' ? { who: 'me', text: s.slice(1).trim() } : { who: 'npc', text: s }))
      .filter(l => l.text);
  function wrap(ctx, text, maxW) {
    const out = [];
    String(text)
      .split('\n')
      .forEach(par => {
        let line = '';
        par.split(' ').forEach(w => {
          const t = line ? line + ' ' + w : w;
          if (line && ctx.measureText(t).width > maxW) {
            out.push(line);
            line = w;
          } else line = t;
        });
        out.push(line);
      });
    return out;
  }
  function patch(ctx, im, s, sc, x, y, w, h) {
    // nine-slice: corners keep their size, edges and middle stretch
    const iw = im.naturalWidth || im.width,
      ih = im.naturalHeight || im.height,
      d = Math.min(s * sc, w / 2, h / 2);
    if (iw < 2 * s + 1 || ih < 2 * s + 1) {
      ctx.drawImage(im, x, y, w, h);
      return;
    }
    const xs = [0, s, iw - s, iw],
      ys = [0, s, ih - s, ih],
      xd = [x, x + d, x + w - d, x + w],
      yd = [y, y + d, y + h - d, y + h];
    for (let j = 0; j < 3; j++)
      for (let i = 0; i < 3; i++)
        ctx.drawImage(
          im,
          xs[i],
          ys[j],
          xs[i + 1] - xs[i],
          ys[j + 1] - ys[j],
          xd[i],
          yd[j],
          xd[i + 1] - xd[i],
          yd[j + 1] - yd[j]
        );
  }
  // box = { x, y, w, h } in canvas pixels. who: 'npc' or 'me'. shown = how many letters are visible so far.
  function draw(ctx, cfg, getSheet, box, who, name, text, shown, time) {
    const sh = cfg.sheet && getSheet ? getSheet(cfg.sheet) : null,
      im = sh && sh.img && sh.img.complete !== false && (sh.img.naturalWidth || sh.img.width) ? sh.img : null;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    if (im) patch(ctx, im, cfg.slice, cfg.scale, box.x, box.y, box.w, box.h);
    else {
      ctx.globalAlpha = 0.94;
      ctx.fillStyle = cfg.bcolor;
      ctx.beginPath();
      ctx.roundRect ? ctx.roundRect(box.x, box.y, box.w, box.h, 10) : ctx.rect(box.x, box.y, box.w, box.h);
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.strokeStyle = 'rgba(255,255,255,.55)';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
    const pad = Math.max(14, im ? cfg.slice * cfg.scale + 6 : 14);
    ctx.textBaseline = 'top';
    ctx.textAlign = 'left';
    ctx.font = 'bold 16px system-ui,sans-serif';
    ctx.fillStyle = who === 'me' ? cfg.pcolor : cfg.ncolor;
    ctx.fillText(name || '', box.x + pad, box.y + pad - 2);
    ctx.font = '15px system-ui,sans-serif';
    ctx.fillStyle = cfg.tcolor;
    const lines = wrap(ctx, String(text).slice(0, shown), box.w - pad * 2);
    lines.forEach((l, i) => ctx.fillText(l, box.x + pad, box.y + pad + 22 + i * 19));
    if (shown >= String(text).length && Math.floor((time || 0) * 2.5) % 2 === 0) {
      ctx.fillStyle = cfg.tcolor;
      ctx.beginPath();
      const ax = box.x + box.w - pad - 4,
        ay = box.y + box.h - pad - 2;
      ctx.moveTo(ax - 6, ay - 6);
      ctx.lineTo(ax + 6, ay - 6);
      ctx.lineTo(ax, ay + 3);
      ctx.fill();
    }
    ctx.restore();
  }
  // A small speech bubble (a character talking as you walk past).
  function bubble(ctx, text, cx, bottom, alpha) {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.font = '13px system-ui,sans-serif';
    ctx.textBaseline = 'top';
    ctx.textAlign = 'left';
    const L = wrap(ctx, text, 190),
      w = Math.min(200, Math.max(...L.map(l => ctx.measureText(l).width)) + 16),
      h = L.length * 16 + 12,
      x = cx - w / 2,
      y = bottom - h - 6;
    ctx.fillStyle = 'rgba(12,26,40,.9)';
    ctx.strokeStyle = 'rgba(255,255,255,.6)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(x, y, w, h, 8) : ctx.rect(x, y, w, h);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - 5, y + h);
    ctx.lineTo(cx + 5, y + h);
    ctx.lineTo(cx, y + h + 6);
    ctx.fill();
    ctx.fillStyle = '#fff';
    L.forEach((l, i) => ctx.fillText(l, x + 8, y + 6 + i * 16));
    ctx.restore();
  }
  return { def, clean, parse, wrap, draw, bubble };
})();
