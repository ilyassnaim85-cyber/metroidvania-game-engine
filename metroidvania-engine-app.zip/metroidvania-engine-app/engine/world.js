// MV.World - pure helpers for the world editor (no page access): what a room contains, world checks, copying rooms and areas,
// aligning boxes, searching, markers and room templates. The editor draws the UI; everything here works on plain project data.
(function (root) {
  const MV = (root.MV = root.MV || {});
  const key = (a, r) => a + '/' + r;
  const clone = o => (typeof structuredClone === 'function' ? structuredClone(o) : JSON.parse(JSON.stringify(o)));
  const rid = () => Math.random().toString(36).slice(2, 8);
  const SOLID = '#g_=xiymu><';

  const everyRoom = S => {
    const o = [];
    (S.areas || []).forEach(a => (a.rooms || []).forEach(r => o.push({ a, r })));
    return o;
  };

  // 'D' tiles of a room: [{x,y}]
  function dTiles(r) {
    const o = [],
      g = r.grid;
    if (!Array.isArray(g)) return o;
    for (let y = 0; y < g.length; y++) {
      const row = g[y];
      if (typeof row !== 'string') continue;
      for (let x = row.indexOf('D'); x >= 0; x = row.indexOf('D', x + 1)) o.push({ x, y });
    }
    return o;
  }

  // Counts of what is in a room (entities, plus the old e / B / * tiles).
  function contents(r) {
    const c = {
      enemy: 0,
      boss: 0,
      item: 0,
      chest: 0,
      door: 0,
      trans: (r.tr || []).length,
      checkpoint: 0,
      spawn: 0,
      sw: 0,
      comment: !!(r.note && String(r.note).trim()),
      ents: (r.ent || []).length
    };
    (r.ent || []).forEach(e => {
      const t = e.type;
      if (t === 'enemy') c.enemy++;
      else if (t === 'boss') c.boss++;
      else if (t === 'pickup') c.item++;
      else if (t === 'chest') {
        c.chest++;
        c.item++;
      } else if (t === 'door') c.door++;
      else if (t === 'checkpoint' || t === 'checkpointkey') c.checkpoint++;
      else if (t === 'spawn') c.spawn++;
      else if (t === 'switch') c.sw++;
    });
    const g = r.grid;
    if (Array.isArray(g))
      for (let y = 0; y < g.length; y++) {
        const row = g[y];
        if (typeof row !== 'string') continue;
        for (let x = row.indexOf('e'); x >= 0; x = row.indexOf('e', x + 1)) c.enemy++;
        for (let x = row.indexOf('B'); x >= 0; x = row.indexOf('B', x + 1)) c.enemy++;
        for (let x = row.indexOf('*'); x >= 0; x = row.indexOf('*', x + 1)) c.item++;
      }
    return c;
  }

  // ---------- markers ----------
  const MARKS = {
    start: { t: 'S', c: '#5dcaa5', n: 'Start point', auto: 1 },
    entrance: { t: '▶', c: '#7fd1ff', n: 'Entrance' },
    exit: { t: '◀', c: '#c9a0ff', n: 'Exit' },
    save: { t: '◆', c: '#378add', n: 'Checkpoint / save', auto: 1 },
    goal: { t: '★', c: '#ef9f27', n: 'Objective' },
    boss: { t: 'B', c: '#e24b4a', n: 'Boss', auto: 1 },
    lock: { t: 'L', c: '#c08a4a', n: 'Locked door', auto: 1 },
    loot: { t: '$', c: '#e8c34a', n: 'Chest or pickup', auto: 1 },
    secret: { t: '?', c: '#a78bfa', n: 'Secret' },
    danger: { t: '!', c: '#d85a30', n: 'Danger' }
  };
  const MANUAL = ['start', 'entrance', 'exit', 'save', 'goal', 'boss', 'secret', 'danger'];
  function autoMarks(r, c) {
    c = c || contents(r);
    const o = [];
    if (c.spawn) o.push('start');
    if (c.checkpoint) o.push('save');
    if (c.boss) o.push('boss');
    if (c.door) o.push('lock');
    if (c.item) o.push('loot');
    return o;
  }
  function marksOf(r, withAuto) {
    const set = [];
    (r.mk || []).forEach(k => {
      if (MARKS[k] && !set.includes(k)) set.push(k);
    });
    if (withAuto)
      autoMarks(r).forEach(k => {
        if (!set.includes(k)) set.push(k);
      });
    return set;
  }

  // ---------- search and filters ----------
  const FILTERS = {
    enemy: 'Enemies',
    boss: 'Bosses',
    item: 'Items',
    trans: 'Transitions',
    comment: 'Comments',
    save: 'Checkpoints',
    marks: 'Markers'
  };
  function roomHas(r, f, c) {
    c = c || contents(r);
    return f === 'enemy'
      ? c.enemy > 0
      : f === 'boss'
        ? c.boss > 0
        : f === 'item'
          ? c.item > 0
          : f === 'trans'
            ? c.trans > 0 || dTiles(r).length > 0
            : f === 'comment'
              ? c.comment
              : f === 'save'
                ? c.checkpoint > 0
                : f === 'marks'
                  ? (r.mk || []).length > 0
                  : false;
  }
  // q = text, fl = list of filter keys (all must match). Returns true when the room should stay lit.
  function matchRoom(r, q, fl) {
    q = String(q || '')
      .trim()
      .toLowerCase();
    if (
      q &&
      !(
        String(r.n).toLowerCase().includes(q) ||
        String(r.s || '')
          .toLowerCase()
          .includes(q) ||
        String(r.note || '')
          .toLowerCase()
          .includes(q)
      )
    )
      return false;
    if (fl && fl.length) {
      const c = contents(r);
      return fl.every(f => roomHas(r, f, c));
    }
    return true;
  }
  function matchArea(a, q, fl) {
    q = String(q || '')
      .trim()
      .toLowerCase();
    const named =
      !q ||
      String(a.n).toLowerCase().includes(q) ||
      String(a.s || '')
        .toLowerCase()
        .includes(q) ||
      String(a.note || '')
        .toLowerCase()
        .includes(q);
    if (!fl || !fl.length) return named || (a.rooms || []).some(r => matchRoom(r, q, fl));
    return (a.rooms || []).some(r => (named || matchRoom(r, q, [])) && matchRoom(r, '', fl));
  }

  // ---------- connections ----------
  // Every transition as {from:{a,r}, to:{a,r}, x, y, ok}
  function transitions(S) {
    const rs = everyRoom(S),
      ok = new Set(rs.map(q => key(q.a.id, q.r.id))),
      o = [];
    rs.forEach(q =>
      (q.r.tr || []).forEach(t =>
        o.push({ from: { a: q.a.id, r: q.r.id }, to: { a: t.a, r: t.r }, x: t.x, y: t.y, ok: ok.has(key(t.a, t.r)) })
      )
    );
    return o;
  }
  // rooms connected to one room: {out:[{a,r,x,y,ok}], inn:[{a,r}]}
  function neighbours(S, a, r) {
    const t = transitions(S),
      me = key(a, r);
    return {
      out: t.filter(q => key(q.from.a, q.from.r) === me).map(q => ({ a: q.to.a, r: q.to.r, x: q.x, y: q.y, ok: q.ok })),
      inn: t.filter(q => key(q.to.a, q.to.r) === me && q.ok).map(q => ({ a: q.from.a, r: q.from.r, x: q.x, y: q.y }))
    };
  }

  // ---------- validation ----------
  // Things a door, switch, chest or pickup can give the player.
  function provided(S) {
    const T = new Set(),
      add = v => {
        v = String(v || '').trim();
        if (!v) return;
        T.add(v);
        T.add('flag:' + v);
        if (v.startsWith('flag:')) T.add(v.slice(5));
      };
    everyRoom(S).forEach(q =>
      (q.r.ent || []).forEach(e => {
        const p = e.props || {};
        if (e.type === 'switch') add(p.flag || 'switch1');
        else if (e.type === 'chest' || e.type === 'pickup') add(p.give);
        else if (e.type === 'boss') {
          const b = (S.bosses || []).find(x => x.id === p.boss);
          if (b) {
            add(b.reward);
            add(b.flag || 'boss_' + b.id);
          }
        }
      })
    );
    (S.bosses || []).forEach(b => {
      add(b.reward);
      add(b.flag || 'boss_' + b.id);
    });
    return T;
  }
  const need = (T, req) => {
    req = String(req || '').trim();
    return !req || T.has(req) || (req.startsWith('flag:') && T.has(req.slice(5))) || T.has('flag:' + req);
  };

  function validate(S) {
    const out = [],
      all = everyRoom(S),
      byKey = new Map(all.map(q => [key(q.a.id, q.r.id), q]));
    const add = (sev, code, msg, q, x, y) =>
      out.push({
        sev,
        code,
        msg,
        a: q ? q.a.id : null,
        r: q ? q.r.id : null,
        x,
        y,
        name: q ? q.r.n : '',
        area: q ? q.a.n : ''
      });
    {
      // progression: energy costs, upgrades and charms need something to work with
      const T = MV.Tuning ? MV.Tuning.resolve(S.player) : {},
        ups = new Set(),
        ents = [];
      all.forEach(q => (q.r.ent || []).forEach(e => ents.push(e)));
      ents.forEach(e => {
        const p = e.props || {};
        if ((e.type === 'pickup' && p.kind === 'upgrade') || (e.type === 'chest' && p.reward === 'upgrade')) {
          if (['maxHp', 'energyMax', 'charmSlots'].includes(p.give)) ups.add(p.give);
          else
            add(
              'warn',
              'upgrade-unknown',
              'An upgrade gives "' + p.give + '", which is not an upgrade. Use maxHp, energyMax or charmSlots.'
            );
        }
      });
      (S.events || []).forEach(ev =>
        (ev.actions || []).forEach(a => {
          if (a.type === 'upgrade') ups.add(a.stat);
        })
      );
      const costed = [].concat(S.moves || [], S.attacks || []).filter(m => m && (m.cost > 0 || m.drain > 0)),
        charmE = (S.items || []).some(d => d.use === 'charm' && (d.mods || []).some(m => m.key === 'energyMax'));
      if (costed.length && !(T.energyMax > 0) && !ups.has('energyMax') && !charmE)
        add(
          'warn',
          'energy-none',
          (costed[0].label || costed[0].id) +
            (costed.length > 1 ? ' and ' + (costed.length - 1) + ' more cost' : ' costs') +
            ' energy, but the player has no energy bar (Settings, Energy, maximum is 0), so they can never be used.'
        );
      if (
        (T.energyMax > 0 || ups.has('energyMax')) &&
        !(T.energyRegen > 0) &&
        !(T.energyPerHit > 0) &&
        !ents.some(
          e =>
            (e.type === 'pickup' && e.props && e.props.kind === 'energy') ||
            (e.type === 'chest' && e.props && e.props.reward === 'energy')
        ) &&
        !(S.events || []).some(ev => (ev.actions || []).some(a => a.type === 'energy' && a.n > 0)) &&
        !costed.some(m => (m.effects || []).some(f => f.do === 'energy' && f.value > 0))
      )
        add(
          'info',
          'energy-no-refill',
          'Energy never refills: no regrowth, no energy per hit, no energy pickup and no event gives any. It only comes back when you rest at a key checkpoint or die.'
        );
      const ch = (S.items || []).filter(d => d.use === 'charm');
      if (ch.length && !(T.charmSlots > 0) && !ups.has('charmSlots'))
        add(
          'warn',
          'charm-no-slots',
          'There are charm items but the player has no notches (Settings, Charms), so none can be equipped.'
        );
      ch.forEach(d => {
        if (!(T.charmSlots > 0 && d.notches <= T.charmSlots + 20)) return;
        if (d.grant && MV.data && !MV.data.abilities[d.grant] && !(S.moves || []).some(m => m.requires === d.grant))
          add(
            'info',
            'charm-grant',
            'The charm "' + d.name + '" grants "' + d.grant + '", but no move or attack uses that ability.'
          );
      });
    }
    {
      // enemy types: placed enemies must have their type; drops and pictures must exist
      const types = S.enemies || [],
        ids = new Set(types.map(d => d.id)),
        used = new Set(),
        T = MV.Tuning ? MV.Tuning.resolve(S.player) : {},
        itemIds = new Set((S.items || []).map(i => i.id)),
        anims = new Set((S.anims || []).map(a => a.id)),
        snds = new Set((S.sounds || []).map(a => a.id));
      all.forEach(q =>
        (q.r.ent || []).forEach(e => {
          if (e.type !== 'enemy') return;
          const k = e.props && e.props.kind;
          if (!k) return;
          used.add(k);
          if (!ids.has(k))
            add(
              'error',
              'enemy-missing',
              'An enemy uses the type "' + k + '", which does not exist (deleted or renamed in the Enemies tab).',
              q,
              e.x,
              e.y
            );
        })
      );
      types.forEach(d => {
        const nm = d.name || d.id;
        if (!used.has(d.id)) add('info', 'enemy-unused', 'The enemy type "' + nm + '" is not placed in any room.');
        if (d.dropItem && !itemIds.has(d.dropItem))
          add(
            'warn',
            'enemy-drop',
            'The enemy type "' + nm + '" drops the item "' + d.dropItem + '", which does not exist.'
          );
        if (d.energy > 0 && !(T.energyMax > 0))
          add(
            'info',
            'enemy-energy',
            'The enemy type "' + nm + '" drops energy, but the player has no energy bar (Settings, Energy).'
          );
        Object.keys(d.clips || {}).forEach(c => {
          if (!anims.has(d.clips[c]))
            add(
              'warn',
              'enemy-anim',
              'The enemy type "' + nm + '" uses an animation ("' + d.clips[c] + '") that no longer exists.'
            );
        });
        Object.keys(d.snds || {}).forEach(c => {
          if (!snds.has(d.snds[c]))
            add(
              'warn',
              'enemy-sound',
              'The enemy type "' + nm + '" uses a sound ("' + d.snds[c] + '") that no longer exists.'
            );
        });
        if (d.move === 'stand still' && !MV.Enemies.attacks(d).length && d.damage === 0)
          add(
            'info',
            'enemy-harmless',
            'The enemy type "' +
              nm +
              '" cannot hurt anything (stands still, no attack, no touch damage). That is fine for a punching bag.'
          );
        if (MV.Enemies.attacks(d).includes('strike') && !(d.strike || []).length)
          add(
            'warn',
            'enemy-strike-empty',
            'The enemy type "' + nm + '" attacks with hitboxes but has none. Add one under Strike hitboxes.'
          );
        if (MV.Enemies.attacks(d).includes('strike') && (d.strike || []).length && !(d.strike || []).some(h => h.dmg > 0))
          add('warn', 'enemy-strike-harmless', 'Every strike hitbox of "' + nm + '" has 0 damage.');
        if (d.weakOnly === 'yes' && !(d.weak || []).length)
          add(
            'error',
            'enemy-unhittable',
            'The enemy type "' + nm + '" can only be hurt on weak spots but has none, so it can never be killed.'
          );
        if (d.weakOnly === 'yes' && (d.weak || []).length && !(d.weak || []).some(q => q.mult > 0))
          add(
            'error',
            'enemy-unhittable',
            'Every weak spot of "' + nm + '" has damage x 0, so it can never be killed.'
          );
        if (d.touch === 'no' && !MV.Enemies.attacks(d).length)
          add('info', 'enemy-harmless', 'The enemy type "' + nm + '" does not hurt by touching and has no attack.');
        if ((d.move === 'chase' || d.move === 'fly' || d.move === 'hop') && !(d.sight > 0))
          add(
            'warn',
            'enemy-blind',
            'The enemy type "' + nm + '" never notices you (Sees you from is 0), so it only patrols or hovers.'
          );
      });
    }
    {
      // items that run a script, and the items the screen shows
      const fnl = MV.Script && MV.Script.fnNames ? MV.Script.fnNames(S.scripts) : null,
        itemIds = new Set((S.items || []).map(i => i.id)),
        T = MV.Tuning ? MV.Tuning.resolve(S.player) : {};
      (S.items || []).forEach(d => {
        if (d.use === 'script' && !d.fn)
          add('warn', 'item-script', 'The item "' + d.name + '" runs a script but has no function name.');
        else if (d.use === 'script' && fnl && !fnl.has(d.fn))
          add(
            'warn',
            'item-script',
            'The item "' + d.name + '" runs the script function "' + d.fn + '", which no script defines with fn().'
          );
        if (d.use === 'energy' && !(T.energyMax > 0))
          add('info', 'item-energy', 'The item "' + d.name + '" restores energy but the player has no energy bar.');
      });
      if (S.ui && /^f:/.test(S.ui.font || '') && !(S.fonts || []).some(f => 'f:' + f.id === S.ui.font))
        add('info', 'ui-font', 'The UI tab uses a font file that is not in the project any more, so the standard font is used.');
      ((S.ui && S.ui.hudItems) || '')
        .split(',')
        .map(z => z.trim())
        .filter(z => z && !itemIds.has(z))
        .forEach(z => add('info', 'ui-item', 'The UI tab shows the item "' + z + '", which does not exist.'));
    }
    {
      // bosses: warnings, sounds and damage
      const sn = new Set((S.sounds || []).map(z => z.id)),
        itemIds = new Set((S.items || []).map(i => i.id));
      (S.bosses || []).forEach(b => {
        const nm = b.name || b.id;
        if (b.dropItem && !itemIds.has(b.dropItem))
          add('warn', 'boss-drop', 'The boss "' + nm + '" gives the item "' + b.dropItem + '", which does not exist.');
        if (!(b.patterns || []).length)
          add('warn', 'boss-no-patterns', 'The boss "' + nm + '" has no patterns, so it never attacks.');
        else if (
          !(b.patterns || []).some(pt => (pt.hitboxes || []).some(h => h.dmg > 0)) &&
          !(b.touch === 'yes' && b.damage > 0)
        )
          add(
            'warn',
            'boss-harmless',
            'The boss "' + nm + '" cannot hurt you: every hitbox has 0 damage and touching it is harmless.'
          );
        (b.patterns || []).forEach(pt => {
          if (!(pt.warn > 0) && (pt.hitboxes || []).some(h => h.dmg > 0 && h.from < 0.15))
            add(
              'info',
              'boss-no-warning',
              'The pattern "' +
                pt.name +
                '" of "' +
                nm +
                '" hurts at once with no warning time. Give it a Warning time so players can react.'
            );
        });
        if (b.select === 'rules') {
          (b.patterns || []).forEach(pt => {
            if (pt.min > pt.max)
              add(
                'warn',
                'boss-rule',
                'The pattern "' +
                  pt.name +
                  '" of "' +
                  nm +
                  '" needs you farther than it allows (min distance is larger than max), so it is never chosen.'
              );
            if (pt.hpAbove >= pt.hpBelow)
              add(
                'warn',
                'boss-rule',
                'The pattern "' +
                  pt.name +
                  '" of "' +
                  nm +
                  '" only starts above ' +
                  pt.hpAbove +
                  '% and below ' +
                  pt.hpBelow +
                  '% health, which never happens.'
              );
          });
          if ((b.patterns || []).length && !(b.patterns || []).some(pt => pt.weight > 0))
            add('warn', 'boss-rule', 'Every pattern of "' + nm + '" has weight 0, so it never attacks.');
        }
        if (b.speed > 0 && b.fly === 'no' && !(b.w > 0))
          add('info', 'boss-walk', 'The boss "' + nm + '" has no body width.');
        (b.phases || []).forEach((ph, i) => {
          if (ph.patterns && ph.patterns.length === 0 && (b.patterns || []).length > 1 && b.phases.length > 1)
            add(
              'info',
              'boss-phase-all',
              'Phase ' + (i + 1) + ' of "' + nm + '" has no patterns ticked, so it uses all of them.'
            );
        });
        if (b.weakOnly === 'yes' && (!(b.weak || []).length || !(b.weak || []).some(q => q.mult > 0)))
          add(
            'error',
            'boss-unhittable',
            'The boss "' + nm + '" can only be hurt on weak spots but none can do damage, so it can never be beaten.'
          );
        const an = new Set((S.anims || []).map(z => z.id));
        Object.keys(b.clips || {}).forEach(k => {
          if (!an.has(b.clips[k]))
            add(
              'warn',
              'boss-anim',
              'The boss "' + nm + '" uses an animation ("' + b.clips[k] + '") that no longer exists (' + k + ').'
            );
        });
        if (!(b.clips || {}).idle && !Object.keys((b.sprite || {}).anims || {}).length)
          add(
            'info',
            'boss-no-art',
            'The boss "' + nm + '" has no animation yet, so it is drawn as a purple box. Pick clips in the Bosses tab.'
          );
        if (b.stagger > 0 && b.staggerTime > 0 && b.staggerMult < 1)
          add(
            'info',
            'boss-stagger',
            'The boss "' + nm + '" takes less damage while stunned, which is the opposite of a reward for stunning it.'
          );
        ['wakeSnd', 'hurtSnd', 'phaseSnd', 'dieSnd'].forEach(k => {
          if (b[k] && !sn.has(b[k]))
            add('warn', 'boss-sound', 'The boss "' + nm + '" uses a sound ("' + b[k] + '") that no longer exists.');
        });
        (b.patterns || []).forEach(pt => {
          if (pt.snd && !sn.has(pt.snd))
            add(
              'warn',
              'boss-sound',
              'The pattern "' + pt.name + '" of "' + nm + '" uses a sound ("' + pt.snd + '") that no longer exists.'
            );
        });
      });
    }
    if (!all.length) return out;
    let start = all.find(q => (q.r.ent || []).some(e => e.type === 'spawn'));
    const hasSpawn = !!start;
    if (!start) start = all[0];
    const out_ = new Map(),
      in_ = new Map();
    all.forEach(q => {
      const k = key(q.a.id, q.r.id);
      out_.set(k, []);
      in_.set(k, []);
    });
    all.forEach(q => {
      const k = key(q.a.id, q.r.id),
        d = dTiles(q.r),
        dset = new Set(d.map(p => p.x + ',' + p.y)),
        have = new Set(),
        stale = [];
      (q.r.tr || []).forEach(t => {
        have.add(t.x + ',' + t.y);
        const tk = key(t.a, t.r);
        if (!byKey.has(tk))
          add(
            'error',
            'broken-transition',
            'The transition at (' + t.x + ', ' + t.y + ') leads to a room that does not exist any more.',
            q,
            t.x,
            t.y
          );
        else {
          out_.get(k).push(tk);
          in_.get(tk).push(k);
        }
        if (!dset.has(t.x + ',' + t.y)) stale.push(t);
      });
      if (stale.length)
        add(
          'warn',
          'stale-transition',
          (stale.length === 1
            ? 'A destination is saved at (' + stale[0].x + ', ' + stale[0].y + ')'
            : stale.length + ' destinations are saved at tiles') + ' where there is no transition tile.',
          q,
          stale[0].x,
          stale[0].y
        );
      const miss = d.filter(p => !have.has(p.x + ',' + p.y));
      if (miss.length)
        add(
          'warn',
          'no-destination',
          (miss.length === 1
            ? 'The transition tile at (' + miss[0].x + ', ' + miss[0].y + ') has no destination.'
            : miss.length +
              ' transition tiles have no destination (the first is at ' +
              miss[0].x +
              ', ' +
              miss[0].y +
              ').') + ' Pick one next to "Transition goes to", then paint the tile again.',
          q,
          miss[0].x,
          miss[0].y
        );
    });
    // reachability from the start room
    const seen = new Set([key(start.a.id, start.r.id)]),
      queue = [key(start.a.id, start.r.id)];
    while (queue.length) {
      const k = queue.shift();
      (out_.get(k) || []).forEach(n => {
        if (!seen.has(n)) {
          seen.add(n);
          queue.push(n);
        }
      });
    }
    all.forEach(q => {
      const k = key(q.a.id, q.r.id);
      if (q === start) return;
      if (!in_.get(k).length)
        add('warn', 'no-entrance', 'Nothing leads into this room: no transition from another room points here.', q);
      else if (!seen.has(k))
        add('warn', 'unreachable', 'This room cannot be reached from the start room (' + start.r.n + ').', q);
    });
    // trap rooms: you can get in but there is no way out
    all.forEach(q => {
      const k = key(q.a.id, q.r.id);
      if (!out_.get(k).length && (in_.get(k).length || q === start) && all.length > 1 && q.a.c !== 'p')
        add(
          'warn',
          'softlock-trap',
          q === start
            ? 'The start room has no transition out, so the player cannot leave it.'
            : 'Likely softlock: the player can enter this room but it has no transition out.',
          q
        );
    });
    // one-way doors
    all.forEach(q => {
      const k = key(q.a.id, q.r.id);
      [...new Set(out_.get(k))].forEach(n => {
        if (n !== k && !(out_.get(n) || []).includes(k)) {
          const t = byKey.get(n);
          add('info', 'one-way', 'One-way: this room leads to "' + t.r.n + '" but nothing there leads back.', q);
        }
      });
    });
    // gates nothing can open
    const T = provided(S);
    all.forEach(q =>
      (q.r.ent || []).forEach(e => {
        const p = e.props || {};
        if (e.type === 'door' && p.requires && !need(T, p.requires))
          add(
            'warn',
            'softlock-gate',
            'Likely softlock: this locked door needs "' +
              p.requires +
              '" but no switch, chest, pickup or boss gives it.',
            q,
            e.x,
            e.y
          );
        if (e.type === 'breakable' && p.needs && !need(T, p.needs))
          add(
            'warn',
            'softlock-gate',
            'Likely softlock: this breakable wall needs "' + p.needs + '" but nothing in the world gives it.',
            q,
            e.x,
            e.y
          );
      })
    );
    if (!hasSpawn)
      add(
        'info',
        'no-start',
        'No Start point (spawn) entity is placed. Playtest from the world starts in the first room.',
        start
      );
    // duplicate names inside an area
    (S.areas || []).forEach(a => {
      const seenN = {};
      (a.rooms || []).forEach(r => {
        const n = String(r.n).trim().toLowerCase();
        if (seenN[n])
          add('info', 'duplicate-name', 'Two rooms in "' + a.n + '" are both called "' + r.n + '".', { a, r });
        seenN[n] = 1;
      });
    });
    const order = { error: 0, warn: 1, info: 2 };
    out.sort((p, q) => order[p.sev] - order[q.sev]);
    return out;
  }
  // rooms that have a problem, for the red dots on the map: Map(roomId -> worst severity)
  function problemMap(list) {
    const m = new Map();
    const rank = { error: 3, warn: 2, info: 1 };
    list.forEach(i => {
      if (!i.r || i.sev === 'info') return;
      const o = m.get(i.r);
      if (!o || rank[i.sev] > rank[o]) m.set(i.r, i.sev);
    });
    return m;
  }

  // ---------- copying ----------
  function newId(prefix, used) {
    let id;
    do {
      id = prefix + rid();
    } while (used && used.has(id));
    return id;
  }
  function cloneRoom(r, o) {
    o = o || {};
    const c = clone(r);
    c.id = o.id || newId('r');
    c.n = (o.name != null ? o.name : 'Copy of ' + r.n).slice(0, 30);
    c.x = Math.max(0, (r.x || 0) + (o.dx == null ? 20 : o.dx));
    c.y = Math.max(0, (r.y || 0) + (o.dy == null ? 20 : o.dy));
    return c;
  }
  // a whole area with new ids; transitions that stayed inside the area follow the new rooms
  function cloneArea(a, o) {
    o = o || {};
    const c = clone(a),
      na = o.id || newId('a'),
      map = {};
    c.id = na;
    c.n = (o.name != null ? o.name : 'Copy of ' + a.n).slice(0, 30);
    c.x = Math.max(0, (a.x || 0) + (o.dx == null ? 20 : o.dx));
    c.y = Math.max(0, (a.y || 0) + (o.dy == null ? 20 : o.dy));
    (c.rooms || []).forEach(r => {
      map[r.id] = newId('r');
    });
    (c.rooms || []).forEach(r => {
      r.id = map[r.id];
      (r.tr || []).forEach(t => {
        if (t.a === a.id && map[t.r]) {
          t.a = na;
          t.r = map[t.r];
        }
      });
    });
    c.links = (c.links || []).map(l => [map[l[0]], map[l[1]]]).filter(l => l[0] && l[1]);
    c.pins = (c.pins || []).map(p => ({ ...p, id: newId('p') }));
    return c;
  }
  const CONTENT = ['gw', 'gh', 'grid', 'art', 'table', 'ent', 'tr', 'bg', 'light', 'cam', 'stream'];
  function contentOf(r) {
    const o = {};
    CONTENT.forEach(k => {
      if (r[k] !== undefined) o[k] = clone(r[k]);
    });
    return o;
  }
  function applyContent(r, c) {
    CONTENT.forEach(k => {
      if (c[k] !== undefined) r[k] = clone(c[k]);
    });
    return r;
  }

  // ---------- boxes: snapping and alignment ----------
  const snapTo = (v, g) => (g > 1 ? Math.round(v / g) * g : Math.round(v));
  function alignBoxes(items, how) {
    if (items.length < 2) return;
    const L = Math.min(...items.map(i => i.x)),
      R = Math.max(...items.map(i => i.x + i.w)),
      T = Math.min(...items.map(i => i.y)),
      B = Math.max(...items.map(i => i.y + i.h));
    items.forEach(i => {
      if (how === 'left') i.x = L;
      else if (how === 'right') i.x = R - i.w;
      else if (how === 'center') i.x = Math.round((L + R) / 2 - i.w / 2);
      else if (how === 'top') i.y = T;
      else if (how === 'bottom') i.y = B - i.h;
      else if (how === 'middle') i.y = Math.round((T + B) / 2 - i.h / 2);
    });
  }
  function distribute(items, axis) {
    if (items.length < 3) return;
    const h = axis === 'h',
      s = items.slice().sort((p, q) => (h ? p.x - q.x : p.y - q.y)),
      sz = i => (h ? i.w : i.h);
    const a0 = h ? s[0].x : s[0].y,
      last = s[s.length - 1],
      a1 = (h ? last.x : last.y) + sz(last),
      total = s.reduce((n, i) => n + sz(i), 0),
      gap = (a1 - a0 - total) / (s.length - 1);
    let p = a0;
    s.forEach(i => {
      if (h) i.x = Math.round(p);
      else i.y = Math.round(p);
      p += sz(i) + gap;
    });
  }
  function sameSize(items, ref) {
    items.forEach(i => {
      i.w = ref.w;
      i.h = ref.h;
    });
  }
  // lay boxes out in a neat grid (left to right, top to bottom)
  function arrange(items, gap, x0, y0, width) {
    let x = x0,
      y = y0,
      rowH = 0;
    items.forEach(i => {
      if (x > x0 && x + i.w > width) {
        x = x0;
        y += rowH + gap;
        rowH = 0;
      }
      i.x = x;
      i.y = y;
      x += i.w + gap;
      rowH = Math.max(rowH, i.h);
    });
  }
  // a free spot for a new box of size w x h inside a map of size mw x mh (scans left to right, top to bottom)
  function freeSpot(list, w, h, mw, mh, step) {
    step = step || 10;
    const hit = (x, y) => list.some(i => x < i.x + i.w + 6 && x + w + 6 > i.x && y < i.y + i.h + 6 && y + h + 6 > i.y);
    for (let y = 20; y + h <= mh - 10; y += step)
      for (let x = 20; x + w <= mw - 10; x += step) if (!hit(x, y)) return { x, y };
    return { x: 20, y: Math.min(mh - h, 20) };
  }

  // ---------- doors between rooms ----------
  // find a floor spot beside a room's left or right wall and put a 2 tall transition tile on the edge column. Returns {x,y} of the lower tile.
  function addDoor(r, side) {
    if (!Array.isArray(r.grid)) {
      r.grid = [];
      for (let y = 0; y < r.gh; y++) r.grid.push((y >= r.gh - 2 ? '#' : '.').repeat(r.gw));
    }
    const g = r.grid,
      W = g[0].length,
      H = g.length,
      ex = side === 'l' ? 0 : W - 1,
      ix = side === 'l' ? Math.min(1, W - 1) : Math.max(W - 2, 0);
    let fy = -1;
    for (let y = H - 2; y >= 1; y--) {
      const c = g[y][ix],
        b = g[y + 1][ix];
      if (c === '.' && SOLID.includes(b)) {
        fy = y;
        break;
      }
    }
    if (fy < 1) fy = Math.max(2, H - 3);
    [fy, fy - 1].forEach(y => {
      g[y] = g[y].slice(0, ex) + 'D' + g[y].slice(ex + 1);
    });
    return {
      x: ex,
      y: fy,
      tiles: [
        { x: ex, y: fy },
        { x: ex, y: fy - 1 }
      ]
    };
  }
  // two-way transition between two rooms of one area (left/right chosen from where their boxes sit on the map)
  function connect(areaId, A, B) {
    if (
      (A.tr || []).some(t => t.a === areaId && t.r === B.id) &&
      (B.tr || []).some(t => t.a === areaId && t.r === A.id)
    )
      return false;
    const aLeft = A.x + A.w / 2 <= B.x + B.w / 2;
    A.tr = A.tr || [];
    B.tr = B.tr || [];
    if (!A.tr.some(t => t.a === areaId && t.r === B.id)) {
      const p = addDoor(A, aLeft ? 'r' : 'l');
      p.tiles.forEach(t => A.tr.push({ x: t.x, y: t.y, a: areaId, r: B.id }));
    }
    if (!B.tr.some(t => t.a === areaId && t.r === A.id)) {
      const q = addDoor(B, aLeft ? 'l' : 'r');
      q.tiles.forEach(t => B.tr.push({ x: t.x, y: t.y, a: areaId, r: A.id }));
    }
    return true;
  }

  // take the doors between two rooms away again (the transition tiles turn back into empty space)
  function disconnect(areaId, A, B) {
    let n = 0;
    [
      [A, B],
      [B, A]
    ].forEach(([P, Q]) => {
      const gone = (P.tr || []).filter(t => t.a === areaId && t.r === Q.id);
      gone.forEach(t => {
        if (Array.isArray(P.grid) && P.grid[t.y] && P.grid[t.y][t.x] === 'D')
          P.grid[t.y] = P.grid[t.y].slice(0, t.x) + '.' + P.grid[t.y].slice(t.x + 1);
        n++;
      });
      P.tr = (P.tr || []).filter(t => !(t.a === areaId && t.r === Q.id));
    });
    return n;
  }

  // ---------- templates ----------
  function mkGrid(w, h) {
    const g = [];
    for (let y = 0; y < h; y++) g.push(new Array(w).fill('.'));
    return g;
  }
  const put = (g, x, y, c) => {
    if (y >= 0 && y < g.length && x >= 0 && x < g[0].length) g[y][x] = c;
  };
  const box = (g, x0, y0, x1, y1, c) => {
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) put(g, x, y, c);
  };
  const shell = (w, h, floor) => {
    const g = mkGrid(w, h);
    box(g, 0, h - floor, w - 1, h - 1, '#');
    box(g, 0, 0, w - 1, 1, '#');
    box(g, 0, 0, 1, h - 1, '#');
    box(g, w - 2, 0, w - 1, h - 1, '#');
    return g;
  };
  const doorL = (g, y) => {
    const h = g.length;
    put(g, 0, y, 'D');
    put(g, 0, y - 1, 'D');
    put(g, 1, y, '.');
    put(g, 1, y - 1, '.');
    void h;
  };
  const doorR = (g, y) => {
    const w = g[0].length;
    put(g, w - 1, y, 'D');
    put(g, w - 1, y - 1, 'D');
    put(g, w - 2, y, '.');
    put(g, w - 2, y - 1, '.');
  };
  const rows = g => g.map(r => r.join(''));
  const ent = (type, x, y, props) => ({ id: 'e' + rid(), type, x, y, props: props || {} });
  const TEMPLATES = [
    {
      id: 'corridor',
      name: 'Corridor',
      desc: 'A long, low hallway with a door at each end.',
      make() {
        const w = 60,
          h = 14,
          g = shell(w, h, 2);
        doorL(g, h - 3);
        doorR(g, h - 3);
        return { gw: w, gh: h, grid: rows(g), ent: [] };
      }
    },
    {
      id: 'arena',
      name: 'Arena',
      desc: 'A wide room with three platforms and a door on each side.',
      make() {
        const w = 40,
          h = 22,
          g = shell(w, h, 2);
        box(g, 8, 15, 13, 15, '=');
        box(g, 26, 15, 31, 15, '=');
        box(g, 17, 10, 22, 10, '=');
        doorL(g, h - 3);
        doorR(g, h - 3);
        return { gw: w, gh: h, grid: rows(g), ent: [] };
      }
    },
    {
      id: 'save',
      name: 'Save room',
      desc: 'A small safe room with a checkpoint and two doors.',
      make() {
        const w = 20,
          h = 12,
          g = shell(w, h, 2);
        doorL(g, h - 3);
        doorR(g, h - 3);
        return { gw: w, gh: h, grid: rows(g), ent: [ent('checkpoint', 10, h - 3)] };
      }
    },
    {
      id: 'shaft',
      name: 'Vertical shaft',
      desc: 'A tall climb with alternating ledges, door at the bottom and the top.',
      make() {
        const w = 14,
          h = 40,
          g = shell(w, h, 2);
        for (let i = 0; i < 6; i++) box(g, i % 2 ? 7 : 2, h - 7 - i * 5, i % 2 ? 11 : 6, h - 7 - i * 5, '=');
        doorL(g, h - 3);
        doorR(g, 5);
        return { gw: w, gh: h, grid: rows(g), ent: [] };
      }
    },
    {
      id: 'hub',
      name: 'Hub',
      desc: 'A big room with three levels and three doors.',
      make() {
        const w = 50,
          h = 28,
          g = shell(w, h, 2);
        box(g, 6, 19, 20, 19, '=');
        box(g, 29, 19, 43, 19, '=');
        box(g, 16, 12, 33, 12, '=');
        doorL(g, h - 3);
        doorR(g, h - 3);
        doorR(g, 10);
        return { gw: w, gh: h, grid: rows(g), ent: [] };
      }
    },
    {
      id: 'boss',
      name: 'Boss arena',
      desc: 'An empty walled arena with one door. Add the boss from Entities.',
      make() {
        const w = 36,
          h = 20,
          g = shell(w, h, 2);
        doorL(g, h - 3);
        return { gw: w, gh: h, grid: rows(g), ent: [] };
      }
    }
  ];
  // content for a new room from a template (built in or your own saved one)
  function fromTemplate(t) {
    const c = typeof t.make === 'function' ? t.make() : clone(t);
    delete c.id;
    delete c.name;
    if (!c.art) c.art = [];
    if (!c.table) c.table = [];
    if (!c.tr) c.tr = [];
    c.tr = [];
    if (!c.ent) c.ent = [];
    return c;
  }
  // a template from a room (tiles, sprites, entities, background, settings; destinations are left out)
  function toTemplate(r, name) {
    const c = contentOf(r);
    c.tr = [];
    c.id = newId('t');
    c.name = String(name || r.n || 'Template').slice(0, 30);
    c.w = r.w;
    c.h = r.h;
    return c;
  }

  MV.World = {
    key,
    everyRoom,
    dTiles,
    contents,
    MARKS,
    MANUAL,
    autoMarks,
    marksOf,
    FILTERS,
    roomHas,
    matchRoom,
    matchArea,
    transitions,
    neighbours,
    provided,
    validate,
    problemMap,
    newId,
    cloneRoom,
    cloneArea,
    contentOf,
    applyContent,
    CONTENT,
    snapTo,
    alignBoxes,
    distribute,
    sameSize,
    arrange,
    freeSpot,
    addDoor,
    connect,
    disconnect,
    TEMPLATES,
    fromTemplate,
    toTemplate
  };
})(typeof window !== 'undefined' ? window : globalThis);
