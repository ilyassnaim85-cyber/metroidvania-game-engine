// Player sprite and animations: one animation per state, frames read in order from a sprite sheet.
window.MV = window.MV || {};
MV.PlayerSprite = {
  states: [
    'idle',
    'run',
    'jump',
    'fall',
    'dash',
    'wall',
    'attack',
    'swim',
    'land',
    'hurt',
    'die',
    'pickup',
    'checkpoint',
    'chest',
    'sign',
    'talk',
    'crouch',
    'sprint',
    'morph',
    'ledge',
    'pullup',
    'swing',
    'zip',
    'burrow',
    'phase',
    'ride',
    'cannon',
    'drown',
    'fly'
  ],
  // Behaviour animations play once when something happens (they are not movement). 'freeze' holds the player still while they play.
  once: ['land', 'hurt', 'die', 'pickup', 'checkpoint', 'chest', 'sign'],
  fb: {
    sprint: 'run',
    morph: 'crouch',
    ledge: 'wall',
    pullup: 'jump',
    zip: 'wall',
    swing: 'jump',
    burrow: 'crouch',
    ride: 'idle',
    cannon: 'jump',
    drown: 'swim',
    phase: 'dash',
    fly: 'jump'
  }, // when a state has no animation, the nearest one plays
  def: () => ({ w: 1.5, h: 1.5, anims: {} }),
  // Where Animation Studio clips come from (the editor and the game replace this with the project's clip list).
  clips: () => [],
  // How long a behaviour animation plays once: a sheet animation by its frames, a Studio clip by its own timing.
  len(a) {
    if (a && a.clip) {
      const c = MV.Anim && MV.Anim.find(this.clips(), a.clip);
      return c && c.frames.length ? Math.max(0.05, MV.Anim.compile(c).cycle) : 0.5;
    }
    return a ? a.frames / a.fps : 0.5;
  },
  clean(o) {
    if (!o || typeof o !== 'object') return this.def();
    const N = (v, a, b, d) => (v !== null && v !== '' && isFinite(+v) ? Math.min(b, Math.max(a, +v)) : d),
      out = { w: N(o.w, 0.5, 6, 1.5), h: N(o.h, 0.5, 6, 1.5), anims: {} };
    this.states.forEach(s => {
      const a = o.anims && o.anims[s];
      if (a && typeof a.clip === 'string' && /^[\w-]{1,32}$/.test(a.clip))
        out.anims[s] = {
          clip: a.clip,
          sheet: typeof a.sheet === 'string' ? a.sheet : '',
          col: Math.floor(N(a.col, 0, 255, 0)),
          row: Math.floor(N(a.row, 0, 255, 0)),
          frames: Math.floor(N(a.frames, 1, 64, 1)),
          fps: N(a.fps, 1, 60, 8),
          loop: a.loop !== false,
          freeze: a.freeze === true
        }; // a clip from the Animation Studio
      else if (a && typeof a.sheet === 'string' && a.sheet)
        out.anims[s] = {
          sheet: a.sheet,
          col: Math.floor(N(a.col, 0, 255, 0)),
          row: Math.floor(N(a.row, 0, 255, 0)),
          frames: Math.floor(N(a.frames, 1, 64, 1)),
          fps: N(a.fps, 1, 60, 8),
          loop: a.loop !== false,
          freeze: a.freeze === true
        };
    });
    return out;
  },
  state: p =>
    p.act
      ? p.act.s
      : p.atk > 0
        ? 'attack'
        : p.xst
          ? p.xst
          : p.hst && p.hst !== 'sprint'
            ? p.hst
            : p.hst === 'sprint' && p.on && Math.abs(p.vx) > 0.5
              ? 'sprint'
              : p.mv
                ? 'dash'
                : p.swimming
                  ? 'swim'
                  : !p.on && p.wall
                    ? 'wall'
                    : !p.on
                      ? p.vy < 0
                        ? 'jump'
                        : 'fall'
                      : Math.abs(p.vx) > 0.5
                        ? 'run'
                        : 'idle',
  // Draws one frame with the feet at (fx, fy) pixels. sheetOf(id) -> {img, tw, th}. Returns false when there is nothing to draw.
  frame(ctx, sp, sheetOf, state, t, fx, fy, face, Z) {
    const a = sp.anims[state] || sp.anims[this.fb[state]] || sp.anims.idle;
    if (!a) return false;
    if (a.clip) {
      // a clip from the Animation Studio, drawn with its feet at the spot and its height fitted to the player's draw height
      const c = MV.Anim && MV.Anim.find(this.clips(), a.clip);
      if (!c || !c.frames.length) return false;
      const cyc = MV.Anim.compile(c).cycle,
        sm = MV.Anim.sample(c, a.loop === false ? Math.min(t, Math.max(0, cyc - 0.001)) : t),
        f0 = sm.frame,
        s0 = f0 && sheetOf(f0.sheet);
      if (!s0) return false;
      return MV.Anim.draw(ctx, c, sm, sheetOf, fx, fy, { scale: (sp.h * Z) / s0.th, flipX: face < 0 });
    }
    const sh = sheetOf(a.sheet);
    if (!sh || !sh.img || !sh.img.complete || !sh.img.naturalWidth) return false;
    const cols = Math.max(1, Math.floor(sh.img.naturalWidth / sh.tw)),
      f = a.loop ? Math.floor(t * a.fps) % a.frames : Math.min(a.frames - 1, Math.floor(t * a.fps));
    const i = a.row * cols + a.col + f,
      w = sp.w * Z,
      h = sp.h * Z;
    ctx.save();
    ctx.imageSmoothingEnabled = false;
    ctx.translate(fx, fy);
    if (face < 0) ctx.scale(-1, 1);
    ctx.drawImage(sh.img, (i % cols) * sh.tw, Math.floor(i / cols) * sh.th, sh.tw, sh.th, -w / 2, -h, w, h);
    ctx.restore();
    return true;
  }
};
