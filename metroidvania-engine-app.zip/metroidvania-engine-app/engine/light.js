// Lighting: a room can be dark (room light level below 1). Lights - the player's own light, Light entities and Lamps - cut soft holes in the darkness.
// Light is blocked by walls (it casts real shadows), coloured lights add a glow on top of the scene, and lamps can flicker.
// A Lamp can also have a colour (it tints the area it lights) and a shape: a circle, or a polygon with any number of corners you place yourself.
// Levels run from 0 (pitch black) to 1 (fully lit). Radii are in whatever unit you pass (tiles in room data, pixels when drawing).
(function (root) {
  const MV = (root.MV = root.MV || {});
  const num = (v, a, b, d) =>
    v === null || v === '' || v === undefined || !isFinite(+v) ? d : Math.min(b, Math.max(a, +v));
  // Per-room settings: ambient = room light level, pr = player light radius (tiles), pl = player light level.
  const AMBIENT_HEX = '#0d1226'; // dark blue-black: the room's own darkness
  const def = () => ({ ambient: 1, pr: 6, pl: 1, tint: AMBIENT_HEX, hz: 0.6 });
  const clean = l =>
    l && typeof l === 'object'
      ? {
          ambient: num(l.ambient, 0, 1, 1),
          pr: num(l.pr, 0, 40, 6),
          pl: num(l.pl, 0, 1, 1),
          tint: hex(l.tint) || AMBIENT_HEX,
          hz: num(l.hz, 0, 1, 0.6)
        }
      : null;
  // A light is brightest in the middle and fades smoothly to nothing at its radius (no visible ring or kink).
  const falloff = t => (t >= 1 ? 0 : (1 - t * t) * (1 - t * t));
  // A lamp has an edge softness: 0 = full strength right up to its radius and a sharp edge, 1 = fades from the middle. The effect never goes past the radius or the polygon.
  const profile = (t, soft) => {
    if (t >= 1) return 0;
    if (!(soft > 0)) return 1;
    const u = (1 - t) / soft;
    return u >= 1 ? 1 : u * u * (3 - 2 * u);
  };
  const stopCache = {},
    stopsFor = soft => {
      const k = Math.round(soft * 100);
      if (!stopCache[k]) {
        const a = [],
          e = Math.max(0.001, soft);
        for (let i = 0; i <= 16; i++) {
          const t = 1 - e + (e * i) / 16;
          if (t >= 0 && t < 1) a.push([t, profile(t, soft)]);
        }
        if (!a.length || a[0][0] > 0) a.unshift([0, 1]);
        a.push([1, 0]);
        stopCache[k] = a;
      }
      return stopCache[k];
    };
  const FLAT = [
    [0, 1],
    [1, 1]
  ];
  const STOPS = Array.from({ length: 11 }, (_, i) => [i / 10, falloff(i / 10)]);

  // ---- colours ("#rrggbb") ----
  const hex = c => (/^#[0-9a-f]{6}$/i.test(c) ? c.toLowerCase() : null);
  const rgb = c => {
    const h = hex(c) || '#000000';
    return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
  };
  const toHex = (r, g, b) =>
    '#' +
    [r, g, b]
      .map(v =>
        Math.round(num(v, 0, 255, 0))
          .toString(16)
          .padStart(2, '0')
      )
      .join('');
  const LAMP = '#ffd699'; // a soft warm white-orange

  // ---- polygon shapes: corners are [x, y] offsets from the lamp's centre, in tiles ----
  const regular = (n, r) => {
    n = Math.max(3, Math.min(16, Math.round(+n) || 5));
    r = +r || 5;
    return Array.from({ length: n }, (_, i) => {
      const a = -Math.PI / 2 + (i * 2 * Math.PI) / n;
      return [Math.round(Math.cos(a) * r * 100) / 100, Math.round(Math.sin(a) * r * 100) / 100];
    });
  };
  const cleanPts = p =>
    Array.isArray(p) &&
    p.length >= 3 &&
    p.length <= 16 &&
    p.every(q => Array.isArray(q) && isFinite(+q[0]) && isFinite(+q[1]))
      ? p.map(q => [num(q[0], -40, 40, 0), num(q[1], -40, 40, 0)])
      : null;
  const inside = (pts, x, y) => {
    let c = false;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const a = pts[i],
        b = pts[j];
      if (a[1] > y !== b[1] > y && x < ((b[0] - a[0]) * (y - a[1])) / (b[1] - a[1]) + a[0]) c = !c;
    }
    return c;
  };
  const edgeDist = (pts, x, y) => {
    let m = Infinity;
    for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      const a = pts[j],
        b = pts[i],
        dx = b[0] - a[0],
        dy = b[1] - a[1],
        L = dx * dx + dy * dy,
        t = L ? Math.max(0, Math.min(1, ((x - a[0]) * dx + (y - a[1]) * dy) / L)) : 0;
      m = Math.min(m, Math.hypot(x - a[0] - t * dx, y - a[1] - t * dy));
    }
    return m;
  };
  const softOf = r => Math.max(0.01, r * 0.3); // how wide a polygon's soft edge is

  // A light's strength (0 to 1) at a point, before its level is applied.
  // Distance from the middle in units of the radius. With an egg value ov (0 = a circle) the shape is wider than tall, narrower on top and fuller below, like an egg.
  const eggUp = ov => 1 - ov * 0.5,
    eggDown = ov => 1 + ov * 0.6;
  const radial = (l, x, y) => {
    const ov = l.ov || 0,
      dy = y - l.y;
    return ov > 0
      ? Math.hypot((x - l.x) / (1 + ov), dy / (dy < 0 ? eggUp(ov) : eggDown(ov))) / l.r
      : Math.hypot(x - l.x, dy) / l.r;
  };
  const shapeAt = (l, x, y) =>
    l.shape === 'polygon' && l.pts
      ? inside(l.pts, x, y)
        ? 1
        : l.soft === undefined
          ? Math.max(0, 1 - edgeDist(l.pts, x, y) / softOf(l.r))
          : l.soft > 0
            ? Math.max(0, 1 - edgeDist(l.pts, x, y) / (l.r * l.soft * 0.5))
            : 0
      : l.soft === undefined
        ? falloff(radial(l, x, y))
        : profile(radial(l, x, y), l.soft);
  // How bright it is at a point: 1 = fully lit, 0 = pitch black. lights: [{ x, y, r, level, shape?, pts? }], zones (optional): [{ x, y, r, amount, shape?, pts? }].
  const levelAt = (ambient, lights, x, y, zones) => {
    let b = ambient;
    for (const z of zones || []) if (z.r > 0 && z.amount > 0) b *= 1 - z.amount * shapeAt(z, x, y);
    for (const l of lights) if (l.r > 0 && l.level > 0) b = 1 - (1 - b) * (1 - l.level * shapeAt(l, x, y));
    return b;
  };

  // Where a lamp or darkness entity sits and what shape it has, in tiles: a circle, or a polygon with pts as offsets from the entity.
  const geom = e => {
    const p = e.props || {},
      cx = e.x + 0.5,
      cy = e.y + 0.5;
    if (p.shape === 'polygon') {
      const rel = cleanPts(p.pts) || regular(p.sides, num(p.radius, 0.5, 40, 5));
      return {
        x: cx,
        y: cy,
        r: Math.max(0.1, ...rel.map(q => Math.hypot(q[0], q[1]))),
        shape: 'polygon',
        pts: rel.map(q => [cx + q[0], cy + q[1]])
      };
    }
    return { x: cx, y: cy, r: num(p.radius, 0, 40, 5), shape: 'circle' };
  };
  // Lights from a room's entity list, in tiles: [{ x, y, r, level, color, shape, pts }]. Light entities have a radius and level. Lamps also have a colour, a shape, flicker and softness.
  const lampOf = e => {
    const p = e.props || {};
    return Object.assign(geom(e), {
      id: e.id,
      level: num(p.level, 0, 1, 1),
      color: hex(p.color) || LAMP,
      flicker: num(p.flicker, 0, 1, 0),
      shadows: p.shadows !== 'no',
      soft: num(p.soft, 0, 1, 0.9)
    });
  };
  const fromEntities = ents =>
    (ents || [])
      .filter(e => e && (e.type === 'light' || e.type === 'lamp'))
      .map(e =>
        e.type === 'lamp'
          ? lampOf(e)
          : {
              id: e.id,
              x: e.x + 0.5,
              y: e.y + 0.5,
              r: num((e.props || {}).radius, 0, 40, 5),
              level: num((e.props || {}).level, 0, 1, 1),
              shadows: true
            }
      );
  // Darkness zones: [{ x, y, r, amount, color, shape, pts, soft, walls }]. walls (on by default): the darkness fills the room it is in and stops dead at the walls, with no blur past them.
  const SHADE_HEX = '#04060b'; // near-black: a dark room shows almost nothing outside the light
  const zoneOf = e => {
    const p = e.props || {};
    if (e.type === 'lightzone')
      return Object.assign(geom(e), {
        id: e.id,
        amount: num(p.dark, 0, 1, 1),
        color: hex(p.color) || SHADE_HEX,
        soft: num(p.soft, 0, 1, 0.2),
        walls: p.walls !== 'no',
        bleed: num(p.bleed, 0, 1, 0.2),
        ov: 0,
        lz: true
      });
    return Object.assign(geom(e), {
      id: e.id,
      amount: p.amount === undefined || p.amount === 0.8 || p.amount === 0.85 ? 1 : num(p.amount, 0, 1, 1),
      color: hex(p.color) && hex(p.color) !== '#1a2040' && hex(p.color) !== '#2c2f36' ? hex(p.color) : SHADE_HEX,
      soft: num(p.soft, 0, 1, 0.5),
      walls: p.walls !== 'no',
      bleed: num(p.bleed, 0, 1, 0.2),
      ov: num(p.oval, 0, 1, 0)
    });
  };
  const zonesFromEntities = ents =>
    (ents || []).filter(e => e && (e.type === 'darkness' || e.type === 'lightzone')).map(zoneOf); // light zones are darkness zones whose amount the game changes as you walk in and out
  // Converts a light or zone from tiles to pixels: x*k - ox, y*k - oy.
  const scale = (l, k, ox, oy) => {
    const o = { x: l.x * k - ox, y: l.y * k - oy, r: l.r * k };
    ['level', 'amount', 'id', 'color', 'shape', 'flicker', 'shadows', 'walls', 'bleed', 'ov', 'soft'].forEach(f => {
      if (l[f] !== undefined) o[f] = l[f];
    });
    if (l.pts) o.pts = l.pts.map(q => [q[0] * k - ox, q[1] * k - oy]);
    return o;
  };

  // A soft-edged polygon, drawn with a shadow: the shape itself is far off screen, only its blurred shadow lands on the canvas.
  function softPoly(g, pts, color, blur) {
    const OFF = 30000;
    g.save();
    g.shadowColor = color;
    g.shadowBlur = blur;
    g.shadowOffsetX = OFF;
    g.shadowOffsetY = 0;
    g.fillStyle = '#000';
    g.beginPath();
    pts.forEach((q, i) => (i ? g.lineTo(q[0] - OFF, q[1]) : g.moveTo(q[0] - OFF, q[1])));
    g.closePath();
    g.fill();
    g.restore();
  }
  const usable = l => l.r > 0 && l.level > 0;
  // Tile surface profiles: for a tile that is only partly solid, the surface height at its left and right edge as a fraction of the tile from the top (0 = full block, 1 = nothing).
  // '/' and '\\' are the steep slopes, '[' ']' are a gentle up-right slope over two tiles, '{' '}' a gentle up-left one, and '_' is a half block.
  const PROFILES = {
    '/': [1, 0],
    '\\': [0, 1],
    '[': [1, 0.5],
    ']': [0.5, 0],
    '{': [0, 0.5],
    '}': [0.5, 1],
    _: [0.5, 0.5]
  };
  const FULL_LIGHT = '#gim><usw',
    FULL_DARK = '#im><usw'; // tiles that are full blocks for light (g = shade wall: blocks light but darkness passes), and for darkness
  // What a tile means to light: true (full block), its profile character (partly solid), or false (open; the invisible wall lets light through).
  const tileSolid = ch => (PROFILES[ch] ? ch : FULL_LIGHT.indexOf(ch) >= 0);
  const tileZsolid = ch => FULL_DARK.indexOf(ch) >= 0;
  // Walls: how far a ray from (x, y) travels before it hits a solid tile (grid walk). A light inside a wall shines out through the wall it sits in.
  // solid(tx, ty) says true for a full block, '/' or '\\' for a slope tile (only the half under its diagonal is solid, so light follows the slope instead of stair steps), falsy for open air.
  function castRay(x, y, dx, dy, maxD, solid) {
    let tx = Math.floor(x),
      ty = Math.floor(y);
    const sx = dx > 0 ? 1 : -1,
      sy = dy > 0 ? 1 : -1,
      tdx = dx ? Math.abs(1 / dx) : Infinity,
      tdy = dy ? Math.abs(1 / dy) : Infinity;
    let mx = dx > 0 ? (tx + 1 - x) * tdx : dx < 0 ? (x - tx) * tdx : Infinity,
      my = dy > 0 ? (ty + 1 - y) * tdy : dy < 0 ? (y - ty) * tdy : Infinity,
      d = 0;
    // Distance at which the ray first is inside tile (ax, ay)'s solid part while travelling from d0 to d1 inside that tile, or -1.
    const enter = (v, ax, ay, d0, d1) => {
      const pf = PROFILES[v];
      if (pf) {
        const f = t => {
            const u = x + dx * t - ax,
              w = y + dy * t - ay;
            return w - pf[0] - (pf[1] - pf[0]) * u;
          },
          f0 = f(d0);
        if (f0 >= 0) return d0;
        const f1 = f(d1);
        return f1 < 0 ? -1 : d0 + ((d1 - d0) * f0) / (f0 - f1);
      }
      return v ? d0 : -1;
    };
    const h0 = enter(solid(tx, ty), tx, ty, 0, Math.min(mx, my));
    let inWall = h0 === 0;
    if (h0 > 0) return Math.min(h0, maxD);
    while (d < maxD) {
      if (Math.abs(mx - my) < 1e-9 && !inWall && solid(tx + sx, ty) === true && solid(tx, ty + sy) === true)
        return Math.min(Math.min(mx, my), maxD); // a ray through the corner where two solid blocks touch diagonally is blocked
      if (mx < my) {
        d = mx;
        mx += tdx;
        tx += sx;
      } else {
        d = my;
        my += tdy;
        ty += sy;
      }
      const h = enter(solid(tx, ty), tx, ty, d, Math.min(mx, my));
      if (inWall) {
        if (h !== d) {
          inWall = false;
          if (h >= 0) return Math.min(h, maxD);
        }
      } else if (h >= 0) return Math.min(h, maxD);
    }
    return maxD;
  }
  // The area a light can see, as a polygon in the light's own units (tiles). It reaches a little way into walls so their faces catch the light.
  function visibility(x, y, r, solid) {
    const n = Math.max(90, Math.min(360, Math.round(r * 20))),
      pts = [];
    for (let i = 0; i < n; i++) {
      const a = (i * 2 * Math.PI) / n,
        dx = Math.cos(a),
        dy = Math.sin(a),
        d = castRay(x, y, dx, dy, r + 1, solid);
      pts.push([x + dx * Math.min(r * 1.05, d + 0.55), y + dy * Math.min(r * 1.05, d + 0.55)]);
    }
    return pts;
  }
  // The tiles a darkness zone covers: open tiles connected to its middle (inside its shape). Walls are not shaded and stop it at their face; it never reaches the other side.
  function zoneTiles(z, solid, k, ox, oy) {
    const cx = (z.x + ox) / k,
      cy = (z.y + oy) / k,
      r = z.r / k,
      tz = Object.assign({}, z, {
        x: cx,
        y: cy,
        r: r + 0.8,
        soft: undefined,
        pts: z.pts && z.pts.map(q => [(q[0] + ox) / k, (q[1] + oy) / k])
      });
    const R = r * (1 + (z.ov || 0)),
      x0 = Math.floor(cx - R) - 2,
      y0 = Math.floor(cy - R) - 2,
      w = Math.ceil(R * 2) + 5,
      h = w,
      seen = new Uint8Array(w * h),
      out = [],
      stack = [],
      D4 = [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1]
      ];
    const inZone = (tx, ty) =>
      tx >= x0 && ty >= y0 && tx < x0 + w && ty < y0 + h && shapeAt(tz, tx + 0.5, ty + 0.5) > 0;
    const add = (tx, ty, wall) => {
      const i = (ty - y0) * w + (tx - x0);
      if (seen[i]) return;
      seen[i] = 1;
      if (!wall) {
        out.push([tx, ty]);
        stack.push([tx, ty]);
      }
    };
    const sx = Math.floor(cx),
      sy = Math.floor(cy);
    if (!solid(sx, sy)) add(sx, sy, false);
    else
      D4.forEach(d => {
        if (!solid(sx + d[0], sy + d[1]) && inZone(sx + d[0], sy + d[1])) add(sx + d[0], sy + d[1], false);
      });
    while (stack.length) {
      const t = stack.pop();
      for (const d of D4) {
        const nx = t[0] + d[0],
          ny = t[1] + d[1];
        if (inZone(nx, ny)) add(nx, ny, solid(nx, ny));
      }
    }
    return out;
  }
  const flick = (l, t) => {
    if (!(l.flicker > 0) || t === undefined) return 1;
    const s = (l.x * 12.9 + l.y * 78.2) % 6.28;
    return (
      1 -
      l.flicker * (0.5 + 0.25 * Math.sin(t * 17 + s) + 0.25 * Math.sin(t * 6.3 + s * 2.1) * Math.sin(t * 23 + s)) * 0.9
    );
  };
  const layer = (cache, name, w, h) => {
    const c = cache[name] || (cache[name] = root.document.createElement('canvas'));
    if (c.width !== w || c.height !== h) {
      c.width = w;
      c.height = h;
    }
    return c;
  };
  // Draws the darkness over ctx. spec = { w, h, ambient, lights:[{x, y, r, level, color?, shape?, pts?, flicker?, shadows?, soft?}], zones?:[{x, y, r, amount, color?, shape?, pts?, soft?, walls?, bleed?}], solid? (true = block, '/' or '\\' = slope tile), zsolid? (walls that stop darkness; defaults to solid; leave slope tiles out), slope? (tx, ty) => '/' | '\\' | null for slope tiles, k?, ox?, oy?, time? } in pixels.
  // solid(tx, ty) says whether a tile blocks light; k is pixels per tile and ox, oy the pixel offset (pixel = tile * k - o). cache is any object you keep between frames.
  // Order: the room's darkness, then darkness zones add shade, then lights cut through all of it. Coloured lights add a glow on top, even in a fully lit room.
  function draw(ctx, spec, cache) {
    const amb = spec.ambient,
      dark = 1 - amb,
      W = spec.w,
      H = spec.h,
      lights = spec.lights.filter(usable),
      zones = (spec.zones || []).filter(z => z.r > 0 && z.amount > 0),
      tinted = lights.some(l => l.color);
    if (!(dark > 0) && !tinted && !zones.length) return false;
    const dk = layer(cache, 'dk', W, H),
      gl = layer(cache, 'gl', W, H),
      sc = layer(cache, 'sc', W, H),
      mk = layer(cache, 'mk', W, H),
      tc = layer(cache, 'tc', W, H);
    const D = dk.getContext('2d'),
      G = gl.getContext('2d'),
      S = sc.getContext('2d'),
      M = mk.getContext('2d'),
      T = tc.getContext('2d'),
      k = spec.k || 24,
      ox = spec.ox || 0,
      oy = spec.oy || 0,
      soft = Math.max(2, k * 0.3);
    D.globalCompositeOperation = 'source-over';
    D.globalAlpha = 1;
    D.clearRect(0, 0, W, H);
    if (dark > 0) {
      D.fillStyle = 'rgba(' + rgb(hex(spec.tint) || AMBIENT_HEX).join(',') + ',' + dark + ')';
      D.fillRect(0, 0, W, H);
    }
    G.globalCompositeOperation = 'source-over';
    G.clearRect(0, 0, W, H);
    // Paints a light's or zone's shape into the scratch layer as white with alpha = strength; returns the area it covers, or null when it is off screen.
    const shape = (l, strength, walls, flat) => {
      const R = l.r * (1 + (l.shape === 'polygon' ? 0 : l.ov || 0)),
        x0 = Math.max(0, Math.floor(l.x - R - 2)),
        y0 = Math.max(0, Math.floor(l.y - R - 2)),
        x1 = Math.min(W, Math.ceil(l.x + R + 2)),
        y1 = Math.min(H, Math.ceil(l.y + R + 2)),
        bw = x1 - x0,
        bh = y1 - y0;
      if (bw <= 0 || bh <= 0) return null;
      S.globalCompositeOperation = 'source-over';
      S.clearRect(x0, y0, bw, bh); // 1. brightness: full in the middle, easing out to the edge
      const stops =
          l.shape === 'polygon' && l.pts
            ? FLAT
            : flat
              ? [
                  [0, 1],
                  [1 - (l.soft === undefined ? 0.15 : l.soft * 0.3), 1],
                  [1, 0]
                ]
              : l.soft === undefined
                ? STOPS
                : stopsFor(l.soft),
        ov = l.shape === 'polygon' ? 0 : l.ov || 0;
      if (ov > 0)
        for (const up of [true, false]) {
          const sy = up ? eggUp(ov) : eggDown(ov),
            g2 = S.createRadialGradient(0, 0, 0, 0, 0, l.r);
          stops.forEach(st => g2.addColorStop(st[0], 'rgba(255,255,255,' + strength * st[1] + ')'));
          S.save();
          S.beginPath();
          S.rect(x0, up ? y0 : l.y, bw, up ? l.y - y0 : y1 - l.y);
          S.clip();
          S.translate(l.x, l.y);
          S.scale(1 + ov, sy);
          S.fillStyle = g2;
          S.fillRect((x0 - l.x) / (1 + ov), (y0 - l.y) / sy, bw / (1 + ov), bh / sy);
          S.restore();
        }
      else {
        const gr = S.createRadialGradient(l.x, l.y, 0, l.x, l.y, l.r);
        stops.forEach(st => gr.addColorStop(st[0], 'rgba(255,255,255,' + strength * st[1] + ')'));
        S.fillStyle = gr;
        S.fillRect(x0, y0, bw, bh);
      }
      S.globalCompositeOperation = 'destination-in';
      if (l.shape === 'polygon' && l.pts) {
        M.clearRect(x0, y0, bw, bh);
        softPoly(M, l.pts, '#fff', l.soft === undefined ? soft : l.r * l.soft * 0.5);
        S.drawImage(mk, x0, y0, bw, bh, x0, y0, bw, bh);
      } // 2. its own shape: nothing outside it
      if (walls && spec.solid) {
        const v = visibility((l.x + ox) / k, (l.y + oy) / k, l.r / k, spec.solid).map(q => [
          q[0] * k - ox,
          q[1] * k - oy
        ]); // 3. walls block it
        M.clearRect(x0, y0, bw, bh);
        softPoly(M, v, '#fff', soft);
        S.drawImage(mk, x0, y0, bw, bh, x0, y0, bw, bh);
      }
      S.globalCompositeOperation = 'source-over';
      return { x0, y0, bw, bh };
    };
    for (const z of zones) {
      const zs = spec.zsolid || spec.solid,
        wl = z.walls !== false && !!zs,
        b = shape(z, z.amount, false, wl);
      if (!b) continue; // darkness zone: add shade in its colour
      if (wl) {
        // walls stop it: keep only the room's open tiles, ending at the wall faces
        const slopeOf = spec.slope || (() => null),
          all = zoneTiles(z, zs, k, ox, oy),
          tiles = all.filter(t => !slopeOf(t[0], t[1])).sort((a, c) => a[1] - c[1] || a[0] - c[0]);
        M.clearRect(b.x0, b.y0, b.bw, b.bh);
        M.fillStyle = '#fff';
        for (let i = 0; i < tiles.length; ) {
          let j = i;
          while (j + 1 < tiles.length && tiles[j + 1][1] === tiles[i][1] && tiles[j + 1][0] === tiles[j][0] + 1) j++;
          const px0 = Math.round(tiles[i][0] * k - ox),
            px1 = Math.round((tiles[j][0] + 1) * k - ox),
            py0 = Math.round(tiles[i][1] * k - oy),
            py1 = Math.round((tiles[i][1] + 1) * k - oy);
          M.fillRect(px0, py0, px1 - px0, py1 - py0);
          i = j + 1;
        }
        for (const t of all) {
          const sc2 = slopeOf(t[0], t[1]);
          if (!sc2) continue; // a slope tile: only the open triangle above its diagonal is shaded, so the shade follows the slope
          const X0 = Math.round(t[0] * k - ox),
            X1 = Math.round((t[0] + 1) * k - ox),
            Y0 = Math.round(t[1] * k - oy),
            Y1 = Math.round((t[1] + 1) * k - oy);
          const pf = PROFILES[sc2];
          M.beginPath();
          M.moveTo(X0, Y0);
          M.lineTo(X1, Y0);
          M.lineTo(X1, Y0 + pf[1] * (Y1 - Y0));
          M.lineTo(X0, Y0 + pf[0] * (Y1 - Y0));
          M.closePath();
          M.fill();
        }
        if (z.bleed > 0) {
          // wall bleed: the room's shade melts smoothly into the FIRST wall only. It is the room blurred (so turns and corners are naturally round), made full strength at the wall face, fading out inside the wall
          const R = layer(cache, 'rm', W, H).getContext('2d'),
            sg = Math.max(0.5, z.bleed * k * 0.6);
          R.globalCompositeOperation = 'source-over';
          R.filter = 'none';
          R.clearRect(b.x0, b.y0, b.bw, b.bh);
          R.filter = 'blur(' + sg.toFixed(1) + 'px)';
          R.drawImage(mk, b.x0, b.y0, b.bw, b.bh, b.x0, b.y0, b.bw, b.bh);
          R.filter = 'none';
          R.globalCompositeOperation = 'lighter';
          R.drawImage(R.canvas, b.x0, b.y0, b.bw, b.bh, b.x0, b.y0, b.bw, b.bh); // x2: half strength at the face becomes full
          T.globalCompositeOperation = 'source-over';
          T.clearRect(b.x0, b.y0, b.bw, b.bh);
          T.fillStyle = '#fff';
          const opn = new Set(all.map(t => t[0] + ',' + t[1])); // only the first wall: the wall tiles touching the room (a slope tile's solid half counts as wall)
          for (const t of all)
            if (slopeOf(t[0], t[1]))
              T.fillRect(Math.round(t[0] * k - ox), Math.round(t[1] * k - oy), Math.ceil(k), Math.ceil(k));
          for (const t of all)
            for (let dy = -1; dy <= 1; dy++)
              for (let dx = -1; dx <= 1; dx++) {
                const nx = t[0] + dx,
                  ny = t[1] + dy;
                if (zs(nx, ny) && !opn.has(nx + ',' + ny))
                  T.fillRect(Math.round(nx * k - ox), Math.round(ny * k - oy), Math.ceil(k), Math.ceil(k));
              }
          R.globalCompositeOperation = 'destination-in';
          R.drawImage(tc, b.x0, b.y0, b.bw, b.bh, b.x0, b.y0, b.bw, b.bh);
          R.globalCompositeOperation = 'source-over';
          M.drawImage(R.canvas, b.x0, b.y0, b.bw, b.bh, b.x0, b.y0, b.bw, b.bh);
        }
        S.globalCompositeOperation = 'destination-in';
        S.drawImage(mk, b.x0, b.y0, b.bw, b.bh, b.x0, b.y0, b.bw, b.bh);
        S.globalCompositeOperation = 'source-over';
      }
      T.globalCompositeOperation = 'source-over';
      T.clearRect(b.x0, b.y0, b.bw, b.bh);
      T.drawImage(sc, b.x0, b.y0, b.bw, b.bh, b.x0, b.y0, b.bw, b.bh);
      T.globalCompositeOperation = 'source-in';
      T.fillStyle = z.color || SHADE_HEX;
      T.fillRect(b.x0, b.y0, b.bw, b.bh);
      D.globalCompositeOperation = 'source-over';
      D.drawImage(tc, b.x0, b.y0, b.bw, b.bh, b.x0, b.y0, b.bw, b.bh);
    }
    for (const l of lights) {
      const lv = l.level * flick(l, spec.time),
        b = shape(l, lv, l.shadows !== false);
      if (!b) continue; // light: cut it out of the darkness, add its colour as a glow
      D.globalCompositeOperation = 'destination-out';
      D.drawImage(sc, b.x0, b.y0, b.bw, b.bh, b.x0, b.y0, b.bw, b.bh);
      if (l.color) {
        T.globalCompositeOperation = 'source-over';
        T.clearRect(b.x0, b.y0, b.bw, b.bh);
        T.drawImage(sc, b.x0, b.y0, b.bw, b.bh, b.x0, b.y0, b.bw, b.bh);
        T.globalCompositeOperation = 'source-in';
        T.fillStyle = l.color;
        T.fillRect(b.x0, b.y0, b.bw, b.bh);
        G.globalCompositeOperation = 'lighter';
        G.globalAlpha = 0.42;
        G.drawImage(tc, b.x0, b.y0, b.bw, b.bh, b.x0, b.y0, b.bw, b.bh);
        G.globalAlpha = 1;
      }
    }
    D.globalCompositeOperation = 'source-over';
    // Darkness shades the scene instead of covering it: the picture is multiplied by a light map (white = lit, a deep blue-grey = dark), so shapes and colours stay readable in the shade.
    if (dark > 0 || zones.length) {
      const lm = layer(cache, 'lm', W, H),
        Lc = lm.getContext('2d');
      Lc.globalCompositeOperation = 'source-over';
      Lc.fillStyle = '#fff';
      Lc.fillRect(0, 0, W, H);
      Lc.drawImage(dk, 0, 0);
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.drawImage(lm, 0, 0);
      ctx.restore();
    }
    if (tinted) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      ctx.drawImage(gl, 0, 0);
      ctx.restore();
    }
    return true;
  }
  MV.Light = {
    PROFILES,
    tileSolid,
    tileZsolid,
    AMBIENT: AMBIENT_HEX,
    zoneTiles,
    def,
    clean,
    falloff,
    profile,
    levelAt,
    shapeAt,
    fromEntities,
    zonesFromEntities,
    scale,
    draw,
    visibility,
    regular,
    cleanPts,
    geom,
    hex,
    rgb,
    toHex,
    LAMP,
    SHADE: SHADE_HEX
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = MV.Light;
})(typeof window !== 'undefined' ? window : globalThis);
