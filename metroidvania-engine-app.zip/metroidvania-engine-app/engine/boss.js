// Bosses: validation, hitbox animation (keyframes), and the runtime brain (wake, phases, patterns, damage, defeat).
// A pattern is a timeline: hitboxes that move by keyframes, an optional body movement track, and a boss animation.
window.MV = window.MV || {};
MV.Boss = (() => {
  const F = () => MV.data.bossFields;
  const N = (v, a, b, d) =>
    v === null || v === '' || v === undefined || !isFinite(+v) ? d : Math.min(b, Math.max(a, +v));
  const S = (v, d, n) => (typeof v === 'string' ? v.trim().slice(0, n || 30) : d);
  const id = v => (typeof v === 'string' && /^[\w-]{1,24}$/.test(v) ? v : 'x' + Math.random().toString(36).slice(2, 7));
  // Boss pictures come from the Animations tab: one clip per state (an old boss that only has the old sprite animations still draws them where no clip is set).
  const CLIPS = [
    ['passive', 'Asleep (before it sees you)'],
    ['awakened', 'Waking up (plays once, sets how long it takes)'],
    ['idle', 'Normal (between attacks)'],
    ['attack', 'Attacking (when a pattern has no animation of its own)'],
    ['warn', 'Warning before an attack'],
    ['phase', 'Changing phase'],
    ['stun', 'Stunned'],
    ['hurt', 'Hurt'],
    ['die', 'Defeated']
  ];
  const cid = v => (typeof v === 'string' && /^[\w-]{1,24}$/.test(v) ? v : '');
  const anim = a =>
    a && typeof a === 'object' && typeof a.sheet === 'string' && a.sheet
      ? {
          sheet: a.sheet,
          col: Math.floor(N(a.col, 0, 255, 0)),
          row: Math.floor(N(a.row, 0, 255, 0)),
          frames: Math.floor(N(a.frames, 1, 64, 1)),
          fps: N(a.fps, 1, 60, 8),
          loop: a.loop !== false
        }
      : null;
  const kfs = (l, dur, d) => {
    const k = (Array.isArray(l) ? l : [])
      .slice(0, 60)
      .map(q => ({ t: N(q && q.t, 0, dur, 0), x: N(q && q.x, -60, 60, 0), y: N(q && q.y, -60, 60, 0) }))
      .sort((a, b) => a.t - b.t);
    return k.length ? k : d;
  };
  const hitbox = (h, dur) => {
    h = h || {};
    const sp = MV.Attacks
      ? MV.Attacks.shape(h, 1, 1)
      : { shape: 'rect', w: N(h.w, 0.1, 30, 1), h: N(h.h, 0.1, 30, 1), r: 0.5, pts: null };
    return {
      id: id(h.id),
      name: S(h.name, 'Hitbox'),
      shape: sp.shape,
      w: sp.w,
      h: sp.h,
      r: sp.r,
      pts: sp.pts,
      dmg: N(h.dmg, 0, 30, 1),
      from: N(h.from, 0, dur, 0),
      to: N(h.to, 0, dur, dur),
      follow: h.follow === true,
      vis: anim(h.vis),
      kf: kfs(h.kf, dur, [{ t: 0, x: 1.5, y: -1 }]),
      clip: cid(h.clip)
    };
  };
  const pattern = p => {
    p = p || {};
    const dur = N(p.duration, 0.2, 20, 2);
    return {
      id: id(p.id),
      name: S(p.name, 'Pattern'),
      min: N(p.min, 0, 200, 0),
      max: N(p.max, 0, 200, 200),
      vert: ['any', 'player above', 'player level', 'player below'].includes(p.vert) ? p.vert : 'any',
      repeat: Math.floor(N(p.repeat, 1, 8, 1)),
      at: ['any', 'player on ground', 'player in air'].includes(p.at) ? p.at : 'any',
      hpBelow: N(p.hpBelow, 1, 100, 100),
      hpAbove: N(p.hpAbove, 0, 99, 0),
      cd: N(p.cd, 0, 120, 0),
      weight: N(p.weight, 0, 20, 1),
      track: p.track === 'yes' ? 'yes' : 'no',
      aim: p.aim === 'at player' ? 'at player' : 'fixed',
      aimMax: N(p.aimMax, 0, 180, 80),
      reach: p.reach === 'to player' ? 'to player' : 'fixed',
      anim: S(p.anim, '', 24),
      snd: S(p.snd, '', 24).replace(/[^\w-]/g, ''),
      warn: N(p.warn, 0, 5, 0),
      clip: cid(p.clip),
      inv: (Array.isArray(p.inv) ? p.inv : []).slice(0, 8).map(q => {
        const a = N(q && q.from, 0, dur, 0),
          b = N(q && q.to, 0, dur, dur);
        return { from: Math.min(a, b), to: Math.max(a, b) };
      }),
      duration: dur,
      hitboxes: (Array.isArray(p.hitboxes) ? p.hitboxes : []).slice(0, 12).map(h => hitbox(h, dur)),
      body: kfs(p.body, dur, [])
    };
  };
  const blankGrid = (w, h) => {
    const g = [];
    for (let y = 0; y < h; y++) g.push((y >= h - 2 ? '#' : '.').repeat(w));
    return g;
  };
  const arena = a => {
    a = a || {};
    const gw = Math.floor(N(a.gw, 8, 80, 32)),
      gh = Math.floor(N(a.gh, 6, 50, 16));
    const ok =
      Array.isArray(a.grid) && a.grid.length === gh && a.grid.every(r => typeof r === 'string' && r.length === gw);
    return {
      gw,
      gh,
      grid: ok ? a.grid.slice() : blankGrid(gw, gh),
      bx: Math.floor(N(a.bx, 0, gw - 1, Math.floor(gw * 0.7))),
      by: Math.floor(N(a.by, 0, gh - 1, gh - 3))
    };
  };
  function clean(b) {
    b = b || {};
    const o = { id: id(b.id) };
    for (const k in F()) {
      const f = F()[k];
      let v = b[k];
      if (f.t === 'number') v = N(v, f.min, f.max, f.def);
      else if (f.t === 'select') {
        if (!f.o.includes(v)) v = f.def;
      } else v = S(v, f.def);
      o[k] = v;
    }
    const sp = b.sprite || {};
    o.sprite = { w: N(sp.w, 0.5, 12, 3), h: N(sp.h, 0.5, 12, 3), anims: {} };
    for (const k of Object.keys(sp.anims || {}).slice(0, 24)) {
      const a = anim(sp.anims[k]);
      if (a) o.sprite.anims[S(k, '', 24) || 'x'] = a;
    }
    o.clips = {};
    CLIPS.forEach(c => {
      const v = cid(b.clips && b.clips[c[0]]);
      if (v) o.clips[c[0]] = v;
    });
    o.pts = MV.Enemies.ptsOf(b.pts);
    o.weak = MV.Enemies.weakOf(b.weak);
    o.dropItem = S(o.dropItem, '', 24).replace(/[^\w-]/g, '');
    ['wakeSnd', 'hurtSnd', 'phaseSnd', 'dieSnd', 'stunSnd'].forEach(k => {
      o[k] = S(o[k], '', 24).replace(/[^\w-]/g, '');
    });
    o.arena = arena(b.arena);
    const seen = {};
    o.patterns = (Array.isArray(b.patterns) ? b.patterns : [])
      .slice(0, 16)
      .map(pattern)
      .filter(p => !seen[p.id] && (seen[p.id] = 1));
    const ids = o.patterns.map(p => p.id);
    o.phases = (Array.isArray(b.phases) ? b.phases : []).slice(0, 6).map(ph => {
      ph = ph || {};
      return {
        below: N(ph.below, 1, 100, 100),
        idle: N(ph.idle, 0, 10, 1.2),
        speed: N(ph.speed, 0.2, 3, 1),
        enter: N(ph.enter, 0, 10, 0),
        patterns: (Array.isArray(ph.patterns) ? ph.patterns : []).filter(x => ids.includes(x))
      };
    });
    return o;
  }
  const list = l => {
    const seen = {};
    return (Array.isArray(l) ? l : [])
      .slice(0, 24)
      .map(clean)
      .filter(b => !seen[b.id] && (seen[b.id] = 1));
  };
  const find = (l, bid) => (l || []).find(b => b.id === bid);
  // A new boss comes with two example patterns: a claw swipe that follows the boss, and a thrown rock that flies on its own.
  const blank = name =>
    clean({
      name: name || 'New boss',
      select: 'rules',
      speed: 3,
      fly: 'no',
      patterns: [
        {
          name: 'Claw swipe',
          anim: 'attack',
          max: 4,
          track: 'yes',
          warn: 0.5,
          duration: 1.2,
          hitboxes: [
            {
              name: 'Claw',
              w: 1.8,
              h: 1.4,
              from: 0.4,
              to: 0.9,
              follow: true,
              kf: [
                { t: 0.4, x: 1.4, y: -1.4 },
                { t: 0.9, x: 2, y: -0.7 }
              ]
            }
          ]
        },
        {
          name: 'Throw rock',
          anim: 'throw',
          min: 3,
          cd: 2,
          warn: 0.6,
          duration: 2,
          hitboxes: [
            {
              name: 'Rock',
              w: 0.8,
              h: 0.8,
              from: 0.5,
              to: 1.9,
              kf: [
                { t: 0.5, x: 1, y: -2 },
                { t: 1.9, x: 10, y: -0.6 }
              ]
            }
          ]
        }
      ]
    });
  const sample = (k, t) => {
    if (!k.length) return { x: 0, y: 0 };
    if (t <= k[0].t) return k[0];
    for (let i = 1; i < k.length; i++)
      if (t <= k[i].t) {
        const a = k[i - 1],
          b = k[i],
          u = b.t === a.t ? 1 : (t - a.t) / (b.t - a.t);
        return { x: a.x + (b.x - a.x) * u, y: a.y + (b.y - a.y) * u };
      }
    return k[k.length - 1];
  };
  // Hitbox position at time t. Keyframes are tiles from the boss's feet, mirrored by facing. "follow" keeps them on the boss.
  // Aim: the drawn path is turned about the boss's middle so that "forward" points at you (b.aim, in radians, in the boss's own mirrored space).
  const turn = (k, a, hh) => {
    if (!a) return k;
    const c = Math.cos(a),
      s = Math.sin(a),
      y = k.y + hh;
    return { x: k.x * c - y * s, y: k.x * s + y * c - hh };
  };
  const aimAt = (e, env, b) => {
    const def = b.def,
      p = env.p,
      H = env.H || 1,
      dx = (p.x - e.cx) * (b.face || 1),
      dy = p.y - H / 2 - (e.by - def.h / 2),
      m = ((b.pat ? b.pat.aimMax : 80) * Math.PI) / 180;
    return clampN(Math.atan2(dy, Math.abs(dx) < 0.05 ? 0.05 : dx), -m, m);
  };
  const hbRect = (b, e, hb, t) => {
    const k = turn(sample(hb.kf, t), b.aim, b.def ? b.def.h / 2 : 0),
      ox = hb.follow ? e.cx : b.sx,
      oy = hb.follow ? e.by : b.sy;
    return { cx: ox + b.face * k.x, cy: oy + k.y, w: hb.w, h: hb.h };
  };
  // The hitbox as a shape in the world at time t (rect, circle or polygon; mirrored by the way the boss faces).
  const hbShape = (b, e, hb, t) => {
    const r = hbRect(b, e, hb, t),
      f = b.face || 1;
    if (hb.shape === 'circle')
      return { sh: 'circle', cx: r.cx, cy: r.cy, r: hb.r, w: hb.r * 2, h: hb.r * 2, d: hb.dmg, hb };
    if (hb.shape === 'polygon')
      return {
        sh: 'polygon',
        cx: r.cx,
        cy: r.cy,
        pts: (hb.pts || []).map(q => ({ x: r.cx + f * q.x, y: r.cy + q.y })),
        w: hb.w,
        h: hb.h,
        d: hb.dmg,
        hb
      };
    return { sh: 'rect', cx: r.cx, cy: r.cy, w: hb.w, h: hb.h, d: hb.dmg, hb };
  };
  const phaseOf = (def, pct) => {
    const L = def.phases.length ? def.phases : [{ below: 100, idle: 1.2, speed: 1, patterns: [] }];
    let best = null;
    L.forEach(p => {
      if (p.below >= pct && (!best || p.below < best.below)) best = p;
    });
    return best || L.reduce((a, b) => (b.below > a.below ? b : a));
  };
  // States: passive (asleep, before it sees you) -> waking (awakened animation plays once) -> idle/attack (the fight). A phase change adds 'phase' (invulnerable, its own animation).
  // An attack starts with a warning (b.t counts up from minus the warning time): the hitboxes show where they will be, but nothing hurts yet.
  const init = def => ({
    def,
    state: 'passive',
    t: 0,
    len: 0,
    pi: 0,
    pat: null,
    sx: 0,
    sy: 0,
    face: 1,
    awake: false,
    as: 'passive',
    at: 0,
    ph: -1,
    lost: 0,
    ck: 'passive',
    clock: 0,
    cdt: {},
    last: '',
    aim: 0,
    streak: 0,
    wait: 0,
    vy: 0,
    rk: 1
  });
  const wakeLen = (def, env) => {
    const id = def.clips.awakened,
      cl = id && env && env.anims && MV.Anim.find(env.anims, id);
    if (cl && cl.frames.length) return MV.Anim.compile(cl).cycle;
    const a = def.sprite.anims.awakened;
    return a ? a.frames / a.fps : def.wakeTime;
  };
  const snd = (env, id) => {
    if (id && env.snd) env.snd(id);
  };
  // ---- movement with collision ----
  // The boss body is a box (def.w x def.h, feet at by). Moves are made in small steps, one axis at a time, so it slides along walls instead of passing through them.
  // env.blocked(cx, by, w, h) says whether that box overlaps solid tiles; env.room = { gw, gh } keeps it inside the room; def.leash keeps it near its spot.
  const clampN = (v, a, b) => Math.min(b, Math.max(a, v));
  function moveBody(e, tx, ty, env) {
    const b = e.b,
      def = b.def,
      w = def.w,
      h = def.h,
      R = env.room;
    if (!isFinite(tx) || !isFinite(ty)) return false;
    if (R) {
      tx = clampN(tx, w / 2, Math.max(w / 2, R.gw - w / 2));
      ty = clampN(ty, h, Math.max(h, R.gh));
    }
    if (e.arena) {
      const A = e.arena;
      tx = clampN(tx, A[0] + w / 2, Math.max(A[0] + w / 2, A[2] - w / 2));
      ty = clampN(ty, A[1] + h, Math.max(A[1] + h, A[3]));
    }
    if (def.leash > 0 && isFinite(e.ox)) tx = clampN(tx, e.ox - def.leash, e.ox + def.leash);
    const dx = tx - e.cx,
      dy = ty - e.by,
      n = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / 0.2)),
      free = !env.blocked || env.blocked(e.cx, e.by, w, h);
    let hit = false; // already inside a wall (bad placement): do not trap it
    for (let i = 0; i < n; i++) {
      const sx = dx / n,
        sy = dy / n;
      if (sx) {
        if (free || !env.blocked(e.cx + sx, e.by, w, h)) e.cx += sx;
        else hit = true;
      }
      if (sy) {
        if (free || !env.blocked(e.cx, e.by + sy, w, h)) e.by += sy;
        else hit = true;
      }
    }
    return hit;
  }
  // The box a boss may move in, in tiles [x0, y0, x1, y1]: the one stamped when it was placed ("x0,y0,x1,y1"), else worked out from its spawn tile and its arena size (older placements), always inside the room.
  function arenaOf(str, sx, sy, def, room) {
    let a = String(str || '')
      .split(',')
      .map(Number);
    if (a.length !== 4 || a.some(v => !isFinite(v)) || a[2] <= a[0] || a[3] <= a[1]) {
      const A = def.arena;
      a = [sx - A.bx, sy - A.by, sx - A.bx + A.gw, sy - A.by + A.gh];
    }
    if (room) a = [Math.max(0, a[0]), Math.max(0, a[1]), Math.min(room.gw, a[2]), Math.min(room.gh, a[3])];
    return a;
  }
  const onGround = (e, env) => !!env.blocked && env.blocked(e.cx, e.by + 0.08, e.b.def.w, e.b.def.h);
  // ---- choosing the next attack ----
  // The rules of a pattern: how far you are, whether you are on the ground, the boss's health, and a cooldown. 'order' mode ignores them (the old fixed order).
  function ruleOk(e, pat, env, b) {
    const def = b.def,
      p = env.p,
      H = env.H || 1,
      d = Math.hypot(p.x - e.cx, p.y - H / 2 - (e.by - def.h / 2)),
      pct = (e.hp / def.hp) * 100;
    if (d < pat.min || d > pat.max) return false;
    const dy = p.y - H / 2 - (e.by - def.h / 2);
    if (pat.vert === 'player above' && dy > -1.5) return false;
    if (pat.vert === 'player below' && dy < 1.5) return false;
    if (pat.vert === 'player level' && Math.abs(dy) > 1.5) return false;
    if (pct > pat.hpBelow || pct < pat.hpAbove) return false;
    if (pat.at === 'player on ground' && p.on === false) return false;
    if (pat.at === 'player in air' && p.on !== false) return false;
    return !(b.cdt && b.cdt[pat.id] > b.clock);
  }
  function choose(e, ids, env, relax) {
    const b = e.b,
      def = b.def;
    if (def.select !== 'rules') return def.patterns.find(q => q.id === ids[b.pi % ids.length]) || null;
    const pool = ids.map(i => def.patterns.find(q => q.id === i)).filter(Boolean);
    let c = pool.filter(q => ruleOk(e, q, env, b));
    if (!c.length && relax) c = pool.filter(q => !(b.cdt && b.cdt[q.id] > b.clock)); // nothing fits for a while: do something anyway
    if (!c.length) return null;
    if (c.length > 1) {
      const o = c.filter(q => !(q.id === b.last && b.streak >= q.repeat));
      if (o.length) c = o;
    } // a pattern may only be used 'repeat' times in a row while others are possible
    const tot = c.reduce((a, q) => a + q.weight, 0);
    if (!(tot > 0)) return c[0];
    let r = (env.rand ? env.rand() : Math.random()) * tot;
    for (const q of c) {
      r -= q.weight;
      if (r <= 0) return q;
    }
    return c[c.length - 1];
  }
  // Start the fight over: full health, back at its spot, asleep again.
  function reset(e) {
    const def = e.b.def;
    e.hp = def.hp;
    e.cx = e.ox;
    e.by = e.oy;
    e.vy = 0;
    e.inv = 0;
    e.hurt = 0;
    e.b = init(def);
  }
  function defeat(e, env) {
    const def = e.b.def,
      st = env.st;
    e.dead = true;
    st.opened[e.uid] = 1;
    st.flags[def.flag || 'boss_' + def.id] = 1;
    snd(env, def.dieSnd);
    if (env.die) env.die(e, def);
    if (def.reward) st.abilities[def.reward] = 1;
    if (env.drop) env.drop(def);
    env.msg('Defeated ' + def.name + (def.reward ? ' - unlocked ' + def.reward : ''));
    env.shake(0.9);
    env.save();
  }
  // env: room {gw, gh}, blocked(cx, by, w, h), rand() (optional), p (player), W, H (player size), st (progress), hit(e), dmg(e), bodyS(shape), msg, shake, save, hurt({d,k,s}), snd(id), onHit()
  function tick(e, dt, env) {
    const b = e.b,
      def = b.def,
      p = env.p;
    e.dir = b.face || 1;
    e.hurt = Math.max(0, (e.hurt || 0) - dt);
    e.wkT = Math.max(0, (e.wkT || 0) - dt);
    if (b.state === 'passive') {
      // asleep until it sees you; hitting it also wakes it, without damage
      if (Math.hypot(p.x - e.cx, p.y - e.by) < def.wake || (env.hit(e) && e.inv <= 0)) {
        e.inv = 0.25;
        b.state = 'waking';
        b.awake = true;
        if (env.emit) env.emit('bosswake', { boss: def.id });
        b.t = 0;
        b.len = wakeLen(def, env);
        env.shake(0.4);
        snd(env, def.wakeSnd);
      }
    } else if (b.state === 'waking') {
      // plays the awakened animation; harmless and unhurtable until it ends
      b.t += dt;
      if (b.t >= b.len) {
        b.state = 'idle';
        b.t = 0;
      }
    } else if (b.state === 'phase') {
      // changing phase: harmless and unhurtable, with its own animation
      b.t += dt;
      if (b.t >= b.len) {
        b.state = 'idle';
        b.t = 0;
      }
    } else if (fight(e, dt, env)) return;
    const s =
      b.state === 'passive'
        ? 'passive'
        : b.state === 'waking'
          ? 'awakened'
          : b.state === 'phase'
            ? 'phase'
            : b.state === 'stun'
              ? 'stun'
              : b.state === 'attack'
                ? b.t < 0
                  ? 'warn'
                  : b.pat.anim || 'attack'
                : 'idle';
    b.ck =
      b.state === 'attack' && b.t >= 0
        ? 'attack'
        : b.state === 'attack'
          ? 'warn'
          : b.state === 'waking'
            ? 'awakened'
            : b.state;
    if (s !== b.as) {
      b.as = s;
      b.at = 0;
    } else b.at += dt;
  }
  // Start a pattern now (the boss stands at its spot and the warning begins).
  function begin(e, pat, env) {
    const b = e.b;
    b.pat = pat;
    b.state = 'attack';
    b.t = -(pat.warn || 0);
    b.sx = e.cx;
    b.sy = e.by;
    b.wait = 0;
    b.streak = pat.id === b.last ? b.streak + 1 : 1;
    b.last = pat.id;
    if (pat.cd > 0) b.cdt[pat.id] = b.clock + pat.cd;
    b.rk = 1;
    b.armed = false;
    b.aim = pat.aim === 'at player' ? aimAt(e, env, b) : 0;
    snd(env, pat.snd);
  }
  // AI = Script: a script function (def.brain) decides what the boss does while it is idle. `me` is what it can read and do.
  // Everything goes through the same safe steps the built-in AI uses (moveBody keeps it in the room, the arena and its leash).
  function brainTick(e, dt, env, ids, ph, pick) {
    const b = e.b,
      def = b.def,
      p = env.p,
      fin = (v, d) => (isFinite(+v) && v !== null && v !== '' ? +v : d),
      dx = p.x - e.cx,
      dy = p.y - env.H / 2 - (e.by - def.h / 2);
    e.mem = e.mem || {};
    const me = {
      dt,
      t: b.clock,
      mem: e.mem,
      dx,
      dy,
      dist: Math.hypot(dx, dy),
      x: e.cx,
      y: e.by,
      w: def.w,
      h: def.h,
      hp: e.hp,
      maxHp: def.hp,
      hpPercent: Math.round((e.hp / def.hp) * 100),
      phase: ph.below,
      player: { x: p.x, y: p.y },
      onGround: onGround(e, env),
      facing: b.face,
      patterns: ids.slice(),
      ready: pid => !!def.patterns.find(q => q.id === pid) && !(b.cdt[pid] > b.clock),
      turn: d => {
        if (fin(d, 0)) b.face = d < 0 ? -1 : 1;
        e.dir = b.face;
      },
      walk: (dir, speed) => {
        moveBody(e, e.cx + Math.sign(fin(dir, 0)) * clampN(fin(speed, def.speed), 0, 30) * dt, e.by, env);
      },
      move: (vx, vy) => {
        moveBody(
          e,
          e.cx + clampN(fin(vx, 0), -40, 40) * dt,
          e.by + (def.fly === 'yes' ? clampN(fin(vy, 0), -40, 40) * dt : 0),
          env
        );
      },
      moveTo: (x, y) => {
        moveBody(e, fin(x, e.cx), fin(y, e.by), env);
      },
      jump: power => {
        if (def.fly === 'no' && onGround(e, env)) b.vy = -clampN(fin(power, 12), 0, 40);
      },
      attack: pid => {
        const q = def.patterns.find(x => x.id === pid);
        if (!q || b.state !== 'idle') return false;
        begin(e, q, env);
        return true;
      },
      hitbox: (x, y, w, h, dmg) => {
        const r = {
          sh: 'rect',
          cx: fin(x, 0),
          cy: fin(y, 0),
          w: clampN(fin(w, 1), 0.1, 30),
          h: clampN(fin(h, 1), 0.1, 30)
        };
        r.d = fin(dmg, def.damage);
        if (r.d > 0 && (env.bodyS ? env.bodyS(r) : Math.abs(r.cx - p.x) < (r.w + env.W) / 2))
          pick(r.d, def.knock, def.stun);
      },
      shoot: (vx, vy, o) => {
        if (env.shoot)
          env.shoot(Object.assign({ x: e.cx, y: e.by - def.h / 2 }, o || {}, { vx: fin(vx, 0), vy: fin(vy, 0) }));
      },
      invulnerable: sec => {
        e.inv = Math.max(e.inv || 0, clampN(fin(sec, 0), 0, 10));
      },
      sound: sid => snd(env, String(sid)),
      shake: amt => env.shake(fin(amt, 0.2))
    };
    env.brain(def.brain, me);
  }
  function fight(e, dt, env) {
    // returns true when the boss was just defeated
    const b = e.b,
      def = b.def,
      p = env.p,
      tune = env.tune || {};
    if (e.sts) {
      const dot = MV.Status.step(e.sts, dt, tune); // poison and burn
      if (dot > 0 && !e.dead) {
        e.hp -= dot;
        e.hurt = 0.2;
        if (e.hp <= 0) {
          defeat(e, env);
          return true;
        }
      }
    }
    dt *= MV.Status.speedMul(e.sts, tune); // slowed: it acts at a fraction of the speed
    let dm = env.dmg ? env.dmg(e) : env.hit(e) ? 1 : 0;
    e.shield = b.state === 'attack' && b.t >= 0 && (b.pat.inv || []).some(w => b.t >= w.from && b.t <= w.to); // an invulnerable moment of the pattern
    if (e.shield) dm = 0;
    else if (b.state === 'stun') dm *= def.staggerMult;
    dm *= MV.Status.mult(def, e.hitMeta && e.hitMeta.ty);
    if (dm > 0 && e.inv <= 0) {
      const r = MV.Actor.hit(e, { dmg: dm, fromX: p.x, knock: 0, flinch: 0, invul: def.invul });
      if (r.hit) {
        const hm = e.hitMeta;
        if (hm && hm.inf && hm.inf !== 'none') MV.Status.add(e.sts || (e.sts = {}), hm.inf, hm.it);
        env.shake(e.wkNow ? 0.4 : 0.2);
        if (e.wkNow) e.wkT = 0.45;
        if (env.onHit) env.onHit();
        snd(env, def.hurtSnd);
        if (r.dead) {
          defeat(e, env);
          return true;
        }
        if (def.stagger > 0 && b.state !== 'stun' && b.state !== 'phase') {
          b.lost += dm;
          if (b.lost >= (def.hp * def.stagger) / 100) {
            b.lost = 0;
            b.state = 'stun';
            b.t = 0;
            b.len = def.staggerTime;
            b.pat = null;
            snd(env, def.stunSnd);
            env.shake(0.5);
          }
        }
      }
    }
    if (b.state === 'stun') {
      b.t += dt;
      if (b.t >= b.len) {
        b.state = 'idle';
        b.t = 0;
      }
      return false;
    } // stunned: no attacks, no touch damage
    const ph = phaseOf(def, (e.hp / def.hp) * 100),
      ids = ph.patterns.length ? ph.patterns : def.patterns.map(q => q.id);
    if (b.ph !== ph.below) {
      const first = b.ph === -1;
      b.ph = ph.below;
      if (!first && env.emit) env.emit('bossphase', { boss: def.id, phase: ph.below });
      if (!first && ph.enter > 0) {
        b.state = 'phase';
        b.t = 0;
        b.len = ph.enter;
        b.pat = null;
        b.pi = 0;
        e.inv = Math.max(e.inv, ph.enter);
        env.shake(0.6);
        snd(env, def.phaseSnd);
        return false;
      }
    }
    b.t += dt * ph.speed;
    b.clock += dt;
    let best = null;
    const pick = (d, k, s2) => {
      if (d > 0 && (!best || d > best.d)) best = { d, k, s: s2 };
    };
    if (b.state === 'idle') {
      b.face = p.x >= e.cx ? 1 : -1;
      e.dir = b.face;
      if (def.ai === 'script' && def.brain && env.brain) brainTick(e, dt, env, ids, ph, pick);
      else {
        if (def.speed > 0) {
          const dx = p.x - e.cx;
          if (Math.abs(dx) > def.keep)
            moveBody(e, e.cx + Math.sign(dx) * Math.min(Math.abs(dx) - def.keep, def.speed * dt), e.by, env);
        } // walks toward you until it is at its preferred distance
        if (ids.length && b.t >= ph.idle) {
          b.wait += dt;
          const pat = choose(e, ids, env, b.wait > 3);
          if (pat) begin(e, pat, env);
          else if (def.select !== 'rules') b.pi++;
        }
      }
    } else {
      const pat = b.pat;
      if (b.t >= 0) {
        if (!b.armed) {
          b.armed = true;
          const L = pat.body.length ? pat.body[pat.body.length - 1].x : 0;
          if (pat.reach === 'to player' && Math.abs(L) > 0.1)
            b.rk = clampN(((p.x - e.cx) * b.face) / Math.abs(L), 0, 2);
        } // lunge so it ends where you stand when the warning is over
        if (pat.body.length) {
          const o = sample(pat.body, b.t);
          const q = turn(o, b.aim, 0);
          moveBody(e, b.sx + b.face * q.x * b.rk, b.sy + q.y, env);
        }
        pat.hitboxes.forEach(hb => {
          if (b.t < hb.from || b.t > hb.to || !(hb.dmg > 0)) return;
          const r = hbShape(b, e, hb, b.t);
          if (
            env.bodyS
              ? env.bodyS(r)
              : Math.abs(r.cx - p.x) < (r.w + env.W) / 2 && r.cy + r.h / 2 > p.y - env.H && r.cy - r.h / 2 < p.y
          )
            pick(hb.dmg, def.knock, def.stun);
        });
      }
      if (b.t >= pat.duration) {
        b.state = 'idle';
        b.t = 0;
        b.pi++;
        b.pat = null;
      }
      if (b.pat && b.t < 0 && (pat.track === 'yes' || pat.aim === 'at player')) {
        b.face = p.x >= e.cx ? 1 : -1;
        if (pat.aim === 'at player') b.aim = aimAt(e, env, b);
      } // it keeps turning to you while the warning shows
    }
    if (def.fly === 'no' && env.blocked) {
      // a walking boss falls to the floor and stays on it (its pattern is measured from where it stands)
      if (onGround(e, env)) b.vy = 0;
      else {
        b.vy = Math.min(30, b.vy + 40 * dt);
        const y0 = e.by;
        moveBody(e, e.cx, e.by + b.vy * dt, env);
        b.sy += e.by - y0;
        if (onGround(e, env)) b.vy = 0;
      }
    }
    if (def.touch === 'yes' && def.damage > 0) {
      const bs = MV.Enemies.bodyShape(e, def);
      if (
        env.bodyS
          ? env.bodyS(bs)
          : Math.abs(e.cx - p.x) < (def.w + env.W) / 2 && e.by > p.y - env.H && e.by - def.h < p.y
      )
        pick(def.damage, def.knock, def.stun);
    }
    if (best) env.hurt(best);
    return false;
  }
  // The clip a boss plays now: the hurt clip right after a hit, else the one for its state (a pattern can bring its own).
  function clipNow(e, ctx) {
    const b = e.b,
      def = b.def,
      A = ctx && ctx.anims;
    if (!A) return null;
    const hit = e.hurt > 0 && def.clips.hurt && b.state !== 'waking' && b.state !== 'phase';
    const id = hit
      ? def.clips.hurt
      : (b.ck === 'attack' && b.pat && b.pat.clip) ||
        def.clips[b.ck] ||
        (b.ck === 'attack' || b.ck === 'warn' || b.ck === 'stun' || b.ck === 'phase' ? def.clips.idle : '') ||
        def.clips.idle;
    return { cl: id ? MV.Anim.find(A, id) : null, t: hit ? 0.35 - e.hurt : b.at };
  }
  function draw(x, e, Z, sheetOf, debug, ctx) {
    const b = e.b,
      def = b.def,
      face = b.face || 1,
      A = MV.Attacks;
    x.save();
    if (e.inv > 0 && e.hurt <= 0) x.globalAlpha = e.shield ? 0.4 : 0.55;
    const cn = clipNow(e, ctx);
    let drawn = false;
    if (cn && cn.cl && cn.cl.frames.length) {
      const sm = MV.Anim.sample(cn.cl, cn.t),
        sh = sheetOf && sheetOf(cn.cl.frames[0].sheet);
      if (sh)
        drawn = MV.Anim.draw(x, cn.cl, sm, sheetOf, e.cx * Z, e.by * Z, {
          scale: (def.sprite.w * Z) / sh.tw,
          flipX: face < 0
        });
    }
    if (!drawn && sheetOf && MV.PlayerSprite)
      drawn = MV.PlayerSprite.frame(
        x,
        { w: def.sprite.w, h: def.sprite.h, anims: def.sprite.anims },
        sheetOf,
        b.as,
        b.at,
        e.cx * Z,
        e.by * Z,
        face,
        Z
      );
    if (!drawn) {
      x.fillStyle = e.hurt > 0 ? '#fff' : '#7f77dd';
      A.trace(x, MV.Enemies.bodyShape(e, def), Z);
      x.fill();
      x.fillStyle = '#12324a';
      x.fillRect((e.cx + face * def.w * 0.18 - 0.12) * Z, (e.by - def.h * 0.75) * Z, 0.24 * Z, 0.24 * Z);
    } else if (e.hurt > 0 && !(def.clips.hurt && ctx && ctx.anims)) {
      x.globalAlpha = 0.45;
      x.fillStyle = '#fff';
      A.trace(x, MV.Enemies.bodyShape(e, def), Z);
      x.fill();
    }
    x.restore();
    if (b.state === 'phase') {
      x.strokeStyle = 'rgba(255,210,74,' + (0.4 + 0.4 * Math.sin(b.t * 18)) + ')';
      x.lineWidth = 4;
      A.trace(x, MV.Enemies.bodyShape(e, def), Z);
      x.stroke();
    }
    if (b.state === 'attack' && b.t < 0) {
      // the warning: where each hitbox will be when it starts
      const pulse = Math.floor(b.t * -12) % 2 === 0;
      b.pat.hitboxes.forEach(hb => {
        if (!(hb.dmg > 0)) return;
        const r = hbShape(b, e, hb, hb.from);
        x.setLineDash([5, 4]);
        x.lineWidth = 2;
        x.strokeStyle = pulse ? 'rgba(255,210,74,.95)' : 'rgba(255,210,74,.4)';
        A.trace(x, r, Z);
        x.stroke();
        x.setLineDash([]);
      });
      x.fillStyle = '#ffd24a';
      x.font = 'bold 18px system-ui,sans-serif';
      x.textAlign = 'center';
      x.fillText('!', e.cx * Z, (e.by - def.h - 0.3) * Z);
      x.textAlign = 'left';
    }
    if (b.state === 'attack' && b.t >= 0)
      b.pat.hitboxes.forEach(hb => {
        if (b.t < hb.from || b.t > hb.to) return;
        const r = hbShape(b, e, hb, b.t);
        const hcl = hb.clip && ctx && ctx.anims && MV.Anim.find(ctx.anims, hb.clip),
          hsh = hcl && hcl.frames.length && sheetOf && sheetOf(hcl.frames[0].sheet);
        const art =
          (hsh &&
            MV.Anim.draw(x, hcl, MV.Anim.sample(hcl, b.t - hb.from), sheetOf, r.cx * Z, r.cy * Z, {
              scale: (Math.max(hb.w, hb.r * 2 || 0) * Z) / hsh.tw,
              flipX: face < 0
            })) ||
          (sheetOf &&
            hb.vis &&
            MV.PlayerSprite.frame(
              x,
              { w: hb.w, h: hb.h, anims: { idle: hb.vis } },
              sheetOf,
              'idle',
              b.t - hb.from,
              r.cx * Z,
              (r.cy + hb.h / 2) * Z,
              face,
              Z
            ));
        if (!art) {
          x.fillStyle = hb.dmg > 0 ? 'rgba(226,75,74,.55)' : 'rgba(226,75,74,.2)';
          A.trace(x, r, Z);
          x.fill();
        }
        if (debug) {
          x.strokeStyle = '#e24b4a';
          x.lineWidth = 1.5;
          A.trace(x, r, Z);
          x.stroke();
        }
      });
    if (e.wkT > 0) {
      x.fillStyle = '#ffd24a';
      x.font = 'bold 13px system-ui,sans-serif';
      x.textAlign = 'center';
      x.fillText('Weak spot!', e.cx * Z, (e.by - def.h - 0.5 - (0.45 - e.wkT)) * Z);
      x.textAlign = 'left';
    }
    if (debug) {
      x.lineWidth = 1.5;
      x.strokeStyle = '#ef9f27';
      A.trace(x, MV.Enemies.bodyShape(e, def), Z);
      x.stroke();
      x.strokeStyle = '#ffe08a';
      MV.Enemies.weakWorld(e, def).forEach(w => {
        A.trace(x, w, Z);
        x.stroke();
      });
    }
  }
  function hud(x, G, cw, U) {
    const e = G.en.find(q => q.type === 'boss' && q.b && q.b.awake && !q.dead);
    if (!e) return;
    MV.UI.bossBar(x, cw, U || MV.UI.def(), {
      name: e.b.def.name,
      hp: e.hp,
      max: e.b.def.hp,
      safe: e.b.state === 'waking' || e.b.state === 'phase',
      phases: e.b.def.phases.map(ph => ph.below)
    }, G.sheet, G.time);
  }
  return {
    arenaOf,
    CLIPS,
    clipNow,
    clean,
    list,
    find,
    blank,
    sample,
    hbRect,
    hbShape,
    phaseOf,
    init,
    reset,
    tick,
    draw,
    hud,
    blankGrid
  };
})();
