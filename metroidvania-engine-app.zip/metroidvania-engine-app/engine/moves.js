// Moves: validates the designer's move list and registers each move's ability so pickups can unlock it.
window.MV = window.MV || {};
MV.Moves = (() => {
  const F = () => MV.data.moveFields;
  // The picture shown while a dash or impulse plays. fit = spread all frames over the move's duration.
  const num = (v, a, b, d) =>
    v === null || v === '' || v === undefined || !isFinite(+v) ? d : Math.min(b, Math.max(a, +v));
  const anim = a =>
    a && typeof a === 'object' && typeof a.sheet === 'string' && a.sheet
      ? {
          sheet: a.sheet,
          col: Math.floor(num(a.col, 0, 255, 0)),
          row: Math.floor(num(a.row, 0, 255, 0)),
          frames: Math.floor(num(a.frames, 1, 64, 1)),
          fps: num(a.fps, 1, 60, 12),
          loop: a.loop === true,
          fit: a.fit !== false
        }
      : null;
  const clean1 = m => {
    m = m || {};
    const o = {};
    for (const k in F()) {
      const f = F()[k];
      let v = m[k];
      if (f.t === 'number') {
        v = v === '' || v === null || v === undefined ? NaN : Number(v);
        v = isFinite(v) ? Math.min(f.max, Math.max(f.min, v)) : f.def;
      } else if (f.t === 'select') {
        if (!f.o.includes(v) && !(f.legacy || []).includes(v)) v = f.def;
      } else if (f.t === 'key') v = typeof v === 'string' && /^[A-Za-z0-9]{1,16}$/.test(v) ? v : f.def;
      else v = typeof v === 'string' ? v.trim().slice(0, 30) : f.def;
      o[k] = v;
    }
    if (o.type === 'roll' && (m.squash === undefined || m.squash === null)) o.squash = 0.5; // a roll saved before Body height was a setting of every timed move
    o.sprite = anim(m.sprite);
    const T = o.type,
      hv =
        T === 'surface' ||
        T === 'dash' ||
        T === 'impulse' ||
        T === 'roll' ||
        T === 'grapple' ||
        T === 'bash' ||
        T === 'path' ||
        T === 'scripted' ||
        T === 'sequence',
      tm = hv && T !== 'impulse' && T !== 'sequence';
    let dur = Math.max(0.05, o.duration); // timed hitboxes ride along with every timed move; a speed curve and a player path with the ones that move over time
    if (T === 'sequence') {
      o.steps = MV.Attacks.steps(m.steps);
      o.duration = Math.max(
        0.05,
        Math.round(o.steps.reduce((a, q) => a + q.dur, 0) * Math.max(1, Math.floor(o.repeat || 1)) * 1000) / 1000
      );
      dur = o.duration;
    } else o.steps = [];
    o.hit = hv ? MV.Attacks.hitboxes(m.hit, dur) : [];
    o.curve = tm ? MV.Attacks.curve(m.curve, dur) : [];
    o.path = T === 'dash' || T === 'roll' || T === 'path' || T === 'surface' ? MV.Attacks.path(m.path, dur) : [];
    if (T === 'path' && !o.path.length)
      o.path = [
        { t: 0, x: 0, y: 0 },
        { t: dur, x: 3, y: 0 }
      ];
    {
      const bo = MV.Attacks.bodyOf(m, dur, m.iframes);
      o.body = T === 'hold' || T === 'swim' ? { off: [], kf: [], shape: bo.shape } : bo;
    }
    Object.assign(
      o,
      T === 'hold' || T === 'swim'
        ? {
            chainTo: '',
            chainWin: 0.4,
            charge: 0,
            chargeMult: 2,
            chargeLock: T === 'hold' && m.chargeLock === 'yes' ? 'yes' : 'no',
            more: MV.Attacks.moreKeys(m.more),
            shots: [],
            effects: T === 'hold' ? MV.Attacks.effects(m.effects) : []
          }
        : MV.Attacks.extras(m, dur)
    );
    if (!o.id) o.id = 'move' + Math.random().toString(36).slice(2, 5);
    if (!o.label) o.label = o.id;
    return o;
  };
  const resolve = list => {
    const seen = {};
    return (Array.isArray(list) ? list : MV.data.moves)
      .slice(0, 24)
      .map(clean1)
      .filter(m => !seen[m.id] && (seen[m.id] = 1));
  };
  const sync = list => {
    const A = MV.data.abilities;
    for (const k in A) if (A[k].move) delete A[k];
    list.forEach(m => {
      if (m.requires && !A[m.requires]) A[m.requires] = { label: m.label, requires: [], move: 1 };
    });
  };
  return { resolve, sync, clean1 };
})();
