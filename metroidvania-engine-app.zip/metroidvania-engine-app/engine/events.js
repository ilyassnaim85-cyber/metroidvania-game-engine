// MV.Events - things that happen in your game, built without code: a trigger (when), conditions (only if) and actions (then do this).
// One event = { id, name, on, once, trigger: {type, ...}, conds: [{type, ...}], actions: [{type, ...}] }, saved in world.events.
// This file holds the schema (the editor builds its forms from it and the checker reads it), the cleaner, the checker (validate) and the runner that the game drives.
window.MV = window.MV || {};
MV.Events = (() => {
  const P = {
    room: { t: 'room', label: 'Room' },
    item: { t: 'item', label: 'Item' },
    ability: { t: 'ability', label: 'Ability' },
    weapon: { t: 'weapon', label: 'Weapon' },
    flag: { t: 'flag', label: 'Flag' },
    boss: { t: 'boss', label: 'Boss' },
    enemy: { t: 'enemy', label: 'Enemy type' },
    npc: { t: 'npc', label: 'Character' },
    event: { t: 'event', label: 'Event' },
    prof: { t: 'camprofile', label: 'Camera profile' },
    sound: { t: 'sound', label: 'Sound' },
    vari: { t: 'var', label: 'Counter' },
    entity: { t: 'entity', label: 'Thing in a room' },
    tile: { t: 'tile', label: 'Tile' }
  };
  const any = (p, w) => Object.assign({}, p, { any: w });
  const num = (label, def, min, max, step) => ({ t: 'number', label, def, min, max, step: step || 1 });
  // when: what starts an event. "any" in a picker means the event starts for every room, item, flag...
  const TRIGGERS = {
    room: { label: 'The player enters a room', p: { room: any(P.room, 'Any room') } },
    roomleave: { label: 'The player leaves a room', p: { room: any(P.room, 'Any room') } },
    stay: {
      label: 'The player has been in a room for a while',
      p: { room: any(P.room, 'Any room'), secs: num('Seconds', 10, 0.1, 3600, 0.1) }
    },
    item: { label: 'An item is collected', p: { item: any(P.item, 'Any item') } },
    ability: { label: 'An ability is gained', p: { ability: any(P.ability, 'Any ability') } },
    flag: { label: 'A flag is set (a switch is turned on...)', p: { flag: any(P.flag, 'Any flag') } },
    flagoff: { label: 'A flag is cleared (a switch is turned off...)', p: { flag: any(P.flag, 'Any flag') } },
    boss: { label: 'A boss is defeated', p: { boss: any(P.boss, 'Any boss') } },
    enemy: { label: 'An enemy is defeated', p: { enemy: any(P.enemy, 'Any enemy') } },
    npc: { label: 'A conversation with a character ends', p: { npc: any(P.npc, 'Any character') } },
    zone: { label: 'The player walks into an Event zone', p: { tag: { t: 'text', label: 'Zone name', def: 'zone1' } } },
    zoneleave: {
      label: 'The player walks out of an Event zone',
      p: { tag: { t: 'text', label: 'Zone name', def: 'zone1' } }
    },
    death: { label: 'The player dies', p: {} },
    key: { label: 'A key is pressed', p: { key: { t: 'key', label: 'Key', def: 'F' } } },
    var: { label: 'A counter changes', p: { var: any(P.vari, 'Any counter') } },
    when: { label: 'All the conditions below become true (kills, items, bosses, counters...)', p: {} },
    called: { label: 'Only when another event calls it', p: {} }
  };
  // only if: every condition must be true when the trigger happens
  const CONDS = {
    flagset: { label: 'A flag is set', p: { flag: P.flag } },
    flagnot: { label: 'A flag is not set', p: { flag: P.flag } },
    hasitem: { label: 'The player has an item', p: { item: P.item, n: num('At least', 1, 1, 99) } },
    noitem: { label: 'The player does not have an item', p: { item: P.item } },
    ability: { label: 'The player has an ability', p: { ability: P.ability } },
    noability: { label: 'The player does not have an ability', p: { ability: P.ability } },
    weapon: { label: 'The player owns a weapon', p: { weapon: P.weapon } },
    inroom: { label: 'The player is in a room', p: { room: P.room } },
    energy: { label: "The player's energy is at least", p: { n: num('Points', 10, 0, 300) } },
    coins: { label: 'The player has coins', p: { n: num('At least', 1, 0, 99999) } },
    hp: {
      label: "The player's health is",
      p: { op: { t: 'select', label: '', o: ['at most', 'at least'], def: 'at most' }, n: num('Hits', 1, 0, 99) }
    },
    bossdead: { label: 'A boss is defeated', p: { boss: P.boss } },
    bossalive: { label: 'A boss is not defeated yet', p: { boss: P.boss } },
    var: {
      label: 'A counter compares',
      p: {
        var: P.vari,
        op: { t: 'select', label: '', o: ['=', '>=', '<=', '>', '<', '!='], def: '>=' },
        n: num('To', 1, -999999, 999999)
      }
    },
    kills: { label: 'Enemies of a type defeated (at least)', p: { enemy: P.enemy, n: num('How many', 6, 1, 9999) } },
    bosses: { label: 'Bosses defeated (at least)', p: { n: num('How many', 2, 1, 99) } },
    chance: { label: 'Random chance', p: { pct: num('Percent', 50, 1, 100) } }
  };
  // then: the steps, in order. Wait and Dialogue hold the list until they finish.
  const ACTIONS = {
    setflag: { label: 'Set a flag', p: { flag: P.flag } },
    clearflag: { label: 'Clear a flag', p: { flag: P.flag } },
    toggleflag: { label: 'Switch a flag on or off', p: { flag: P.flag } },
    giveitem: { label: 'Give an item', p: { item: P.item, n: num('How many', 1, 1, 99) } },
    takeitem: { label: 'Take an item away', p: { item: P.item, n: num('How many', 1, 1, 99) } },
    giveability: { label: 'Give an ability', p: { ability: P.ability } },
    takeability: { label: 'Take an ability away', p: { ability: P.ability } },
    giveweapon: { label: 'Give a weapon', p: { weapon: P.weapon } },
    coins: { label: 'Give coins (negative takes them)', p: { n: num('Coins', 10, -99999, 99999) } },
    script: { label: 'Run a script function', p: { name: { t: 'text', label: 'Function name (fn("name", ...) in a script)', def: 'myFunction' }, arg: { t: 'text', label: 'Argument (optional text)', def: '' } } },
    message: { label: 'Show a message', p: { text: { t: 'text', label: 'Text', def: 'Something happened.' } } },
    dialogue: {
      label: 'Start a conversation',
      p: {
        text: {
          t: 'longtext',
          label: "Lines (one per line, start with > for the player's character)",
          def: 'Hello there.\n>Hi!'
        },
        speaker: { t: 'text', label: 'Speaker name', def: '' }
      }
    },
    wait: { label: 'Wait', p: { secs: num('Seconds', 1, 0.05, 600, 0.05) } },
    freeze: { label: 'Freeze the player', p: { secs: num('Seconds', 1, 0.05, 60, 0.05) } },
    heal: { label: 'Heal the player (0 = fully)', p: { n: num('Hits', 0, 0, 99) } },
    energy: { label: 'Give energy (negative spends it)', p: { n: num('Points', 10, -300, 300) } },
    upgrade: {
      label: 'Permanent upgrade',
      p: {
        stat: { t: 'select', label: '', o: ['maxHp', 'energyMax', 'charmSlots'], def: 'maxHp' },
        n: num('Amount', 1, 1, 20)
      }
    },
    hurt: { label: 'Hurt the player', p: { n: num('Hits', 1, 1, 99) } },
    goroom: {
      label: 'Move the player to a room',
      p: {
        room: P.room,
        x: { t: 'number', label: "x tile (empty = the room's start)", def: null, min: 0, max: 10000, step: 0.5 },
        y: { t: 'number', label: 'y tile (feet)', def: null, min: 0, max: 10000, step: 0.5 }
      }
    },
    camera: {
      label: 'Change the camera profile',
      p: { profile: P.prof, blend: num('Blend seconds', 0.8, 0, 10, 0.1) }
    },
    camreset: { label: "Put the camera back to the room's own", p: {} },
    shake: { label: 'Shake the screen', p: { amount: num('Strength', 0.4, 0.05, 2, 0.05) } },
    camzoom: {
      label: 'Camera: zoom (1 = normal)',
      p: {
        zoom: num('Zoom', 1.5, 0.4, 3, 0.05),
        secs: num('Takes (seconds)', 0.8, 0.05, 20, 0.05),
        hold: num('Stays (seconds, 0 = until changed)', 0, 0, 600, 0.1)
      }
    },
    camfade: {
      label: 'Camera: fade the screen',
      p: {
        to: { t: 'select', label: '', o: ['to black', 'back to clear', 'flash white'], def: 'to black' },
        secs: num('Takes (seconds)', 0.8, 0.05, 20, 0.05)
      }
    },
    camfocus: {
      label: 'Camera: look at a spot for a while',
      p: {
        x: num('x tile', 10, 0, 10000, 0.5),
        y: num('y tile', 10, 0, 10000, 0.5),
        secs: num('Stays (seconds)', 2, 0.1, 600, 0.1),
        zoom: num('Zoom (1 = normal)', 1, 0.4, 3, 0.05),
        lock: { t: 'select', label: 'Player controls', o: ['stay on', 'locked while it looks'], def: 'stay on' }
      }
    },
    camtilt: {
      label: 'Camera: tilt the view (0 = level)',
      p: { deg: num('Degrees', 6, -30, 30, 1), secs: num('Takes (seconds)', 0.8, 0.05, 20, 0.05) }
    },
    sound: { label: 'Play a sound', p: { sound: P.sound } },
    music: { label: 'Change the music (empty = stop it)', p: { sound: P.sound } },
    setvar: {
      label: 'Change a counter',
      p: {
        var: P.vari,
        op: { t: 'select', label: '', o: ['set to', 'add', 'subtract'], def: 'add' },
        n: num('Number', 1, -999999, 999999)
      }
    },
    settile: {
      label: 'Change tiles in a room for good (open a path, close one...)',
      p: {
        room: P.room,
        x: num('Left x', 0, 0, 10000, 1),
        y: num('Top y', 0, 0, 10000, 1),
        w: num('Width', 1, 1, 100, 1),
        h: num('Height', 1, 1, 100, 1),
        tile: P.tile
      }
    },
    entity: {
      label: 'Remove or show a thing placed in a room',
      p: { entity: P.entity, set: { t: 'select', label: '', o: ['remove', 'show'], def: 'remove' } }
    },
    bossskip: { label: 'Skip a boss (counts as defeated, gives its reward)', p: { boss: P.boss } },
    ending: {
      label: 'Show an ending (sets the flag ending:<name>)',
      p: {
        name: { t: 'text', label: 'Name', def: 'good' },
        title: { t: 'text', label: 'Title', def: 'The End' },
        text: { t: 'longtext', label: 'Text', def: 'Thank you for playing.' }
      }
    },
    event: { label: 'Run another event', p: { event: P.event } },
    enable: {
      label: 'Turn an event on or off',
      p: { event: P.event, set: { t: 'select', label: '', o: ['on', 'off'], def: 'on' } }
    }
  };
  const TILES = [
    ['.', 'Empty (open air)'],
    ['#', 'Wall'],
    ['=', 'Platform (one-way)'],
    ['^', 'Spikes'],
    ['~', 'Water'],
    ['D', 'Transition tile']
  ];
  const SCHEMA = { triggers: TRIGGERS, conds: CONDS, actions: ACTIONS };

  // ---- cleaning ----
  const str = (v, n) => (typeof v === 'string' ? v.slice(0, n) : '');
  function cleanParams(def, o) {
    const out = {};
    o = o && typeof o === 'object' ? o : {};
    for (const k in def.p) {
      const d = def.p[k],
        v = o[k];
      if (d.t === 'number') {
        if (v === null || v === undefined || v === '') out[k] = d.def === undefined ? 0 : d.def;
        else {
          const n = +v;
          out[k] = isFinite(n) ? Math.max(d.min, Math.min(d.max, n)) : d.def === undefined ? 0 : d.def;
        }
      } else if (d.t === 'select') out[k] = d.o.includes(v) ? v : d.def;
      else if (d.t === 'longtext') out[k] = str(v, 2000) || (v === undefined ? d.def || '' : '');
      else out[k] = v === undefined ? (d.def === undefined ? '' : d.def) : str(String(v), 80);
    }
    return out;
  }
  function cleanList(list, schema, max) {
    return (Array.isArray(list) ? list : [])
      .slice(0, max)
      .filter(x => x && schema[x.type])
      .map(x => Object.assign({ type: x.type }, cleanParams(schema[x.type], x)));
  }
  function clean(list) {
    const seen = new Set(),
      out = [];
    (Array.isArray(list) ? list : []).slice(0, 300).forEach((e, i) => {
      if (!e || typeof e !== 'object') return;
      let id = typeof e.id === 'string' && /^[\w-]{1,24}$/.test(e.id) ? e.id : 'ev' + (i + 1);
      while (seen.has(id)) id += 'x';
      seen.add(id);
      const tt = TRIGGERS[e.trigger && e.trigger.type] ? e.trigger.type : 'room';
      out.push({
        id,
        name: str(e.name, 40).trim() || 'Event ' + (i + 1),
        on: e.on !== false,
        once: e.once === 'no' ? 'no' : 'yes',
        trigger: Object.assign({ type: tt }, cleanParams(TRIGGERS[tt], e.trigger)),
        conds: cleanList(e.conds, CONDS, 12),
        actions: cleanList(e.actions, ACTIONS, 40)
      });
    });
    return out;
  }
  const blank = (n, type) => {
    const t = type || 'room';
    return {
      id: 'ev' + n,
      name: 'Event ' + n,
      on: true,
      once: 'yes',
      trigger: Object.assign({ type: t }, cleanParams(TRIGGERS[t], {})),
      conds: [],
      actions: []
    };
  };
  const blankPart = (kind, type) => Object.assign({ type }, cleanParams(SCHEMA[kind][type], {}));

  // ---- reading the project: what exists ----
  const roomsOf = w => {
    const out = [];
    ((w && w.areas) || []).forEach(a =>
      (a.rooms || []).forEach(r =>
        out.push({ id: r.id, name: (a.n || a.id) + ' / ' + (r.n || r.id), room: r, area: a })
      )
    );
    return out;
  };
  const npcsOf = w => {
    const out = [];
    roomsOf(w).forEach(r =>
      (r.room.ent || []).forEach(e => {
        if (e.type === 'npc')
          out.push({ id: r.id + ':' + e.id, name: ((e.props && e.props.name) || 'Character') + ' (' + r.name + ')' });
      })
    );
    return out;
  };
  const bossFlag = b => b.flag || 'boss_' + b.id;
  // every flag name that something in the project sets (or that the engine sets by itself), for the pickers and for the "nothing sets this flag" warning
  function flagSources(w) {
    const set = new Map();
    const add = (f, why) => {
      f = String(f || '').trim();
      if (f) {
        if (!set.has(f)) set.set(f, []);
        set.get(f).push(why);
      }
    };
    roomsOf(w).forEach(r =>
      (r.room.ent || []).forEach(e => {
        const p = e.props || {};
        if (e.type === 'switch') add(p.flag, 'Switch in ' + r.name);
        if (e.type === 'pickup' && p.kind === 'flag') add(p.give, 'Pickup in ' + r.name);
        if (e.type === 'chest' && p.reward === 'flag') add(p.give, 'Chest in ' + r.name);
      })
    );
    (w.bosses || []).forEach(b => add(bossFlag(b), 'Defeating the boss ' + (b.name || b.id)));
    (w.events || []).forEach(ev =>
      ev.actions.forEach(a => {
        if (a.type === 'setflag' || a.type === 'toggleflag') add(a.flag, 'Event "' + ev.name + '"');
      })
    );
    return set;
  }
  const isBuiltinFlag = f => /^(talked:|chest:|lz:|ev:|evoff:|boss_)/.test(f);
  const abilitiesOf = w => {
    const s = new Set(Object.keys(MV.data.abilities || {}));
    (w.moves || []).forEach(m => {
      if (m.requires) s.add(m.requires);
    });
    (w.attacks || []).forEach(a => {
      if (a.requires) s.add(a.requires);
    });
    roomsOf(w).forEach(r =>
      (r.room.ent || []).forEach(e => {
        if (e.type === 'pickup' && (!e.props.kind || e.props.kind === 'ability') && e.props.give) s.add(e.props.give);
      })
    );
    return s;
  };
  const weaponsOf = w => {
    const s = new Set();
    (w.attacks || []).forEach(a => {
      if (a.weapon) s.add(a.weapon);
    });
    roomsOf(w).forEach(r =>
      (r.room.ent || []).forEach(e => {
        if ((e.type === 'pickup' && e.props.kind === 'weapon') || (e.type === 'chest' && e.props.reward === 'weapon'))
          s.add(e.props.give);
      })
    );
    return s;
  };

  // ---- the checker: what points at something that does not exist ----
  // Returns [{ev, level: 'error'|'warn', text}]. ev is the event id (or '' for the whole list).
  function validate(w) {
    const out = [],
      evs = w.events || [],
      rooms = new Set(roomsOf(w).map(r => r.id)),
      items = new Set((w.items || []).map(i => i.id)),
      bosses = new Set((w.bosses || []).map(b => b.id)),
      npcs = new Set(npcsOf(w).map(n => n.id)),
      abil = abilitiesOf(w),
      wpn = weaponsOf(w),
      profs = new Set(MV.Camera ? MV.Camera.all(w.camProfiles).map(q => q.id) : []),
      ids = new Set(evs.map(e => e.id)),
      src = flagSources(w),
      zones = new Set(),
      ents = new Set(),
      varSet = new Set(['kills', 'bosses']);
    roomsOf(w).forEach(r => (r.room.ent || []).forEach(e => ents.add(r.id + ':' + e.id)));
    evs.forEach(e =>
      e.actions.forEach(a => {
        if (a.type === 'setvar') varSet.add(a.var);
      })
    );
    const src2 = src;
    roomsOf(w).forEach(r =>
      (r.room.ent || []).forEach(e => {
        if (e.type === 'evzone') zones.add(String((e.props || {}).tag || ''));
      })
    );
    const calls = new Map();
    evs.forEach(e =>
      e.actions.forEach(a => {
        if (a.type === 'event') {
          if (!calls.has(e.id)) calls.set(e.id, new Set());
          calls.get(e.id).add(a.event);
        }
      })
    );
    const called = new Set();
    calls.forEach(s => s.forEach(x => called.add(x)));
    const need = (ev, set, v, what, where) => {
      if (v && !set.has(v))
        out.push({
          ev: ev.id,
          level: 'error',
          text: where + ': the ' + what + ' "' + v + '" does not exist (it was deleted or renamed).'
        });
    };
    const empty = (ev, v, what, where) => {
      if (!v) out.push({ ev: ev.id, level: 'error', text: where + ': no ' + what + ' picked.' });
    };
    const check = (ev, kind, x, where) => {
      const d = SCHEMA[kind][x.type];
      if (!d) return;
      for (const k in d.p) {
        const pd = d.p[k],
          v = x[k];
        if (!pd.t || ['number', 'select', 'text', 'longtext', 'key'].includes(pd.t)) continue;
        if (!v && pd.any) continue;
        if (pd.t === 'camprofile') {
          if (v) need(ev, profs, v, 'camera profile', where);
          continue;
        }
        if (pd.t === 'sound' || pd.t === 'var' || pd.t === 'tile') continue;
        if (!v) {
          empty(ev, v, pd.label.toLowerCase(), where);
          continue;
        }
        if (pd.t === 'entity') need(ev, ents, v, 'thing in a room (it was deleted)', where);
        else if (pd.t === 'room') need(ev, rooms, v, 'room', where);
        else if (pd.t === 'item') need(ev, items, v, 'item', where);
        else if (pd.t === 'boss') need(ev, bosses, v, 'boss', where);
        else if (pd.t === 'enemy') need(ev, new Set((w.enemies || []).map(q => q.id)), v, 'enemy type', where);
        else if (pd.t === 'npc') need(ev, npcs, v, 'character', where);
        else if (pd.t === 'event') need(ev, ids, v, 'event', where);
        else if (pd.t === 'ability') {
          if (!abil.has(v))
            out.push({
              ev: ev.id,
              level: 'warn',
              text: where + ': no move, attack or pickup uses the ability "' + v + '", so nothing unlocks it.'
            });
        } else if (pd.t === 'weapon') {
          if (!wpn.has(v) && kind !== 'actions')
            out.push({ ev: ev.id, level: 'warn', text: where + ': no attack uses the weapon "' + v + '".' });
        } else if (pd.t === 'flag') {
          if ((kind === 'triggers' || kind === 'conds') && !src.has(v) && !isBuiltinFlag(v))
            out.push({
              ev: ev.id,
              level: 'warn',
              text:
                where +
                ': nothing sets the flag "' +
                v +
                '" (no switch, pickup, boss or event), so this can never happen.'
            });
        }
      }
    };
    evs.forEach(ev => {
      check(ev, 'triggers', ev.trigger, 'Trigger');
      ev.conds.forEach((c, i) => check(ev, 'conds', c, 'Condition ' + (i + 1)));
      ev.actions.forEach((a, i) => check(ev, 'actions', a, 'Step ' + (i + 1)));
      if (ev.trigger.type === 'zone' || ev.trigger.type === 'zoneleave') {
        if (!ev.trigger.tag) out.push({ ev: ev.id, level: 'error', text: 'Trigger: the zone has no name.' });
        else if (!zones.has(ev.trigger.tag))
          out.push({
            ev: ev.id,
            level: 'warn',
            text: 'Trigger: no Event zone named "' + ev.trigger.tag + '" is placed in any room.'
          });
      }
      if (ev.trigger.type === 'when' && !ev.conds.length)
        out.push({
          ev: ev.id,
          level: 'error',
          text: 'Trigger: "All the conditions become true" needs at least one condition below.'
        });
      ev.conds.forEach((c, i) => {
        if (c.type === 'var' && c.var && !varSet.has(c.var) && !/^kills:/.test(c.var))
          out.push({
            ev: ev.id,
            level: 'warn',
            text: 'Condition ' + (i + 1) + ': no event changes the counter "' + c.var + '", so it stays 0.'
          });
      });
      if (ev.trigger.type === 'var' && ev.trigger.var && !varSet.has(ev.trigger.var) && !/^kills:/.test(ev.trigger.var))
        out.push({ ev: ev.id, level: 'warn', text: 'Trigger: no event changes the counter "' + ev.trigger.var + '".' });
      if (ev.trigger.type === 'called' && !called.has(ev.id))
        out.push({ ev: ev.id, level: 'warn', text: 'Nothing calls this event, so it never runs.' });
      if (!ev.actions.length) out.push({ ev: ev.id, level: 'warn', text: 'It has no steps, so it does nothing.' });
      if (
        ev.once === 'no' &&
        (ev.trigger.type === 'flag' || ev.trigger.type === 'flagoff') &&
        ev.actions.some(
          a => (a.type === 'setflag' || a.type === 'clearflag' || a.type === 'toggleflag') && a.flag === ev.trigger.flag
        )
      )
        out.push({
          ev: ev.id,
          level: 'warn',
          text: 'It changes the same flag that starts it and is not "only once": it can start itself over and over.'
        });
      // a call that leads back to itself
      const seen = new Set(),
        walk = id => {
          for (const n of calls.get(id) || []) {
            if (n === ev.id) return true;
            if (!seen.has(n)) {
              seen.add(n);
              if (walk(n)) return true;
            }
          }
          return false;
        };
      if (walk(ev.id))
        out.push({
          ev: ev.id,
          level: 'warn',
          text: 'It runs another event that ends up running this one again (a loop).'
        });
    });
    return out;
  }

  // ---- the runner: the game gives it a host (what it can touch) and calls tick(dt) every frame ----
  // host: { st (progress state), world, items() , roomId(), coins(v?), hp(v?), maxHp(), msg(t), dialogue(lines, speaker, done), freeze(s), goRoom(roomId, x, y), camera(id, blend), cameraReset(), shake(a), sound(id), music(id), giveWeapon(id), keyCode(v) }
  class Runner {
    constructor(host, list) {
      this.h = host;
      this.list = clean(list);
      this.clock = 0;
      this.run = [];
      this.log = [];
      this.snap = null;
      this.rt = 0;
      this.last = {};
      this.fired = {};
      this.depth = 0;
      this.n = 0;
    }
    note(ev, text) {
      this.log.push({ t: +this.clock.toFixed(2), ev: ev.name, text });
      if (this.log.length > 40) this.log.shift();
    }
    find(id) {
      return this.list.find(e => e.id === id);
    }
    on(ev) {
      return ev.on && !this.h.st.flags['evoff:' + ev.id];
    }
    match(t, d) {
      const eq = (a, b) => !a || a === b;
      switch (t.type) {
        case 'room':
        case 'roomleave':
          return eq(t.room, d.room);
        case 'item':
          return eq(t.item, d.item);
        case 'ability':
          return eq(t.ability, d.ability);
        case 'flag':
        case 'flagoff':
          return eq(t.flag, d.flag);
        case 'boss': {
          if (!t.boss) return (this.h.world.bosses || []).some(b => bossFlag(b) === d.flag);
          const b = (this.h.world.bosses || []).find(q => q.id === t.boss);
          return !!b && bossFlag(b) === d.flag;
        }
        case 'enemy':
          return eq(t.enemy, d.kind);
        case 'npc':
          return eq(t.npc, d.npc);
        case 'zone':
        case 'zoneleave':
          return t.tag === d.tag;
        case 'var':
          return eq(t.var, d.var);
        case 'key':
          return this.h.keyCode(t.key) === d.code;
        case 'death':
          return true;
        case 'stay':
          return eq(t.room, d.room);
        default:
          return false;
      }
    }
    emit(type, d) {
      d = d || {};
      if (this.h.script) this.h.script(type, d); // scripts hear the same things events do
      if (type === 'enemy') {
        this.bump('kills');
        if (d.kind) this.bump('kills:' + d.kind);
      }
      this.list.forEach(ev => {
        if (ev.trigger.type === type && this.on(ev) && this.match(ev.trigger, d)) this.fire(ev, 'by ' + type);
      });
    }
    cond(c) {
      const h = this.h,
        st = h.st,
        f = n => !!st.flags[n];
      switch (c.type) {
        case 'flagset':
          return f(c.flag);
        case 'flagnot':
          return !f(c.flag);
        case 'hasitem':
          return MV.Inventory.count(st, c.item) >= (c.n || 1);
        case 'noitem':
          return MV.Inventory.count(st, c.item) < 1;
        case 'ability':
          return !!st.abilities[c.ability];
        case 'noability':
          return !st.abilities[c.ability];
        case 'weapon':
          return !!(st.weapons && st.weapons[c.weapon]);
        case 'inroom':
          return h.roomId() === c.room;
        case 'coins':
          return h.coins() >= c.n;
        case 'energy':
          return (h.energy ? h.energy() : 0) >= c.n;
        case 'hp':
          return c.op === 'at least' ? h.hp() >= c.n : h.hp() <= c.n;
        case 'bossdead':
        case 'bossalive': {
          const b = (h.world.bosses || []).find(q => q.id === c.boss),
            dead = !!b && f(bossFlag(b));
          return c.type === 'bossdead' ? dead : !dead;
        }
        case 'var': {
          const v = this.getVar(c.var);
          return c.op === '='
            ? v === c.n
            : c.op === '>='
              ? v >= c.n
              : c.op === '<='
                ? v <= c.n
                : c.op === '>'
                  ? v > c.n
                  : c.op === '<'
                    ? v < c.n
                    : v !== c.n;
        }
        case 'kills':
          return this.getVar('kills:' + c.enemy) >= c.n;
        case 'bosses':
          return this.getVar('bosses') >= c.n;
        case 'chance':
          return Math.random() * 100 < c.pct;
        default:
          return true;
      }
    }
    getVar(n) {
      const v = this.h.st.vars && this.h.st.vars[n];
      return isFinite(+v) ? +v : 0;
    }
    setVar(n, v) {
      const st = this.h.st;
      st.vars = st.vars || {};
      if (!(n in st.vars) && Object.keys(st.vars).length >= 200) return;
      st.vars[n] = Math.max(-999999, Math.min(999999, Math.round(v)));
    }
    bump(n, d) {
      this.setVar(n, this.getVar(n) + (d === undefined ? 1 : d));
    }
    fire(ev, why, force) {
      const st = this.h.st;
      if (!force && ev.once === 'yes' && st.flags['ev:' + ev.id]) {
        this.note(ev, 'skipped (it already ran once)');
        return false;
      }
      if (ev.once === 'no' && this.last[ev.id] !== undefined && this.clock - this.last[ev.id] < 0.05) return false; // a safety gap so an event cannot spin every frame
      if (this.run.length > 40 || this.n > 200) {
        this.note(ev, 'skipped (too many events running at once)');
        return false;
      }
      for (let i = 0; i < ev.conds.length; i++)
        if (!this.cond(ev.conds[i])) {
          this.note(ev, 'conditions not met: ' + CONDS[ev.conds[i].type].label + ' (condition ' + (i + 1) + ')');
          return false;
        }
      this.last[ev.id] = this.clock;
      this.n++;
      if (ev.once === 'yes') {
        st.flags['ev:' + ev.id] = 1;
        this.h.save && this.h.save();
      }
      this.note(ev, 'started (' + why + ')');
      this.run.push({ ev, i: 0, wait: 0, block: false });
      return true;
    }
    call(id, why) {
      const ev = this.find(id);
      if (ev) this.fire(ev, why || 'called', true);
    }
    act(ins, a) {
      const h = this.h,
        st = h.st,
        ev = ins.ev;
      switch (a.type) {
        case 'setflag':
          st.flags[a.flag] = 1;
          h.save && h.save();
          break;
        case 'clearflag':
          delete st.flags[a.flag];
          break;
        case 'toggleflag':
          if (st.flags[a.flag]) delete st.flags[a.flag];
          else st.flags[a.flag] = 1;
          break;
        case 'giveitem': {
          const def = MV.Inventory.find(h.items(), a.item);
          if (def) {
            const put = MV.Inventory.add(st, def, a.n || 1);
            h.msg(put ? 'Got ' + (put > 1 ? put + ' x ' : '') + def.name : 'You cannot carry more ' + def.name);
          }
          break;
        }
        case 'takeitem':
          MV.Inventory.take(st, a.item, a.n || 1);
          break;
        case 'giveability':
          st.abilities[a.ability] = true;
          h.msg('Unlocked ' + a.ability);
          break;
        case 'takeability':
          delete st.abilities[a.ability];
          break;
        case 'giveweapon':
          h.giveWeapon(a.weapon);
          break;
        case 'coins':
          h.coins(Math.max(0, h.coins() + a.n));
          break;
        case 'message':
          h.msg(a.text);
          break;
        case 'dialogue': {
          const L = MV.Dialog.parse(a.text);
          if (L.length) {
            ins.block = true;
            h.dialogue(L, a.speaker || ev.name, () => {
              ins.block = false;
            });
          }
          break;
        }
        case 'wait':
          ins.wait = a.secs;
          break;
        case 'freeze':
          h.freeze(a.secs);
          break;
        case 'heal':
          h.hp(a.n > 0 ? Math.min(h.maxHp(), h.hp() + a.n) : h.maxHp());
          break;
        case 'hurt':
          h.hurt(a.n);
          break;
        case 'energy':
          if (h.energy) h.energy(a.n);
          break;
        case 'upgrade':
          if (h.upgrade) h.upgrade(a.stat, a.n);
          break;
        case 'goroom':
          h.goRoom(a.room, a.x, a.y);
          break;
        case 'camera':
          h.camera(a.profile, a.blend);
          break;
        case 'camreset':
          h.cameraReset();
          break;
        case 'shake':
          h.shake(a.amount);
          break;
        case 'script':
          if (h.scriptCall) h.scriptCall(a.name, a.arg);
          break;
        case 'camzoom':
        case 'camfade':
        case 'camfocus':
        case 'camtilt':
          if (h.camfx) h.camfx(a.type, a);
          break;
        case 'sound':
          h.sound(a.sound);
          break;
        case 'music':
          h.music(a.sound);
          break;
        case 'setvar':
          this.setVar(
            a.var,
            a.op === 'set to' ? a.n : a.op === 'add' ? this.getVar(a.var) + a.n : this.getVar(a.var) - a.n
          );
          h.save && h.save();
          break;
        case 'settile':
          if (h.setTiles) h.setTiles(a.room, a.x, a.y, a.w, a.h, a.tile);
          break;
        case 'entity':
          if (h.entity) h.entity(a.entity, a.set);
          break;
        case 'bossskip':
          if (h.skipBoss) h.skipBoss(a.boss);
          break;
        case 'ending':
          if (h.ending) h.ending(a.name, a.title, a.text);
          break;
        case 'event':
          this.call(a.event, 'called by "' + ev.name + '"');
          break;
        case 'enable':
          if (a.set === 'on') delete st.flags['evoff:' + a.event];
          else st.flags['evoff:' + a.event] = 1;
          break;
      }
    }
    // flags, items and abilities are watched: whatever changes them (a switch, a chest, a boss...) can start an event
    watch() {
      const st = this.h.st,
        now = {
          f: Object.assign({}, st.flags),
          i: Object.assign({}, st.items || {}),
          a: Object.assign({}, st.abilities),
          v: Object.assign({}, st.vars || {})
        },
        bf = new Set((this.h.world.bosses || []).map(bossFlag));
      if (this.snap) {
        const s = this.snap;
        for (const k in now.v) if (now.v[k] !== s.v[k]) this.emit('var', { var: k, value: now.v[k] });
        for (const k in now.f)
          if (!s.f[k]) {
            if (bf.has(k)) this.bump('bosses');
            this.emit('flag', { flag: k });
            this.emit('boss', { flag: k });
            if (k.startsWith('talked:')) this.emit('npc', { npc: k.slice(7) });
          }
        for (const k in s.f) if (!now.f[k]) this.emit('flagoff', { flag: k });
        for (const k in now.i) if (now.i[k] > (s.i[k] || 0)) this.emit('item', { item: k });
        for (const k in now.a) if (now.a[k] && !s.a[k]) this.emit('ability', { ability: k });
      }
      this.snap = now;
    }
    tick(dt) {
      this.clock += dt;
      this.n = Math.max(0, this.n - 300 * dt);
      this.watch();
      this.rt += dt;
      this.wt = (this.wt || 0) + dt;
      if (this.wt >= 0.25) {
        this.wt = 0;
        this.was = this.was || {};
        this.list.forEach(ev => {
          if (ev.trigger.type !== 'when' || !this.on(ev) || !ev.conds.length) return;
          const ok = ev.conds.every(c => this.cond(c));
          if (ok && !this.was[ev.id]) this.fire(ev, 'the conditions became true');
          this.was[ev.id] = ok;
        });
      }
      this.list.forEach(ev => {
        if (
          ev.trigger.type === 'stay' &&
          this.on(ev) &&
          this.rm !== undefined &&
          this.rt >= ev.trigger.secs &&
          this.match(ev.trigger, { room: this.rm }) &&
          !this.fired[ev.id + '@' + this.rm + '#' + this.rv]
        ) {
          this.fired[ev.id + '@' + this.rm + '#' + this.rv] = 1;
          this.fire(ev, 'stayed ' + ev.trigger.secs + ' s');
        }
      });
      for (let k = 0; k < this.run.length; k++) {
        const ins = this.run[k];
        if (ins.block) continue;
        if (ins.wait > 0) {
          ins.wait -= dt;
          if (ins.wait > 0) continue;
          ins.wait = 0;
        }
        let guard = 0;
        while (ins.i < ins.ev.actions.length && !ins.block && ins.wait <= 0 && guard++ < 60) {
          const a = ins.ev.actions[ins.i++];
          try {
            this.act(ins, a);
          } catch (e) {
            this.note(ins.ev, 'step ' + ins.i + ' failed: ' + e.message);
          }
        }
        if (ins.i >= ins.ev.actions.length && !ins.block && ins.wait <= 0) ins.done = true;
      }
      this.run = this.run.filter(x => !x.done);
    }
    // the game tells it the player arrived in a room (rv counts visits so "stay" can run again on a later visit)
    enterRoom(id, respawn) {
      this.rm = id;
      this.rt = 0;
      this.rv = (this.rv || 0) + 1;
      this.emit('room', { room: id, respawn: !!respawn });
    }
    leaveRoom(id) {
      this.emit('roomleave', { room: id });
    }
    busy() {
      return this.run.length > 0;
    }
  }
  return {
    TILES,
    SCHEMA,
    TRIGGERS,
    CONDS,
    ACTIONS,
    clean,
    blank,
    blankPart,
    validate,
    Runner,
    roomsOf,
    npcsOf,
    flagSources,
    abilitiesOf,
    weaponsOf,
    bossFlag,
    isBuiltinFlag
  };
})();
