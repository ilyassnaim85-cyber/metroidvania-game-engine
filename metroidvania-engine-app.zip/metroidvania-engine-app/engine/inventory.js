// Inventory: the items a project defines (name, description, stack size, what using it does) and the counts the player carries (saved with the progress).
window.MV = window.MV || {};
MV.Inventory = (() => {
  const USE = ['none', 'heal', 'energy', 'upgrade', 'script', 'charm'];
  const STATS = { maxHp: 'Max health', energyMax: 'Max energy', charmSlots: 'Charm notches' };
  // What a charm can change while it is equipped: key -> [label, smallest, biggest]
  const MODS = {
    maxHp: ['Max health', -10, 10],
    energyMax: ['Max energy', -100, 100],
    energyRegen: ['Energy regrowth per second', -20, 20],
    energyPerHit: ['Energy per hit', -20, 20],
    run: ['Run speed', -10, 10],
    jumpHeight: ['Jump height', -3, 5],
    invTime: ['Invisibility time after a hit', -3, 5],
    damage: ['Damage of your hits', -5, 20]
  };
  const S = (v, d, n) => (typeof v === 'string' ? v.trim().slice(0, n || 40) : d);
  const N = (v, a, b, d) =>
    v === null || v === '' || v === undefined || !isFinite(+v) ? d : Math.min(b, Math.max(a, Math.round(+v)));
  const icon = a => (MV.Attacks && MV.Attacks.anim ? MV.Attacks.anim(a) : null); // a sprite: sheet, column, row, frames, speed
  const FIELDS = {
    id: {
      t: 'text',
      def: '',
      label: 'Item id',
      help: 'Short name without spaces, for example potion or redkey. Pickups and chests give it by this id, and you can write it in "Unlocked by" to need it.'
    },
    name: { t: 'text', def: 'Item', label: 'Name', help: 'Shown in the inventory.' },
    desc: { t: 'text', def: '', label: 'Description', help: 'One line shown under the item in the inventory.' },
    max: {
      t: 'number',
      def: 9,
      min: 1,
      max: 99,
      step: 1,
      label: 'Stack size',
      help: 'How many you can carry. A pickup you cannot carry more of stays where it is.'
    },
    use: {
      t: 'select',
      def: 'none',
      o: USE,
      names: {
        none: 'Nothing (a key item or material)',
        heal: 'Heal',
        energy: 'Restore energy',
        upgrade: 'Permanent upgrade (health, energy or notches)',
        script: 'Run a script function',
        charm: 'Charm (equip it in the inventory)'
      },
      label: 'When used',
      help: 'What happens when you use it in the inventory.'
    },
    amount: {
      t: 'number',
      def: 2,
      min: 1,
      max: 99,
      step: 1,
      label: 'Amount',
      help: 'Heal: health points. Restore energy: energy points. Upgrade: how much is added for good.'
    },
    stat: {
      t: 'select',
      def: 'maxHp',
      o: Object.keys(STATS),
      names: STATS,
      label: 'Upgrade',
      help: 'Permanent upgrade: what grows for good when you use it.'
    },
    fn: {
      t: 'text',
      def: '',
      label: 'Script function',
      help: 'Run a script function: the name you gave to fn() in the Scripts tab. It receives { item }.'
    },
    keep: {
      t: 'select',
      def: 'no',
      o: ['no', 'yes'],
      names: { no: 'No, it is used up', yes: 'Yes, you keep it' },
      label: 'Keep it after use',
      help: 'Whether using it takes one from your bag. Charms are never used up.'
    },
    notches: {
      t: 'number',
      def: 1,
      min: 0,
      max: 10,
      step: 1,
      label: 'Charm notches',
      help: 'Charm: how many of your notches it uses while equipped (Settings, Charms).'
    },
    grant: {
      t: 'text',
      def: '',
      label: 'Charm grants ability',
      help: 'Charm: an ability id you have while it is equipped (for example dash). Empty = none.'
    },
    tab: {
      t: 'text',
      def: '',
      label: 'Shown in tab',
      help: 'The id of the inventory tab this item is listed in (see the Tabs section). Empty or unknown = the first tab that shows items.'
    }
  };
  const clean1 = o => {
    o = o && typeof o === 'object' ? o : {};
    let id =
      typeof o.id === 'string' && /^[\w-]{1,24}$/.test(o.id) ? o.id : 'item' + Math.random().toString(36).slice(2, 5);
    return {
      id,
      name: S(o.name, 'Item') || id,
      desc: S(o.desc, '', 90),
      max: N(o.max, 1, 99, 9),
      use: USE.includes(o.use) ? o.use : 'none',
      amount: N(o.amount, 1, 99, 2),
      stat: STATS[o.stat] ? o.stat : 'maxHp',
      fn: typeof o.fn === 'string' && /^[\w-]{1,40}$/.test(o.fn) ? o.fn : '',
      keep: o.keep === 'yes' ? 'yes' : 'no',
      notches: N(o.notches, 0, 10, 1),
      grant: typeof o.grant === 'string' && /^[\w-]{1,24}$/.test(o.grant) ? o.grant : '',
      mods: (Array.isArray(o.mods) ? o.mods : [])
        .filter(q => q && MODS[q.key])
        .slice(0, 6)
        .map(q => ({
          key: q.key,
          add: Math.min(MODS[q.key][2], Math.max(MODS[q.key][1], isFinite(+q.add) ? Math.round(+q.add * 100) / 100 : 0))
        })),
      tab: typeof o.tab === 'string' && /^[\w-]{1,24}$/.test(o.tab) ? o.tab : '',
      icon: icon(o.icon)
    };
  };
  const resolve = list => {
    const seen = {};
    return (Array.isArray(list) ? list : [])
      .slice(0, 24)
      .map(clean1)
      .filter(i => !seen[i.id] && (seen[i.id] = 1));
  };
  const find = (list, id) => (list || []).find(i => i.id === id);
  const count = (st, id) => (st.items && st.items[id]) || 0;
  // Put n of an item in the bag; returns how many fitted.
  const add = (st, def, n) => {
    st.items = st.items || {};
    const have = count(st, def.id),
      put = Math.max(0, Math.min(n, def.max - have));
    if (put) st.items[def.id] = have + put;
    return put;
  };
  const take = (st, id, n) => {
    if (count(st, id) < n) return false;
    st.items[id] -= n;
    if (st.items[id] <= 0) delete st.items[id];
    return true;
  };

  // ---------- The inventory screen: tabs, sprites, colours and transparency (all set in the Items tab) ----------
  const KINDS = ['items', 'weapons', 'abilities'],
    LAYOUTS = ['grid', 'list'];
  const colr = (v, d) => (typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v) ? v : d);
  const nn = (v, a, b, d) =>
    v === null || v === '' || v === undefined || !isFinite(+v) ? d : Math.min(b, Math.max(a, +v));
  const defDesign = () => ({
    title: 'Inventory',
    key: 'KeyI',
    tabs: [
      { id: 'items', name: 'Items', kind: 'items', icon: null },
      { id: 'weapons', name: 'Weapons', kind: 'weapons', icon: null }
    ],
    layout: 'grid',
    cols: 5,
    slot: 48,
    w: 80,
    h: 80,
    opacity: 0.96,
    dim: 0.55,
    radius: 10,
    font: 14,
    detail: 'yes',
    panel: '#141822',
    border: '#8fa3b3',
    bwidth: 2,
    text: '#ffffff',
    muted: '#8fa3b3',
    accent: '#5dcaa5',
    slotc: '#1d2433',
    slota: 0.9,
    sheet: '',
    slice: 8,
    scale: 2,
    meta: {}
  });
  const cleanDesign = o => {
    o = o && typeof o === 'object' ? o : {};
    const d = defDesign();
    const out = {};
    out.title = typeof o.title === 'string' && o.title.trim() ? o.title.trim().slice(0, 24) : d.title;
    out.key = typeof o.key === 'string' && /^[A-Za-z0-9]{1,16}$/.test(o.key) ? o.key : d.key;
    let tabs = Array.isArray(o.tabs)
      ? o.tabs.slice(0, 8).map((t, i) => {
          t = t || {};
          return {
            id: typeof t.id === 'string' && /^[\w-]{1,24}$/.test(t.id) ? t.id : 'tab' + (i + 1),
            name: typeof t.name === 'string' && t.name.trim() ? t.name.trim().slice(0, 20) : 'Tab ' + (i + 1),
            kind: KINDS.includes(t.kind) ? t.kind : 'items',
            icon: icon(t.icon)
          };
        })
      : null;
    if (!tabs || !tabs.length) tabs = d.tabs;
    const seen = {};
    out.tabs = tabs.filter(t => !seen[t.id] && (seen[t.id] = 1));
    out.layout = LAYOUTS.includes(o.layout) ? o.layout : d.layout;
    out.cols = Math.round(nn(o.cols, 1, 10, d.cols));
    out.slot = Math.round(nn(o.slot, 24, 96, d.slot));
    out.w = Math.round(nn(o.w, 30, 100, d.w));
    out.h = Math.round(nn(o.h, 30, 100, d.h));
    out.opacity = nn(o.opacity, 0, 1, d.opacity);
    out.dim = nn(o.dim, 0, 1, d.dim);
    out.radius = Math.round(nn(o.radius, 0, 30, d.radius));
    out.font = Math.round(nn(o.font, 10, 24, d.font));
    out.detail = o.detail === 'no' ? 'no' : 'yes';
    out.panel = colr(o.panel, d.panel);
    out.border = colr(o.border, d.border);
    out.bwidth = Math.round(nn(o.bwidth, 0, 8, d.bwidth));
    out.text = colr(o.text, d.text);
    out.muted = colr(o.muted, d.muted);
    out.accent = colr(o.accent, d.accent);
    out.slotc = colr(o.slotc, d.slotc);
    out.slota = nn(o.slota, 0, 1, d.slota);
    out.sheet = typeof o.sheet === 'string' ? o.sheet.slice(0, 32) : '';
    out.slice = Math.round(nn(o.slice, 1, 64, d.slice));
    out.scale = Math.round(nn(o.scale, 1, 6, d.scale));
    out.meta = {};
    if (o.meta && typeof o.meta === 'object')
      Object.keys(o.meta)
        .slice(0, 80)
        .forEach(k => {
          if (!/^[wa]:[\w-]{1,30}$/.test(k)) return;
          const m = o.meta[k] || {};
          out.meta[k] = { name: S(m.name, '', 24), desc: S(m.desc, '', 90), icon: icon(m.icon) };
        });
    return out;
  };
  // The entries of one tab: items you carry (the ones assigned to that tab), weapons you own, or abilities you have.
  const entries = (D, st, defs, tabIx, abil) => {
    const tab = D.tabs[tabIx];
    if (!tab) return [];
    st = st || {};
    if (tab.kind === 'weapons')
      return Object.keys(st.weapons || {}).map(id => {
        const m = D.meta['w:' + id] || {};
        return {
          k: 'w',
          id,
          name: m.name || id,
          desc: m.desc || 'A weapon. Its attacks only work while it is in your hand.',
          icon: m.icon || null,
          on: st.weapon === id
        };
      });
    if (tab.kind === 'abilities')
      return Object.keys(st.abilities || {})
        .filter(id => st.abilities[id])
        .map(id => {
          const m = D.meta['a:' + id] || {},
            a = abil && abil[id];
          return { k: 'a', id, name: m.name || (a && a.label) || id, desc: m.desc || '', icon: m.icon || null };
        });
    const first = D.tabs.find(t => t.kind === 'items');
    return (defs || [])
      .filter(
        d =>
          count(st, d.id) > 0 &&
          (d.tab === tab.id || (tab === first && !D.tabs.some(t => t.kind === 'items' && t.id === d.tab)))
      )
      .map(d => ({
        k: 'i',
        id: d.id,
        name: d.name,
        desc: d.desc,
        icon: d.icon,
        count: count(st, d.id),
        max: d.max,
        use: d.use,
        stat: d.stat,
        amount: d.amount,
        notches: d.notches,
        grant: d.grant,
        mods: d.mods,
        on: d.use === 'charm' && !!(st.equipped && st.equipped[d.id])
      }));
  };
  function wrap(x, t, w) {
    const out = [];
    let ln = '';
    String(t)
      .split(' ')
      .forEach(wd => {
        if (ln && x.measureText(ln + wd).width > w) {
          out.push(ln.trim());
          ln = '';
        }
        ln += wd + ' ';
      });
    if (ln.trim()) out.push(ln.trim());
    return out;
  }
  function patch(x, im, s, k, px, py, w, h) {
    const iw = im.naturalWidth || im.width,
      ih = im.naturalHeight || im.height,
      d = s * k;
    if (iw < 2 * s + 1 || ih < 2 * s + 1) {
      x.drawImage(im, px, py, w, h);
      return;
    }
    const xs = [0, s, iw - s, iw],
      ys = [0, s, ih - s, ih],
      xd = [px, px + d, px + w - d, px + w],
      yd = [py, py + d, py + h - d, py + h];
    for (let j = 0; j < 3; j++)
      for (let i = 0; i < 3; i++)
        x.drawImage(
          im,
          xs[i],
          ys[j],
          xs[i + 1] - xs[i],
          ys[j + 1] - ys[j],
          xd[i],
          yd[j],
          xd[i + 1] - xd[i],
          yd[j + 1] - yd[j]
        );
  }
  function rr(x, px, py, w, h, r) {
    x.beginPath();
    if (x.roundRect && r > 0) x.roundRect(px, py, w, h, r);
    else x.rect(px, py, w, h);
  }
  // A sprite icon in a square (cx, cy = its middle). Without a sprite: the first letters on a coloured square.
  function drawIcon(x, ic, name, getSheet, time, cx, cy, size, D) {
    if (
      ic &&
      ic.sheet &&
      getSheet &&
      MV.PlayerSprite &&
      MV.PlayerSprite.frame &&
      MV.PlayerSprite.frame(
        x,
        { w: 1, h: 1, anims: { idle: ic } },
        getSheet,
        'idle',
        time || 0,
        cx,
        cy + size / 2,
        1,
        size
      )
    )
      return;
    x.fillStyle = D.muted;
    x.globalAlpha *= 0.35;
    rr(x, cx - size / 2 + 2, cy - size / 2 + 2, size - 4, size - 4, 4);
    x.fill();
    x.globalAlpha /= 0.35;
    x.fillStyle = D.text;
    x.font = 'bold ' + Math.max(10, Math.round(size * 0.38)) + 'px system-ui,sans-serif';
    x.textAlign = 'center';
    x.textBaseline = 'middle';
    x.fillText(
      String(name || '?')
        .slice(0, 2)
        .toUpperCase(),
      cx,
      cy + 1
    );
  }
  // Draw the inventory. st = { tab, sel, list (the entries of the tab) }, canvas size W x H. Returns how many rows fit (for scrolling).
  function draw(x, W, H, D, st, getSheet, time, hint) {
    const fs = D.font,
      list = st.list || [],
      PW = Math.round((W * D.w) / 100),
      PH = Math.round((H * D.h) / 100),
      X0 = Math.round((W - PW) / 2),
      Y0 = Math.round((H - PH) / 2);
    x.save();
    if (D.dim > 0) {
      x.fillStyle = 'rgba(0,0,0,' + D.dim + ')';
      x.fillRect(0, 0, W, H);
    }
    x.globalAlpha = D.opacity;
    const sh = D.sheet && getSheet ? getSheet(D.sheet) : null,
      im = sh && sh.img && sh.img.complete !== false && (sh.img.naturalWidth || sh.img.width) ? sh.img : null;
    x.imageSmoothingEnabled = false;
    if (im) patch(x, im, D.slice, D.scale, X0, Y0, PW, PH);
    else {
      x.fillStyle = D.panel;
      rr(x, X0, Y0, PW, PH, D.radius);
      x.fill();
      if (D.bwidth > 0) {
        x.strokeStyle = D.border;
        x.lineWidth = D.bwidth;
        x.stroke();
      }
    }
    x.globalAlpha = 1;
    x.imageSmoothingEnabled = true;
    const pad = Math.max(12, im ? D.slice * D.scale + 4 : 12),
      IX = X0 + pad,
      IW = PW - pad * 2;
    let y = Y0 + pad - 2;
    x.textAlign = 'left';
    x.textBaseline = 'top';
    x.fillStyle = D.text;
    x.font = 'bold ' + (fs + 5) + 'px system-ui,sans-serif';
    x.fillText(D.title, IX, y);
    y += fs + 12;
    // tabs
    let tx = IX;
    const th = fs + 14;
    x.font = fs + 'px system-ui,sans-serif';
    const tabBox = [];
    D.tabs.forEach((t, i) => {
      const iw = t.icon ? th - 4 : 0,
        w = x.measureText(t.name).width + 18 + (iw ? iw + 4 : 0),
        on = i === st.tab;
      if (tx + w > IX + IW) return;
      x.fillStyle = on ? D.accent : D.slotc;
      x.globalAlpha = on ? 0.35 : D.slota;
      rr(x, tx, y, w, th, Math.min(D.radius, 8));
      x.fill();
      x.globalAlpha = 1;
      if (on) {
        x.strokeStyle = D.accent;
        x.lineWidth = 2;
        x.stroke();
      }
      let cx = tx + 9;
      if (iw) {
        drawIcon(x, t.icon, t.name, getSheet, time, cx + iw / 2, y + th / 2, iw, D);
        cx += iw + 4;
      }
      x.fillStyle = on ? D.text : D.muted;
      x.textAlign = 'left';
      x.textBaseline = 'middle';
      x.fillText(t.name, cx, y + th / 2 + 1);
      tabBox.push({ x: tx, y, w, h: th });
      tx += w + 6;
    });
    y += th + 10;
    const bottom = Y0 + PH - pad - (fs + 4),
      CH = bottom - y;
    x.textBaseline = 'top';
    const showD = D.detail === 'yes',
      LW = showD ? Math.round(IW * 0.56) : IW,
      grid = D.layout === 'grid',
      gap = 6,
      cell = D.slot;
    let cols = grid ? Math.max(1, Math.min(D.cols, Math.floor((LW + gap) / (cell + gap)))) : 1;
    const rowH = grid ? cell + gap : Math.max(cell * 0.7, fs + 12) + 4,
      rows = Math.max(1, Math.floor((CH + (grid ? gap : 0)) / rowH)),
      nRows = Math.ceil(list.length / cols),
      sRow = Math.floor(Math.min(st.sel, Math.max(0, list.length - 1)) / cols);
    const tp = Math.max(0, Math.min(nRows - rows, sRow - Math.floor((rows - 1) / 2))); // the row of the selection stays near the middle
    if (!list.length) {
      x.fillStyle = D.muted;
      x.font = fs + 'px system-ui,sans-serif';
      x.textAlign = 'left';
      x.fillText('Nothing here yet.', IX, y + 4);
    }
    list.forEach((q, i) => {
      const r = Math.floor(i / cols) - tp;
      if (r < 0 || r >= rows) return;
      const c = i % cols,
        px = IX + (grid ? c * (cell + gap) : 0),
        py = y + r * rowH,
        w = grid ? cell : LW,
        h = grid ? cell : rowH - 4,
        on = i === st.sel;
      x.globalAlpha = D.slota;
      x.fillStyle = D.slotc;
      rr(x, px, py, w, h, Math.min(D.radius, 6));
      x.fill();
      x.globalAlpha = 1;
      if (on) {
        x.strokeStyle = D.accent;
        x.lineWidth = 2;
        x.stroke();
        x.fillStyle = D.accent;
        x.globalAlpha = 0.18;
        x.fill();
        x.globalAlpha = 1;
      }
      if (grid) {
        drawIcon(x, q.icon, q.name, getSheet, time, px + w / 2, py + h / 2 - (q.icon ? 0 : 0), Math.min(w, h) - 10, D);
        if (q.k === 'i' && q.count > 1) {
          x.font = 'bold ' + Math.max(10, fs - 2) + 'px system-ui,sans-serif';
          x.textAlign = 'right';
          x.textBaseline = 'bottom';
          x.fillStyle = '#000';
          x.fillText('x' + q.count, px + w - 3, py + h - 1);
          x.fillStyle = D.text;
          x.fillText('x' + q.count, px + w - 4, py + h - 2);
          x.textBaseline = 'top';
        }
        if (q.on) {
          x.fillStyle = D.accent;
          x.beginPath();
          x.moveTo(px + 4, py + 4);
          x.lineTo(px + 14, py + 4);
          x.lineTo(px + 4, py + 14);
          x.fill();
        }
      } else {
        const is = h - 8;
        drawIcon(x, q.icon, q.name, getSheet, time, px + 6 + is / 2, py + h / 2, is, D);
        x.font = fs + 'px system-ui,sans-serif';
        x.textAlign = 'left';
        x.textBaseline = 'middle';
        x.fillStyle = on ? D.text : D.muted;
        x.fillText((q.on ? '▶ ' : '') + q.name, px + is + 14, py + h / 2 + 1);
        if (q.k === 'i') {
          x.textAlign = 'right';
          x.fillText('x' + q.count, px + w - 8, py + h / 2 + 1);
        }
        x.textBaseline = 'top';
      }
    });
    if (nRows > rows) {
      x.fillStyle = D.muted;
      x.font = fs - 2 + 'px system-ui,sans-serif';
      x.textAlign = 'right';
      x.fillText(tp + 1 + '-' + Math.min(nRows, tp + rows) + ' / ' + nRows + ' rows', IX + LW, bottom - fs + 2);
    }
    // detail
    const q = list[Math.min(st.sel, list.length - 1)];
    if (showD && q) {
      const DX = IX + LW + 14,
        DW = IW - LW - 14;
      x.textAlign = 'left';
      x.textBaseline = 'top';
      const bs = Math.min(DW, Math.round(cell * 1.5));
      drawIcon(x, q.icon, q.name, getSheet, time, DX + bs / 2, y + bs / 2, bs, D);
      let yy = y + bs + 8;
      x.textAlign = 'left';
      x.fillStyle = D.text;
      x.font = 'bold ' + (fs + 2) + 'px system-ui,sans-serif';
      x.textBaseline = 'top';
      x.fillText(q.name, DX, yy);
      yy += fs + 8;
      x.font = fs - 1 + 'px system-ui,sans-serif';
      x.fillStyle = D.muted;
      const lines = [];
      if (q.desc) lines.push(q.desc);
      if (q.k === 'i')
        lines.push(
          q.use === 'heal'
            ? 'Use: heals ' + q.amount + '.'
            : q.use === 'energy'
              ? 'Use: restores ' + q.amount + ' energy.'
              : q.use === 'upgrade'
                ? 'Use: ' + STATS[q.stat] + ' +' + q.amount + ' for good.'
                : q.use === 'script'
                  ? 'Press Enter to use it.'
                  : q.use === 'charm'
                    ? 'Charm: ' +
                      q.notches +
                      ' notch' +
                      (q.notches === 1 ? '' : 'es') +
                      (q.mods && q.mods.length
                        ? '. ' + q.mods.map(m => (m.add > 0 ? '+' : '') + m.add + ' ' + MODS[m.key][0]).join(', ')
                        : '') +
                      (q.grant ? '. Gives ' + q.grant : '') +
                      '. ' +
                      (q.on ? 'Equipped. Press Enter to take it off.' : 'Press Enter to equip it.')
                    : 'Cannot be used.',
          'Carrying ' + q.count + ' of ' + q.max + '.'
        );
      if (q.k === 'w') lines.push(q.on ? 'In your hand.' : 'Press Enter to hold it.');
      lines.forEach(t =>
        wrap(x, t, DW).forEach(l => {
          if (yy < bottom) {
            x.fillText(l, DX, yy);
            yy += fs + 3;
          }
        })
      );
    }
    x.fillStyle = D.muted;
    x.font = fs - 2 + 'px system-ui,sans-serif';
    x.textAlign = 'left';
    x.textBaseline = 'top';
    x.fillText(
      hint || 'Arrows: choose   Q / E: tab   Enter: use or equip   I or Esc: close',
      IX,
      Y0 + PH - pad - (fs - 2) + 4
    );
    x.restore();
    return { rows, cols, tabs: tabBox };
  }
  return {
    MODS,
    FIELDS,
    USE,
    KINDS,
    LAYOUTS,
    defDesign,
    cleanDesign,
    entries,
    draw,
    clean1,
    resolve,
    find,
    count,
    add,
    take
  };
})();
