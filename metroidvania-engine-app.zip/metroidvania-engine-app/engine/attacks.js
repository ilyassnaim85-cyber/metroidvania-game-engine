// Attacks and timed hitboxes for the player. An attack is built like a boss pattern: a timeline in which hitboxes move by keyframes,
// a speed curve changes how fast the player moves, and an animation plays. Moves (dash, impulse) can carry the same hitboxes and curve.
// Hitbox keyframes are tiles from the middle of the player's feet: x forward (mirrored by the way you face), y up is negative.
window.MV = window.MV || {};
MV.Attacks = (() => {
  const N = (v, a, b, d) =>
    v === null || v === '' || v === undefined || !isFinite(+v) ? d : Math.min(b, Math.max(a, +v));
  const S = (v, d, n) => (typeof v === 'string' ? v.trim().slice(0, n || 30) : d);
  const id = v => (typeof v === 'string' && /^[\w-]{1,24}$/.test(v) ? v : 'h' + Math.random().toString(36).slice(2, 7));
  const key = (v, d) => (typeof v === 'string' && /^[A-Za-z0-9]{1,16}$/.test(v) ? v : d);
  const anim = a =>
    a && typeof a === 'object' && typeof a.sheet === 'string' && a.sheet
      ? {
          sheet: a.sheet,
          col: Math.floor(N(a.col, 0, 255, 0)),
          row: Math.floor(N(a.row, 0, 255, 0)),
          frames: Math.floor(N(a.frames, 1, 64, 1)),
          fps: N(a.fps, 1, 60, 12),
          loop: a.loop === true,
          fit: a.fit !== false
        }
      : null;
  const kfs = (l, dur, d) => {
    const k = (Array.isArray(l) ? l : [])
      .slice(0, 60)
      .map(q => ({ t: N(q && q.t, 0, dur, 0), x: N(q && q.x, -60, 60, 0), y: N(q && q.y, -60, 60, 0) }))
      .sort((a, b) => a.t - b.t);
    return k.length ? k : d;
  };
  // Speed curve: v is a multiplier of the speed (1 = full speed, 0 = stopped, 2 = twice as fast) at time t.
  const curve = (l, dur) =>
    (Array.isArray(l) ? l : [])
      .slice(0, 40)
      .map(q => ({ t: N(q && q.t, 0, dur, 0), v: N(q && q.v, 0, 5, 1) }))
      .sort((a, b) => a.t - b.t);
  // Player movement: where the player is (tiles from where it started, x forward, y up is negative) at each moment. Empty = no path, the speed settings move the player instead.
  const path = (l, dur) =>
    (Array.isArray(l) ? l : [])
      .slice(0, 40)
      .map(q => ({ t: N(q && q.t, 0, dur, 0), x: N(q && q.x, -60, 60, 0), y: N(q && q.y, -60, 60, 0) }))
      .sort((a, b) => a.t - b.t);
  // Shapes: an attack box or the body hitbox is a rectangle, a circle or a polygon. w and h are always the bounding size (a circle is 2r wide). pts are polygon corners in tiles from the middle of the shape.
  const SHAPES = ['rect', 'circle', 'polygon'];
  const DEFPOLY = () => [
    { x: -0.5, y: 0.5 },
    { x: 0, y: -0.6 },
    { x: 0.5, y: 0.5 }
  ];
  const ptsOf = l => {
    const k = (Array.isArray(l) ? l : [])
      .slice(0, 16)
      .map(q => ({ x: N(q && q.x, -30, 30, 0), y: N(q && q.y, -30, 30, 0) }));
    return k.length >= 3 ? k : null;
  };
  const bbox = P => {
    const xs = P.map(q => q.x),
      ys = P.map(q => q.y);
    return { w: Math.max(0.1, Math.max(...xs) - Math.min(...xs)), h: Math.max(0.1, Math.max(...ys) - Math.min(...ys)) };
  };
  const shape = (h, dw, dh) => {
    h = h || {};
    const sh = SHAPES.includes(h.shape) ? h.shape : 'rect',
      o = { shape: sh };
    o.r = N(h.r !== undefined ? h.r : h.w !== undefined ? h.w / 2 : dw / 2, 0.05, 15, 0.5);
    o.pts = ptsOf(h.pts) || DEFPOLY();
    if (sh === 'circle') {
      o.w = o.h = o.r * 2;
    } else if (sh === 'polygon') {
      const b = bbox(o.pts);
      o.w = b.w;
      o.h = b.h;
    } else {
      o.w = N(h.w, 0.1, 30, dw);
      o.h = N(h.h, 0.1, 30, dh);
    }
    return o;
  };
  const hitbox = (h, dur) => {
    h = h || {};
    const sp = shape(h, 1, 1);
    return {
      id: id(h.id),
      name: S(h.name, 'Attack box'),
      shape: sp.shape,
      w: sp.w,
      h: sp.h,
      r: sp.r,
      pts: sp.pts,
      from: N(h.from, 0, dur, 0),
      to: N(h.to, 0, dur, dur),
      vis: anim(h.vis),
      kf: kfs(h.kf, dur, [{ t: 0, x: 1, y: -0.75 }])
    };
  };
  const hitboxes = (l, dur) => (Array.isArray(l) ? l : []).slice(0, 8).map(h => hitbox(h, dur));
  // The body hitbox: the part of the player that gets hurt. It can be switched off for periods of a move or attack (a dodge: nothing can hurt you then).
  const offs = (l, dur) =>
    (Array.isArray(l) ? l : [])
      .slice(0, 8)
      .map(q => {
        const a = N(q && q.from, 0, dur, 0),
          b = N(q && q.to, 0, dur, dur);
        return { from: Math.min(a, b), to: Math.max(a, b) };
      })
      .sort((a, b) => a.from - b.from);
  // Body size keyframes: the body hitbox gets this size and offset (tiles) at time t, gliding between keyframes. No keyframes = the plain body hitbox.
  const bkf = (l, dur) =>
    (Array.isArray(l) ? l : [])
      .slice(0, 40)
      .map(q => ({
        t: N(q && q.t, 0, dur, 0),
        w: N(q && q.w, 0.1, 30, 0.7),
        h: N(q && q.h, 0.1, 30, 1.5),
        x: N(q && q.x, -10, 10, 0),
        y: N(q && q.y, -10, 10, 0)
      }))
      .sort((a, b) => a.t - b.t);
  const bodyOf = (m, dur, iframes) => {
    let off = offs(m && m.body && m.body.off, dur);
    if (!off.length && iframes === 'yes') off = [{ from: 0, to: dur }];
    return {
      off,
      kf: bkf(m && m.body && m.body.kf, dur),
      shape: m && m.body && SHAPES.includes(m.body.shape) ? m.body.shape : ''
    };
  };
  const bodyKf = (b, t) => {
    const k = b && b.kf;
    if (!k || !k.length) return null;
    if (t <= k[0].t) return k[0];
    for (let i = 1; i < k.length; i++)
      if (t <= k[i].t) {
        const a = k[i - 1],
          c = k[i],
          u = c.t === a.t ? 1 : (t - a.t) / (c.t - a.t);
        return {
          w: a.w + (c.w - a.w) * u,
          h: a.h + (c.h - a.h) * u,
          x: a.x + (c.x - a.x) * u,
          y: a.y + (c.y - a.y) * u
        };
      }
    return k[k.length - 1];
  };
  const isOff = (b, t) => !!(b && (b.off || []).some(q => t >= q.from && t <= q.to));
  // The player's own body hitbox (project setting). Without w and h it follows the player's size; ox and oy move it from the middle of the body.
  const bodyClean = b => {
    b = b || {};
    const sh = SHAPES.includes(b.shape) ? b.shape : 'rect',
      o = {
        shape: sh,
        r: N(b.r, 0.05, 15, 0.4),
        pts: ptsOf(b.pts) || [
          { x: -0.35, y: 0.75 },
          { x: -0.35, y: -0.75 },
          { x: 0.35, y: -0.75 },
          { x: 0.35, y: 0.75 }
        ],
        ox: N(b.ox, -10, 10, 0),
        oy: N(b.oy, -10, 10, 0)
      };
    if (b.w !== undefined && b.w !== null && b.w !== '') o.w = N(b.w, 0.1, 30, 0.7);
    if (b.h !== undefined && b.h !== null && b.h !== '') o.h = N(b.h, 0.1, 30, 1.5);
    return o;
  };
  const body = (b, pr) => {
    const o = bodyClean(b);
    if (o.w === undefined) o.w = pr.w;
    if (o.h === undefined) o.h = pr.h;
    return o;
  };
  // The body hitbox in the world for a player at feet (px, py) facing face; sq < 1 squashes it with a low body (a roll).
  const bodyWorld = (b, pr, px, py, face, sq, ov) => {
    b = body(b, pr);
    sq = sq || 1;
    if (ov) {
      const sx = ov.w / b.w,
        sy = ov.h / b.h;
      b = Object.assign({}, b, {
        w: ov.w,
        h: ov.h,
        r: b.r * Math.sqrt(sx * sy),
        pts: b.pts.map(q => ({ x: q.x * sx, y: q.y * sy })),
        ox: b.ox + ov.x,
        oy: b.oy + ov.y
      });
      if (ov.shape) {
        b.shape = ov.shape;
        if (ov.shape === 'circle') b.r = Math.max(0.05, Math.min(ov.w, ov.h) / 2);
      }
    } // a move can change the body shape while it plays
    const cx = px + (face || 1) * b.ox,
      cy = py - (pr.h * sq) / 2 + b.oy * sq;
    if (b.shape === 'circle')
      return { sh: 'circle', cx, cy, r: b.r * Math.min(1, sq + 0.0001), w: b.r * 2, h: b.r * 2 * sq };
    if (b.shape === 'polygon') {
      const P = b.pts.map(q => ({ x: cx + (face || 1) * q.x, y: cy + q.y * sq })),
        bb = bbox(P);
      return { sh: 'polygon', cx, cy, pts: P, w: bb.w, h: bb.h };
    }
    return { sh: 'rect', cx, cy, w: b.w, h: b.h * sq };
  };
  // Extras that moves and attacks share: chaining into another move, charging, shots that fly out, and effects on events.
  const EFX_ON = ['start', 'hit', 'land', 'wall', 'end', 'charged'],
    EFX_DO = ['bounce', 'refill', 'slow', 'teleport', 'knock', 'heal', 'endmove', 'sound', 'energy'],
    UNTIL = ['time', 'land', 'wall', 'ceiling', 'release', 'jump'];
  const effects = l =>
    (Array.isArray(l) ? l : [])
      .slice(0, 8)
      .map(q => ({
        on: EFX_ON.includes(q && q.on) ? q.on : 'hit',
        do: EFX_DO.includes(q && q.do) ? q.do : 'bounce',
        value: N(q && q.value, -60, 60, 10),
        snd: q && typeof q.snd === 'string' && /^[\w-]{1,24}$/.test(q.snd) ? q.snd : ''
      }));
  const shots = (l, dur) =>
    (Array.isArray(l) ? l : []).slice(0, 8).map(q => {
      q = q || {};
      const sh = q.shape === 'circle' ? 'circle' : 'rect',
        r = N(q.r, 0.05, 5, 0.25);
      return {
        name: S(q.name, 'Shot'),
        at: N(q.at, 0, dur, 0),
        shape: sh,
        w: sh === 'circle' ? r * 2 : N(q.w, 0.1, 10, 0.6),
        h: sh === 'circle' ? r * 2 : N(q.h, 0.1, 10, 0.3),
        r,
        speed: N(q.speed, 0, 80, 18),
        angle: N(q.angle, -180, 180, 0),
        ox: N(q.ox, -10, 10, 1),
        oy: N(q.oy, -10, 10, -0.75),
        gravity: N(q.gravity, 0, 3, 0),
        life: N(q.life, 0.1, 10, 1.5),
        damage: N(q.damage, 0, 99, 1),
        pierce: q.pierce === 'yes' ? 'yes' : 'no'
      };
    });
  const steps = l => {
    const k = (Array.isArray(l) ? l : []).slice(0, 8).map(q => {
      q = q || {};
      return {
        name: S(q.name, 'Step'),
        dur: N(q.dur, 0.02, 3, 0.2),
        vx: N(q.vx, -80, 80, 0),
        vy: N(q.vy, -80, 80, 0),
        gravity: N(q.gravity, 0, 3, 0),
        steer: N(q.steer, 0, 1, 0),
        accel: N(q.accel, -300, 300, 0),
        aim: q.aim === 'input' ? 'input' : 'forward',
        until: UNTIL.includes(q.until) ? q.until : 'time'
      };
    });
    return k.length
      ? k
      : [{ name: 'Step 1', dur: 0.2, vx: 12, vy: 0, gravity: 0, steer: 0, accel: 0, aim: 'forward', until: 'time' }];
  };
  const extras = (m, dur) => ({
    chainTo: typeof m.chainTo === 'string' && /^[ma]:[\w-]{1,24}$/.test(m.chainTo) ? m.chainTo : '',
    chainWin: N(m.chainWin, 0.05, 2, 0.4),
    charge: N(m.charge, 0, 5, 0),
    chargeMult: N(m.chargeMult, 1, 10, 2),
    chargeLock: m.chargeLock === 'yes' ? 'yes' : 'no',
    more: moreKeys(m.more),
    shots: shots(m.shots, dur),
    effects: effects(m.effects)
  });
  // Extra keys that must also be held (a chord like X + Space + Down): Key and Also hold, plus these.
  const moreKeys = l => {
    const o = [];
    (Array.isArray(l) ? l : []).forEach(k => {
      if (typeof k === 'string' && k !== 'None' && /^[A-Za-z0-9]{1,16}$/.test(k) && !o.includes(k) && o.length < 5)
        o.push(k);
    });
    return o;
  };
  const FIELDS = {
    // the plain numbers and choices of an attack (the editor builds its form from this)
    label: { t: 'text', def: 'Attack', label: 'Name', help: 'Shown in the list.' },
    key: { t: 'key', def: 'KeyX', label: 'Key', help: 'Click, then press the key you want.' },
    with: {
      t: 'key',
      def: 'None',
      label: 'Also hold',
      help: 'A second key that must be held, for example Up for an upward slash. None = no second key.'
    },
    requires: { t: 'text', def: '', label: 'Unlocked by', help: 'Ability id from a pickup. Empty = always available.' },
    weapon: {
      t: 'text',
      def: '',
      label: 'Weapon id',
      help: 'The weapon this attack belongs to, for example sword. It only works while you hold that weapon (get it from a Pickup or Chest of kind weapon, switch with Tab). Empty = works with any weapon, or none.'
    },
    where: {
      t: 'select',
      def: 'any',
      o: ['any', 'ground', 'air'],
      label: 'Usable',
      help: 'Where the attack can start.'
    },
    cost: {
      t: 'number',
      def: 0,
      min: 0,
      max: 200,
      step: 1,
      label: 'Energy cost',
      help: 'Energy spent when the attack starts. You cannot use it with less energy than this. Needs Energy set in Settings. 0 = free.'
    },
    damage: {
      t: 'number',
      def: 1,
      min: 0,
      max: 99,
      step: 1,
      label: 'Damage',
      help: 'Health taken from what the attack boxes hit.'
    },
    dtype: {
      t: 'select',
      def: 'physical',
      o: ['physical', 'fire', 'ice', 'poison', 'shock'],
      label: 'Damage type',
      help: 'What kind of damage the hit does. Enemies and bosses can be weak to a type (double damage), resist it (half) or be immune.'
    },
    inflict: {
      t: 'select',
      def: 'none',
      o: ['none', 'poison', 'burn', 'slow'],
      label: 'Inflicts',
      help: 'A status effect the hit puts on what it hits: poison and burn hurt over time, slow makes it move and act slower.'
    },
    inflictTime: {
      t: 'number',
      def: 4,
      min: 0.5,
      max: 60,
      step: 0.5,
      label: 'Status lasts (s)',
      help: 'How long the status lasts.'
    },
    duration: {
      t: 'number',
      def: 0.3,
      min: 0.05,
      max: 5,
      step: 0.01,
      label: 'Length (s)',
      help: 'The whole attack, from start to the moment you can act again.'
    },
    cooldown: {
      t: 'number',
      def: 0.1,
      min: 0,
      max: 10,
      step: 0.01,
      label: 'Cooldown (s)',
      help: 'Wait after the attack before it can be used again.'
    },
    speed: {
      t: 'number',
      def: 0,
      min: 0,
      max: 60,
      step: 0.5,
      label: 'Forward speed (tiles/s)',
      help: 'Push the player forward during the attack. The speed curve in the timeline changes it over time. 0 = no push.'
    },
    lock: {
      t: 'select',
      def: 'no',
      o: ['no', 'yes'],
      label: 'Hold the player still',
      help: 'Yes: you cannot run, jump or turn while the attack plays. No: you keep control.'
    },
    gravity: {
      t: 'number',
      def: 1,
      min: 0,
      max: 3,
      step: 0.05,
      label: 'Gravity x',
      help: 'Only when the player is held or pushed: 0 = float, 1 = normal. Ignored when you keep control or when the player follows a path.'
    },
    keep: {
      t: 'number',
      def: 0.2,
      min: 0,
      max: 1,
      step: 0.05,
      label: 'Keep speed after',
      help: 'When an attack that moves the player ends, this share of its speed is kept (0 = stop dead, 1 = keep sliding).'
    },
    stop: {
      t: 'select',
      def: 'no',
      o: ['no', 'yes'],
      label: 'Stop when blocked',
      help: 'End the movement early when the player hits a wall, floor or ceiling.'
    }
  };
  const TOP = ['label', 'key', 'with', 'requires', 'weapon', 'where', 'duration']; // the form shows these above the timeline; the rest (movement and timing) sit below it
  const clean1 = a => {
    a = a || {};
    const o = {};
    for (const k in FIELDS) {
      const f = FIELDS[k];
      let v = a[k];
      if (f.t === 'number') v = N(v, f.min, f.max, f.def);
      else if (f.t === 'select') {
        if (!f.o.includes(v)) v = f.def;
      } else if (f.t === 'key') v = key(v, f.def);
      else v = S(v, f.def);
      o[k] = v;
    }
    o.id =
      typeof a.id === 'string' && /^[\w-]{1,24}$/.test(a.id) ? a.id : 'atk' + Math.random().toString(36).slice(2, 5);
    if (!o.label) o.label = o.id;
    o.weapon = String(o.weapon || '')
      .replace(/[^\w-]/g, '')
      .slice(0, 30);
    Object.assign(o, extras(a, o.duration));
    o.body = bodyOf(a, o.duration, a.iframes);
    o.hitboxes = hitboxes(a.hitboxes, o.duration);
    o.curve = curve(a.curve, o.duration);
    o.path = path(a.path, o.duration);
    o.anim = anim(a.anim);
    return o;
  };
  // The slash every project had before attacks became editable: same swing time, cooldown and reach as the old Player settings.
  const fromTuning = t => {
    t = t || {};
    const T = MV.Tuning
      ? MV.Tuning.resolve(t)
      : { attackTime: 0.18, attackCooldown: 0.1, attackReach: 1.3, w: 0.7, h: 1.5 };
    return clean1({
      id: 'slash',
      label: 'Slash',
      key: 'KeyX',
      duration: T.attackTime,
      cooldown: T.attackCooldown,
      hitboxes: [
        {
          name: 'Blade',
          w: T.attackReach,
          h: T.h,
          from: 0,
          to: T.attackTime,
          kf: [{ t: 0, x: T.w / 2 + T.attackReach / 2, y: -T.h / 2 }]
        }
      ]
    });
  };
  const resolve = (list, tune) => {
    if (!Array.isArray(list)) return [fromTuning(tune)];
    const seen = {};
    return list
      .slice(0, 12)
      .map(clean1)
      .filter(a => !seen[a.id] && (seen[a.id] = 1));
  };
  const sample = (k, t) => {
    if (!k.length) return { x: 0, y: 0 };
    if (t <= k[0].t) return k[0];
    for (let i = 1; i < k.length; i++)
      if (t <= k[i].t) {
        const a = k[i - 1],
          b = k[i],
          u = b.t === a.t ? 1 : (t - a.t) / (b.t - a.t);
        return { x: a.x + (b.x - a.x) * u, y: a.y + (b.y - a.y) * u };
      }
    return k[k.length - 1];
  };
  const curveAt = (c, t) => {
    if (!c || !c.length) return 1;
    if (t <= c[0].t) return c[0].v;
    for (let i = 1; i < c.length; i++)
      if (t <= c[i].t) {
        const a = c[i - 1],
          b = c[i],
          u = b.t === a.t ? 1 : (t - a.t) / (b.t - a.t);
        return a.v + (b.v - a.v) * u;
      }
    return c[c.length - 1].v;
  };
  // Where each active attack box is at time t, in world tiles, for a player at (px, py) feet facing face (1 or -1). d = damage.
  const rects = (list, t, face, px, py, d) => {
    const o = [];
    (list || []).forEach(h => {
      if (t < h.from || t > h.to) return;
      const k = sample(h.kf, t),
        cx = px + face * k.x,
        cy = py + k.y,
        r = { cx, cy, w: h.w, h: h.h, d, vis: h.vis, t: t - h.from, sh: h.shape || 'rect', r: h.r };
      if (r.sh === 'polygon') r.pts = (h.pts || DEFPOLY()).map(q => ({ x: cx + face * q.x, y: cy + q.y }));
      o.push(r);
    });
    return o;
  };
  const inPoly = (P, x, y) => {
    let c = false;
    for (let i = 0, j = P.length - 1; i < P.length; j = i++)
      if (P[i].y > y !== P[j].y > y && x < ((P[j].x - P[i].x) * (y - P[i].y)) / (P[j].y - P[i].y) + P[i].x) c = !c;
    return c;
  };
  const segHit = (a, b, c, d) => {
    const o = (p, q, r) => (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x);
    return o(a, b, c) > 0 !== o(a, b, d) > 0 && o(c, d, a) > 0 !== o(c, d, b) > 0;
  };
  // Does a shape (from rects() or bodyWorld()) touch the box x0..x1, y0..y1?
  const hits = (r, x0, y0, x1, y1) => {
    if (r.sh === 'circle') {
      const nx = Math.max(x0, Math.min(r.cx, x1)),
        ny = Math.max(y0, Math.min(r.cy, y1));
      return Math.hypot(r.cx - nx, r.cy - ny) < r.r;
    }
    if (r.sh === 'polygon') {
      const P = r.pts;
      if (P.some(q => q.x > x0 && q.x < x1 && q.y > y0 && q.y < y1)) return true;
      const C = [
        { x: x0, y: y0 },
        { x: x1, y: y0 },
        { x: x1, y: y1 },
        { x: x0, y: y1 }
      ];
      if (C.some(q => inPoly(P, q.x, q.y))) return true;
      for (let i = 0; i < P.length; i++)
        for (let j = 0; j < 4; j++) if (segHit(P[i], P[(i + 1) % P.length], C[j], C[(j + 1) % 4])) return true;
      return false;
    }
    return r.cx + r.w / 2 > x0 && r.cx - r.w / 2 < x1 && r.cy + r.h / 2 > y0 && r.cy - r.h / 2 < y1;
  };
  // Shape against shape (both from rects() or bodyWorld()): a rectangle, circle or polygon touching another. Corners and edges are compared, so thin and concave shapes work.
  const outline = r => {
    if (r.sh === 'circle') {
      const P = [];
      for (let i = 0; i < 16; i++)
        P.push({ x: r.cx + Math.cos((i / 16) * 6.2832) * r.r, y: r.cy + Math.sin((i / 16) * 6.2832) * r.r });
      return P;
    }
    if (r.sh === 'polygon') return r.pts;
    return [
      { x: r.cx - r.w / 2, y: r.cy - r.h / 2 },
      { x: r.cx + r.w / 2, y: r.cy - r.h / 2 },
      { x: r.cx + r.w / 2, y: r.cy + r.h / 2 },
      { x: r.cx - r.w / 2, y: r.cy + r.h / 2 }
    ];
  };
  const shapeHit = (a, b) => {
    if (!a || !b) return false;
    if (Math.abs(a.cx - b.cx) > (a.w + b.w) / 2 + 0.01 || Math.abs(a.cy - b.cy) > (a.h + b.h) / 2 + 0.01) return false;
    if (a.sh !== 'circle' && a.sh !== 'polygon')
      return hits(b, a.cx - a.w / 2, a.cy - a.h / 2, a.cx + a.w / 2, a.cy + a.h / 2);
    if (b.sh !== 'circle' && b.sh !== 'polygon')
      return hits(a, b.cx - b.w / 2, b.cy - b.h / 2, b.cx + b.w / 2, b.cy + b.h / 2);
    const A = outline(a),
      B = outline(b);
    if (A.some(q => inPoly(B, q.x, q.y)) || B.some(q => inPoly(A, q.x, q.y))) return true;
    for (let i = 0; i < A.length; i++)
      for (let j = 0; j < B.length; j++)
        if (segHit(A[i], A[(i + 1) % A.length], B[j], B[(j + 1) % B.length])) return true;
    return false;
  };
  // Draw a shape path (for the game and the editor): Z = pixels per tile.
  const trace = (x, r, Z) => {
    x.beginPath();
    if (r.sh === 'circle') x.arc(r.cx * Z, r.cy * Z, r.r * Z, 0, 7);
    else if (r.sh === 'polygon') {
      r.pts.forEach((q, i) => (i ? x.lineTo(q.x * Z, q.y * Z) : x.moveTo(q.x * Z, q.y * Z)));
      x.closePath();
    } else x.rect((r.cx - r.w / 2) * Z, (r.cy - r.h / 2) * Z, r.w * Z, r.h * Z);
  };
  return {
    moreKeys,
    FIELDS,
    TOP,
    SHAPES,
    EFX_ON,
    EFX_DO,
    UNTIL,
    effects,
    shots,
    steps,
    extras,
    bodyKf,
    bkf,
    DEFPOLY,
    shape,
    path,
    clean1,
    resolve,
    fromTuning,
    hitboxes,
    hitbox,
    curve,
    anim,
    sample,
    curveAt,
    rects,
    hits,
    shapeHit,
    outline,
    trace,
    inPoly,
    bodyClean,
    body,
    bodyWorld,
    isOff,
    offs,
    bodyOf
  };
})();
