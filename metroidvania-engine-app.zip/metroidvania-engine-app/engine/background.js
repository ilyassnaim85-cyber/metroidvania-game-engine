// Room background: a color plus as many image layers as you want (up to 256; a new room starts with 4: far, middle, near, and a front layer drawn over the player). Each layer has its own image, name, fit, opacity, blur, fog, camera
// scroll (0 fixed on screen, 1 moves with the room, above 1 moves faster for a foreground feel) and can be drawn
// behind the game or in front of it. Shared by the editor canvas and the runtime.
window.MV = window.MV || {};
MV.Background = (() => {
  const MAXL = 256,
    NAMES = ['Far layer', 'Middle layer', 'Near layer', 'Front layer'];
  const layerDef = i => ({
    name: NAMES[i] || 'Layer ' + (i + 1),
    sheet: '',
    mode: 'cover',
    parallax: i < 4 ? [0.25, 0.5, 0.8, 1.15][i] : 0.6,
    front: i === 3,
    x: 0,
    y: 0,
    w: 0,
    h: 0,
    alpha: 1,
    driftX: 0,
    driftY: 0,
    sway: 0,
    swayHz: 0.4,
    blur: 0,
    fog: 0,
    fogColor: '#9fb4c8',
    fogDir: 'even',
    vis: true
  });
  const nn = (v, a, b, d) => {
    v = +v;
    return isFinite(v) ? Math.max(a, Math.min(b, v)) : d;
  };
  const def = () => ({ color: '#12324a', layers: [0, 1, 2, 3].map(layerDef) });
  const clean = b => {
    if (!b || typeof b !== 'object') return null;
    const legacy = !Array.isArray(b.layers); // older maps had one image
    let src = legacy ? [{ sheet: b.sheet, mode: b.mode, parallax: b.parallax }] : b.layers.slice(0, MAXL),
      n = legacy ? 4 : src.length;
    return {
      color: /^#[0-9a-f]{6}$/i.test(b.color) ? b.color : '#12324a',
      layers: Array.from({ length: n }, (_, i) => {
        const L = src[i] || {},
          d = layerDef(i),
          p = L.parallax === null || L.parallax === '' || L.parallax === undefined ? NaN : +L.parallax;
        return {
          name: typeof L.name === 'string' && L.name.trim() ? L.name.slice(0, 30) : d.name,
          sheet: typeof L.sheet === 'string' ? L.sheet : '',
          mode: ['cover', 'stretch', 'tile', 'free'].includes(L.mode) ? L.mode : 'cover',
          parallax: isFinite(p) ? Math.max(0, Math.min(2, p)) : d.parallax,
          front: i === 3 && L.front === undefined && legacy ? true : L.front === true,
          x: nn(L.x, -20000, 20000, 0),
          y: nn(L.y, -20000, 20000, 0),
          w: nn(L.w, 0, 20000, 0),
          h: nn(L.h, 0, 20000, 0),
          alpha: nn(L.alpha, 0, 1, 1),
          driftX: nn(L.driftX, -10, 10, 0),
          driftY: nn(L.driftY, -10, 10, 0),
          sway: nn(L.sway, 0, 3, 0),
          swayHz: nn(L.swayHz, 0, 4, 0.4),
          blur: nn(L.blur, 0, 40, 0),
          fog: nn(L.fog, 0, 1, 0),
          fogColor: /^#[0-9a-f]{6}$/i.test(L.fogColor) ? L.fogColor : d.fogColor,
          fogDir: ['even', 'bottom', 'top'].includes(L.fogDir) ? L.fogDir : 'even',
          vis: L.vis !== false
        };
      })
    };
  };
  function layer(ctx, L, img, rw, rh, vw, vh, cx, cy, opt) {
    const k0 = opt && opt.k,
      mg = (opt && opt.m) || 0,
      s = L.mode === 'free' && opt && opt.exact ? 1 : L.parallax,
      Lw = vw + Math.max(0, rw - vw) * s,
      Lh = vh + Math.max(0, rh - vh) * s,
      kk = k0 || 32,
      tm = (opt && opt.time) || 0,
      mv = L.mode === 'tile' || L.mode === 'free', // drifting and swaying (clouds, bubbles, kelp) need a layer that can move without leaving gaps
      sw = mv && L.sway > 0 ? Math.sin(tm * Math.PI * 2 * L.swayHz) * L.sway * kk : 0,
      ox = -cx * s + (mv ? (L.driftX || 0) * kk * tm + sw : 0),
      oy =
        -cy * s +
        (mv ? (L.driftY || 0) * kk * tm + (sw ? Math.cos(tm * Math.PI * 2 * L.swayHz) * L.sway * kk * 0.5 : 0) : 0),
      iw = img.naturalWidth,
      ih = img.naturalHeight;
    ctx.save();
    ctx.beginPath();
    ctx.rect(-mg, -mg, vw + 2 * mg, vh + 2 * mg);
    ctx.clip();
    ctx.imageSmoothingEnabled = false;
    if (L.mode === 'stretch')
      ctx.drawImage(img, ox - mg, oy - mg, Lw + 2 * mg, Lh + 2 * mg); // (mg = the extra edge a blurred layer needs so its borders do not fade)
    else if (L.mode === 'free' && k0 && L.w > 0)
      ctx.drawImage(img, L.x * k0 + ox, L.y * k0 + oy, L.w * k0, (L.h > 0 ? L.h : (L.w * ih) / iw) * k0); // free: placed in tiles (x, y, width, height) where you dragged it
    else if (L.mode === 'tile') {
      if (iw >= 4 && ih >= 4) {
        let x0 = ox % iw;
        if (x0 > 0) x0 -= iw;
        let y0 = oy % ih;
        if (y0 > 0) y0 -= ih;
        x0 -= Math.ceil(mg / iw) * iw;
        y0 -= Math.ceil(mg / ih) * ih;
        for (let y = y0; y < vh + mg; y += ih) for (let x = x0; x < vw + mg; x += iw) ctx.drawImage(img, x, y);
      }
    } else {
      const k = Math.max(Lw / iw, Lh / ih),
        dw = iw * k,
        dh = ih * k;
      ctx.drawImage(img, ox + (Lw - dw) / 2 - mg, oy + (Lh - dh) / 2 - mg, dw + 2 * mg, dh + 2 * mg);
    }
    ctx.restore();
  }
  // front = false: the color and the layers behind the game. front = true: only the layers in front of it (alpha lets the editor show them see-through).
  // A layer with blur or fog is drawn on a scratch canvas first: the fog colour is laid over the layer's own pixels only (even, or fading in from the bottom or the top), then it is blurred onto the screen.
  let tmp = null;
  function drawFx(ctx, L, img, rw, rh, vw, vh, cx, cy, opt) {
    const k = (opt && opt.k) || 32,
      bp = (L.blur * k) / 32,
      m = Math.ceil(bp * 2.5),
      W = Math.ceil(vw + 2 * m),
      Hh = Math.ceil(vh + 2 * m);
    if (!tmp) tmp = document.createElement('canvas');
    if (tmp.width !== W || tmp.height !== Hh) {
      tmp.width = W;
      tmp.height = Hh;
    }
    const t = tmp.getContext('2d');
    t.setTransform(1, 0, 0, 1, 0, 0);
    t.clearRect(0, 0, W, Hh);
    t.globalAlpha = 1;
    t.globalCompositeOperation = 'source-over';
    t.translate(m, m);
    layer(t, L, img, rw, rh, vw, vh, cx, cy, Object.assign({}, opt, { m }));
    if (L.fog > 0) {
      t.setTransform(1, 0, 0, 1, 0, 0);
      t.globalCompositeOperation = 'source-atop';
      let fs = L.fogColor;
      if (L.fogDir !== 'even') {
        const g = t.createLinearGradient(0, m, 0, m + vh);
        const a = L.fogDir === 'bottom' ? [0, 1] : [1, 0],
          c = L.fogColor,
          r = parseInt(c.slice(1, 3), 16),
          gg = parseInt(c.slice(3, 5), 16),
          bb = parseInt(c.slice(5, 7), 16);
        g.addColorStop(0, 'rgba(' + r + ',' + gg + ',' + bb + ',' + a[0] + ')');
        g.addColorStop(1, 'rgba(' + r + ',' + gg + ',' + bb + ',' + a[1] + ')');
        fs = g;
      }
      t.globalAlpha = L.fog;
      t.fillStyle = fs;
      t.fillRect(0, 0, W, Hh);
      t.globalAlpha = 1;
      t.globalCompositeOperation = 'source-over';
    }
    ctx.save();
    ctx.globalAlpha *= 1;
    if (bp > 0.05) ctx.filter = 'blur(' + bp.toFixed(2) + 'px)';
    ctx.drawImage(tmp, -m, -m);
    ctx.restore();
  }
  // front = false: the color and the layers behind the game. front = true: only the layers in front of it (alpha lets the editor show them see-through).
  function draw(ctx, bg, imgOf, rw, rh, vw, vh, cx, cy, front, alpha, opt) {
    if (!front) {
      ctx.fillStyle = bg.color;
      ctx.fillRect(0, 0, vw, vh);
    }
    bg.layers.forEach(L => {
      if (!!L.front !== !!front || !L.sheet || L.vis === false) return;
      const img = imgOf(L.sheet);
      if (img && img.complete && img.naturalWidth) {
        ctx.save();
        ctx.globalAlpha = (alpha || 1) * (L.alpha === undefined ? 1 : L.alpha);
        if (L.blur > 0 || L.fog > 0) drawFx(ctx, L, img, rw, rh, vw, vh, cx, cy, opt);
        else layer(ctx, L, img, rw, rh, vw, vh, cx, cy, opt);
        ctx.restore();
      }
    });
  }
  return { def, clean, draw, MAXL, layerDef };
})();
