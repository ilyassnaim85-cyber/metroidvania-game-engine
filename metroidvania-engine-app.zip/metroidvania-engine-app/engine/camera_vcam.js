// Virtual cameras (Cinemachine style). A virtual camera is a saved set of camera settings with a priority; the highest-priority one that is on (and belongs to this room) is live.
// This file only decides WHICH one is live and blends between them; the work of following and framing is done by MV.CameraRig, which it drives through one override.
// Project data: S.vcams = [{ id, name, on, priority, room, follow, offset, zoom, rot, mode, profile, p, bounds, blend }]. See CAMERA.md.
window.MV = window.MV || {};
MV.CameraVcams = (() => {
  const fin = (v, d) => (v !== null && v !== '' && v !== undefined && isFinite(+v) ? +v : d);
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const MAX = 24;
  const FOLLOW = ['player', 'point', 'entity', 'boss'];
  const EASES = ['linear', 'easeIn', 'easeOut', 'easeInOut', 'smooth', 'smoother', 'sine', 'overshoot', 'bounce'];
  const LEAD = 'vcam'; // id of the one override the manager owns
  const ease = e => {
    if (Array.isArray(e) && e.length === 4 && e.every(v => typeof v === 'number' && isFinite(v))) return e.slice();
    return EASES.includes(e) ? e : 'smooth';
  };
  const box = b => {
    if (!Array.isArray(b) || b.length !== 4 || !b.every(v => isFinite(+v))) return null;
    const q = b.map(Number);
    return q[2] > q[0] && q[3] > q[1] ? q : null;
  };
  const id1 = v =>
    String(v || '')
      .toLowerCase()
      .replace(/[^a-z0-9_]/g, '')
      .slice(0, 24);
  const one = (c, used) => {
    c = c && typeof c === 'object' ? c : {};
    let id = id1(c.id) || 'cam';
    if (used.has(id)) {
      let n = 2;
      while (used.has(id.slice(0, 20) + n)) n++;
      id = id.slice(0, 20) + n;
    }
    used.add(id);
    const f = c.follow && typeof c.follow === 'object' ? c.follow : {},
      o = c.offset && typeof c.offset === 'object' ? c.offset : {},
      b = c.blend && typeof c.blend === 'object' ? c.blend : {};
    return {
      id,
      name: String(c.name || id).slice(0, 40),
      on: c.on !== false,
      priority: Math.round(clamp(fin(c.priority, 10), -1000, 1000)),
      room: String(c.room || '').slice(0, 40),
      follow: {
        kind: FOLLOW.includes(f.kind) ? f.kind : 'player',
        x: clamp(fin(f.x, 0), -10000, 10000),
        y: clamp(fin(f.y, 0), -10000, 10000),
        id: String(f.id || '').slice(0, 40)
      },
      offset: { x: clamp(fin(o.x, 0), -30, 30), y: clamp(fin(o.y, 0), -30, 30) },
      zoom: clamp(fin(c.zoom, 1), 0.25, 4),
      rot: clamp(fin(c.rot, 0), -180, 180),
      mode: ['', 'follow', 'side', 'topdown', 'fixed'].includes(c.mode) ? c.mode : '',
      profile: id1(c.profile),
      p: MV.Camera.cleanP(c.p),
      bounds: box(c.bounds),
      blend: { time: clamp(fin(b.time, 0.8), 0, 10), ease: ease(b.ease) }
    };
  };
  const clean = l => {
    const used = new Set();
    return (Array.isArray(l) ? l : []).slice(0, MAX).map(c => one(c, used));
  };
  const blank = (name, list) => {
    const used = new Set((list || []).map(c => c.id));
    return one({ id: id1(name) || 'cam', name: name || 'Camera' }, used);
  };
  // problems in a project's virtual cameras: [{ level, text }]
  const validate = w => {
    const out = [],
      add = (level, text) => out.push({ level, text });
    const list = clean(w && w.vcams),
      rooms = new Set();
    ((w && w.areas) || []).forEach(a => (a.rooms || []).forEach(r => rooms.add(r.id)));
    const profs = new Set(MV.Camera.all(w && w.camProfiles).map(p => p.id));
    ((w && w.vcams) || []).forEach(c => {
      if (c && c.bounds && !box(c.bounds))
        add(
          'error',
          'Virtual camera "' +
            (c.name || c.id) +
            '" has bounds that are not a box (right and bottom must be bigger than left and top).'
        );
    });
    list.forEach(c => {
      if (c.room && rooms.size && !rooms.has(c.room))
        add('warn', 'Virtual camera "' + c.name + '" belongs to the room "' + c.room + '", which does not exist.');
      if (c.profile && !profs.has(c.profile))
        add(
          'warn',
          'Virtual camera "' + c.name + '" uses the camera profile "' + c.profile + '", which does not exist.'
        );
      if (c.follow.kind === 'entity' && !c.follow.id)
        add('warn', 'Virtual camera "' + c.name + '" follows an entity but names none.');
    });
    const top = {};
    list.forEach(c => {
      if (!c.on) return;
      const k = (c.room || '*') + '|' + c.priority;
      (top[k] = top[k] || []).push(c.name);
    });
    for (const k in top)
      if (top[k].length > 1)
        add(
          'info',
          'Virtual cameras ' +
            top[k].map(n => '"' + n + '"').join(', ') +
            ' share a priority in the same room; the one lower in the list wins.'
        );
    return out;
  };

  // The manager. rig: a MV.CameraRig. env: { entity(id) -> entity or null, boss() -> the awake boss or null }
  class Manager {
    constructor(rig, env) {
      this.rig = rig;
      this.env = env || {};
      this.cur = null; // the camera that is live now (its cleaned data)
      this.rt = {}; // changes made by script this play: { id: { on, priority } }
      this.solo_ = '';
      this.B = null; // a blend in progress between two cameras
      this.v = null; // the values the override has right now
    }
    _eff(list, roomId) {
      const out = [];
      list.forEach((c, i) => {
        const r = this.rt[c.id] || {},
          on = r.on !== undefined ? r.on : c.on;
        if (this.solo_) {
          if (c.id === this.solo_) out.push({ c, pri: 1e9, i });
          return;
        }
        if (!on || (c.room && c.room !== roomId)) return;
        out.push({ c, pri: r.priority !== undefined ? r.priority : c.priority, i });
      });
      out.sort((a, b) => a.pri - b.pri || a.i - b.i);
      return out.length ? out[out.length - 1].c : null;
    }
    _target(c) {
      const f = c.follow;
      if (f.kind === 'point') return { x: f.x, y: f.y };
      if (f.kind === 'entity') {
        const env = this.env;
        return () => {
          const e = env.entity && env.entity(f.id);
          return e && !e.dead ? { x: e.cx, y: e.by - (e.h || 0) / 2 } : null;
        };
      }
      if (f.kind === 'boss') {
        const env = this.env;
        return () => {
          const e = env.boss && env.boss();
          return e ? { x: e.cx, y: e.by - (e.h || 0) / 2 } : null;
        };
      }
      return undefined; // the player: no override of the target
    }
    _vals(c) {
      return { zoom: c.zoom, rot: c.rot, ox: c.offset.x, oy: c.offset.y, p: Object.assign({}, c.p) };
    }
    // call once per frame, before the rig's update. list: the project's virtual cameras (cleaned), roomId: the room the player is in
    tick(dt, list, roomId) {
      const rig = this.rig;
      if (!rig || !Array.isArray(list)) return;
      const win = this._eff(list, roomId);
      if (!win) {
        if (this.cur) {
          rig.endOverride(LEAD, this.cur.blend.time || 0.01);
          this.cur = null;
          this.B = null;
        }
        return;
      }
      const live = rig.overrides().some(q => q.id === LEAD && !q.ending);
      if (!this.cur || !live) {
        // none was live: fade the camera's settings in over the blend time
        this.v = this._vals(win);
        rig.override({
          id: LEAD,
          priority: -50,
          zoom: win.zoom,
          rot: win.rot,
          offset: win.offset,
          p: win.p,
          bounds: win.bounds === null ? undefined : win.bounds,
          target: this._target(win),
          mode: win.mode || undefined,
          profile: win.profile || undefined,
          blend: Math.max(0.01, win.blend.time),
          ease: win.blend.ease
        });
        this.cur = win;
        this.sig = JSON.stringify([win.follow, win.bounds, win.mode, win.profile]);
        this.B = null;
        return;
      }
      const sig = JSON.stringify([win.follow, win.bounds, win.mode, win.profile]);
      if (win.id !== this.cur.id) {
        // another camera won: blend the numbers from where they are now, and hand over the follow target and the limits at once (the rig glides to them)
        const t = Math.max(0, win.blend.time);
        this.B = { from: this.v, to: this._vals(win), t: 0, dur: t, ease: win.blend.ease };
        rig._retarget(Math.max(0.05, t));
      }
      if (sig !== this.sig || win.id !== this.cur.id)
        rig.overrideSet(LEAD, {
          target: this._target(win),
          bounds: win.bounds === null ? undefined : win.bounds,
          mode: win.mode || undefined,
          profile: win.profile || undefined
        });
      this.sig = sig;
      this.cur = win;
      if (this.B) {
        const B = this.B;
        B.t += clamp(fin(dt, 0), 0, 0.1);
        const u = B.dur > 0 ? clamp(B.t / B.dur, 0, 1) : 1,
          e = MV.CameraRig.curve(B.ease)(u),
          L = (a, b) => a + (b - a) * e;
        const p = Object.assign({}, B.to.p);
        for (const k in B.to.p)
          if (typeof B.to.p[k] === 'number' && typeof B.from.p[k] === 'number') p[k] = L(B.from.p[k], B.to.p[k]);
        this.v = {
          zoom: L(B.from.zoom, B.to.zoom),
          rot: L(B.from.rot, B.to.rot),
          ox: L(B.from.ox, B.to.ox),
          oy: L(B.from.oy, B.to.oy),
          p
        };
        if (u >= 1) this.B = null;
      } else this.v = this._vals(this.cur);
      rig.overrideSet(LEAD, {
        zoom: this.v.zoom,
        rot: this.v.rot,
        offset: { x: this.v.ox, y: this.v.oy },
        p: this.v.p
      });
    }
    // script and editor controls (this play only)
    set(id, patch) {
      this.rt[id] = Object.assign(this.rt[id] || {}, patch);
    }
    solo(id) {
      this.solo_ = id || '';
    }
    active() {
      return this.cur ? this.cur.id : '';
    }
    blending() {
      return !!this.B;
    }
    reset() {
      this.rt = {};
      this.solo_ = '';
    }
  }
  return { FOLLOW, EASES, clean, blank, validate, Manager };
})();
