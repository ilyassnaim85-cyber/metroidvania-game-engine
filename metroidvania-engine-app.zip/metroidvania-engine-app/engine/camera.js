// Camera: smooth follow, bounds, direction bias, vertical-velocity look, peek, ledge hint, profiles, screen shake.
// A profile (see MV.data.camPresets, MV.data.camExtra and Player > Camera) is a handful of settings that replace the Default ones while it is used.
// With every camera setting at its default the camera behaves exactly like the original smooth follow.
window.MV = window.MV || {};
MV.Camera = class {
  constructor() {
    this.x = 0;
    this.y = 0;
    this.sh = 0;
    this.lx = 0;
    this.ly = 0;
    this.lookDir = 1;
    this.wx = 0;
    this.wy = 0;
    this.pid = null;
    this.bt = 0;
    this.bb = null;
    this.flip = 0;
    this.lt = 0;
    this.pk = 0;
    this.pkd = 0;
    this.dbg = {};
  }
  // tx, ty: the point to follow (tiles). pl: { face, vx, vy, on, up, dn, dir, ledge } of the player (optional). tn: the player tuning with the cam* values (optional).
  // cfg: { id, blend, p (profile settings), follow (a room's own smoothing), box [x0,y0,x1,y1] (limit the view to it), brk (break the room limits), mode ('fixed' = old locked room) }
  update(dt, tx, ty, vw, vh, rw, rh, cfg, snap, pl, tn) {
    cfg = cfg || {};
    tn = tn || {};
    pl = pl || {};
    const num = (v, d) => (typeof v === 'number' && isFinite(v) ? v : d),
      base = MV.data.camera.follow,
      P = Object.assign({}, tn, cfg.p || {});
    if (!cfg.p && cfg.mode === 'fixed') P.modeX = P.modeY = 'locked';
    const modeX = P.modeX || 'follow',
      modeY0 = P.modeY || 'follow',
      modeY = modeY0 === 'grounded' ? 'follow' : modeY0; // 'grounded' follows like 'follow' but only moves up and down when you land or leave a band around the last floor you stood on
    // a new profile, zone or box: the camera glides to it over the blend time instead of jumping
    const id = cfg.id || '';
    if (this.pid !== null && id !== this.pid && !snap) this.bt = Math.max(0.05, num(cfg.blend, 0.8));
    this.pid = id;
    if (this.bt > 0) this.bt = Math.max(0, this.bt - dt);
    const bf = this.bt > 0 ? 1 - Math.pow(0.02, 1 / (60 * Math.max(0.05, num(cfg.blend, 0.8)))) : 1; // the most the camera may close the gap per 1/60 s while blending
    const room = typeof cfg.follow === 'number' ? cfg.follow : null; // a room's own smoothing wins over the player settings
    let fx = room !== null ? room : num(P.camSmoothX, base),
      fy = room !== null ? room : num(P.camSmoothY, base);
    const ease = (f, d) => (d ? 1 - Math.pow(1 - Math.min(1, Math.max(0, f)), d * 60) : 1);
    if (snap) {
      this.lx = this.ly = 0;
      this.wx = this.wy = 0;
      this.lt = this.pk = 0;
      this.bb = null;
    }
    // vertical velocity: the view leans down while you fall and up while you rise, smoothly (eased) between "starts" and "full" speed
    const vy = pl.vy || 0,
      vs0 = num(P.camVelStart, 12),
      vs1 = Math.max(vs0 + 1, num(P.camVelMax, 28));
    const tv = Math.min(1, Math.max(0, (Math.abs(vy) - vs0) / (vs1 - vs0))),
      sm = tv * tv * (3 - 2 * tv);
    const velLook = vy > 0 ? sm * num(P.camFallLook, 0) : -sm * num(P.camRiseLook, 0);
    const vsm = num(P.camVelSmooth, 0);
    if (vsm > 0 && sm > 0) fy += (vsm - fy) * sm; // catch up faster when moving fast
    // direction bias: which way the view leans. facing = the way you face, velocity = the way you move, input = the keys you hold
    const src = P.biasSrc || 'facing',
      vx = pl.vx || 0;
    let want = 0;
    if (src === 'input') want = pl.dir || 0;
    else if (Math.abs(vx) > 1) want = src === 'velocity' ? Math.sign(vx) : pl.face || Math.sign(vx);
    if (want && want !== this.lookDir) {
      this.flip += dt;
      if (this.flip >= num(P.camLookDelay, 0)) {
        this.lookDir = want;
        this.flip = 0;
      }
    } else this.flip = 0;
    const ramp = num(P.camLookRamp, 0),
      spd = Math.min(1, Math.abs(vx) / Math.max(1, num(tn.run, 8)));
    const lookX = modeX === 'follow' ? this.lookDir * num(P.camLookAhead, 0) * (1 - ramp * (1 - spd)) : 0;
    // peek (hold Up or Down while standing still) and ledge hint (stand at the edge of a drop)
    const still = !!pl.on && Math.abs(vx) < 0.5,
      pd = still ? (pl.dn ? 1 : 0) - (pl.up ? 1 : 0) : 0;
    if (pd && pd === this.pkd) this.pk += dt;
    else {
      this.pk = 0;
      this.pkd = pd;
    }
    const peek = pd && this.pk >= num(P.camPeekDelay, 0.4) ? pd * num(P.camPeek, 0) : 0;
    if (pl.ledge && still) this.lt += dt;
    else this.lt = 0;
    const ledge = num(P.camLedgeLook, 0) > 0 && this.lt >= num(P.camLedgeDelay, 0.35) ? num(P.camLedgeLook, 0) : 0;
    const lookY = modeY === 'follow' ? velLook + (peek || ledge) : 0,
      ls = ease(num(P.camLookSpeed, 0.05), snap ? 0 : dt);
    this.lx += (lookX - this.lx) * ls;
    this.ly += (lookY - this.ly) * ls;
    // where the camera wants to be. Hollow Knight style: a "grounded" camera keeps the height of the last floor you stood on until you land again, or fall or rise out of the band.
    if (modeY0 === 'grounded') {
      const band = Math.max(0.5, num(P.groundBand, 4));
      if (this.gt === undefined || snap || pl.on) this.gt = ty;
      else if (ty > this.gt + band) this.gt = ty - band;
      else if (ty < this.gt - band) this.gt = ty + band;
      ty = this.gt;
    }
    const posX = (num(P.camPosX, 0) / 100) * vw,
      posY = (num(P.camPosY, 0) / 100) * vh; // where the player stands on the screen: positive = lower / more to the right
    const lockX = num(P.lockX, null),
      lockY = num(P.lockY, null);
    const gx = modeX === 'locked' ? (lockX !== null ? lockX - vw / 2 : (rw - vw) / 2) : tx - vw / 2 + this.lx - posX;
    const gy =
      modeY === 'locked'
        ? lockY !== null
          ? lockY - vh / 2
          : (rh - vh) / 2
        : ty - vh / 2 + this.ly + num(P.camOffsetY, 0) - posY;
    // bounds: the room, the room plus some extra, no limit, or a zone's box. The limits themselves glide when they change.
    const far = Math.max(vw, vh) + 60;
    let t = [0, 0, rw - vw, rh - vh];
    const bm = P.bounds || 'room',
      pad = num(P.pad, 0);
    if (bm === 'extended') t = [-pad, -pad, rw - vw + pad, rh - vh + pad];
    else if (bm === 'none') t = [-far, -far, rw + far, rh + far];
    if (cfg.brk) t = [-far, -far, rw + far, rh + far];
    if (cfg.box) {
      const b = cfg.box;
      t = [b[0], b[1], b[2] - vw, b[3] - vh];
    }
    if (t[2] < t[0]) t[0] = t[2] = (t[0] + t[2]) / 2;
    if (t[3] < t[1]) t[1] = t[3] = (t[1] + t[3]) / 2; // smaller than the view: centered
    if (!this.bb || snap) this.bb = t.slice();
    else for (let i = 0; i < 4; i++) this.bb[i] += (t[i] - this.bb[i]) * (this.bt > 0 ? ease(bf, dt) : 1);
    // the goal is kept inside the limits too, so the camera eases to a stop at a room edge instead of hitting it
    const gxc = Math.max(this.bb[0], Math.min(this.bb[2], gx)),
      gyc = Math.max(this.bb[1], Math.min(this.bb[3], gy));
    // dead zone and delay: nothing moves until you leave the zone, then the camera waits the follow delay before it starts moving
    const dzx = modeX === 'follow' ? num(P.camDeadX, 0) : 0,
      dzy = modeY === 'follow' ? num(P.camDeadY, 0) : 0,
      wait = num(P.camDelay, 0);
    const axis = (cur, goal, dz, w, key, md) => {
      const d = goal - cur;
      if (md === 'centered' && !(this.bt > 0)) return goal;
      if (!snap && Math.abs(d) <= dz + 0.02) {
        this[key] = 0;
        return cur;
      }
      if (!snap && md === 'follow') {
        this[key] += dt;
        if (this[key] < wait) return cur;
      }
      let ww = md === 'centered' ? 1 : w;
      if (this.bt > 0) ww = Math.min(ww, bf);
      return cur + (goal - Math.sign(d) * (snap ? 0 : dz) - cur) * ease(ww, snap ? 0 : dt);
    };
    this.x = axis(this.x, gxc, dzx, fx, 'wx', modeX);
    this.y = axis(this.y, gyc, dzy, fy, 'wy', modeY);
    this.x = Math.max(this.bb[0], Math.min(this.bb[2], this.x));
    this.y = Math.max(this.bb[1], Math.min(this.bb[3], this.y));
    this.dbg = {
      id,
      x: this.x,
      y: this.y,
      ledge: !!pl.ledge,
      lt: this.lt,
      look: [this.lx, this.ly],
      bounds: this.bb.slice(),
      blend: this.bt
    };
    this.sh = Math.max(0, this.sh - MV.data.camera.shakeDecay * dt);
  }
  shake(a) {
    this.sh = Math.max(this.sh, a);
  }
  offset() {
    const s = this.sh * 0.5;
    return [this.x + (Math.random() - 0.5) * s, this.y + (Math.random() - 0.5) * s];
  }
};
// ---- profiles ----
// Settings that a profile may hold: every number of the Camera group in the player schema, plus the extra fields in MV.data.camExtra.
MV.Camera.fields = () =>
  Object.keys(MV.data.playerSchema)
    .filter(k => MV.data.playerSchema[k].group === 'Camera')
    .concat(Object.keys(MV.data.camExtra));
MV.Camera.cleanP = p => {
  const out = {},
    sc = MV.data.playerSchema,
    ex = MV.data.camExtra;
  if (!p || typeof p !== 'object') return out;
  for (const k in p) {
    const v = p[k];
    if (v === null || v === undefined || v === '') continue;
    if (sc[k] && sc[k].group === 'Camera') {
      const n = Number(v);
      if (isFinite(n)) out[k] = Math.min(sc[k].max, Math.max(sc[k].min, n));
    } else if (ex[k]) {
      if (ex[k].t === 'select') {
        if (ex[k].o.includes(v)) out[k] = v;
      } else {
        const n = Number(v);
        if (isFinite(n)) out[k] = Math.min(ex[k].max, Math.max(ex[k].min, n));
      }
    }
  }
  return out;
};
// The saved list of your own profiles: [{id, name, p}]. Built-in ids cannot be reused.
MV.Camera.cleanProfiles = l => {
  const out = [],
    seen = new Set(MV.data.camPresets.map(q => q.id));
  if (!Array.isArray(l)) return out;
  for (const q of l.slice(0, 40)) {
    if (!q || typeof q !== 'object') continue;
    const id = String(q.id || '')
      .toLowerCase()
      .replace(/[^a-z0-9_]/g, '')
      .slice(0, 24);
    if (!id || seen.has(id)) continue;
    seen.add(id);
    out.push({ id, name: String(q.name || id).slice(0, 40), p: MV.Camera.cleanP(q.p) });
  }
  return out;
};
MV.Camera.all = list => MV.data.camPresets.concat(Array.isArray(list) ? list : []);
MV.Camera.profile = (id, list) => {
  const f = MV.Camera.all(list).find(q => q.id === id);
  return f ? f.p : {};
};
