// Scripts: small JavaScript programs that run inside the game (see SCRIPTING.md).
// A script is plain code that runs once when the game starts. It gets four things:
//   game   - what it may read and change (the player, flags, items, rooms, camera, timers ...; built in engine/game/13-script-api.js)
//   on     - on('room', fn) runs fn when something happens (see HOOKS below)
//   fn     - fn('openGate', f) names a function so the Events tab ("Run a script function") can call it
//   log    - log(...) writes a line to the Scripts tab console
// Scripts are trusted code, like a mod. They are kept away from the page (window, document, MV ... are hidden) but this is not a security wall,
// so the editor asks before it opens a project file that contains scripts.
window.MV = window.MV || {};
MV.Script = (() => {
  const MAX = 40,
    MAXCODE = 60000,
    MAXERR = 60;
  // hook name -> what it is, and the data its function receives
  const HOOKS = {
    start: 'The game has started (after the first room is built). fn()',
    update: 'Every frame while the game runs. fn(dt)',
    room: 'You entered a room. fn({ room, respawn })',
    roomleave: 'You are leaving a room. fn({ room })',
    key: 'A key was pressed in play. fn({ code })',
    death: 'You died. fn()',
    hurt: 'You were hurt. fn({ dmg })',
    flag: 'A flag was set. fn({ flag })',
    flagoff: 'A flag was cleared. fn({ flag })',
    item: 'You gained an item. fn({ item })',
    ability: 'You unlocked an ability. fn({ ability })',
    boss: 'A boss was defeated (its flag was set). fn({ flag })',
    bosswake: 'A boss woke up. fn({ boss })',
    bossphase: 'A boss changed phase. fn({ boss, phase })',
    enemy: 'An enemy was defeated. fn({ kind })',
    zone: 'You walked into an Event zone. fn({ tag })',
    zoneleave: 'You left an Event zone. fn({ tag })',
    npc: 'You talked to a character. fn({ npc })',
    var: 'An event variable changed. fn({ var, value })'
  };
  // friendly spellings: on('roomEnter') is on('room')
  const ALIAS = {
    roomenter: 'room',
    roomleave: 'roomleave',
    enemydefeat: 'enemy',
    bossdefeat: 'boss',
    enemydefeated: 'enemy',
    bossdefeated: 'boss',
    flagset: 'flag',
    flagclear: 'flagoff'
  };
  const key = n =>
    String(n || '')
      .toLowerCase()
      .replace(/[^a-z]/g, '');
  const hookName = n => {
    const k = key(n);
    return ALIAS[k] || (HOOKS[k] ? k : '');
  };
  const SHADOW = [
    'window',
    'document',
    'MV',
    'globalThis',
    'self',
    'parent',
    'top',
    'frames',
    'localStorage',
    'sessionStorage',
    'indexedDB',
    'fetch',
    'XMLHttpRequest',
    'WebSocket',
    'Worker',
    'Function',
    'require',
    'process',
    'module',
    'exports',
    'importScripts',
    'open',
    'alert',
    'confirm',
    'prompt'
  ];
  const PARAMS = ['game', 'on', 'fn', 'log'].concat(SHADOW);
  const id = v =>
    typeof v === 'string' && /^[\w-]{1,24}$/.test(v) ? v : 'sc' + Math.random().toString(36).slice(2, 7);
  function clean(l) {
    const seen = {};
    return (Array.isArray(l) ? l : [])
      .filter(s => s && typeof s === 'object')
      .slice(0, MAX)
      .map(s => {
        return {
          id: id(s.id),
          name: typeof s.name === 'string' && s.name.trim() ? s.name.trim().slice(0, 40) : 'Script',
          on: s.on !== false,
          code: typeof s.code === 'string' ? s.code.slice(0, MAXCODE) : ''
        };
      })
      .filter(s => !seen[s.id] && (seen[s.id] = 1));
  }
  // problems in a project's scripts: [{ level, text }]
  function validate(w) {
    const out = [],
      add = (level, text) => out.push({ level, text }),
      list = clean(w && w.scripts),
      fns = fnNames(list);
    list.forEach(s => {
      const bad = s.on && syntax(s.code);
      if (bad) add('error', 'The script "' + s.name + '" does not compile: ' + bad);
      if (s.on && !s.code.trim()) add('info', 'The script "' + s.name + '" is empty.');
      if (/\bwhile\s*\(\s*(true|1)\s*\)/.test(s.code))
        add(
          'warn',
          'The script "' +
            s.name +
            '" has a while(true) loop. A loop that never ends freezes the game; use game.every(...) or on("update", ...) instead.'
        );
      const re = /\bon\(\s*(['"])([^'"]*)\1/g;
      let m;
      while ((m = re.exec(s.code)))
        if (!hookName(m[2]))
          add('error', 'The script "' + s.name + '" listens for "' + m[2] + '", which is not a hook.');
    });
    ((w && w.events) || []).forEach(ev =>
      (ev.actions || []).forEach(a => {
        if (a.type === 'script' && a.name && !fns.has(a.name))
          add(
            'warn',
            'The event "' +
              ev.name +
              '" runs the script function "' +
              a.name +
              '", but no script defines fn("' +
              a.name +
              '", ...).'
          );
      })
    );
    // things that name a function: enemies (Moves = Script), bosses (AI = Script) and moves (type Scripted)
    const need = (what, name) => {
      if (!name) add('warn', what + ' is set to use a script but names no function.');
      else if (!fns.has(name))
        add('warn', what + ' uses the script function "' + name + '", but no script defines fn("' + name + '", ...).');
    };
    ((w && w.enemies) || []).forEach(d => d && d.move === 'script' && need('The enemy "' + d.name + '"', d.brain));
    ((w && w.bosses) || []).forEach(b => b && b.ai === 'script' && need('The boss "' + b.name + '"', b.brain));
    ((w && w.moves) || []).forEach(
      m => m && m.type === 'scripted' && need('The move "' + (m.label || m.id) + '"', m.script)
    );
    return out;
  }
  const blank = name => clean([{ name: name || 'New script', code: TEMPLATE }])[0];
  const TEMPLATE =
    '// Runs once when the game starts. Use on(...) to react to things, fn(...) to name a function the Events tab can call.\n' +
    "on('room', ({ room }) => {\n  game.say('You entered ' + room);\n});\n";
  // '' when the code compiles, else the message
  function syntax(code) {
    try {
      new Function(...PARAMS, '"use strict";\n' + String(code || ''));
      return '';
    } catch (e) {
      return String((e && e.message) || e);
    }
  }
  // the names a script offers with fn('name', ...) (found by reading the code; used by the checker)
  function fnNames(list) {
    const out = new Set();
    clean(list).forEach(s => {
      const re = /\bfn\(\s*(['"])([\w-]{1,40})\1/g;
      let m;
      while ((m = re.exec(s.code))) out.add(m[2]);
    });
    return out;
  }

  class Runtime {
    // list: the project's scripts; api: what `game` offers (an object of functions); report(text): shows an error to the player
    constructor(list, api, report) {
      this.list = clean(list);
      this.api = api || {};
      this.report = typeof report === 'function' ? report : () => {};
      this.handlers = {};
      this.fns = {};
      this.timers = [];
      this.tseq = 0;
      this.t = 0;
      this.errors = [];
      this.logs = [];
      this.said = {};
      this.game = this._makeGame();
      this.list.forEach(s => s.on && this._load(s));
    }
    _makeGame() {
      const rt = this,
        g = Object.assign({}, this.api);
      const add = (sec, f, rep, o) => {
        if (typeof f !== 'function') return 0;
        const n = ++rt.tseq;
        rt.timers.push({
          id: n,
          at: rt.t + Math.max(0.001, +sec || 0),
          every: rep ? Math.max(0.016, +sec || 0.016) : 0,
          f,
          room: !!(o && o.room),
          h: rt.cur || null
        });
        if (rt.timers.length > 200) rt.timers.shift();
        return n;
      };
      g.after = (sec, f, o) => add(sec, f, false, o); // game.after(2, () => ...) runs once; { room: true } cancels it when the room changes
      g.every = (sec, f, o) => add(sec, f, true, o);
      g.cancel = n => {
        rt.timers = rt.timers.filter(t => t.id !== n);
      };
      Object.defineProperty(g, 'time', { get: () => rt.t, enumerable: true });
      return Object.freeze(g);
    }
    _load(s) {
      const bad = syntax(s.code);
      if (bad) return this._err(s, 'compile', new Error(bad), true);
      const rt = this,
        on = (hook, f, only) => {
          const h = hookName(hook);
          if (!h) throw new Error('on("' + hook + '"): there is no such hook. Hooks: ' + Object.keys(HOOKS).join(', '));
          if (typeof f !== 'function') throw new Error('on("' + hook + '"): the second argument must be a function');
          (rt.handlers[h] = rt.handlers[h] || []).push({
            s,
            hook: h,
            f,
            only: only && typeof only === 'object' ? only : null,
            errs: 0,
            off: false,
            slow: 0
          });
        },
        fn = (name, f) => {
          if (typeof f !== 'function' || !/^[\w-]{1,40}$/.test(String(name)))
            throw new Error('fn(name, function): the name may use letters, digits, - and _');
          rt.fns[name] = { s, f, errs: 0, off: false, slow: 0, hook: 'fn:' + name };
        },
        log = (...a) => rt.log(s, a);
      try {
        rt.cur = { s, hook: 'start-up' };
        new Function(...PARAMS, '"use strict";\n' + s.code)(rt.game, on, fn, log); // the shadowed names stay undefined
      } catch (e) {
        this._err(s, 'start-up', e, true);
      } finally {
        rt.cur = null;
      }
    }
    log(s, a) {
      const text = a.map(v => (typeof v === 'string' ? v : safeStr(v))).join(' ');
      this.logs.push({ script: s.name, text: text.slice(0, 300), t: this.t });
      if (this.logs.length > MAXERR * 3) this.logs.shift();
    }
    _err(s, hook, e, fatal) {
      const msg = String((e && e.message) || e).slice(0, 300);
      this.errors.push({ script: s.name, hook, message: msg, t: this.t });
      if (this.errors.length > MAXERR) this.errors.shift();
      const k = s.id + '|' + hook + '|' + msg;
      if (!this.said[k]) {
        this.said[k] = 1;
        this.report('Script "' + s.name + '" (' + hook + '): ' + msg);
      }
      return fatal;
    }
    _run(h, args) {
      if (h.off) return undefined;
      const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
      let r;
      this.cur = h;
      try {
        r = h.f.apply(null, args);
        h.errs = 0;
      } catch (e) {
        this._err(h.s, h.hook, e);
        if (++h.errs >= 5) {
          h.off = true;
          this._err(h.s, h.hook, new Error('switched off for this play after 5 errors in a row'));
        }
      } finally {
        this.cur = null;
      }
      const ms = (typeof performance !== 'undefined' ? performance.now() : Date.now()) - t0;
      if (ms > 40 && ++h.slow === 3)
        this._err(
          h.s,
          h.hook,
          new Error('this function is slow (' + Math.round(ms) + ' ms); a frame is 16 ms. Do less work per frame.')
        );
      return r;
    }
    // something happened in the game: type is a hook name, d its data
    emit(type, d, args) {
      const l = this.handlers[type];
      if (!l) return;
      for (const h of l.slice()) {
        if (h.only) {
          let ok = true;
          for (const k in h.only) if (d == null || d[k] !== h.only[k]) ok = false;
          if (!ok) continue;
        }
        this._run(h, args || [d]);
      }
    }
    tick(dt) {
      dt = Math.min(0.1, Math.max(0, +dt || 0));
      this.t += dt;
      if (this.timers.length) {
        for (const t of this.timers.slice()) {
          if (this.t < t.at || !this.timers.includes(t)) continue;
          if (t.every) t.at = this.t + t.every;
          else this.timers = this.timers.filter(q => q !== t);
          this._run(
            { s: t.h ? t.h.s : { id: 't', name: 'timer' }, hook: 'timer', f: t.f, errs: 0, off: false, slow: 0 },
            []
          );
        }
      }
      this.emit('update', { dt }, [dt]);
    }
    // the player changed room: timers made with { room: true } end
    sceneChange() {
      this.timers = this.timers.filter(t => !t.room);
    }
    // run a function named with fn('name', ...)
    call(name, arg) {
      const f = this.fns[name];
      if (!f) {
        this._err({ id: 'call', name: 'Events' }, 'fn:' + name, new Error('no script function called "' + name + '"'));
        return undefined;
      }
      return this._run(f, [arg]);
    }
    has(name) {
      return !!this.fns[name];
    }
    clearErrors() {
      this.errors = [];
      this.said = {};
    }
  }
  const safeStr = v => {
    try {
      return typeof v === 'object' ? JSON.stringify(v) : String(v);
    } catch (e) {
      return String(v);
    }
  };
  return { HOOKS, SHADOW, TEMPLATE, MAX, clean, blank, syntax, fnNames, hookName, validate, Runtime };
})();
