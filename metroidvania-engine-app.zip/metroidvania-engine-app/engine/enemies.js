// Enemy types: what a kind of enemy is (body, health, how it moves, how it attacks, how it reacts to being hit, what it drops, how it looks).
// A type is made in the Enemies tab and placed with the Enemy entity (its "Type" setting). The runtime that moves them is in engine/game.js;
// the damage, knockback and flinch rules live in MV.Actor so that bosses and enemies can share them.
window.MV = window.MV || {};
MV.Actor = (() => {
  // The part every fighter shares: take damage with invisible time, be pushed back, flinch, flash, and say what happened.
  // a = { hp, inv, hurt, vx, stun }, o = { dmg, fromX (where the hit came from), knock, flinch, invul }.
  const hit = (a, o) => {
    if (a.inv > 0 || !(o.dmg > 0)) return { hit: false, dead: false };
    a.hp -= o.dmg;
    a.inv = Math.max(0.05, o.invul === undefined ? 0.3 : o.invul);
    a.hurt = 0.35;
    if (o.knock > 0) {
      a.vx = (a.cx >= o.fromX ? 1 : -1) * o.knock;
      a.kicked = true;
    }
    a.stun = Math.max(a.stun || 0, o.flinch || 0);
    return { hit: true, dead: a.hp <= 0 };
  };
  return { hit };
})();

MV.Enemies = (() => {
  const N = (v, a, b, d) =>
    v === null || v === '' || v === undefined || !isFinite(+v) ? d : Math.min(b, Math.max(a, +v));
  const MOVES = ['stand still', 'patrol', 'chase', 'fly', 'hop', 'script'],
    ATTACKS = ['none', 'shoot', 'charge', 'strike'],
    SHAPES = ['rect', 'circle', 'polygon'],
    AIMS = ['at the player', 'forward'];
  const FIELDS = {
    name: { g: 'Body', t: 'text', def: 'Enemy', label: 'Name', help: 'Shown in the list and in the checks.' },
    w: {
      g: 'Body',
      t: 'number',
      def: 0.8,
      min: 0.3,
      max: 8,
      step: 0.1,
      label: 'Width (tiles)',
      help: 'The size of the enemy: it hurts you, and your attacks hit it, inside this box.'
    },
    h: { g: 'Body', t: 'number', def: 0.8, min: 0.3, max: 8, step: 0.1, label: 'Height (tiles)', help: 'See Width.' },
    shape: {
      g: 'Body',
      t: 'select',
      def: 'rect',
      o: SHAPES,
      names: {
        rect: 'Rectangle',
        circle: 'Circle (as wide as the smaller side)',
        polygon: 'Polygon (your own corners)'
      },
      label: 'Body shape',
      help: 'The shape your attacks must touch to hurt it, and that must touch you to hurt you. Width and Height are its bounding box.'
    },
    hp: {
      g: 'Body',
      t: 'number',
      def: 3,
      min: 1,
      max: 999,
      step: 1,
      label: 'Health',
      help: 'How much damage it takes before it dies. Your attacks take their Damage from it.'
    },
    dtype: {
      g: 'Elements',
      t: 'select',
      def: 'physical',
      o: ['physical', 'fire', 'ice', 'poison', 'shock'],
      label: 'Damage type it deals',
      help: 'The type of damage its touch, strikes and shots do. Useful with a status below.'
    },
    inflict: {
      g: 'Elements',
      t: 'select',
      def: 'none',
      o: ['none', 'poison', 'burn', 'slow'],
      label: 'Inflicts on you',
      help: 'A status effect you get when it hurts you: poison and burn hurt over time, slow makes you slower. Resting at a rest point cures them.'
    },
    inflictTime: {
      g: 'Elements',
      t: 'number',
      def: 4,
      min: 0.5,
      max: 60,
      step: 0.5,
      label: 'Status lasts (s)',
      help: 'How long the status lasts.'
    },
    weakTo: {
      g: 'Elements',
      t: 'select',
      def: 'none',
      o: ['none', ...['physical', 'fire', 'ice', 'poison', 'shock']],
      label: 'Weak to',
      help: 'Your attacks of this damage type do double damage to it.'
    },
    resistTo: {
      g: 'Elements',
      t: 'select',
      def: 'none',
      o: ['none', ...['physical', 'fire', 'ice', 'poison', 'shock']],
      label: 'Resists',
      help: 'Your attacks of this damage type do half damage to it.'
    },
    immuneTo: {
      g: 'Elements',
      t: 'select',
      def: 'none',
      o: ['none', ...['physical', 'fire', 'ice', 'poison', 'shock']],
      label: 'Immune to',
      help: 'Your attacks of this damage type do nothing to it.'
    },
    ai: {
      g: 'Brain',
      t: 'select',
      def: 'loop',
      o: ['loop', 'brain', 'hazard'],
      names: {
        loop: 'Loop: just moves the way Movement says (no brain)',
        brain: 'Brain: notices you, chases, attacks when you are in range, gives up and goes home',
        hazard: 'Hazard: a static enemy that hurts when touched'
      },
      label: 'Behaviour',
      help: 'Loop is the simple enemy. Brain adds a real mind: it patrols, notices you, chases, picks an attack from its pattern when you are in range, recovers and returns home. Hazard never moves or attacks (spikes, thorns, a coral).'
    },
    immune: {
      g: 'Brain',
      t: 'select',
      def: 'no',
      o: ['no', 'yes'],
      names: { no: 'No: your attacks hurt it', yes: 'Yes: your attacks do nothing (a true hazard)' },
      label: 'Cannot be hurt',
      help: 'For hazards that must be avoided, not killed.'
    },
    alertTime: {
      g: 'Brain',
      t: 'number',
      def: 0.45,
      min: 0,
      max: 3,
      step: 0.05,
      label: 'Notice time (s)',
      help: 'Brain: how long it freezes and shows "!" after it sees you, before it chases.'
    },
    loseTime: {
      g: 'Brain',
      t: 'number',
      def: 3,
      min: 0.5,
      max: 30,
      step: 0.5,
      label: 'Gives up after (s)',
      help: 'Brain: how long it keeps chasing after you are out of its sight.'
    },
    leash: {
      g: 'Brain',
      t: 'number',
      def: 14,
      min: 1,
      max: 100,
      step: 0.5,
      label: 'Leash (tiles from home)',
      help: 'Brain: it never chases farther than this from where it was placed. Then it walks home.'
    },
    pattern: {
      g: 'Brain',
      t: 'text',
      def: '',
      label: 'Attack pattern',
      help: 'Brain: attacks in the order it uses them, for example "strike, strike, charge" or "shoot, shoot, charge". Words: strike, shoot, charge. Empty = the single Attack below.'
    },
    patMode: {
      g: 'Brain',
      t: 'select',
      def: 'order',
      o: ['order', 'random'],
      names: { order: 'In order, then again', random: 'A random one each time' },
      label: 'Pattern order',
      help: 'Brain: how the next attack of the pattern is chosen.'
    },
    meleeRange: {
      g: 'Brain',
      t: 'number',
      def: 2,
      min: 0.5,
      max: 20,
      step: 0.25,
      label: 'Close attacks from (tiles)',
      help: 'Brain: strikes and charges start when you are this close. Shots start from "Attacks from" in the Attack group.'
    },
    keepAway: {
      g: 'Brain',
      t: 'number',
      def: 0,
      min: 0,
      max: 30,
      step: 0.5,
      label: 'Keeps away (tiles)',
      help: 'Brain with shots: it backs off when you get closer than this (an archer). 0 = it does not back off.'
    },
    move: {
      g: 'Movement',
      t: 'select',
      def: 'patrol',
      o: MOVES,
      names: {
        'stand still': 'Stands still',
        patrol: 'Walks back and forth',
        chase: 'Walks toward you when it sees you',
        fly: 'Flies (toward you when it sees you)',
        hop: 'Hops (toward you when it sees you)',
        script: 'Script (a JavaScript function moves it)'
      },
      label: 'Moves',
      help: 'How it gets around. Walkers and hoppers fall with gravity; flyers do not.'
    },
    speed: {
      g: 'Movement',
      t: 'number',
      def: 2,
      min: 0,
      max: 20,
      step: 0.25,
      label: 'Speed (tiles/s)',
      help: 'How fast it walks, flies or hops.'
    },
    range: {
      g: 'Movement',
      t: 'number',
      def: 3,
      min: 0,
      max: 30,
      step: 0.5,
      label: 'Patrol distance (tiles)',
      help: 'How far from where it was placed it goes before turning round. A chasing enemy that does not see you patrols this far.'
    },
    sight: {
      g: 'Movement',
      t: 'number',
      def: 6,
      min: 0,
      max: 40,
      step: 0.5,
      label: 'Sees you from (tiles)',
      help: 'Chase, fly and hop: how close you must be for it to notice you. 0 = it never notices you.'
    },
    edge: {
      g: 'Movement',
      t: 'select',
      def: 'yes',
      o: ['yes', 'no'],
      names: { yes: 'Yes: it turns round at ledges', no: 'No: it walks off ledges' },
      label: 'Stops at ledges',
      help: 'Walkers only.'
    },
    hopEvery: {
      g: 'Movement',
      t: 'number',
      def: 1.2,
      min: 0.2,
      max: 10,
      step: 0.1,
      label: 'Hop every (s)',
      help: 'Hop: the pause between hops.'
    },
    hopPower: {
      g: 'Movement',
      t: 'number',
      def: 11,
      min: 3,
      max: 30,
      step: 0.5,
      label: 'Hop strength (tiles/s)',
      help: 'Hop: how hard it jumps.'
    },
    brain: {
      g: 'Movement',
      t: 'text',
      def: '',
      label: 'AI script function (when Moves = Script)',
      help: 'The name of a function a script offers with fn("name", me => ...). It runs every frame and sets how the enemy moves and attacks. See SCRIPTING.md.'
    },
    attack: {
      g: 'Attack',
      t: 'select',
      def: 'none',
      o: ATTACKS,
      names: {
        none: 'None',
        shoot: 'Shoots',
        charge: 'Charges at you',
        strike: 'Strikes with hitboxes (a swipe, slam or spin you draw)'
      },
      label: 'Attack',
      help: 'An extra attack on top of touching you. It warns you first (the enemy flashes during Warning time).'
    },
    atkRange: {
      g: 'Attack',
      t: 'number',
      def: 7,
      min: 1,
      max: 40,
      step: 0.5,
      label: 'Attacks from (tiles)',
      help: 'It starts the attack when you are this close.'
    },
    atkWind: {
      g: 'Attack',
      t: 'number',
      def: 0.5,
      min: 0,
      max: 3,
      step: 0.05,
      label: 'Warning time (s)',
      help: 'The enemy stops and flashes this long before it attacks, so the player can react.'
    },
    atkCool: {
      g: 'Attack',
      t: 'number',
      def: 2,
      min: 0.2,
      max: 20,
      step: 0.1,
      label: 'Wait between attacks (s)',
      help: 'The pause after an attack before it can start the next.'
    },
    atkSpeed: {
      g: 'Attack',
      t: 'number',
      def: 10,
      min: 1,
      max: 40,
      step: 0.5,
      label: 'Shot or charge speed (tiles/s)',
      help: 'How fast the shot flies, or how fast it rushes at you.'
    },
    atkDmg: {
      g: 'Attack',
      t: 'number',
      def: 1,
      min: 0,
      max: 30,
      step: 1,
      label: 'Shot damage (hits)',
      help: 'Shoots: health taken by a shot that hits you. A charge hurts like touching it (Damage below).'
    },
    atkSize: {
      g: 'Attack',
      t: 'number',
      def: 0.3,
      min: 0.1,
      max: 3,
      step: 0.05,
      label: 'Shot size (tiles)',
      help: 'Shoots: the width of a shot.'
    },
    atkAim: {
      g: 'Attack',
      t: 'select',
      def: 'at the player',
      o: AIMS,
      label: 'Shot aims',
      help: 'Shoots: straight at you, or just the way the enemy is facing.'
    },
    atkDur: {
      g: 'Attack',
      t: 'number',
      def: 0.6,
      min: 0.1,
      max: 3,
      step: 0.05,
      label: 'Charge / strike length (s)',
      help: 'Charges: how long the rush lasts. Strikes: the length of the timeline the hitboxes run on.'
    },
    touch: {
      g: 'Hurts you',
      t: 'select',
      def: 'yes',
      o: ['yes', 'no'],
      names: { yes: 'Yes: touching its body hurts', no: 'No: only its attacks hurt' },
      label: 'Hurts by touching',
      help: 'Turn off for an enemy that is harmless to walk through and only hurts with its attack hitboxes or shots.'
    },
    damage: {
      g: 'Hurts you',
      t: 'number',
      def: 1,
      min: 0,
      max: 30,
      step: 1,
      label: 'Damage (hits)',
      help: 'Health you lose when it touches you.'
    },
    knock: {
      g: 'Hurts you',
      t: 'number',
      def: 6,
      min: 0,
      max: 20,
      step: 0.5,
      label: 'Pushes you back (tiles/s)',
      help: 'How hard it throws you away when it hurts you.'
    },
    stun: {
      g: 'Hurts you',
      t: 'number',
      def: 0.2,
      min: 0,
      max: 1,
      step: 0.05,
      label: 'You cannot steer for (s)',
      help: 'After it hits you, how long you lose control while the push plays.'
    },
    hurtKnock: {
      g: 'When you hit it',
      t: 'number',
      def: 4,
      min: 0,
      max: 20,
      step: 0.5,
      label: 'Pushed back (tiles/s)',
      help: 'How far your hits throw it away. 0 = it does not move (a heavy enemy).'
    },
    weakOnly: {
      g: 'When you hit it',
      t: 'select',
      def: 'no',
      o: ['no', 'yes'],
      names: { no: 'No: the whole body takes damage', yes: 'Yes: only the weak spots take damage (armoured)' },
      label: 'Only weak spots hurt it',
      help: 'With weak spots drawn below, hits elsewhere do nothing.'
    },
    flinch: {
      g: 'When you hit it',
      t: 'number',
      def: 0.25,
      min: 0,
      max: 3,
      step: 0.05,
      label: 'Flinch (s)',
      help: 'After being hit it cannot move or attack for this long.'
    },
    invul: {
      g: 'When you hit it',
      t: 'number',
      def: 0.3,
      min: 0.05,
      max: 3,
      step: 0.05,
      label: 'Safe time after a hit (s)',
      help: 'It cannot be hurt again for this long, so one swing does not hit it many times.'
    },
    coins: {
      g: 'Drops',
      t: 'number',
      def: 0,
      min: 0,
      max: 99,
      step: 1,
      label: 'Coins',
      help: 'Coins you get when it dies.'
    },
    energy: {
      g: 'Drops',
      t: 'number',
      def: 0,
      min: 0,
      max: 100,
      step: 1,
      label: 'Energy',
      help: 'Energy you get when it dies (needs an energy bar in Settings).'
    },
    dropItem: {
      g: 'Drops',
      t: 'text',
      def: '',
      label: 'Item',
      help: 'An item id (Items tab) it may drop when it dies.'
    },
    dropPct: {
      g: 'Drops',
      t: 'number',
      def: 100,
      min: 0,
      max: 100,
      step: 5,
      label: 'Item chance (%)',
      help: 'The chance that it drops the item.'
    },
    color: { g: 'Look', t: 'color', def: '#c0504d', label: 'Colour', help: 'The box colour when it has no animation.' },
    scale: {
      g: 'Look',
      t: 'number',
      def: 1,
      min: 0.2,
      max: 6,
      step: 0.1,
      label: 'Picture size (x)',
      help: 'How big the animation is drawn compared with the enemy box.'
    },
    bar: {
      g: 'Look',
      t: 'select',
      def: 'after a hit',
      o: ['never', 'after a hit', 'always'],
      label: 'Health bar',
      help: 'A small bar over its head.'
    }
  };
  const CLIPS = [
    ['idle', 'Standing'],
    ['walk', 'Moving'],
    ['warn', 'Warning before an attack'],
    ['attack', 'Attacking'],
    ['hurt', 'Hurt'],
    ['die', 'Dying']
  ];
  const SNDS = [
    ['hurtSnd', 'When you hit it'],
    ['dieSnd', 'When it dies'],
    ['atkSnd', 'When it attacks']
  ];
  const DEFPTS = () => [
    { x: -0.5, y: 0.5 },
    { x: -0.5, y: -0.2 },
    { x: 0, y: -0.5 },
    { x: 0.5, y: -0.2 },
    { x: 0.5, y: 0.5 }
  ];
  // Body polygon corners (relative to the body box, -1..1) and weak spots: shared by enemies and bosses.
  const ptsOf = l => {
    const P = Array.isArray(l) ? l.slice(0, 16).map(q => ({ x: N(q && q.x, -1, 1, 0), y: N(q && q.y, -1, 1, 0) })) : [];
    return P.length >= 3 ? P : DEFPTS();
  };
  const weakOf = l =>
    (Array.isArray(l) ? l : []).slice(0, 6).map(q => {
      q = q || {};
      return {
        name: typeof q.name === 'string' && q.name ? q.name.slice(0, 20) : 'Weak spot',
        x: N(q.x, -8, 8, 0),
        y: N(q.y, -8, 8, -0.2),
        w: N(q.w, 0.1, 8, 0.4),
        h: N(q.h, 0.1, 8, 0.4),
        mult: N(q.mult, 0, 10, 2)
      };
    });
  const id = v =>
    typeof v === 'string' && /^[\w-]{1,24}$/.test(v) ? v : 'en' + Math.random().toString(36).slice(2, 5);
  const clean1 = o => {
    o = o && typeof o === 'object' ? o : {};
    const r = { id: id(o.id) };
    for (const k in FIELDS) {
      const f = FIELDS[k];
      let v = o[k];
      if (f.t === 'number') v = N(v, f.min, f.max, f.def);
      else if (f.t === 'select') {
        if (!f.o.includes(v)) v = f.def;
      } else if (f.t === 'color') v = typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v) ? v : f.def;
      else v = typeof v === 'string' ? v.trim().slice(0, k === 'name' ? 30 : k === 'pattern' ? 80 : 24) : f.def;
      r[k] = v;
    }
    if (!r.name) r.name = r.id;
    r.pattern = (typeof o.pattern === 'string' ? o.pattern : '')
      .toLowerCase()
      .split(/[^a-z]+/)
      .filter(w => ATTACKS.includes(w) && w !== 'none')
      .slice(0, 8)
      .join(', ');
    if (r.ai === 'hazard') {
      r.move = 'stand still';
      r.attack = 'none';
      r.pattern = '';
    }
    r.dropItem = r.dropItem.replace(/[^\w-]/g, '');
    r.pts = ptsOf(o.pts);
    r.weak = weakOf(o.weak);
    const A = MV.Attacks;
    r.strike = A
      ? A.hitboxes(o.strike, r.atkDur)
          .slice(0, 6)
          .map((h, i) => {
            const q = (o.strike || [])[i] || {};
            h.dmg = N(q.dmg, 0, 30, 1);
            return h;
          })
      : [];
    r.clips = {};
    CLIPS.forEach(c => {
      const v = o.clips && o.clips[c[0]];
      if (typeof v === 'string' && /^[\w-]{1,24}$/.test(v)) r.clips[c[0]] = v;
    });
    r.snds = {};
    SNDS.forEach(c => {
      const v = o.snds && o.snds[c[0]];
      if (typeof v === 'string' && /^[\w-]{1,24}$/.test(v)) r.snds[c[0]] = v;
    });
    return r;
  };
  const resolve = list => {
    const seen = {};
    return (Array.isArray(list) ? list : [])
      .slice(0, 40)
      .map(clean1)
      .filter(d => !seen[d.id] && (seen[d.id] = 1));
  };
  const find = (list, i) => (list || []).find(d => d.id === i) || null;
  // The enemy's body in the world: e is a runtime enemy ({cx, by, w, h, dir}); d its type (a legacy simple enemy has no type: a plain box).
  const bodyShape = (e, d) => {
    const cy = e.by - e.h / 2,
      sh = (d && d.shape) || 'rect';
    if (sh === 'circle') {
      const r = Math.min(e.w, e.h) / 2;
      return { sh: 'circle', cx: e.cx, cy, r, w: r * 2, h: r * 2 };
    }
    if (sh === 'polygon')
      return {
        sh: 'polygon',
        cx: e.cx,
        cy,
        pts: d.pts.map(q => ({ x: e.cx + (e.dir || 1) * q.x * e.w, y: cy + q.y * e.h })),
        w: e.w,
        h: e.h
      };
    return { sh: 'rect', cx: e.cx, cy, w: e.w, h: e.h };
  };
  // Weak spots in the world (mirrored by the way the enemy faces).
  const weakWorld = (e, d) =>
    ((d && d.weak) || []).map(q => ({
      sh: 'rect',
      cx: e.cx + (e.dir || 1) * q.x,
      cy: e.by - e.h / 2 + q.y,
      w: q.w,
      h: q.h,
      mult: q.mult,
      name: q.name
    }));
  // The strike hitboxes of the enemy that are live at time t of the strike, with their own damage.
  const strikeWorld = (e, d, t) => {
    const o = [];
    (d.strike || []).forEach(h => {
      MV.Attacks.rects([h], t, e.dir || 1, e.cx, e.by - e.h / 2, h.dmg).forEach(r => o.push(r));
    });
    return o;
  };
  // The attacks this type can use: the pattern for a brain, otherwise its single Attack.
  const attacks = d => {
    if (!d) return [];
    if (d.ai === 'brain' && d.pattern) return d.pattern.split(', ');
    return d.attack && d.attack !== 'none' ? [d.attack] : [];
  };
  return {
    attacks,
    ptsOf,
    weakOf,
    N,
    bodyShape,
    weakWorld,
    strikeWorld,
    SHAPES,
    FIELDS,
    CLIPS,
    SNDS,
    MOVES,
    ATTACKS,
    clean1,
    resolve,
    find
  };
})();
