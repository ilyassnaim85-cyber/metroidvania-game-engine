// Progression state: abilities, flags, collected items, opened doors, checkpoint. Save/load with validation.
window.MV = window.MV || {};
MV.Progress = (() => {
  let KEY = 'mv_save_v1'; // one save slot per project (the editor sets it when a project opens)
  const fresh = () => ({
    v: 1,
    abilities: {},
    flags: {},
    collected: {},
    opened: {},
    cp: null,
    weapons: {},
    weapon: '',
    items: {},
    stats: {},
    equipped: {},
    lostCoins: null
  }); // weapons: the weapon ids you own, weapon: the one in your hand
  // req: '' (always), 'flag:name', or an ability id
  const has = (st, req) =>
    !req ||
    (req.startsWith('flag:')
      ? !!st.flags[req.slice(5)]
      : !!st.abilities[req] || !!st.flags[req] || !!(st.items && st.items[req] > 0));
  const unlock = (st, id) => {
    const d = MV.data.abilities[id];
    if (!d || !(d.requires || []).every(r => has(st, r))) return false;
    st.abilities[id] = true;
    return true;
  };
  const find = (w, a, r) => {
    const A = w.areas.find(x => x.id === a);
    return A && A.rooms && A.rooms.find(x => x.id === r);
  };
  const areaOf = (w, room) => w.areas.find(a => a.rooms && a.rooms.includes(room));
  function load(world) {
    try {
      const o = JSON.parse(localStorage.getItem(KEY)),
        s = fresh();
      if (!o || o.v !== 1) return s;
      ['abilities', 'flags', 'collected', 'opened'].forEach(k => {
        if (o[k] && typeof o[k] === 'object')
          for (const n in o[k]) if (o[k][n] && (k !== 'abilities' || n in MV.data.abilities)) s[k][n] = 1;
      });
      if (o.weapons && typeof o.weapons === 'object')
        for (const n in o.weapons) if (o.weapons[n] && /^[\w-]{1,30}$/.test(n)) s.weapons[n] = 1;
      if (o.items && typeof o.items === 'object')
        for (const n in o.items)
          if (/^[\w-]{1,24}$/.test(n) && isFinite(+o.items[n]) && +o.items[n] > 0)
            s.items[n] = Math.min(99, Math.floor(+o.items[n]));
      if (o.stats && typeof o.stats === 'object')
        ['maxHp', 'energyMax', 'charmSlots'].forEach(k => {
          if (isFinite(+o.stats[k]) && +o.stats[k] > 0) s.stats[k] = Math.min(99, Math.floor(+o.stats[k]));
        });
      if (o.equipped && typeof o.equipped === 'object')
        for (const n in o.equipped) if (o.equipped[n] && /^[\w-]{1,24}$/.test(n) && s.items[n] > 0) s.equipped[n] = 1;
      const lc = o.lostCoins;
      if (lc && find(world, lc.a, lc.r) && isFinite(+lc.x) && isFinite(+lc.y) && isFinite(+lc.n) && +lc.n > 0)
        s.lostCoins = { a: lc.a, r: lc.r, x: +lc.x, y: +lc.y, n: Math.min(9999999, Math.floor(+lc.n)) };
      if (typeof o.weapon === 'string' && s.weapons[o.weapon]) s.weapon = o.weapon;
      const c = o.cp;
      if (c && find(world, c.a, c.r) && isFinite(c.x) && isFinite(c.y)) s.cp = { a: c.a, r: c.r, x: +c.x, y: +c.y };
      return s;
    } catch (e) {
      return fresh();
    } // missing or corrupt save: start fresh
  }
  const save = st => {
    try {
      localStorage.setItem(KEY, JSON.stringify(st));
    } catch (e) {}
  };
  const clear = () => {
    try {
      localStorage.removeItem(KEY);
    } catch (e) {}
  };
  return {
    fresh,
    has,
    unlock,
    find,
    areaOf,
    load,
    save,
    clear,
    setKey: k => {
      KEY = k;
    }
  };
})();
