// MV.CameraRig - the camera system. It wraps the original follow camera (MV.Camera, engine/camera.js: dead zones, look-ahead, grounded follow, bounds, profiles)
// and adds everything around it, as small independent parts that all end in one place (update()):
//   modes (MODES), targets / lock-on / multi-target framing, manual pan and a free camera, soft bounds and screen-edge margins,
//   effects (shake, recoil, zoom, rotation, fades, flashes, transitions), rails and cutscenes, an override stack with priorities,
//   user settings (sensitivity, inversion, smoothing, zoom, accessibility) and input (keyboard, gamepad, mouse).
// It knows nothing about rendering or gameplay: the game gives it a few functions with bind() and reads the result with view().
// With every new setting at its default the camera behaves exactly like the original one. See CAMERA.md.
window.MV = window.MV || {};
MV.CameraRig = (() => {
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v)),
    fin = (v, d) => (typeof v === 'number' && isFinite(v) ? v : d),
    lerp = (a, b, t) => a + (b - a) * t;
  const ZMIN = 0.25,
    ZMAX = 4,
    ROTMAX = 45;

  // ---------- response curves: a name, a function t -> t (0..1), or a cubic bezier [x1, y1, x2, y2] like CSS ----------
  const CURVES = {
    linear: t => t,
    easeIn: t => t * t,
    easeOut: t => 1 - (1 - t) * (1 - t),
    easeInOut: t => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2),
    smooth: t => t * t * (3 - 2 * t),
    smoother: t => t * t * t * (t * (6 * t - 15) + 10),
    sine: t => -(Math.cos(Math.PI * t) - 1) / 2,
    overshoot: t => {
      const c1 = 1.70158,
        c3 = c1 + 1;
      return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
    },
    bounce: t => {
      const n = 7.5625,
        d = 2.75;
      if (t < 1 / d) return n * t * t;
      if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
      if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
      return n * (t -= 2.625 / d) * t + 0.984375;
    }
  };
  const bezier = (x1, y1, x2, y2) => {
    const cx = 3 * x1,
      bx = 3 * (x2 - x1) - cx,
      ax = 1 - cx - bx,
      cy = 3 * y1,
      by = 3 * (y2 - y1) - cy,
      ay = 1 - cy - by;
    const X = t => ((ax * t + bx) * t + cx) * t,
      Y = t => ((ay * t + by) * t + cy) * t;
    return u => {
      if (u <= 0) return 0;
      if (u >= 1) return 1;
      let lo = 0,
        hi = 1,
        t = u;
      for (let i = 0; i < 24; i++) {
        const x = X(t);
        if (Math.abs(x - u) < 1e-5) break;
        if (x < u) lo = t;
        else hi = t;
        t = (lo + hi) / 2;
      }
      return Y(t);
    };
  };
  const curve = spec => {
    if (typeof spec === 'function')
      return t => {
        const v = spec(clamp(t, 0, 1));
        return fin(v, t);
      };
    if (Array.isArray(spec) && spec.length === 4 && spec.every(v => typeof v === 'number' && isFinite(v)))
      return bezier(clamp(spec[0], 0, 1), spec[1], clamp(spec[2], 0, 1), spec[3]);
    return CURVES[spec] || CURVES.smooth;
  };

  // ---------- modes. A mode is a small description: p = profile settings it forces, free = the player does not steer the view, look2d = look ahead in both directions (top-down) ----------
  const MODES = {
    follow: { label: 'Follow', p: {} },
    side: { label: 'Side-scrolling', p: { modeX: 'follow', modeY: 'grounded' } },
    topdown: {
      label: 'Top-down',
      p: {
        modeX: 'follow',
        modeY: 'follow',
        camFallLook: 0,
        camRiseLook: 0,
        camPeek: 0,
        camLedgeLook: 0,
        camPosY: 0,
        camLookAhead: 0
      },
      look2d: true
    },
    fixed: { label: 'Fixed', p: { modeX: 'locked', modeY: 'locked' } },
    free: { label: 'Free camera', p: {}, free: true }
  };
  // The renderer of this engine is an orthographic 2D tile view, so these two are refused (mode() returns false and says why in rig.unsupported).
  const UNSUPPORTED = {
    isometric: 'The tile renderer draws a flat side view; an isometric projection would need a different renderer.',
    firstperson: 'There is no 3D view in this engine; a first-person camera needs a 3D renderer.'
  };
  const modeKey = n =>
    String(n || '')
      .toLowerCase()
      .replace(/[^a-z]/g, '');

  // ---------- user settings (what a player may change in an options menu) ----------
  const USER = () => MV.data.camUser || {};
  const cleanUser = (o, base) => {
    const out = Object.assign({}, base || {}),
      S = USER();
    o = o && typeof o === 'object' ? o : {};
    for (const k in S) {
      const f = S[k],
        v = o[k];
      if (v === undefined) {
        if (out[k] === undefined) out[k] = f.def;
        continue;
      }
      if (f.t === 'bool') out[k] = !!v;
      else {
        const n = Number(v);
        out[k] = isFinite(n) ? clamp(n, f.min, f.max) : out[k] !== undefined ? out[k] : f.def;
      }
    }
    return out;
  };
  const STORE = 'mv.camera.settings';
  const loadUser = () => {
    try {
      return cleanUser(JSON.parse(localStorage.getItem(STORE) || '{}'));
    } catch (e) {
      return cleanUser({});
    }
  };
  const saveUser = s => {
    try {
      localStorage.setItem(STORE, JSON.stringify(s));
    } catch (e) {
      /* private window or no storage: the settings just last for this session */
    }
  };
  const KEYS = () => MV.data.camKeys || {};

  const noise = (seed, x) =>
    (Math.sin(x * 1.7 + seed * 12.9898) +
      0.5 * Math.sin(x * 3.9 + seed * 78.233) +
      0.25 * Math.sin(x * 8.1 + seed * 37.719)) /
    1.75;
  const X = k => (MV.data.camExtra && MV.data.camExtra[k]) || {};

  // The point of an entity (its middle), a {x, y}, a function, 'player' or an entity uid.
  const entPoint = e => ({ x: e.cx, y: e.by - (e.h || 0) / 2 });
  const goodPt = p => (p && isFinite(p.x) && isFinite(p.y) ? { x: p.x, y: p.y } : null);

  class Rig {
    constructor() {
      this.core = new MV.Camera();
      this.env = {};
      this.set = loadUser();
      this.curves = {
        register: (n, f) => {
          if (typeof f === 'function' && /^[\w-]{1,24}$/.test(n)) CURVES[n] = f;
        },
        list: () => Object.keys(CURVES)
      };
      this.unsupported = '';
      this.modeName = '';
      this.listeners = [];
      this.x = 0;
      this.y = 0;
      this.dbg = {};
      this.sh = 0;
      this._init();
    }
    // everything that belongs to one play session (a scene change clears most of it)
    _init() {
      Object.assign(this, {
        ovs: [],
        seq: 0,
        tgt: null,
        targets: [],
        tseq: 0,
        frameOn: null,
        bossOn: null,
        lock: null,
        shakes: [],
        legacy: 0,
        rec: { x: 0, y: 0, vx: 0, vy: 0 },
        pn: { x: 0, y: 0 },
        manual: null,
        free: null,
        zfx: null,
        zp: 0,
        zman: 1,
        rfx: null,
        rp: 0,
        fadeA: 0,
        fadeC: '#000',
        fade_: null,
        flash_: null,
        trans: null,
        cs: null,
        pendingFade: false,
        z: 1,
        r: 0,
        zeff: 1,
        reff: 0,
        vw: 25,
        vh: 14,
        lastVw: 0,
        lastVh: 0,
        fp: null,
        rt: 0,
        rtn: 0.6,
        sig: '',
        shx: 0,
        shy: 0,
        shr: 0,
        time: 0,
        tx: 0,
        ty: 0,
        inp: { px: 0, py: 0, zoom: 0, wheel: 0, dx: 0, dy: 0, reset: false },
        cx: 0,
        cy: 0,
        ppt: 32,
        snapNext: true,
        tl: { x: 0, y: 0 },
        mouseHeld: false
      });
    }
    bind(env) {
      this.env = env || {};
      if (env && env.ppt) this.ppt = env.ppt;
      return this;
    }

    // ================= settings =================
    settings(patch) {
      if (patch === undefined) return Object.assign({}, this.set);
      this.set = cleanUser(patch, this.set);
      saveUser(this.set);
      this.listeners.forEach(f => {
        try {
          f(this.settings());
        } catch (e) {
          /* a listener must not break the camera */
        }
      });
      return this.settings();
    }
    resetSettings() {
      this.set = cleanUser({});
      saveUser(this.set);
      return this.settings();
    }
    onSettings(f) {
      if (typeof f === 'function') this.listeners.push(f);
      return () => {
        this.listeners = this.listeners.filter(q => q !== f);
      };
    }

    // ================= modes =================
    mode(name) {
      if (name === undefined) return this.mode_ || 'follow';
      const k = modeKey(name);
      if (!name || (k === 'follow' && !this.modeName)) {
        this.modeName = '';
        this.free = null;
        return true;
      }
      if (UNSUPPORTED[k]) {
        this.unsupported = UNSUPPORTED[k];
        return false;
      }
      const real =
        Object.keys(MODES).find(m => modeKey(m) === k) ||
        (k === 'sidescrolling' ? 'side' : k === 'topdown' ? 'topdown' : '');
      if (!real) {
        this.unsupported = 'Unknown camera mode "' + name + '". Known: ' + Object.keys(MODES).join(', ') + '.';
        return false;
      }
      this.unsupported = '';
      this.modeName = real === 'follow' ? '' : real;
      if (real !== 'free') this.free = null;
      return true;
    }
    static registerMode(name, def) {
      if (!/^[a-z][\w-]{0,23}$/.test(name) || !def || typeof def !== 'object') return false;
      MODES[name] = Object.assign({ label: name, p: {} }, def);
      return true;
    }
    static modes() {
      return Object.keys(MODES).map(k => ({ id: k, label: MODES[k].label }));
    }

    // ================= targets, lock-on, framing =================
    _pt(spec) {
      if (!spec) return null;
      if (spec === 'player') return { x: this.tx, y: this.ty };
      try {
        if (typeof spec === 'function') return goodPt(spec());
        if (typeof spec === 'string') {
          const e = this.env.entity && this.env.entity(spec);
          return e && !e.dead ? goodPt(entPoint(e)) : null;
        }
        if (typeof spec === 'object') {
          if (spec.dead) return null;
          if (this.env.alive && 'cx' in spec && !this.env.alive(spec)) return null;
          return 'cx' in spec ? goodPt(entPoint(spec)) : goodPt(spec);
        }
      } catch (e) {
        return null;
      }
      return null;
    }
    target(spec, o) {
      this.tgt = spec || null;
      this._retarget(o && o.blend);
      return true;
    }
    addTarget(spec, weight) {
      if (!spec || this.targets.length >= 12) return 0;
      const id = ++this.tseq;
      this.targets.push({ id, spec, w: clamp(fin(weight, 1), 0, 4) });
      return id;
    }
    removeTarget(idOrSpec) {
      const n = this.targets.length;
      this.targets = this.targets.filter(t => t.id !== idOrSpec && t.spec !== idOrSpec);
      return this.targets.length < n;
    }
    clearTargets() {
      this.targets = [];
    }
    // Keep several things in view: the follow point, the added targets, the lock-on target and (with bossFrame) awake bosses. Zooms out when they do not fit.
    frame(on, o) {
      if (on === false || on === null) {
        this.frameOn = null;
        this._retarget();
        return false;
      }
      o = o || {};
      this.frameOn = {
        pad: clamp(fin(o.pad, 3), 0, 30),
        min: clamp(fin(o.min, 0.5), ZMIN, 1),
        max: clamp(fin(o.max, 1), ZMIN, ZMAX),
        zoomIn: !!o.zoomIn
      };
      this._retarget(o.blend);
      return true;
    }
    bossFrame(on, o) {
      if (on === false || on === null) {
        this.bossOn = null;
        this._retarget();
        return false;
      }
      o = o || {};
      this.bossOn = { pad: clamp(fin(o.pad, 3), 0, 30), min: clamp(fin(o.min, 0.6), ZMIN, 1) };
      this._retarget(o.blend);
      return true;
    }
    lockOn(spec, o) {
      o = o || {};
      const L = {
        spec: null,
        type: '',
        range: clamp(fin(o.range, 14), 1, 200),
        w: clamp(fin(o.weight, 0.5), 0, 1),
        maxDist: clamp(fin(o.maxDist, 14), 1, 200),
        auto: o.release !== 'manual',
        frame: !!o.frame
      };
      if (
        spec &&
        typeof spec === 'object' &&
        !('x' in spec) &&
        !('cx' in spec) &&
        typeof spec !== 'function' &&
        spec.type
      ) {
        L.type = String(spec.type);
        L.range = clamp(fin(spec.range, L.range), 1, 200);
      } else L.spec = spec || null;
      if (!L.spec && !L.type) {
        this.lock = null;
        return false;
      }
      this.lock = L;
      this._retarget(o.blend);
      if (L.type) this._lockPick(0);
      return true;
    }
    unlock(blend) {
      if (this.lock) {
        this.lock = null;
        this._retarget(blend);
      }
    }
    _candidates() {
      const L = this.lock,
        es = (this.env.entities && this.env.entities()) || [];
      if (!L || !L.type) return [];
      return es
        .filter(
          e =>
            e &&
            !e.dead &&
            (e.type === L.type || (L.type === 'enemy' && e.type === 'enemy') || e.type === L.type) &&
            Math.hypot(e.cx - this.tx, e.by - (e.h || 0) / 2 - this.ty) <= L.range
        )
        .sort((a, b) => Math.hypot(a.cx - this.tx, a.by - this.ty) - Math.hypot(b.cx - this.tx, b.by - this.ty));
    }
    _lockPick(step) {
      const c = this._candidates(),
        L = this.lock;
      if (!L || !c.length) {
        if (L && L.auto && L.type) L.spec = null;
        return false;
      }
      let i = L.spec ? c.indexOf(L.spec) : -1;
      i = i < 0 ? 0 : (i + (step || 0) + c.length) % c.length;
      L.spec = c[i];
      return true;
    }
    lockNext(dir) {
      if (!this.lock || !this.lock.type) return false;
      return this._lockPick(dir < 0 ? -1 : 1);
    }

    // ================= manual pan, free camera =================
    manualPan(on) {
      this.manual = !!on;
      return this.manual;
    }
    free_(on, o) {
      if (!on) {
        if (this.free) {
          this.free = null;
          if (this.modeName === 'free') this.modeName = '';
          this._retarget();
        }
        return false;
      }
      o = o || {};
      this.modeName = 'free';
      this.free = {
        x: this.cx,
        y: this.cy,
        speed: clamp(fin(o.speed, 12), 1, 80),
        bounds: o.bounds !== false,
        lock: o.lockInput !== false
      };
      return true;
    }
    pan(dx, dy) {
      this.pn.x = fin(dx, 0);
      this.pn.y = fin(dy, 0);
    } // set the manual pan offset directly (tiles)
    feed(i) {
      if (!i) return;
      const n = this.inp; // called every frame by the game: { keys(code) -> bool, stick: {x, y}, zoomAxis, wheel, drag: {dx, dy} (pixels), reset }
      const U = this.set,
        K = KEYS(),
        any = a => (a || []).some(c => i.keys && i.keys(c));
      let px = (any(K.panRight) ? 1 : 0) - (any(K.panLeft) ? 1 : 0),
        py = (any(K.panDown) ? 1 : 0) - (any(K.panUp) ? 1 : 0),
        z = (any(K.zoomIn) ? 1 : 0) - (any(K.zoomOut) ? 1 : 0);
      if (this.free || this.modeName === 'free') {
        px += (any(K.freeRight) ? 1 : 0) - (any(K.freeLeft) ? 1 : 0);
        py += (any(K.freeDown) ? 1 : 0) - (any(K.freeUp) ? 1 : 0);
      }
      const s = i.stick;
      if (s) {
        const m = Math.hypot(s.x || 0, s.y || 0),
          dz = U.deadzone;
        if (m > dz) {
          const k = (m - dz) / (1 - dz) / m;
          px += s.x * k;
          py += s.y * k;
        }
      }
      if (i.zoomAxis) z += i.zoomAxis;
      n.px = clamp(px, -1, 1) * (U.invertX ? -1 : 1);
      n.py = clamp(py, -1, 1) * (U.invertY ? -1 : 1);
      n.zoom = clamp(z, -1, 1);
      if (U.mouse) {
        n.wheel += fin(i.wheel, 0);
        if (i.drag) {
          n.dx += fin(i.drag.dx, 0) * (U.invertX ? -1 : 1);
          n.dy += fin(i.drag.dy, 0) * (U.invertY ? -1 : 1);
        }
      }
      if (i.reset || any(K.reset)) n.reset = true;
    }

    // ================= effects =================
    // shake(0.4) is the old call (strength, decays by itself). shake({ amount (tiles), time, freq, roll (degrees), dir: {x, y}, curve, power, id })
    shake(a) {
      if (typeof a === 'number') {
        this.legacy = Math.max(this.legacy, clamp(fin(a, 0), 0, 4));
        return;
      }
      a = a || {};
      const n = this.shakes.length;
      if (n >= 16) this.shakes.shift();
      const d = a.dir && Math.hypot(a.dir.x || 0, a.dir.y || 0) > 0 ? a.dir : null,
        m = d ? Math.hypot(d.x, d.y) : 1;
      this.shakes.push({
        id: a.id || '',
        amp: clamp(fin(a.amount, 0.3), 0, 3),
        dur: clamp(fin(a.time, 0.4), 0.02, 10),
        t: 0,
        freq: clamp(fin(a.freq, 28), 1, 80),
        roll: clamp(fin(a.roll, 0), 0, 20),
        dx: d ? d.x / m : 0,
        dy: d ? d.y / m : 0,
        power: clamp(fin(a.power, 2), 0.5, 6),
        seed: Math.random() * 100,
        curve: a.curve ? curve(a.curve) : null
      });
    }
    stopShake(id) {
      if (id === undefined) {
        this.shakes = [];
        this.legacy = 0;
      } else this.shakes = this.shakes.filter(s => s.id !== id);
    }
    // a kick: the view jumps away from (dx, dy) and springs back
    recoil(dx, dy, strength) {
      const m = Math.hypot(dx, dy) || 1,
        k = clamp(fin(strength, 1), 0, 6);
      this.rec.vx -= (dx / m) * k * 14;
      this.rec.vy -= (dy / m) * k * 14;
    }
    // zoom: factor 1.5 = closer. { time, ease, hold (seconds, then it returns by itself) }. A new call starts from where the last one is now.
    zoomTo(f, o) {
      o = o || {};
      const cur = this._zfx();
      this.zfx = {
        from: cur,
        to: clamp(fin(f, 1), ZMIN, ZMAX),
        t: 0,
        dur: Math.max(0.001, fin(o.time, 0.5)),
        cv: curve(o.ease),
        hold: o.hold > 0 ? o.hold : 0,
        back: Math.max(0.001, fin(o.returnTime, o.time || 0.5)),
        ph: 0
      };
    }
    zoomReset(time) {
      this.zoomTo(1, { time: fin(time, 0.5) });
    }
    zoomPunch(amount, time) {
      this.zp = clamp(this.zp + fin(amount, 0.1), -1, 1);
      this.zpT = Math.max(0.05, fin(time, 0.3));
    }
    rotateTo(deg, o) {
      o = o || {};
      const cur = this._rfx();
      this.rfx = {
        from: cur,
        to: clamp(fin(deg, 0), -ROTMAX, ROTMAX),
        t: 0,
        dur: Math.max(0.001, fin(o.time, 0.5)),
        cv: curve(o.ease),
        hold: o.hold > 0 ? o.hold : 0,
        back: Math.max(0.001, fin(o.returnTime, o.time || 0.5)),
        ph: 0
      };
    }
    rotatePunch(deg, time) {
      this.rp = clamp(this.rp + fin(deg, 2), -ROTMAX, ROTMAX);
      this.rpT = Math.max(0.05, fin(time, 0.3));
    }
    fade(color, to, time, o) {
      o = o || {};
      this.fadeC = typeof color === 'string' ? color : '#000';
      const from = o.from !== undefined ? clamp(fin(o.from, 0), 0, 1) : this.fadeA;
      this.fadeA = from;
      this.fade_ = {
        from,
        to: clamp(fin(to, 1), 0, 1),
        t: 0,
        dur: Math.max(0.001, fin(time, 0.5)),
        cv: curve(o.ease),
        done: typeof o.onDone === 'function' ? o.onDone : null
      };
    }
    fadeOut(time, color) {
      this.fade(color || this.fadeC, 1, time);
    }
    fadeIn(time) {
      this.fade(this.fadeC, 0, time);
    }
    flash(color, time, alpha) {
      this.flash_ = {
        c: typeof color === 'string' ? color : '#fff',
        a: clamp(fin(alpha, 0.8), 0, 1),
        t: 0,
        dur: Math.max(0.03, fin(time, 0.25))
      };
    }
    // fade / wipe / iris out, call onMid (switch the room there), then back in. The last call wins.
    transition(kind, time, onMid, o) {
      o = o || {};
      this.trans = {
        kind: ['fade', 'wipe', 'iris', 'slide', 'dissolve'].includes(kind) ? kind : 'fade',
        dur: Math.max(0.05, fin(time, 0.8)),
        t: 0,
        mid: false,
        onMid: typeof onMid === 'function' ? onMid : null,
        c: typeof o.color === 'string' ? o.color : '#000',
        fx: clamp(fin(o.fx, 0.5), 0, 1),
        fy: clamp(fin(o.fy, 0.5), 0, 1)
      };
    }
    _zfx() {
      const f = this.zfx;
      if (!f) return 1;
      return f.ph === 0 ? lerp(f.from, f.to, f.cv(f.t / f.dur)) : f.ph === 1 ? f.to : lerp(f.to, 1, f.cv(f.t / f.back));
    }
    _rfx() {
      const f = this.rfx;
      if (!f) return 0;
      return f.ph === 0 ? lerp(f.from, f.to, f.cv(f.t / f.dur)) : f.ph === 1 ? f.to : lerp(f.to, 0, f.cv(f.t / f.back));
    }
    _tween(f, dt, key) {
      if (!f) return null;
      f.t += dt;
      if (f.ph === 0 && f.t >= f.dur) {
        if (f.hold > 0) {
          f.ph = 1;
          f.t = 0;
        } else {
          f.ph = 3;
          f.t = 0;
          if (Math.abs(f.to - (key === 'z' ? 1 : 0)) < 1e-6) return null;
        }
      }
      if (f.ph === 1 && f.t >= f.hold) {
        f.ph = 2;
        f.t = 0;
      }
      if (f.ph === 2 && f.t >= f.back) return null;
      return f;
    }

    // ================= overrides: temporary changes with a priority =================
    // override({ id, priority, mode, target, zoom, rot, offset {x, y}, profile, p, bounds ([x0, y0, x1, y1] | false), frame, lockInput, blend, ttl, scope: 'room' | 'global', onEnd })
    // The highest priority wins each property; equal priorities: the newest. It blends in and out over `blend` seconds. Returns its id.
    override(o) {
      o = o && typeof o === 'object' ? o : {};
      if (this.ovs.length >= 24) return '';
      const id = String(o.id || 'ov' + (this.seq + 1)).slice(0, 32);
      this.ovs = this.ovs.filter(q => q.id !== id);
      const ov = {
        id,
        seq: ++this.seq,
        priority: fin(o.priority, 0),
        mode: o.mode,
        target: o.target,
        zoom: o.zoom,
        rot: o.rot,
        offset: o.offset,
        profile: o.profile,
        p: o.p,
        bounds: o.bounds,
        frame: o.frame,
        lockInput: !!o.lockInput,
        blend: Math.max(0.01, fin(o.blend, 0.6)),
        ease: o.ease,
        we: 0,
        ttl: o.ttl > 0 ? +o.ttl : 0,
        scope: o.scope === 'room' ? 'room' : 'global',
        w: 0,
        ending: false,
        onEnd: typeof o.onEnd === 'function' ? o.onEnd : null,
        rail: o.rail || null
      };
      this.ovs.push(ov);
      this._retarget(ov.blend);
      return id;
    }
    // change a live override (the virtual camera manager does this every frame): overrideSet(id, { zoom, rot, offset, p, bounds, target, mode, profile, frame, priority })
    overrideSet(id, patch) {
      const ov = this.ovs.find(q => q.id === id);
      if (!ov || !patch) return false;
      for (const k of [
        'zoom',
        'rot',
        'offset',
        'p',
        'bounds',
        'target',
        'mode',
        'profile',
        'frame',
        'priority',
        'ease'
      ])
        if (k in patch) ov[k] = patch[k];
      return true;
    }
    // the camera stops following for `time` seconds (shake, zoom and fades still play)
    freeze(time) {
      this.frz = clamp(fin(time, 0), 0, 30);
      this.fz = { x: this.tx, y: this.ty };
    }
    endOverride(id, blend) {
      const ov = this.ovs.find(q => q.id === id);
      if (!ov) return false;
      ov.ending = true;
      if (blend !== undefined) ov.blend = Math.max(0.01, fin(blend, ov.blend));
      this._retarget(ov.blend);
      return true;
    }
    overrides() {
      return this.ovs.map(q => ({
        id: q.id,
        priority: q.priority,
        weight: +q.w.toFixed(2),
        ending: q.ending,
        scope: q.scope
      }));
    }
    inputLocked() {
      return this.ovs.some(q => q.lockInput && q.w > 0) || !!(this.free && this.free.lock);
    }
    _tickOv(dt) {
      for (const q of this.ovs.slice()) {
        if (q.ttl > 0 && (q.ttl -= dt) <= 0) q.ending = true;
        if (q.rail && !q.rail.cut && !q.ending) this._tickRail(q, dt);
        q.w = clamp(q.w + ((q.ending ? -1 : 1) * dt) / q.blend, 0, 1);
        q.we = q.ease ? curve(q.ease)(q.w) : q.w; // the weight after the blend curve
        if (q.ending && q.w <= 0) {
          this.ovs = this.ovs.filter(z => z !== q);
          if (q.onEnd) {
            try {
              q.onEnd();
            } catch (e) {
              /* a script error must not stop the camera */
            }
          }
        }
      }
    }
    _resolve() {
      const O = { w: 0, p: null, pid: '' };
      this.ovs
        .slice()
        .sort((a, b) => a.priority - b.priority || a.seq - b.seq)
        .forEach(q => {
          const w = q.we;
          if (!(w > 0)) return;
          O.w = Math.max(O.w, w);
          if (q.mode) O.mode = q.mode;
          if (q.target !== undefined) O.target = q.target;
          if (q.zoom !== undefined) {
            O.zoom = q.zoom;
            O.wz = w;
          }
          if (q.rot !== undefined) {
            O.rot = q.rot;
            O.wr = w;
          }
          if (q.offset) {
            O.off = { x: fin(q.offset.x, 0) * w, y: fin(q.offset.y, 0) * w };
          }
          if (q.profile) {
            O.p = Object.assign({}, O.p, MV.Camera.profile(q.profile, this.env.profiles && this.env.profiles()));
            O.pid = q.profile;
          }
          if (q.p) O.p = Object.assign({}, O.p, MV.Camera.cleanP(q.p));
          if (q.bounds !== undefined) O.box = q.bounds;
          if (q.frame) O.frame = q.frame;
          if (q.rail) {
            O.rail = q.rail;
            O.cinBounds = q.rail.bounds;
          }
        });
      return O;
    }

    // ================= rails and cutscenes =================
    // rail([{x, y, zoom?, rot?}, ...], { time | speed (tiles/s), ease, loop: 'none' | 'repeat' | 'pingpong', smooth (curved), hold, bounds, lockInput, priority, blend, onDone, id }) -> id
    rail(pts, o) {
      o = o || {};
      pts = (Array.isArray(pts) ? pts : [])
        .map(goodPt)
        .filter(Boolean)
        .map((p, i) => Object.assign(p, { zoom: (pts[i] || {}).zoom, rot: (pts[i] || {}).rot }))
        .slice(0, 64);
      if (pts.length < 1) return '';
      if (pts.length === 1) pts.push(Object.assign({}, pts[0]));
      const seg = [];
      let len = 0;
      for (let i = 1; i < pts.length; i++) {
        len += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
        seg.push(len);
      }
      const dur = o.time > 0 ? +o.time : o.speed > 0 && len > 0 ? len / o.speed : Math.max(0.5, len / 8);
      const R = {
        pts,
        seg,
        len,
        dur: Math.max(0.05, dur),
        t: 0,
        cv: curve(o.ease),
        loop: ['repeat', 'pingpong'].includes(o.loop) ? o.loop : 'none',
        smooth: !!o.smooth,
        hold: !!o.hold,
        bounds: !!o.bounds,
        onDone: typeof o.onDone === 'function' ? o.onDone : null,
        x: pts[0].x,
        y: pts[0].y
      };
      return this.override({
        id: o.id || 'rail' + (this.seq + 1),
        priority: fin(o.priority, 50),
        mode: 'rail',
        lockInput: !!o.lockInput,
        blend: fin(o.blend, 0.5),
        scope: 'global',
        rail: R
      });
    }
    stopRail(id, blend) {
      return this.endOverride(id, blend);
    }
    _tickRail(q, dt) {
      const R = q.rail;
      R.t += dt;
      let u = R.t / R.dur;
      if (u >= 1) {
        if (R.loop === 'repeat') {
          R.t -= R.dur;
          u = R.t / R.dur;
        } else if (R.loop === 'pingpong') {
          const m = R.t % (2 * R.dur);
          u = m <= R.dur ? m / R.dur : 2 - m / R.dur;
        } else {
          u = 1;
          if (!R.done) {
            R.done = true;
            if (R.onDone) {
              try {
                R.onDone();
              } catch (e) {
                /* ignore */
              }
            }
            if (!R.hold) q.ending = true;
          }
        }
      }
      const e = R.cv(clamp(u, 0, 1)),
        d = e * R.len;
      let i = 0;
      while (i < R.seg.length - 1 && R.seg[i] < d) i++;
      const s0 = i ? R.seg[i - 1] : 0,
        s1 = R.seg[i],
        f = s1 > s0 ? clamp((d - s0) / (s1 - s0), 0, 1) : 1;
      const A = R.pts[i],
        B = R.pts[i + 1];
      let x, y;
      if (R.smooth && R.pts.length > 2) {
        const P0 = R.pts[Math.max(0, i - 1)],
          P3 = R.pts[Math.min(R.pts.length - 1, i + 2)],
          f2 = f * f,
          f3 = f2 * f,
          cr = (a, b, c, dd) =>
            0.5 * (2 * b + (-a + c) * f + (2 * a - 5 * b + 4 * c - dd) * f2 + (-a + 3 * b - 3 * c + dd) * f3);
        x = cr(P0.x, A.x, B.x, P3.x);
        y = cr(P0.y, A.y, B.y, P3.y);
      } else {
        x = lerp(A.x, B.x, f);
        y = lerp(A.y, B.y, f);
      }
      R.x = x;
      R.y = y;
      R.zoom = A.zoom !== undefined || B.zoom !== undefined ? lerp(fin(A.zoom, 1), fin(B.zoom, 1), f) : undefined;
      R.rot = A.rot !== undefined || B.rot !== undefined ? lerp(fin(A.rot, 0), fin(B.rot, 0), f) : undefined;
    }
    // cutscene([{ pan: {x, y} | target, dur, ease, zoom, rot, shake, recoil, fade: {to, color}, flash, lock, unlock, call, wait, parallel }, ...], { lockInput (default true), bounds, onDone, id })
    // Steps run one after another (a step with `parallel: true` does not make the next one wait). skipCutscene() jumps to the end.
    cutscene(steps, o) {
      o = o || {};
      this.endCutscene(0);
      steps = (Array.isArray(steps) ? steps : []).slice(0, 80);
      if (!steps.length) return false;
      const C = { steps, i: 0, wait: 0, pt: null, tw: null, o, id: o.id || 'cutscene', done: false };
      C.ov = this.override({
        id: C.id,
        priority: 100,
        mode: 'rail',
        lockInput: o.lockInput !== false,
        blend: 0.4,
        scope: 'global',
        rail: { cut: true, bounds: !!o.bounds, x: this.cx, y: this.cy }
      });
      this.cs = C;
      return true;
    }
    endCutscene(blend) {
      const C = this.cs;
      if (!C) return false;
      this.cs = null;
      this.endOverride(C.ov, blend === undefined ? 0.6 : blend);
      if (!C.done && C.o.onDone && !C.skipped) {
        /* ended early: no callback */
      }
      return true;
    }
    skipCutscene() {
      const C = this.cs;
      if (!C) return false;
      C.skipped = true;
      while (C.i < C.steps.length) this._csRun(C, true);
      this._csFinish(C);
      return true;
    }
    _csRun(C, instant) {
      const s = C.steps[C.i++] || {},
        dur = instant ? 0 : Math.max(0, fin(s.dur, fin(s.wait, 0)));
      let to = null;
      if (s.pan) to = goodPt(s.pan);
      else if (s.target) to = this._pt(s.target);
      if (to) {
        const from = C.pt || { x: this.cx, y: this.cy };
        if (dur > 0) C.tw = { from, to, t: 0, dur, cv: curve(s.ease) };
        else {
          C.tw = null;
          C.pt = to;
        }
      }
      if (s.zoom !== undefined) this.zoomTo(s.zoom, { time: dur || 0.001, ease: s.ease });
      if (s.rot !== undefined) this.rotateTo(s.rot, { time: dur || 0.001, ease: s.ease });
      if (!instant) {
        if (s.shake !== undefined) this.shake(typeof s.shake === 'object' ? s.shake : { amount: +s.shake || 0.3 });
        if (s.recoil) this.recoil(fin(s.recoil.x, 0), fin(s.recoil.y, 0), s.recoil.strength);
        if (s.flash) this.flash(s.flash.color, s.flash.time, s.flash.alpha);
      }
      if (s.fade) this.fade(s.fade.color, s.fade.to, instant ? 0.001 : fin(s.fade.time, dur || 0.5));
      if (s.lock) this.lockOn(s.lock.spec !== undefined ? s.lock.spec : s.lock, s.lock);
      if (s.unlock) this.unlock();
      if (typeof s.call === 'function') {
        try {
          s.call(this);
        } catch (e) {
          /* a script error must not stop the cutscene */
        }
      }
      C.wait = s.parallel ? 0 : dur;
    }
    _csFinish(C) {
      if (C.done) return;
      C.done = true;
      if (this.cs === C) this.cs = null;
      this.endOverride(C.ov, 0.6);
      if (C.o.onDone) {
        try {
          C.o.onDone();
        } catch (e) {
          /* ignore */
        }
      }
    }
    _tickCs(dt) {
      const C = this.cs;
      if (!C) return;
      if (C.tw) {
        C.tw.t += dt;
        const f = clamp(C.tw.t / C.tw.dur, 0, 1),
          e = C.tw.cv(f);
        C.pt = { x: lerp(C.tw.from.x, C.tw.to.x, e), y: lerp(C.tw.from.y, C.tw.to.y, e) };
        if (f >= 1) C.tw = null;
      }
      if (C.wait > 0) {
        C.wait -= dt;
        if (C.wait > 0) return;
      }
      let guard = 0;
      while (C.i < C.steps.length && C.wait <= 0 && guard++ < 80) this._csRun(C, false);
      if (C.i >= C.steps.length && C.wait <= 0 && !C.tw) this._csFinish(C);
    }

    // ================= scene changes =================
    // Called by the game when a room is loaded. Room-scoped overrides end, targets that no longer exist are dropped, effects calm down and the camera jumps to the new room.
    sceneChange() {
      this.ovs = this.ovs.filter(q => q.scope !== 'room');
      if (this.cs && !this.cs.o.persist) {
        this.cs = null;
        this.ovs = this.ovs.filter(q => q.id !== 'cutscene');
      }
      this.shakes = [];
      this.legacy = 0;
      this.rec = { x: 0, y: 0, vx: 0, vy: 0 };
      this.pn = { x: 0, y: 0 };
      this.zp = 0;
      this.rp = 0;
      this.tgt = this._pt(this.tgt) ? this.tgt : null;
      this.targets = this.targets.filter(t => this._pt(t.spec) || typeof t.spec === 'function');
      if (this.lock && !this.lock.type && !this._pt(this.lock.spec)) this.lock = null;
      this.free = null;
      if (this.modeName === 'free') this.modeName = '';
      this.fp = null;
      this.rt = 0;
      this.snapNext = true;
      this.pendingFade = true;
      this.core.gt = undefined;
    }
    resize() {
      this.snapNext = true;
      this.lastVw = 0;
      this.lastVh = 0;
    }
    _retarget(t) {
      this.rt = Math.max(this.rt, clamp(fin(t, 0.6), 0.05, 5));
      this.rtn = this.rt;
    }

    // ================= the update =================
    // Same call as the original camera: (dt, target x, target y, view width, view height (tiles), room width, room height, cfg, snap, player info, tuning).
    update(dt, tx, ty, vw0, vh0, rw, rh, cfg, snap, pl, tn) {
      dt = clamp(fin(dt, 0), 0, 0.1);
      vw0 = Math.max(1, fin(vw0, 25));
      vh0 = Math.max(1, fin(vh0, 14));
      rw = Math.max(1, fin(rw, vw0));
      rh = Math.max(1, fin(rh, vh0));
      this.tx = tx = fin(tx, this.tx);
      this.ty = ty = fin(ty, this.ty);
      if (this.frz > 0) {
        this.frz -= dt;
        tx = this.fz.x;
        ty = this.fz.y;
      }
      cfg = cfg || {};
      pl = pl || {};
      tn = tn || {};
      const U = this.set,
        calm = U.reduceMotion;
      if (this.snapNext) {
        snap = true;
        this.snapNext = false;
      }
      this.time += dt;
      this._tickOv(dt);
      this._tickCs(dt);
      const O = this._resolve(),
        base = Object.assign({}, tn, cfg.p || {}, O.p || {}),
        nb = k => fin(base[k], X(k).def);
      // mode: override > mode() > profile
      let mname = O.mode || this.modeName || base.view || 'follow';
      if (mname === 'rail') mname = 'rail';
      const md = mname === 'rail' ? { label: 'Rail', p: {}, cin: true } : MODES[mname] || MODES.follow;
      this.mode_ = md === MODES[mname] || mname === 'rail' ? mname : 'follow';
      if (this.pendingFade) {
        this.pendingFade = false;
        const rf = nb('roomFade');
        if (rf > 0) this.fade('#000', 0, rf, { from: 1 });
      }
      // ---- input: manual pan, free camera, zoom keys, mouse ----
      const free = !!md.free || !!this.free,
        panOn = free || this.manual || base.manualPan === 'yes',
        I = this.inp,
        ppt = Math.max(1, this.ppt);
      if (free && !this.free) this.free = { x: this.cx, y: this.cy, speed: 12, bounds: true, lock: true };
      if (!free && this.free) this.free = null;
      if (I.reset) {
        this.pn.x = this.pn.y = 0;
        this.zman = 1;
        if (this.free) {
          this.free.x = tx;
          this.free.y = ty;
        }
      }
      const sens = U.sensitivity;
      if (panOn) {
        const wheel = I.wheel;
        if (wheel) this.zman = clamp(this.zman * Math.exp(-wheel * 0.0012 * sens), 0.25, 4);
        if (I.zoom) this.zman = clamp(this.zman * Math.exp(I.zoom * 1.2 * sens * dt), 0.25, 4);
      }
      if (this.free) {
        const F = this.free,
          sp = (F.speed * sens) / Math.max(0.25, this.zeff);
        F.x += I.px * sp * dt + (I.dx / ppt / Math.max(0.25, this.zeff)) * -1 * sens;
        F.y += I.py * sp * dt + (I.dy / ppt / Math.max(0.25, this.zeff)) * -1 * sens;
      } else if (panOn) {
        const R = Math.max(0, nb('panRange')),
          sp = 10 * sens;
        this.pn.x += I.px * sp * dt - (I.dx / ppt) * sens;
        this.pn.y += I.py * sp * dt - (I.dy / ppt) * sens;
        if (!I.px && !I.py && !I.dx && !I.dy) {
          const k = Math.exp(-dt * 3);
          this.pn.x *= k;
          this.pn.y *= k;
        }
        const m = Math.hypot(this.pn.x, this.pn.y);
        if (m > R) {
          this.pn.x *= R / m;
          this.pn.y *= R / m;
        }
      } else {
        this.pn.x *= Math.exp(-dt * 6);
        this.pn.y *= Math.exp(-dt * 6);
        if (Math.abs(this.pn.x) < 1e-3) this.pn.x = 0;
        if (Math.abs(this.pn.y) < 1e-3) this.pn.y = 0;
      }
      I.wheel = 0;
      I.dx = 0;
      I.dy = 0;
      I.reset = false;
      // ---- where to look: cutscene / rail > free > target, lock-on and framing ----
      let D = { x: tx, y: ty },
        src = 'player',
        cin = false,
        zc,
        rc2;
      if (this.free) {
        D = { x: this.free.x, y: this.free.y };
        src = 'free';
        cin = true;
        if (this.free.bounds) {
          const pad = 2;
          D.x = this.free.x = clamp(this.free.x, -pad, rw + pad);
          D.y = this.free.y = clamp(this.free.y, -pad, rh + pad);
        }
      } else if (O.rail) {
        const R = O.rail;
        if (R.cut) {
          const c = this.cs;
          if (c && c.pt) {
            D = { x: c.pt.x, y: c.pt.y };
            cin = true;
            src = 'cutscene';
          }
        } else {
          D = { x: fin(R.x, tx), y: fin(R.y, ty) };
          cin = true;
          src = 'rail';
          zc = R.zoom;
          rc2 = R.rot;
        }
      }
      let pts = null,
        frame = O.frame ? Object.assign({ pad: 3, min: 0.5, max: 1 }, O.frame) : this.frameOn;
      if (!cin) {
        const tg = O.target !== undefined ? O.target : this.tgt;
        if (tg) {
          const p = this._pt(tg);
          if (p) {
            D = p;
            src = 'target';
          } else if (O.target === undefined) this.tgt = null;
        }
        const prim = { x: D.x, y: D.y };
        pts = [prim];
        if (this.lock) {
          const L = this.lock;
          if (L.type && !L.spec) this._lockPick(0);
          const p = this._pt(L.spec);
          if (!p) {
            if (L.auto) this.lock = null;
          } else {
            const dist = Math.hypot(p.x - prim.x, p.y - prim.y);
            if (dist > L.maxDist * 1.25 && L.auto) this.lock = null;
            else {
              const w = L.w * clamp((L.maxDist * 1.25 - dist) / (L.maxDist * 0.25), 0, 1);
              D = { x: lerp(D.x, p.x, w), y: lerp(D.y, p.y, w) };
              src += '+lock';
              if (L.frame) pts.push(p);
            }
          }
        }
        for (const t of this.targets) {
          const p = this._pt(t.spec);
          if (p) pts.push(p);
          else if (typeof t.spec !== 'function') this.targets = this.targets.filter(z => z !== t);
        }
        const bo = this.bossOn;
        if (bo || base.bossFrame === 'yes') {
          const bs = (this.env.bosses && this.env.bosses()) || [];
          bs.forEach(b => {
            if (b && !b.dead && b.b && b.b.awake) pts.push(entPoint(b));
          });
          if (bs.some(b => b && !b.dead && b.b && b.b.awake))
            frame = frame || { pad: bo ? bo.pad : nb('framePad'), min: bo ? bo.min : nb('frameMin'), max: 1 };
        }
        if (pts.length > 1 && frame) {
          let a = 1e9,
            b = 1e9,
            c = -1e9,
            d = -1e9;
          pts.forEach(p => {
            a = Math.min(a, p.x);
            b = Math.min(b, p.y);
            c = Math.max(c, p.x);
            d = Math.max(d, p.y);
          });
          D = { x: (a + c) / 2, y: (b + d) / 2 };
          this.fit = {
            w: c - a,
            h: d - b,
            pad: frame.pad,
            min: frame.min,
            max: frame.max,
            zoomIn: frame.zoomIn,
            prim,
            a,
            b,
            c,
            d
          };
          src += '+frame';
        } else this.fit = null;
        if (!(pts.length > 1 && frame)) this.fit = null;
        // look ahead in both directions (top-down): the view leans the way you move
        if (md.look2d) {
          const la = nb('camLookAhead') || 0,
            mx = Math.abs(pl.vx || 0) > 0.5 ? Math.sign(pl.vx) : 0,
            my = Math.abs(pl.vy || 0) > 0.5 ? Math.sign(pl.vy) : 0,
            k = 1 - Math.pow(1 - clamp(nb('camLookSpeed'), 0.01, 1), dt * 60);
          this.tl.x += (mx * la - this.tl.x) * (snap ? 1 : k);
          this.tl.y += (my * la - this.tl.y) * (snap ? 1 : k);
          D = { x: D.x + this.tl.x, y: D.y + this.tl.y };
        }
      } else this.fit = null;
      if (O.off) {
        D = { x: D.x + O.off.x, y: D.y + O.off.y };
      }
      // a change of what the camera looks at glides instead of jumping
      const sig = mname + '|' + src + '|' + (this.lock && this.lock.spec ? 1 : 0) + (this.fit ? 1 : 0) + (cin ? 1 : 0);
      if (sig !== this.sig && !snap && this.sig) this._retarget();
      this.sig = sig;
      if (!this.fp || snap) this.fp = { x: D.x, y: D.y };
      if (this.rt > 0) {
        const k = 1 - Math.pow(0.001, dt / Math.max(0.05, this.rtn));
        this.fp.x += (D.x - this.fp.x) * k;
        this.fp.y += (D.y - this.fp.y) * k;
        this.rt = Math.max(0, this.rt - dt);
      } else this.fp = { x: D.x, y: D.y };
      // ---- zoom and rotation ----
      const bm = base.bounds || 'room',
        boxd = cfg.box ? [cfg.box[2] - cfg.box[0], cfg.box[3] - cfg.box[1]] : null,
        hardRoom = bm === 'room' && !cfg.brk && O.box === undefined && !cin;
      let zmin = ZMIN;
      if (boxd) zmin = Math.max(zmin, Math.min(1, Math.max(vw0 / Math.max(1, boxd[0]), vh0 / Math.max(1, boxd[1]))));
      else if (hardRoom) zmin = Math.max(zmin, Math.min(1, Math.max(vw0 / rw, vh0 / rh)));
      let zt = fin(zc, nb('zoom'));
      if (O.zoom !== undefined) zt = lerp(zt, fin(O.zoom, 1), fin(O.wz, 1));
      zt *= U.zoom * (panOn ? this.zman : 1);
      if (this.fit) {
        const f = this.fit,
          need = Math.min(vw0 / Math.max(1, f.w + 2 * f.pad), vh0 / Math.max(1, f.h + 2 * f.pad));
        zt = f.zoomIn ? clamp(need, f.min, f.max) : clamp(Math.min(zt, need), f.min, zt);
      }
      zt = clamp(zt, zmin, ZMAX);
      const zr = 1 - Math.exp(-Math.max(0.1, nb('zoomSpeed')) * dt);
      this.z = snap ? zt : this.z + (zt - this.z) * zr;
      this.zfx = this._tween(this.zfx, dt, 'z');
      this.rfx = this._tween(this.rfx, dt, 'r');
      if (this.zp) {
        this.zp *= Math.exp((-dt / Math.max(0.05, this.zpT || 0.3)) * 3);
        if (Math.abs(this.zp) < 0.002) this.zp = 0;
      }
      if (this.rp) {
        this.rp *= Math.exp((-dt / Math.max(0.05, this.rpT || 0.3)) * 3);
        if (Math.abs(this.rp) < 0.01) this.rp = 0;
      }
      this.zeff = clamp(this.z * (calm ? 1 : this._zfx() * Math.exp(this.zp)), zmin, ZMAX);
      let rt0 = fin(rc2, nb('rot'));
      if (O.rot !== undefined) rt0 = lerp(rt0, fin(O.rot, 0), fin(O.wr, 1));
      this.r = snap ? rt0 : this.r + (rt0 - this.r) * (1 - Math.exp(-4 * dt));
      this.reff = calm || this.noRotate ? 0 : clamp(this.r + this._rfx() + this.rp, -ROTMAX, ROTMAX);
      const vw = vw0 / this.zeff,
        vh = vh0 / this.zeff;
      this.vw = vw;
      this.vh = vh;
      // keep the middle of the view where it was when the zoom changes
      if (this.lastVw > 0 && !snap) {
        this.core.x += (this.lastVw - vw) / 2;
        this.core.y += (this.lastVh - vh) / 2;
      }
      this.lastVw = vw;
      this.lastVh = vh;
      // ---- the base camera ----
      const m = Math.pow(2, (0.5 - U.smoothing) * 3),
        cfg2 = Object.assign({}, cfg),
        p2 = Object.assign({}, cfg.p || {}, md.p || {}, O.p || {});
      if (m !== 1) {
        p2.camSmoothX = clamp(fin(base.camSmoothX, MV.data.camera.follow) * m, 0.02, 1);
        p2.camSmoothY = clamp(fin(base.camSmoothY, MV.data.camera.follow) * m, 0.02, 1);
        if (typeof cfg.follow === 'number') cfg2.follow = clamp(cfg.follow * m, 0.02, 1);
      }
      if (cin)
        Object.assign(p2, {
          modeX: 'centered',
          modeY: 'centered',
          camLookAhead: 0,
          camFallLook: 0,
          camRiseLook: 0,
          camPeek: 0,
          camLedgeLook: 0,
          camPosX: 0,
          camPosY: 0,
          camOffsetY: 0,
          camDeadX: 0,
          camDeadY: 0
        });
      if (md.look2d) p2.camLookAhead = 0;
      cfg2.p = p2;
      cfg2.id = (cfg.id || '') + (O.pid ? '|' + O.pid : '') + '|' + mname;
      if (O.box !== undefined) {
        cfg2.box = O.box || null;
        if (O.box === false) cfg2.brk = true;
      }
      if (cin && !(O.cinBounds || (O.rail && O.rail.bounds)) && !(this.free && this.free.bounds)) cfg2.brk = true;
      const softPad = nb('softPad');
      let soft = null;
      if (softPad > 0 && !cin) {
        soft = cfg2.box ? cfg2.box.slice() : [0, 0, rw, rh];
        cfg2.box = null;
        cfg2.brk = true;
      }
      this.core.update(dt, this.fp.x, this.fp.y, vw, vh, rw, rh, cfg2, snap, pl, tn);
      let Xp = this.core.x,
        Yp = this.core.y;
      if (soft) {
        const sf = (v, lo, hi) => {
          if (hi < lo) return (lo + hi) / 2;
          if (v < lo) return lo - softPad * (1 - Math.exp(-(lo - v) / softPad));
          if (v > hi) return hi + softPad * (1 - Math.exp(-(v - hi) / softPad));
          return v;
        };
        Xp = sf(Xp, soft[0], soft[2] - vw);
        Yp = sf(Yp, soft[1], soft[3] - vh);
      }
      // screen-edge margin: the thing you follow never gets closer than this to the edge of the screen
      const edge = clamp(nb('edge'), 0, Math.min(vw, vh) / 2 - 0.01);
      if (edge > 0 && !cin) {
        const q = this.fit ? this.fit.prim : { x: tx, y: ty };
        Xp = clamp(Xp, q.x - vw + edge, q.x - edge);
        Yp = clamp(Yp, q.y - vh + edge, q.y - edge);
      }
      // manual pan, kept inside the same limits
      if (!this.free && (this.pn.x || this.pn.y)) {
        Xp += this.pn.x;
        Yp += this.pn.y;
        const bb = this.core.bb;
        if (bb && !cfg2.brk && !soft) {
          Xp = clamp(Xp, bb[0], bb[2]);
          Yp = clamp(Yp, bb[1], bb[3]);
        }
      }
      // recoil: a critically damped spring (small fixed steps so it is the same at any frame rate)
      {
        const R = this.rec;
        let left = dt;
        while (left > 1e-6) {
          const h = Math.min(left, 1 / 120),
            w = 16;
          R.vx += (-w * w * R.x - 2 * w * R.vx) * h;
          R.vy += (-w * w * R.y - 2 * w * R.vy) * h;
          R.x += R.vx * h;
          R.y += R.vy * h;
          left -= h;
        }
        R.x = clamp(R.x, -3, 3);
        R.y = clamp(R.y, -3, 3);
        if (Math.abs(R.x) + Math.abs(R.y) + Math.abs(R.vx) + Math.abs(R.vy) < 1e-3) {
          R.x = R.y = R.vx = R.vy = 0;
        }
      }
      Xp += this.rec.x;
      Yp += this.rec.y;
      // shake
      {
        let sx = 0,
          sy = 0,
          sr = 0;
        const gain = calm ? Math.min(U.shake, 0.25) : U.shake;
        if (this.legacy > 0) {
          const a = this.legacy * 0.25,
            t = this.time * 30;
          sx += a * noise(1.3, t);
          sy += a * noise(7.1, t);
          this.legacy = Math.max(0, this.legacy - MV.data.camera.shakeDecay * dt);
        }
        this.shakes = this.shakes.filter(s => (s.t += dt) < s.dur);
        this.shakes.forEach(s => {
          const f = clamp(1 - s.t / s.dur, 0, 1),
            env = (s.curve ? s.curve(f) : Math.pow(f, s.power)) * s.amp,
            t = s.t * s.freq,
            n1 = noise(s.seed, t),
            n2 = noise(s.seed + 7.3, t);
          if (s.dx || s.dy) {
            sx += s.dx * n1 * env;
            sy += s.dy * n1 * env;
          } else {
            sx += n1 * env;
            sy += n2 * env;
          }
          sr += s.roll * noise(s.seed + 3.1, t) * (s.curve ? s.curve(f) : Math.pow(f, s.power));
        });
        this.shx = clamp(sx * gain, -2, 2);
        this.shy = clamp(sy * gain, -2, 2);
        this.shr = calm || this.noRotate ? 0 : clamp(sr * gain, -ROTMAX, ROTMAX);
        this.sh = this.legacy;
      }
      this.x = Xp;
      this.y = Yp;
      this.cx = Xp + vw / 2;
      this.cy = Yp + vh / 2;
      // fades, flashes, transitions
      if (this.fade_) {
        const f = this.fade_;
        f.t += dt;
        const u = clamp(f.t / f.dur, 0, 1);
        this.fadeA = lerp(f.from, f.to, f.cv(u));
        if (u >= 1) {
          this.fadeA = f.to;
          this.fade_ = null;
          if (f.done) {
            try {
              f.done();
            } catch (e) {
              /* ignore */
            }
          }
        }
      }
      if (this.flash_) {
        this.flash_.t += dt;
        if (this.flash_.t >= this.flash_.dur) this.flash_ = null;
      }
      if (this.trans) {
        const T = this.trans;
        T.t += dt;
        if (!T.mid && T.t >= T.dur / 2) {
          T.mid = true;
          if (T.onMid) {
            try {
              T.onMid();
            } catch (e) {
              /* ignore */
            }
          }
        }
        if (T.t >= T.dur) this.trans = null;
      }
      this.dbg = Object.assign({}, this.core.dbg, {
        mode: this.mode_,
        src,
        zoom: +this.zeff.toFixed(3),
        rot: +this.reff.toFixed(2),
        overrides: this.ovs.map(q => q.id),
        lock: !!this.lock,
        targets: this.targets.length,
        frame: !!this.fit,
        free: !!this.free,
        view: [+this.x.toFixed(2), +this.y.toFixed(2), +vw.toFixed(2), +vh.toFixed(2)]
      });
    }

    // ================= what the renderer needs =================
    // cx, cy: the middle of the view (tiles, with shake); vw, vh: how many tiles are visible; zoom, rot (radians); rx, ry, rw, rh: the rectangle to draw (covers the view even when rotated); plain: nothing to compose.
    view() {
      const th = ((this.reff + this.shr) * Math.PI) / 180,
        c = Math.abs(Math.cos(th)),
        s = Math.abs(Math.sin(th)),
        vw = this.vw,
        vh = this.vh,
        cx = this.cx + this.shx,
        cy = this.cy + this.shy,
        rw = vw * c + vh * s,
        rh = vw * s + vh * c;
      return {
        cx,
        cy,
        vw,
        vh,
        zoom: this.zeff,
        rot: th,
        rw,
        rh,
        rx: cx - rw / 2,
        ry: cy - rh / 2,
        plain: Math.abs(this.zeff - 1) < 1e-3 && Math.abs(th) < 1e-4,
        x: this.x,
        y: this.y
      };
    }
    offset() {
      const v = this.view();
      return [v.rx, v.ry];
    }
    // world tiles <-> screen pixels of a canvas cw x ch drawn with z pixels per tile (zoom and rotation included)
    toScreen(wx, wy, cw, ch, z) {
      const v = this.view(),
        c = Math.cos(v.rot),
        s = Math.sin(v.rot),
        dx = (wx - v.cx) * z * v.zoom,
        dy = (wy - v.cy) * z * v.zoom;
      return { x: cw / 2 + dx * c - dy * s, y: ch / 2 + dx * s + dy * c };
    }
    toWorld(sx, sy, cw, ch, z) {
      const v = this.view(),
        c = Math.cos(-v.rot),
        s = Math.sin(-v.rot),
        dx = sx - cw / 2,
        dy = sy - ch / 2,
        k = z * v.zoom;
      return { x: v.cx + (dx * c - dy * s) / k, y: v.cy + (dx * s + dy * c) / k };
    }
    // screen overlays (fade, flash, transition) drawn over the finished picture
    drawOverlay(x, w, h) {
      if (this.fadeA > 0.002) {
        x.save();
        x.globalAlpha = clamp(this.fadeA, 0, 1);
        x.fillStyle = this.fadeC;
        x.fillRect(0, 0, w, h);
        x.restore();
      }
      const fl = this.flash_;
      if (fl && this.set.flashes && !this.set.reduceMotion) {
        const u = 1 - fl.t / fl.dur;
        x.save();
        x.globalAlpha = clamp(fl.a * u * u, 0, 1);
        x.fillStyle = fl.c;
        x.fillRect(0, 0, w, h);
        x.restore();
      }
      const T = this.trans;
      if (T) {
        const half = T.dur / 2,
          p = T.t < half ? T.t / half : 1 - (T.t - half) / half,
          e = CURVES.smooth(clamp(p, 0, 1));
        x.save();
        x.fillStyle = T.c;
        if (T.kind === 'wipe') x.fillRect(0, 0, w * e, h);
        else if (T.kind === 'slide') x.fillRect(T.t < half ? -w * (1 - e) : w * (1 - e), 0, w, h);
        else if (T.kind === 'dissolve') {
          const B = Math.max(8, Math.round(h / 24));
          for (let by = 0; by * B < h; by++)
            for (let bx = 0; bx * B < w; bx++) {
              const r = Math.abs(Math.sin(bx * 12.9898 + by * 78.233) * 43758.5453) % 1;
              if (r < e) x.fillRect(bx * B, by * B, B, B);
            }
        } else if (T.kind === 'iris') {
          const R = Math.hypot(Math.max(T.fx, 1 - T.fx) * w, Math.max(T.fy, 1 - T.fy) * h) * (1 - e);
          x.beginPath();
          x.rect(0, 0, w, h);
          x.arc(T.fx * w, T.fy * h, Math.max(0, R), 0, Math.PI * 2, true);
          x.fill('evenodd');
        } else {
          x.globalAlpha = e;
          x.fillRect(0, 0, w, h);
        }
        x.restore();
      }
    }
    status() {
      return {
        mode: this.mode_ || 'follow',
        zoom: this.zeff,
        rotation: this.reff,
        overrides: this.overrides(),
        lock: !!this.lock,
        targets: this.targets.length,
        free: !!this.free,
        cutscene: !!this.cs,
        fade: this.fadeA,
        unsupported: this.unsupported
      };
    }
  }
  Rig.prototype.free = null;
  Rig.CURVES = CURVES;
  Rig.curve = curve;
  Rig.MODES = MODES;
  Rig.UNSUPPORTED = UNSUPPORTED;
  Rig.cleanUser = cleanUser;
  return Rig;
})();
