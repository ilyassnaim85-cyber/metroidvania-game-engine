// Player tuning: validates designer overrides against the schema in data/config.js.
window.MV = window.MV || {};
MV.Tuning = (() => {
  const schema = () => MV.data.playerSchema;
  // Clamp to the allowed range; anything that is not a number falls back to the default.
  const clamp = (k, v) => {
    const d = schema()[k];
    v = Number(v);
    return isFinite(v) ? Math.min(d.max, Math.max(d.min, v)) : d.def;
  };
  // Keep only known keys, clamp them, and drop values equal to the default (keeps saved maps small).
  const clean = o => {
    const out = {};
    if (o && typeof o === 'object')
      for (const k in schema()) {
        if (o[k] === undefined || o[k] === null || o[k] === '') continue;
        const v = clamp(k, o[k]);
        if (v !== schema()[k].def) out[k] = v;
      }
    return out;
  };
  // Full, validated tuning for the runtime: body size + defaults + overrides.
  const resolve = o => {
    const r = Object.assign({}, MV.data.player);
    for (const k in schema()) r[k] = schema()[k].def;
    Object.assign(r, clean(o));
    if (r.airTime > 0) r.gravity = Math.min(600, Math.max(5, (8 * r.jumpHeight) / (r.airTime * r.airTime)));
    return r;
  }; // Air time sets gravity: up and down take airTime seconds, so g = 8h / t^2
  return { clamp, clean, resolve, schema };
})();
