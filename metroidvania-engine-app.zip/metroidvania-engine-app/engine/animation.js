// MV.Anim - reusable 2D sprite animation clips: validate, sample, play, draw, import and export.
// It does not depend on the editor or on the rest of the engine, so game code can use it on its own.
// Units: frame durations in clip data are milliseconds; every time you pass to or get from the API is seconds.
(function (root) {
  const MV = (root.MV = root.MV || {});
  const MODES = ['loop', 'once', 'pingpong'];
  const num = (v, a, b, d) =>
    v === null || v === '' || v === undefined || !isFinite(+v) ? d : Math.min(b, Math.max(a, +v));
  const str = (v, d, n) => (typeof v === 'string' ? v.trim().slice(0, n || 40) : d);
  const rid = () => Math.random().toString(36).slice(2, 8);
  const goodId = (v, n) => typeof v === 'string' && /^[\w-]{1,32}$/.test(v) && v.length <= (n || 32);
  const MAX_CLIPS = 100,
    MAX_FRAMES = 256,
    MAX_SHEETS = 60,
    MAX_URL = 15e6;

  // ---------- data ----------
  // A frame is a grid cell of its sheet (col, row), or a free pixel rectangle {x, y, w, h} of any size (a 16x16 first frame, a 10x20 second one...).
  // Frames of different sizes are drawn at the same scale (one pixel of the sheet is the same size on screen) and share the clip's pivot, which is a fraction of each frame's own size.
  const customRect = f => f && f.w > 0 && f.h > 0;
  const rectOf = (f, sh) =>
    customRect(f)
      ? { sx: f.x, sy: f.y, sw: f.w, sh: f.h }
      : { sx: f.col * sh.tw, sy: f.row * sh.th, sw: sh.tw, sh: sh.th };
  const frame = f => {
    f = f || {};
    const o = {
      sheet: str(f.sheet, '', 32),
      col: Math.floor(num(f.col, 0, 1023, 0)),
      row: Math.floor(num(f.row, 0, 1023, 0)),
      dur: Math.round(num(f.dur, 10, 10000, 100)),
      event: str(f.event, '', 24)
    };
    if (f.w > 0 && f.h > 0) {
      o.x = Math.floor(num(f.x, 0, 16384, 0));
      o.y = Math.floor(num(f.y, 0, 16384, 0));
      o.w = Math.floor(num(f.w, 1, 4096, 16));
      o.h = Math.floor(num(f.h, 1, 4096, 16));
    }
    return o;
  };
  const clean = c => {
    c = c || {};
    const pv = c.pivot || {};
    return {
      id: goodId(c.id, 24) ? c.id : 'c' + rid(),
      name: str(c.name, 'Animation'),
      mode: MODES.includes(c.mode) ? c.mode : 'loop',
      speed: num(c.speed, 0.1, 4, 1),
      pivot: { x: num(pv.x, -2, 3, 0.5), y: num(pv.y, -2, 3, 1) },
      frames: (Array.isArray(c.frames) ? c.frames : [])
        .slice(0, MAX_FRAMES)
        .map(frame)
        .filter(f => f.sheet)
    };
  };
  const list = l => {
    const seen = {};
    return (Array.isArray(l) ? l : [])
      .slice(0, MAX_CLIPS)
      .map(clean)
      .map(c => {
        while (seen[c.id]) c.id = 'c' + rid();
        seen[c.id] = 1;
        return c;
      });
  };
  const cleanSheet = s => {
    s = s || {};
    if (
      !goodId(s.id) ||
      typeof s.url !== 'string' ||
      !/^data:image\/(png|gif|webp|jpeg);base64,/.test(s.url) ||
      s.url.length > MAX_URL
    )
      return null;
    return {
      id: s.id,
      name: str(s.name, 'sheet.png'),
      url: s.url,
      tw: Math.floor(num(s.tw, 1, 1024, 16)),
      th: Math.floor(num(s.th, 1, 1024, 16))
    };
  };
  const sheetList = l => (Array.isArray(l) ? l : []).slice(0, MAX_SHEETS).map(cleanSheet).filter(Boolean);
  const find = (clips, key) => (clips || []).find(c => c.id === key) || (clips || []).find(c => c.name === key) || null;

  // ---------- sampling ----------
  // compile() lays the clip out on a time line: the order frames play in (ping pong goes forward then back without repeating the ends).
  function compile(clip) {
    if (clip && clip.seq && clip.clip) return clip;
    const n = clip.frames.length,
      order = [];
    for (let i = 0; i < n; i++) order.push(i);
    if (clip.mode === 'pingpong') for (let i = n - 2; i >= 1; i--) order.push(i);
    let ms = 0;
    const seq = order.map(i => {
      const d = clip.frames[i].dur,
        s = { i, sMs: ms, eMs: ms + d, start: ms / 1000, end: (ms + d) / 1000 };
      ms += d;
      return s;
    }); // whole milliseconds, so frame edges are exact
    return { clip, seq, cycle: ms / 1000, cycleMs: ms, n };
  }
  // The frame showing at time t. loop and pingpong repeat forever; once stops on the last frame and reports done.
  function sample(clip, t) {
    const P = compile(clip),
      c = P.clip;
    if (!P.n) return { index: -1, frame: null, time: 0, cycle: 0, done: true };
    let u = (t > 0 ? t : 0) * 1000 + 1e-6,
      done = false,
      cycle = 0; // milliseconds, nudged so exact edges land on the next frame
    if (c.mode === 'once') {
      if (u >= P.cycleMs) {
        u = P.cycleMs;
        done = true;
      }
    } else {
      cycle = Math.floor(u / P.cycleMs);
      u -= cycle * P.cycleMs;
    }
    let s = P.seq[P.seq.length - 1];
    if (!(done && c.mode === 'once'))
      for (let k = 0; k < P.seq.length; k++)
        if (u < P.seq[k].eMs) {
          s = P.seq[k];
          break;
        }
    return { index: s.i, frame: c.frames[s.i], time: Math.max(0, u / 1000), cycle, done };
  }
  // Event markers fire when their frame starts. Returns every one in (t0, t1], in order. Start from t0 = -1e-9 to include time 0.
  function events(clip, t0, t1) {
    const P = compile(clip),
      out = [],
      c = P.clip;
    if (!P.n || !(t1 > t0)) return out;
    const m0 = t0 < 0 ? -1 : t0 * 1000 + 1e-6,
      m1 = t1 * 1000 + 1e-6; // milliseconds
    const first = Math.max(0, Math.floor(m0 / P.cycleMs)),
      last = c.mode === 'once' ? 0 : Math.min(Math.floor(m1 / P.cycleMs), first + 64);
    for (let k = first; k <= last; k++)
      for (const s of P.seq) {
        const a = k * P.cycleMs + s.sMs,
          ev = c.frames[s.i].event;
        if (ev && a > m0 && a <= m1 && out.length < 256) out.push({ name: ev, frame: s.i, time: a / 1000 });
      }
    return out;
  }

  // ---------- drawing ----------
  // getSheet is a function (or object) id -> { img, tw, th }. (x, y) is where the pivot goes. Returns false if the image is not ready.
  function draw(ctx, clip, s, getSheet, x, y, o) {
    o = o || {};
    const f = s && s.frame;
    if (!f) return false;
    const sh = typeof getSheet === 'function' ? getSheet(f.sheet) : getSheet && getSheet[f.sheet];
    if (!sh || !sh.img || sh.img.complete === false || !(sh.img.naturalWidth || sh.img.width)) return false;
    const k = o.scale || 1,
      R = rectOf(f, sh),
      w = R.sw * k,
      h = R.sh * k;
    ctx.save();
    if (o.alpha !== undefined) ctx.globalAlpha = o.alpha;
    ctx.imageSmoothingEnabled = !!o.smooth;
    ctx.translate(x, y);
    ctx.scale(o.flipX ? -1 : 1, o.flipY ? -1 : 1);
    ctx.drawImage(sh.img, R.sx, R.sy, R.sw, R.sh, -clip.pivot.x * w, -clip.pivot.y * h, w, h);
    ctx.restore();
    return true;
  }

  // ---------- player: keeps its own time, fires events, draws ----------
  function createPlayer(clip, o) {
    o = o || {};
    const p = {
      clip,
      t: 0,
      speed: 1,
      paused: false,
      done: false,
      onEvent: o.onEvent || null,
      library: o.library || null,
      _last: -1e-9
    };
    p.reset = () => {
      p.t = 0;
      p._last = -1e-9;
      p.done = false;
      return p;
    };
    // play(clipOrNameOrId, { restart: false }) switches clips; asking for the clip that is already playing does nothing when restart is false.
    p.play = (c, opt) => {
      const next = typeof c === 'string' ? (p.library ? p.library.get(c) : null) : c;
      if (!next) return p;
      if (next === p.clip && opt && opt.restart === false) return p;
      p.clip = next;
      return p.reset();
    };
    p.update = dt => {
      if (p.paused || p.done || !p.clip) return p;
      const a = p._last;
      p.t += dt * p.speed * p.clip.speed;
      p._last = p.t;
      if (p.onEvent) events(p.clip, a, p.t).forEach(e => p.onEvent(e.name, e));
      if (p.clip.mode === 'once' && sample(p.clip, p.t).done) p.done = true;
      return p;
    };
    p.sample = () => sample(p.clip, p.t);
    p.draw = (ctx, getSheet, x, y, opt) =>
      draw(ctx, p.clip, p.sample(), getSheet || (p.library && p.library.sheet), x, y, opt);
    return p;
  }

  // ---------- JSON: individual clips and whole libraries, with their sprite sheets ----------
  const used = (project, clips) => {
    const ids = new Set();
    clips.forEach(c => c.frames.forEach(f => ids.add(f.sheet)));
    return (project.sheets || [])
      .filter(s => ids.has(s.id))
      .map(s => ({ id: s.id, name: s.name, url: s.url, tw: s.tw, th: s.th }));
  };
  const exportClip = (project, key) => {
    const c = find(project.anims, key);
    if (!c) throw new Error('No such animation: ' + key);
    return { type: 'mv-animation-clip', version: 1, clip: c, sheets: used(project, [c]) };
  };
  const exportLibrary = (project, keys) => {
    const clips = keys ? keys.map(k => find(project.anims, k)).filter(Boolean) : project.anims || [];
    return { type: 'mv-animation-library', version: 1, clips, sheets: used(project, clips) };
  };
  // Reads a clip file, a library file, or a whole project file.
  function parse(json) {
    if (!json || typeof json !== 'object') throw new Error('This is not an animation file.');
    let clips, sheets;
    if (json.type === 'mv-animation-clip' && json.clip) {
      clips = [json.clip];
      sheets = json.sheets;
    } else if (json.type === 'mv-animation-library' && Array.isArray(json.clips)) {
      clips = json.clips;
      sheets = json.sheets;
    } else if (Array.isArray(json.anims)) {
      clips = json.anims;
      sheets = json.sheets;
    } else throw new Error('This is not an animation clip or library file.');
    return { clips: list(clips), sheets: sheetList(sheets) };
  }
  // Adds the file's clips and sheets to project ({ sheets, anims }). Sheets that are already there (same image) are reused,
  // ids and names that clash are renamed, and frames whose sheet is missing from the file are dropped.
  function importInto(project, json) {
    const r = parse(json);
    project.sheets = project.sheets || [];
    project.anims = project.anims || [];
    if (project.anims.length + r.clips.length > MAX_CLIPS)
      throw new Error('Too many animations (the limit is ' + MAX_CLIPS + ').');
    const idmap = {};
    let sheetsAdded = 0;
    r.sheets.forEach(s => {
      const same = project.sheets.find(x => x.url === s.url);
      if (same) {
        idmap[s.id] = same.id;
        return;
      }
      let id = s.id;
      while (project.sheets.some(x => x.id === id)) id = 's' + rid();
      idmap[s.id] = id;
      project.sheets.push({ id, name: s.name, url: s.url, tw: s.tw, th: s.th });
      sheetsAdded++;
    });
    const added = [];
    r.clips.forEach(c => {
      c.frames = c.frames
        .map(f => Object.assign({}, f, { sheet: idmap[f.sheet] || f.sheet }))
        .filter(f => project.sheets.some(s => s.id === f.sheet));
      while (project.anims.some(x => x.id === c.id)) c.id = 'c' + rid();
      const base = c.name;
      let n = 2;
      while (project.anims.some(x => x.name === c.name)) c.name = (base + ' ' + n++).slice(0, 40);
      project.anims.push(c);
      added.push(c);
    });
    return { clips: added.length, sheets: sheetsAdded, added };
  }

  // ---------- library: load a file once, then play clips by name ----------
  function loadImages(sheets) {
    const map = {};
    const ps = sheets.map(
      s =>
        new Promise(res => {
          const img = new root.Image();
          img.onload = img.onerror = () => res();
          img.src = s.url;
          map[s.id] = { img, tw: s.tw, th: s.th };
        })
    );
    return { map, ready: Promise.all(ps) };
  }
  class Library {
    constructor(json) {
      this.clips = [];
      this.sheets = [];
      this.map = {};
      this.ready = Promise.resolve();
      this.sheet = id => this.map[id] || null;
      if (json) this.load(json);
    }
    load(json) {
      const r = parse(json);
      this.clips = r.clips;
      this.sheets = r.sheets;
      if (root.Image) {
        const l = loadImages(r.sheets);
        this.map = l.map;
        this.ready = l.ready;
      }
      return this;
    }
    get(key) {
      return find(this.clips, key);
    }
    names() {
      return this.clips.map(c => c.name);
    }
    player(key, o) {
      const c = this.get(key);
      if (!c) throw new Error('No such animation: ' + key);
      return createPlayer(c, Object.assign({ library: this }, o));
    }
  }

  MV.Anim = {
    rectOf,
    customRect,
    MODES,
    clean,
    list,
    find,
    compile,
    sample,
    events,
    draw,
    createPlayer,
    exportClip,
    exportLibrary,
    parse,
    importInto,
    loadImages,
    Library,
    cleanSheet,
    sheetList
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = MV.Anim;
})(typeof window !== 'undefined' ? window : globalThis);
