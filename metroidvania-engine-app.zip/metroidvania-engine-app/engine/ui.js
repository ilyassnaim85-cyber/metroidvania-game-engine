// MV.UI - how the game screen looks: health, energy, counters, messages, the boss bar, the death screen and the title screen of an exported game.
// Used by the game (every frame) and by the UI tab preview, so what you see in the tab is what the game draws.
window.MV = window.MV || {};
MV.UI = (() => {
  const CORNERS = ['top-left', 'top-right', 'bottom-left', 'bottom-right'];
  const FONTS = {
    sans: 'system-ui,sans-serif',
    serif: 'Georgia,"Times New Roman",serif',
    mono: 'ui-monospace,Consolas,monospace'
  };
  const YN = ['yes', 'no'];
  // g = group in the editor. Every field has a default, a range or a list, and a help line.
  const FIELDS = {
    // ----- health
    hpShow: {
      g: 'Health',
      t: 'select',
      def: 'yes',
      o: YN,
      label: 'Show health',
      help: 'The health squares, hearts or bar.'
    },
    hpStyle: {
      g: 'Health',
      t: 'select',
      def: 'squares',
      o: ['squares', 'hearts', 'bar'],
      label: 'Health style',
      help: 'Squares or hearts: one per health point. Bar: one bar that shrinks.'
    },
    hpColor: { g: 'Health', t: 'color', def: '#e24b4a', label: 'Health colour', help: 'Full points.' },
    hpEmpty: { g: 'Health', t: 'color', def: '#3a3f4d', label: 'Empty colour', help: 'Points you have lost.' },
    heartFull: {
      g: 'Health',
      t: 'sprite',
      def: null,
      label: 'Picture: full point',
      help: 'Your own sprite for each health point you have, instead of a square or heart. It is drawn at the size set here.'
    },
    heartEmpty: {
      g: 'Health',
      t: 'sprite',
      def: null,
      label: 'Picture: lost point',
      help: 'Your own sprite for each health point you lost. Empty = a lost point is not drawn.'
    },
    hpSize: {
      g: 'Health',
      t: 'number',
      def: 14,
      min: 6,
      max: 40,
      step: 1,
      label: 'Size (pixels)',
      help: 'Width of one point (the height of a bar).'
    },
    hpGap: {
      g: 'Health',
      t: 'number',
      def: 4,
      min: 0,
      max: 16,
      step: 1,
      label: 'Gap (pixels)',
      help: 'Space between points.'
    },
    hpCorner: {
      g: 'Health',
      t: 'select',
      def: 'top-left',
      o: CORNERS,
      label: 'Corner',
      help: 'Which corner health and energy sit in.'
    },
    margin: {
      g: 'Health',
      t: 'number',
      def: 8,
      min: 0,
      max: 80,
      step: 1,
      label: 'Distance from the edge',
      help: 'Pixels between the corner and the first row.'
    },
    // ----- energy
    mpShow: {
      g: 'Energy',
      t: 'select',
      def: 'yes',
      o: YN,
      label: 'Show energy',
      help: 'Only shows when the player has an energy maximum (Settings).'
    },
    mpColor: { g: 'Energy', t: 'color', def: '#5aa9ff', label: 'Energy colour', help: 'The filled part of the bar.' },
    mpEmpty: { g: 'Energy', t: 'color', def: '#10141c', label: 'Bar background', help: 'Behind the bar.' },
    mpFill: {
      g: 'Energy',
      t: 'sprite',
      def: null,
      label: 'Picture: filled part',
      help: 'A sprite stretched over the whole bar and cut off where the energy ends.'
    },
    mpBack: {
      g: 'Energy',
      t: 'sprite',
      def: null,
      label: 'Picture: bar background',
      help: 'A sprite stretched behind the bar (a frame, for example).'
    },
    mpWidth: {
      g: 'Energy',
      t: 'number',
      def: 200,
      min: 40,
      max: 400,
      step: 10,
      label: 'Longest bar (pixels)',
      help: 'A bigger maximum makes a longer bar, up to this.'
    },
    mpHeight: { g: 'Energy', t: 'number', def: 8, min: 4, max: 24, step: 1, label: 'Bar height (pixels)', help: '' },
    // ----- text and counters
    font: {
      g: 'Text',
      t: 'select',
      def: 'sans',
      o: Object.keys(FONTS),
      names: { sans: 'Sans-serif', serif: 'Serif', mono: 'Monospace' },
      label: 'Font',
      help: 'For every text on the screen. Fonts you add under Fonts (in this tab) are listed too.'
    },
    size: {
      g: 'Text',
      t: 'number',
      def: 14,
      min: 10,
      max: 32,
      step: 1,
      label: 'Text size',
      help: 'The line under your health, and messages.'
    },
    color: { g: 'Text', t: 'color', def: '#ffffff', label: 'Text colour', help: '' },
    shadow: {
      g: 'Text',
      t: 'select',
      def: 'no',
      o: YN,
      label: 'Dark outline on text',
      help: 'Easier to read on bright rooms.'
    },
    showRoom: { g: 'Text', t: 'select', def: 'yes', o: YN, label: 'Show the room name', help: '' },
    showCoins: { g: 'Text', t: 'select', def: 'yes', o: YN, label: 'Show coins', help: '' },
    coinIcon: {
      g: 'Text',
      t: 'sprite',
      def: null,
      label: 'Picture: coin icon',
      help: 'A small sprite shown in front of the coin number. With a picture, the label is not written.'
    },
    coinsLabel: { g: 'Text', t: 'text', def: 'Coins', label: 'Coins label', help: 'For example Gold or Shells.' },
    showAbilities: {
      g: 'Text',
      t: 'select',
      def: 'yes',
      o: YN,
      label: 'Show the ability list',
      help: 'Useful while you build. Turn it off for the finished game.'
    },
    showWeapon: { g: 'Text', t: 'select', def: 'yes', o: YN, label: 'Show the weapon', help: '' },
    statusShow: {
      g: 'Health',
      t: 'select',
      def: 'yes',
      o: YN,
      label: 'Show status effects',
      help: 'A coloured tag with the seconds left while you are poisoned, burning or slowed.'
    },
    hudItems: {
      g: 'Text',
      t: 'text',
      def: '',
      label: 'Items shown on the screen',
      help: 'Item ids separated by commas, for example potion, redkey. Each shows its name and how many you carry (hidden when you have none).'
    },
    // ----- minimap
    mapShow: {
      g: 'Minimap',
      t: 'select',
      def: 'no',
      o: YN,
      label: 'Show a minimap',
      help: 'The rooms of the current area you have been in, with a dot where you are.'
    },
    mapAll: {
      g: 'Minimap',
      t: 'select',
      def: 'no',
      o: YN,
      label: 'Also show rooms you have not visited',
      help: 'Shown as faint outlines, so the player can see how big the area is.'
    },
    mapCorner: {
      g: 'Minimap',
      t: 'select',
      def: 'top-right',
      o: CORNERS,
      label: 'Corner',
      help: 'Pick a different corner than health if both are on.'
    },
    mapW: { g: 'Minimap', t: 'number', def: 150, min: 60, max: 400, step: 10, label: 'Width (pixels)', help: '' },
    mapH: { g: 'Minimap', t: 'number', def: 90, min: 40, max: 300, step: 10, label: 'Height (pixels)', help: '' },
    mapAlpha: { g: 'Minimap', t: 'number', def: 0.75, min: 0.2, max: 1, step: 0.05, label: 'Opacity', help: '' },
    mapBg: { g: 'Minimap', t: 'color', def: '#0b1620', label: 'Background colour', help: '' },
    mapRoom: { g: 'Minimap', t: 'color', def: '#4d7a96', label: 'Room colour', help: 'Rooms you have been in.' },
    mapHere: { g: 'Minimap', t: 'color', def: '#5dcaa5', label: 'Current room colour', help: '' },
    mapDot: { g: 'Minimap', t: 'color', def: '#ffd24a', label: 'Player dot colour', help: '' },
    // ----- the full-screen map (M, or Map in the pause menu)
    mapScreen: {
      g: 'Map screen',
      t: 'select',
      def: 'yes',
      o: YN,
      label: 'Map screen',
      help: 'Press M (or choose Map in the pause menu) to see every area you have visited, with markers. Left and Right change area.'
    },
    mapTitle: { g: 'Map screen', t: 'text', req: 1, def: 'Map', label: 'Title', help: '' },
    pauseMap: { g: 'Map screen', t: 'text', req: 1, def: 'Map', label: 'Pause menu button', help: '' },
    mapMarks: {
      g: 'Map screen',
      t: 'select',
      def: 'yes',
      o: YN,
      label: 'Markers',
      help: 'Rest points, bosses and items you have not picked up yet, in rooms you have visited.'
    },
    mapPanel: { g: 'Map screen', t: 'color', def: '#0a1620', label: 'Background colour', help: '' },
    mapOutline: { g: 'Map screen', t: 'color', def: '#8fb4cc', label: 'Room outline colour', help: '' },
    mapRestC: { g: 'Map screen', t: 'color', def: '#5dcaa5', label: 'Rest point marker', help: '' },
    mapBossC: { g: 'Map screen', t: 'color', def: '#e24b4a', label: 'Boss marker', help: '' },
    mapItemC: { g: 'Map screen', t: 'color', def: '#ef9f27', label: 'Item marker', help: '' },
    // ----- the shop (a character with items for sale)
    shopTitle: {
      g: 'Shop',
      t: 'text',
      req: 1,
      def: 'Shop',
      label: 'Title',
      help: 'Set what a character sells in its Shop setting (Entities > Character).'
    },
    shopCoins: { g: 'Shop', t: 'text', req: 1, def: 'Coins', label: 'Coins label', help: '' },
    shopOwned: { g: 'Shop', t: 'text', req: 1, def: 'owned', label: 'Owned label', help: '' },
    shopNoCoins: { g: 'Shop', t: 'text', req: 1, def: 'Not enough coins', label: 'Message: too poor', help: '' },
    shopFull: { g: 'Shop', t: 'text', req: 1, def: 'You cannot carry more', label: 'Message: bag full', help: '' },
    shopPanel: { g: 'Shop', t: 'color', def: '#10202e', label: 'Panel colour', help: '' },
    // ----- messages
    msgColor: {
      g: 'Messages',
      t: 'color',
      def: '#ffffff',
      label: 'Message colour',
      help: 'The short messages such as "Got Potion".'
    },
    msgSize: { g: 'Messages', t: 'number', def: 14, min: 10, max: 32, step: 1, label: 'Message size', help: '' },
    msgY: {
      g: 'Messages',
      t: 'number',
      def: 30,
      min: 0,
      max: 400,
      step: 2,
      label: 'Message height (pixels from the top)',
      help: ''
    },
    msgTime: {
      g: 'Messages',
      t: 'number',
      def: 2.5,
      min: 0.5,
      max: 10,
      step: 0.5,
      label: 'Seconds on screen',
      help: ''
    },
    // ----- boss bar
    bossColor: { g: 'Boss bar', t: 'color', def: '#e24b4a', label: 'Bar colour', help: '' },
    bossSafe: {
      g: 'Boss bar',
      t: 'color',
      def: '#b4b2a9',
      label: 'Colour while it cannot be hurt',
      help: 'Waking up and changing phase.'
    },
    bossBack: { g: 'Boss bar', t: 'color', def: '#000000', label: 'Background colour', help: '' },
    bossFillImg: {
      g: 'Boss bar',
      t: 'sprite',
      def: null,
      label: 'Picture: filled part',
      help: 'A sprite stretched over the whole bar and cut off where the boss health ends.'
    },
    bossBackImg: {
      g: 'Boss bar',
      t: 'sprite',
      def: null,
      label: 'Picture: bar background',
      help: 'A sprite stretched behind the boss bar.'
    },
    bossWidth: {
      g: 'Boss bar',
      t: 'number',
      def: 60,
      min: 20,
      max: 95,
      step: 5,
      label: 'Width (% of the screen)',
      help: ''
    },
    bossHeight: { g: 'Boss bar', t: 'number', def: 12, min: 4, max: 40, step: 1, label: 'Height (pixels)', help: '' },
    bossY: {
      g: 'Boss bar',
      t: 'number',
      def: 56,
      min: 10,
      max: 400,
      step: 2,
      label: 'Height from the top (pixels)',
      help: ''
    },
    bossName: { g: 'Boss bar', t: 'select', def: 'yes', o: YN, label: 'Show the boss name', help: '' },
    bossTicks: {
      g: 'Boss bar',
      t: 'select',
      def: 'yes',
      o: YN,
      label: 'Show phase marks',
      help: 'A small line where the next phase starts.'
    },
    // ----- death screen
    deathText: { g: 'Death screen', t: 'text', def: 'YOU DIED', label: 'Text', help: 'Shown when the player dies.' },
    deathColor: { g: 'Death screen', t: 'color', def: '#e24b4a', label: 'Colour', help: '' },
    deathSize: { g: 'Death screen', t: 'number', def: 40, min: 16, max: 120, step: 2, label: 'Size', help: '' },
    // ----- title screen (exported game)
    titleText: {
      g: 'Title screen',
      t: 'text',
      def: '',
      label: 'Title',
      help: 'Empty = the project name. Used by the exported game.'
    },
    subtitle: {
      g: 'Title screen',
      t: 'text',
      def: '',
      label: 'Subtitle',
      help: 'A line under the title in the exported game.'
    },
    titleBg: { g: 'Title screen', t: 'color', def: '#0b1620', label: 'Background colour', help: '' },
    titleColor: { g: 'Title screen', t: 'color', def: '#ffffff', label: 'Text colour', help: '' },
    titleAccent: { g: 'Title screen', t: 'color', def: '#5dcaa5', label: 'Button outline colour', help: '' },
    menuBg: {
      g: 'Title screen',
      t: 'sprite',
      def: null,
      label: 'Picture: background',
      help: 'A sprite stretched over the whole title screen (drawn over the background colour).'
    },
    menuLogo: {
      g: 'Title screen',
      t: 'sprite',
      def: null,
      label: 'Picture: logo',
      help: 'A sprite shown instead of the title text.'
    },
    footer: {
      g: 'Title screen',
      t: 'text',
      def: '',
      label: 'Footer line',
      help: 'A small line at the bottom, for example a version or a copyright.'
    },
    logoH: {
      g: 'Title screen',
      t: 'number',
      def: 110,
      min: 30,
      max: 260,
      step: 5,
      label: 'Logo height (pixels)',
      help: 'The logo keeps its shape.'
    },
    titleStart: {
      g: 'Menu buttons',
      t: 'text',
      req: 1,
      def: 'New game',
      label: 'Text: new game',
      help: 'The title screen button that starts over.'
    },
    titleContinue: {
      g: 'Menu buttons',
      t: 'text',
      req: 1,
      def: 'Continue',
      label: 'Text: continue',
      help: 'Shown when there is a saved game.'
    },
    titleFull: { g: 'Menu buttons', t: 'text', req: 1, def: 'Full screen', label: 'Text: full screen', help: '' },
    titleQuit: {
      g: 'Menu buttons',
      t: 'text',
      req: 1,
      def: 'Quit',
      label: 'Text: quit',
      help: 'Shown in the PC game only.'
    },
    menuAlign: {
      g: 'Menu buttons',
      t: 'select',
      def: 'center',
      o: ['center', 'left'],
      label: 'Alignment',
      help: 'Buttons and title in the middle, or on the left side of the screen.'
    },
    menuY: {
      g: 'Menu buttons',
      t: 'number',
      def: 48,
      min: 25,
      max: 85,
      step: 1,
      label: 'First button height (% of the screen)',
      help: ''
    },
    btnW: {
      g: 'Menu buttons',
      t: 'number',
      def: 240,
      min: 100,
      max: 500,
      step: 10,
      label: 'Button width (pixels)',
      help: ''
    },
    btnH: {
      g: 'Menu buttons',
      t: 'number',
      def: 40,
      min: 20,
      max: 90,
      step: 2,
      label: 'Button height (pixels)',
      help: ''
    },
    btnGap: {
      g: 'Menu buttons',
      t: 'number',
      def: 10,
      min: 0,
      max: 40,
      step: 1,
      label: 'Gap between buttons',
      help: ''
    },
    btnFont: {
      g: 'Menu buttons',
      t: 'number',
      def: 18,
      min: 10,
      max: 40,
      step: 1,
      label: 'Button text size',
      help: ''
    },
    btnColor: { g: 'Menu buttons', t: 'color', def: '#ffffff', label: 'Button text colour', help: '' },
    btnBg: {
      g: 'Menu buttons',
      t: 'color',
      def: '#17293a',
      label: 'Button colour',
      help: 'Used when there is no button picture.'
    },
    btnSel: {
      g: 'Menu buttons',
      t: 'color',
      def: '#2a5675',
      label: 'Chosen button colour',
      help: 'The button the cursor is on.'
    },
    btnImg: {
      g: 'Menu buttons',
      t: 'sprite',
      def: null,
      label: 'Picture: button',
      help: 'A sprite stretched to each button.'
    },
    btnImgSel: {
      g: 'Menu buttons',
      t: 'sprite',
      def: null,
      label: 'Picture: chosen button',
      help: 'A sprite for the button the cursor is on. Empty = the normal button picture.'
    },
    btnSlice: {
      g: 'Menu buttons',
      t: 'number',
      def: 0,
      min: 0,
      max: 32,
      step: 1,
      label: 'Picture border size (pixels of the picture)',
      help: '0 = the button picture is stretched. Above 0 = a nine-slice: the corners of this size keep their shape and only the edges and the middle stretch, so a framed button does not look squashed.'
    },
    btnScale: {
      g: 'Menu buttons',
      t: 'number',
      def: 2,
      min: 1,
      max: 6,
      step: 1,
      label: 'Border scale',
      help: 'How many screen pixels one picture pixel of the border takes (with a border size above 0).'
    },
    cursor: {
      g: 'Menu buttons',
      t: 'sprite',
      def: null,
      label: 'Picture: cursor',
      help: 'A small sprite shown beside the chosen button.'
    },
    pauseOn: {
      g: 'Pause menu',
      t: 'select',
      def: 'yes',
      o: YN,
      label: 'Esc opens a pause menu',
      help: 'Resume, Inventory and (in the PC game) Quit to title.'
    },
    pauseTitle: { g: 'Pause menu', t: 'text', req: 1, def: 'Paused', label: 'Title', help: '' },
    pauseResume: { g: 'Pause menu', t: 'text', req: 1, def: 'Resume', label: 'Text: resume', help: '' },
    pauseInv: { g: 'Pause menu', t: 'text', req: 1, def: 'Inventory', label: 'Text: inventory', help: '' },
    pauseQuit: {
      g: 'Pause menu',
      t: 'text',
      req: 1,
      def: 'Quit to title',
      label: 'Text: quit to title',
      help: 'Shown in the PC game and the web page only.'
    },
    optionsOn: {
      g: 'Options screen',
      t: 'select',
      def: 'yes',
      o: YN,
      label: 'Show an Options button',
      help: 'On the title screen and in the pause menu: volume sliders and full screen.'
    },
    optionsLabel: { g: 'Options screen', t: 'text', req: 1, def: 'Options', label: 'Button text', help: '' },
    optTitle: { g: 'Options screen', t: 'text', req: 1, def: 'Options', label: 'Title', help: '' },
    optMaster: { g: 'Options screen', t: 'text', req: 1, def: 'Master volume', label: 'Text: master volume', help: '' },
    optMusic: { g: 'Options screen', t: 'text', req: 1, def: 'Music volume', label: 'Text: music volume', help: '' },
    optSfx: { g: 'Options screen', t: 'text', req: 1, def: 'Effects volume', label: 'Text: effects volume', help: '' },
    optFull: {
      g: 'Options screen',
      t: 'text',
      req: 1,
      def: 'Full screen',
      label: 'Text: full screen',
      help: 'Shown in the PC game and the web page only.'
    },
    optControls: {
      g: 'Options screen',
      t: 'text',
      req: 1,
      def: 'Controls',
      label: 'Text: controls button',
      help: 'Opens the page where the player picks other keys.'
    },
    optKeys: {
      g: 'Options screen',
      t: 'text',
      req: 1,
      def: 'Move left, Move right, Up, Down, Jump',
      label: 'Text: the five actions',
      help: 'The names of Left, Right, Up, Down and Jump on the controls page, separated by commas.'
    },
    optReset: { g: 'Options screen', t: 'text', req: 1, def: 'Reset keys', label: 'Text: reset keys', help: '' },
    optPress: {
      g: 'Options screen',
      t: 'text',
      req: 1,
      def: 'Press a key...',
      label: 'Text: waiting for a key',
      help: ''
    },
    optBack: { g: 'Options screen', t: 'text', req: 1, def: 'Back', label: 'Text: back', help: '' },
    pauseDim: {
      g: 'Pause menu',
      t: 'number',
      def: 0.6,
      min: 0,
      max: 1,
      step: 0.05,
      label: 'Darkness behind the menu',
      help: ''
    }
  };
  const col = (v, d) => (typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v) ? v.toLowerCase() : d);
  const def = () => {
    const o = {};
    for (const k in FIELDS) o[k] = FIELDS[k].def;
    return o;
  };
  const clean = o => {
    o = o && typeof o === 'object' ? o : {};
    const out = {};
    for (const k in FIELDS) {
      const f = FIELDS[k],
        v = o[k];
      if (f.t === 'sprite') out[k] = MV.Attacks && MV.Attacks.anim ? MV.Attacks.anim(v) : null;
      else if (f.t === 'color') out[k] = col(v, f.def);
      else if (k === 'font')
        out[k] = f.o.includes(v) || (typeof v === 'string' && /^f:[\w-]{1,24}$/.test(v)) ? v : f.def;
      else if (f.t === 'select') out[k] = f.o.includes(v) ? v : f.def;
      else if (f.t === 'number') {
        const n = v === null || v === '' || v === undefined ? NaN : +v;
        out[k] = isFinite(n) ? Math.min(f.max, Math.max(f.min, Math.round(n * 100) / 100)) : f.def;
      } else if (k === 'hudItems')
        out[k] = (typeof v === 'string' ? v : '')
          .split(',')
          .map(s => s.trim())
          .filter(s => /^[\w-]{1,24}$/.test(s))
          .slice(0, 6)
          .join(', ');
      else
        out[k] =
          typeof v === 'string'
            ? v.trim().slice(0, k === 'subtitle' ? 80 : 40) ||
              (f.req || k === 'coinsLabel' || k === 'deathText' ? f.def : '')
            : f.def;
    }
    return out;
  };
  // One frame of a sprite stretched to a box; false when it has no picture (or the sheet is not loaded yet)
  function spr(x, ic, getSheet, time, X, Y, W, H) {
    if (!ic || !getSheet) return false;
    const sh = getSheet(ic.sheet);
    if (!sh || !sh.img || !sh.img.complete || !sh.img.naturalWidth) return false;
    const cols = Math.max(1, Math.floor(sh.img.naturalWidth / sh.tw)),
      t = time || 0,
      f = ic.loop ? Math.floor(t * ic.fps) % ic.frames : Math.min(ic.frames - 1, Math.floor(t * ic.fps)),
      i = ic.row * cols + ic.col + f;
    x.save();
    x.imageSmoothingEnabled = false;
    x.drawImage(sh.img, (i % cols) * sh.tw, Math.floor(i / cols) * sh.th, sh.tw, sh.th, X, Y, W, H);
    x.restore();
    return true;
  }
  // A nine-slice: the corners (slice source pixels, drawn at scale) keep their shape, the edges and the middle stretch.
  function spr9(x, ic, getSheet, time, X, Y, W, H, slice, scale) {
    if (!(slice > 0)) return spr(x, ic, getSheet, time, X, Y, W, H);
    if (!ic || !getSheet) return false;
    const sh = getSheet(ic.sheet);
    if (!sh || !sh.img || !sh.img.complete || !sh.img.naturalWidth) return false;
    const cols = Math.max(1, Math.floor(sh.img.naturalWidth / sh.tw)),
      t = time || 0,
      f = ic.loop ? Math.floor(t * ic.fps) % ic.frames : Math.min(ic.frames - 1, Math.floor(t * ic.fps)),
      i = ic.row * cols + ic.col + f,
      sx = (i % cols) * sh.tw,
      sy = Math.floor(i / cols) * sh.th,
      c = Math.min(slice, Math.floor(sh.tw / 2) - 0, Math.floor(sh.th / 2)),
      d = Math.min(c * scale, W / 2, H / 2),
      xs = [0, c, sh.tw - c, sh.tw],
      ys = [0, c, sh.th - c, sh.th],
      xd = [0, d, W - d, W],
      yd = [0, d, H - d, H];
    x.save();
    x.imageSmoothingEnabled = false;
    for (let r = 0; r < 3; r++)
      for (let q = 0; q < 3; q++) {
        const w0 = xs[q + 1] - xs[q],
          h0 = ys[r + 1] - ys[r];
        if (w0 > 0 && h0 > 0)
          x.drawImage(
            sh.img,
            sx + xs[q],
            sy + ys[r],
            w0,
            h0,
            X + xd[q],
            Y + yd[r],
            xd[q + 1] - xd[q],
            yd[r + 1] - yd[r]
          );
      }
    x.restore();
    return true;
  }
  // the font family of the settings: one of the three built-in ones, or a font file of the project ("f:id")
  const family = U =>
    /^f:/.test(U.font) ? '"mvf-' + U.font.slice(2) + '",' + FONTS.sans : FONTS[U.font] || FONTS.sans;
  const font = (U, px, bold) => (bold ? 'bold ' : '') + px + 'px ' + family(U);
  // Fonts of the project: [{ id, name, url }] with the file inside as a data address. At most 4, 450 KB each.
  const MAXFONT = 450000;
  const cleanFonts = list => {
    const seen = {};
    return (Array.isArray(list) ? list : [])
      .slice(0, 4)
      .map(f => ({
        id: f && typeof f.id === 'string' && /^[\w-]{1,24}$/.test(f.id) ? f.id : '',
        name: f && typeof f.name === 'string' ? f.name.trim().slice(0, 40) : '',
        url:
          f &&
          typeof f.url === 'string' &&
          f.url.length <= MAXFONT * 1.4 &&
          /^data:font\/(ttf|otf|woff|woff2);base64,[A-Za-z0-9+/=]+$/.test(f.url)
            ? f.url
            : ''
      }))
      .filter(f => f.id && f.url && !seen[f.id] && (seen[f.id] = 1))
      .map(f => ({ id: f.id, name: f.name || f.id, url: f.url }));
  };
  const loaded = {};
  // Makes the fonts usable by the page (async; the screens use the fallback font until each one has loaded).
  function loadFonts(list) {
    if (typeof FontFace === 'undefined' || typeof document === 'undefined' || !document.fonts) return Promise.resolve();
    return Promise.all(
      cleanFonts(list).map(f => {
        if (loaded[f.id] === f.url) return null;
        loaded[f.id] = f.url;
        return new FontFace('mvf-' + f.id, 'url(' + f.url + ')')
          .load()
          .then(ff => document.fonts.add(ff))
          .catch(() => {
            loaded[f.id] = '';
          });
      })
    );
  }
  const text = (x, U, s, X, Y) => {
    if (U.shadow === 'yes') {
      x.save();
      x.lineJoin = 'round';
      x.lineWidth = 3;
      x.strokeStyle = 'rgba(0,0,0,.85)';
      x.strokeText(s, X, Y);
      x.restore();
    }
    x.fillText(s, X, Y);
  };
  const heart = (x, cx, cy, s) => {
    // a heart that fits a square of side s, centred on cx, cy
    const r = s * 0.27;
    x.beginPath();
    x.arc(cx - r, cy - r * 0.5, r, Math.PI, 0);
    x.arc(cx + r, cy - r * 0.5, r, Math.PI, 0);
    x.lineTo(cx, cy + s * 0.45);
    x.closePath();
    x.fill();
  };
  // The HUD. st = { hp, maxHp, mp, mpMax, mpFlash, room, coins, abilities: [], weapon, items: [{ name, count }] }
  function hud(x, cw, ch, U, st, getSheet, time) {
    const top = U.hpCorner.startsWith('top'),
      left = U.hpCorner.endsWith('left'),
      M = U.margin;
    x.save();
    x.textBaseline = 'top';
    x.textAlign = left ? 'left' : 'right';
    x.font = font(U, U.size);
    x.fillStyle = U.color;
    // the rows, top to bottom as they are read; a bottom corner stacks them upward
    const rows = [];
    const info = [];
    if (U.showRoom === 'yes' && st.room) info.push(st.room);
    if (U.showCoins === 'yes' && !U.coinIcon) info.push(U.coinsLabel + ': ' + st.coins);
    if (U.showAbilities === 'yes') info.push('Abilities: ' + (st.abilities.length ? st.abilities.join(', ') : 'none'));
    if (U.showWeapon === 'yes' && st.weapon) info.push('Weapon: ' + st.weapon);
    if (info.length) rows.push({ h: Math.ceil(U.size * 1.3), draw: (X, Y) => text(x, U, info.join('   '), X, Y) });
    if (U.showCoins === 'yes' && U.coinIcon) {
      const isz = Math.round(U.size * 1.3);
      rows.push({
        h: isz + 2,
        draw: (X, Y) => {
          const num = String(st.coins);
          x.textBaseline = 'middle';
          if (left) {
            spr(x, U.coinIcon, getSheet, time, X, Y, isz, isz);
            text(x, U, num, X + isz + 4, Y + isz / 2);
          } else {
            spr(x, U.coinIcon, getSheet, time, X - isz, Y, isz, isz);
            text(x, U, num, X - isz - 4, Y + isz / 2);
          }
        }
      });
    }
    if (U.hpShow === 'yes' && st.maxHp > 0) {
      const mx = st.maxHp,
        big = mx > 12,
        sz = U.hpStyle === 'bar' ? U.hpSize : big ? Math.max(6, Math.round(U.hpSize * 0.65)) : U.hpSize,
        gap = U.hpGap;
      const w = U.hpStyle === 'bar' ? Math.min(cw - 2 * M, 40 + mx * 6 + 60) : mx * (sz + gap) - gap;
      rows.push({
        h: sz + 6,
        draw: (X, Y) => {
          const x0 = left ? X : X - w;
          if (U.hpStyle === 'bar') {
            x.fillStyle = U.hpEmpty;
            x.fillRect(x0, Y, w, sz);
            x.fillStyle = U.hpColor;
            x.fillRect(x0, Y, w * Math.max(0, Math.min(1, st.hp / mx)), sz);
            x.strokeStyle = 'rgba(255,255,255,.5)';
            x.lineWidth = 1;
            x.strokeRect(x0 + 0.5, Y + 0.5, w - 1, sz - 1);
          } else
            for (let i = 0; i < mx; i++) {
              const ic = i < st.hp ? U.heartFull : U.heartEmpty;
              if ((U.heartFull || U.heartEmpty) && spr(x, ic, getSheet, time, x0 + i * (sz + gap), Y, sz, sz)) continue;
              if ((U.heartFull || U.heartEmpty) && !ic) continue; // no picture for a lost point: nothing is drawn
              x.fillStyle = i < st.hp ? U.hpColor : U.hpEmpty;
              if (U.hpStyle === 'hearts') heart(x, x0 + i * (sz + gap) + sz / 2, Y + sz / 2, sz * 1.15);
              else x.fillRect(x0 + i * (sz + gap), Y, sz, sz);
            }
        }
      });
    }
    if (U.mpShow === 'yes' && st.mpMax > 0) {
      const w = Math.min(U.mpWidth, 40 + st.mpMax * 2),
        f = Math.max(0, Math.min(1, st.mp / st.mpMax)),
        hh = U.mpHeight;
      rows.push({
        h: hh + 6,
        draw: (X, Y) => {
          const x0 = left ? X : X - w;
          const pic = U.mpFill || U.mpBack;
          if (!spr(x, U.mpBack, getSheet, time, x0, Y, w, hh)) {
            x.fillStyle = U.mpEmpty;
            x.globalAlpha = 0.75;
            x.fillRect(x0, Y, w, hh);
            x.globalAlpha = 1;
          }
          x.save();
          x.beginPath();
          x.rect(x0, Y, w * f, hh);
          x.clip();
          if (!spr(x, U.mpFill, getSheet, time, x0, Y, w, hh)) {
            x.fillStyle = st.mpFlash > 0 ? '#ff6b6b' : U.mpColor;
            x.fillRect(x0, Y, w, hh);
          }
          x.restore();
          if (!pic) {
            x.strokeStyle = 'rgba(255,255,255,.5)';
            x.lineWidth = 1;
            x.strokeRect(x0 + 0.5, Y + 0.5, w - 1, hh - 1);
          }
        }
      });
    }
    // status effects (poison, burn, slow): a coloured tag with the seconds left
    if (U.statusShow === 'yes' && st.status && st.status.length)
      rows.push({
        h: Math.ceil(U.size * 1.4),
        draw: (X, Y) => {
          x.textBaseline = 'middle';
          const tags = st.status.map(s2 => ({ s2, label: s2.label + ' ' + Math.ceil(s2.t) }));
          const pad = 6,
            gap2 = 6,
            hh = Math.ceil(U.size * 1.3);
          const tot = tags.reduce((a2, q) => a2 + x.measureText(q.label).width + pad * 2, 0) + gap2 * (tags.length - 1);
          let cx2 = left ? X : X - tot;
          x.textAlign = 'left';
          tags.forEach(q => {
            const w2 = x.measureText(q.label).width + pad * 2;
            x.fillStyle = q.s2.color;
            x.fillRect(cx2, Y, w2, hh);
            x.fillStyle = '#10161c';
            x.fillText(q.label, cx2 + pad, Y + hh / 2);
            cx2 += w2 + gap2;
          });
          x.fillStyle = U.color;
        }
      });
    const chips = (st.items || []).filter(q => q.count > 0);
    if (chips.length) {
      const isz = Math.round(U.size * 1.4);
      rows.push({
        h: chips.some(q => q.icon) ? isz + 2 : Math.ceil(U.size * 1.3),
        draw: (X, Y) => {
          // each item: its picture (when it has one) or its name, then how many
          const parts = chips.map(q => {
            const label = (q.icon ? '' : q.name + ' ') + 'x' + q.count;
            return { q, label, w: (q.icon ? isz + 4 : 0) + x.measureText(label).width };
          });
          const gap = 16,
            tot = parts.reduce((a2, p) => a2 + p.w, 0) + gap * (parts.length - 1);
          let cx2 = left ? X : X - tot;
          x.textAlign = 'left';
          x.textBaseline = 'middle';
          parts.forEach(p => {
            if (p.q.icon) {
              spr(x, p.q.icon, getSheet, time, cx2, Y, isz, isz);
              cx2 += isz + 4;
            }
            text(x, U, p.label, cx2, Y + (p.q.icon ? isz : Math.ceil(U.size * 1.3)) / 2);
            cx2 += x.measureText(p.label).width + gap;
          });
        }
      });
    }
    // the text row comes first in a top corner, last in a bottom one so health stays closest to the corner
    const list = top ? rows : rows.slice().reverse();
    const total = list.reduce((a, r) => a + r.h, 0);
    let Y = top ? M : ch - M - total;
    const X = left ? M : cw - M;
    list.forEach(r => {
      x.fillStyle = U.color;
      x.font = font(U, U.size);
      x.textAlign = left ? 'left' : 'right';
      x.textBaseline = 'top';
      r.draw(X, Y);
      Y += r.h;
    });
    x.restore();
  }
  // The minimap. m = { rooms: [{ x, y, w, h, here, seen }], px, py } where px and py are where the player is inside the current room (0..1).
  // The full-screen map. m = { title, area (name), index, count, rooms: [{ x, y, w, h, here, seen, name, marks: [{ k: 'rest' | 'boss' | 'item', x, y }] }], px, py, hint }
  function fullMap(x, cw, ch, U, m) {
    const rooms = (m.rooms || []).filter(r => r.seen || r.here);
    x.save();
    x.fillStyle = U.mapPanel;
    x.fillRect(0, 0, cw, ch);
    x.textBaseline = 'middle';
    x.textAlign = 'center';
    x.fillStyle = U.titleColor;
    x.font = font(U, 30, true);
    text(x, U, m.title || U.mapTitle, cw / 2, 34);
    x.font = font(U, 16, false);
    x.fillStyle = U.titleAccent;
    text(x, U, (m.count > 1 ? '< ' : '') + (m.area || '') + (m.count > 1 ? ' >' : ''), cw / 2, 64);
    if (!rooms.length) {
      x.fillStyle = U.color;
      text(x, U, 'Nothing explored here yet.', cw / 2, ch / 2);
    } else {
      let a = 1e9,
        b = 1e9,
        c = -1e9,
        d = -1e9;
      rooms.forEach(r => {
        a = Math.min(a, r.x);
        b = Math.min(b, r.y);
        c = Math.max(c, r.x + r.w);
        d = Math.max(d, r.y + r.h);
      });
      const X0 = 40,
        Y0 = 84,
        W = cw - 80,
        H = ch - 84 - 44,
        k = Math.min(W / Math.max(1, c - a), H / Math.max(1, d - b)),
        ox = X0 + (W - (c - a) * k) / 2 - a * k,
        oy = Y0 + (H - (d - b) * k) / 2 - b * k;
      rooms.forEach(r => {
        const rx = ox + r.x * k,
          ry = oy + r.y * k,
          rw = Math.max(3, r.w * k),
          rh = Math.max(3, r.h * k);
        x.fillStyle = r.here ? U.mapHere : U.mapRoom;
        x.globalAlpha = r.here ? 1 : 0.85;
        x.fillRect(rx + 1, ry + 1, rw - 2, rh - 2);
        x.globalAlpha = 1;
        x.strokeStyle = U.mapOutline;
        x.lineWidth = 1.5;
        x.strokeRect(rx + 0.5, ry + 0.5, rw - 1, rh - 1);
        if (U.mapMarks === 'yes')
          (r.marks || []).forEach(q => {
            x.fillStyle = q.k === 'boss' ? U.mapBossC : q.k === 'rest' ? U.mapRestC : U.mapItemC;
            const mx = rx + rw * Math.min(0.95, Math.max(0.05, q.x)),
              my = ry + rh * Math.min(0.95, Math.max(0.05, q.y));
            x.beginPath();
            if (q.k === 'boss') {
              x.moveTo(mx, my - 5);
              x.lineTo(mx + 5, my);
              x.lineTo(mx, my + 5);
              x.lineTo(mx - 5, my);
              x.closePath();
            } else if (q.k === 'rest') x.rect(mx - 4, my - 4, 8, 8);
            else x.arc(mx, my, 3.5, 0, 6.2832);
            x.fill();
            x.strokeStyle = 'rgba(0,0,0,.6)';
            x.lineWidth = 1;
            x.stroke();
          });
        if (r.here) {
          x.fillStyle = U.mapDot;
          x.beginPath();
          x.arc(rx + rw * Math.min(1, Math.max(0, m.px)), ry + rh * Math.min(1, Math.max(0, m.py)), 5, 0, 6.2832);
          x.fill();
          x.strokeStyle = '#000';
          x.lineWidth = 1.5;
          x.stroke();
        }
      });
    }
    x.textAlign = 'center';
    x.font = font(U, 13, false);
    x.fillStyle = U.color;
    text(x, U, m.hint || '', cw / 2, ch - 22);
    if (U.mapMarks === 'yes') {
      let lx = 40;
      x.textAlign = 'left';
      [
        ['rest', U.mapRestC, 'Rest point'],
        ['boss', U.mapBossC, 'Boss'],
        ['item', U.mapItemC, 'Item']
      ].forEach(q => {
        x.fillStyle = q[1];
        x.fillRect(lx, ch - 36, 9, 9);
        x.fillStyle = U.color;
        text(x, U, q[2], lx + 14, ch - 31);
        lx += 90;
      });
    }
    x.restore();
  }
  // The shop. m = { title, coins, sel, msg, hint, rows: [{ name, desc, price, owned, can }] }
  function shop(x, cw, ch, U, m) {
    x.save();
    x.fillStyle = 'rgba(0,0,0,0.55)';
    x.fillRect(0, 0, cw, ch);
    const W = Math.min(cw - 40, 560),
      rows = m.rows || [],
      rh = 40,
      H = 110 + rows.length * rh + 44,
      X0 = (cw - W) / 2,
      Y0 = Math.max(10, (ch - H) / 2);
    x.fillStyle = U.shopPanel;
    x.fillRect(X0, Y0, W, H);
    x.strokeStyle = U.titleAccent;
    x.lineWidth = 2;
    x.strokeRect(X0 + 1, Y0 + 1, W - 2, H - 2);
    x.textBaseline = 'middle';
    x.textAlign = 'left';
    x.fillStyle = U.titleColor;
    x.font = font(U, 26, true);
    text(x, U, m.title || U.shopTitle, X0 + 20, Y0 + 30);
    x.textAlign = 'right';
    x.fillStyle = U.titleAccent;
    x.font = font(U, 16, true);
    text(x, U, U.shopCoins + ': ' + m.coins, X0 + W - 20, Y0 + 30);
    rows.forEach((r, i) => {
      const y = Y0 + 66 + i * rh,
        on = i === m.sel;
      x.fillStyle = on ? U.btnSel : U.btnBg;
      x.fillRect(X0 + 14, y, W - 28, rh - 6);
      if (on) {
        x.strokeStyle = U.titleAccent;
        x.lineWidth = 2;
        x.strokeRect(X0 + 15, y + 1, W - 30, rh - 8);
      }
      x.textAlign = 'left';
      x.fillStyle = r.can ? U.btnColor : 'rgba(255,255,255,.45)';
      x.font = font(U, 16, true);
      text(
        x,
        U,
        r.name + (r.owned > 0 ? '  (' + r.owned + ' ' + U.shopOwned + ')' : ''),
        X0 + 24,
        y + (r.desc ? 11 : (rh - 6) / 2)
      );
      if (r.desc) {
        x.font = font(U, 12, false);
        x.fillStyle = 'rgba(255,255,255,.6)';
        text(x, U, r.desc, X0 + 24, y + 26);
      }
      x.textAlign = 'right';
      x.font = font(U, 16, true);
      x.fillStyle = r.can ? U.titleAccent : '#e24b4a';
      text(x, U, String(r.price), X0 + W - 24, y + (rh - 6) / 2);
    });
    x.textAlign = 'center';
    x.font = font(U, 13, false);
    x.fillStyle = '#ffd98a';
    text(x, U, m.msg || '', cw / 2, Y0 + H - 36);
    x.fillStyle = U.color;
    text(x, U, m.hint || '', cw / 2, Y0 + H - 16);
    x.restore();
  }
  function minimap(x, cw, ch, U, m) {
    const rooms = m.rooms || [];
    if (U.mapShow !== 'yes' || !rooms.length) return;
    const M = U.margin,
      W = U.mapW,
      H = U.mapH,
      X0 = U.mapCorner.endsWith('left') ? M : cw - M - W,
      Y0 = U.mapCorner.startsWith('top') ? M : ch - M - H;
    let a = 1e9,
      b = 1e9,
      c = -1e9,
      d = -1e9;
    rooms.forEach(r => {
      a = Math.min(a, r.x);
      b = Math.min(b, r.y);
      c = Math.max(c, r.x + r.w);
      d = Math.max(d, r.y + r.h);
    });
    const pad = 6,
      k = Math.min((W - 2 * pad) / Math.max(1, c - a), (H - 2 * pad) / Math.max(1, d - b)),
      ox = X0 + (W - (c - a) * k) / 2 - a * k,
      oy = Y0 + (H - (d - b) * k) / 2 - b * k;
    x.save();
    x.globalAlpha = U.mapAlpha;
    x.fillStyle = U.mapBg;
    x.fillRect(X0, Y0, W, H);
    x.beginPath();
    x.rect(X0, Y0, W, H);
    x.clip();
    rooms.forEach(r => {
      const rx = ox + r.x * k,
        ry = oy + r.y * k,
        rw = Math.max(2, r.w * k),
        rh = Math.max(2, r.h * k);
      if (r.seen || r.here) {
        x.fillStyle = r.here ? U.mapHere : U.mapRoom;
        x.fillRect(rx + 0.5, ry + 0.5, rw - 1, rh - 1);
      } else {
        x.strokeStyle = U.mapRoom;
        x.globalAlpha = U.mapAlpha * 0.4;
        x.strokeRect(rx + 0.5, ry + 0.5, rw - 1, rh - 1);
        x.globalAlpha = U.mapAlpha;
      }
      if (r.here) {
        x.fillStyle = U.mapDot;
        x.beginPath();
        x.arc(rx + rw * Math.min(1, Math.max(0, m.px)), ry + rh * Math.min(1, Math.max(0, m.py)), 3, 0, 6.2832);
        x.fill();
      }
    });
    x.restore();
    x.save();
    x.strokeStyle = 'rgba(255,255,255,.45)';
    x.strokeRect(X0 + 0.5, Y0 + 0.5, W - 1, H - 1);
    x.restore();
  }
  // short messages ("Got Potion"), newest at the bottom
  function messages(x, cw, U, list) {
    x.save();
    x.font = font(U, U.msgSize);
    x.textAlign = 'center';
    x.textBaseline = 'top';
    x.fillStyle = U.msgColor;
    list.forEach((m, i) => text(x, U, m.t, cw / 2, U.msgY + i * Math.ceil(U.msgSize * 1.3)));
    x.restore();
  }
  // the boss bar: b = { name, hp, max, safe, phases: [percent, ...] }
  function bossBar(x, cw, U, b, getSheet, time) {
    const w = (cw * U.bossWidth) / 100,
      h = U.bossHeight,
      X = (cw - w) / 2,
      Y = U.bossY;
    x.save();
    if (!spr(x, U.bossBackImg, getSheet, time, X, Y, w, h)) {
      x.globalAlpha = 0.5;
      x.fillStyle = U.bossBack;
      x.fillRect(X - 2, Y - 2, w + 4, h + 4);
      x.globalAlpha = 1;
    }
    const fw = w * Math.min(1, Math.max(0, b.hp / Math.max(1, b.max)));
    if (U.bossFillImg) {
      x.save();
      x.beginPath();
      x.rect(X, Y, fw, h);
      x.clip();
      spr(x, U.bossFillImg, getSheet, time, X, Y, w, h);
      x.restore();
    } else {
      x.fillStyle = b.safe ? U.bossSafe : U.bossColor;
      x.fillRect(X, Y, fw, h);
    }
    if (U.bossTicks === 'yes') {
      x.fillStyle = 'rgba(255,255,255,.7)';
      (b.phases || []).forEach(p => {
        if (p < 100) x.fillRect(X + (w * p) / 100 - 1, Y - 1, 2, h + 2);
      });
    }
    if (U.bossName === 'yes') {
      x.fillStyle = U.color;
      x.font = font(U, Math.max(10, U.size - 2));
      x.textAlign = 'center';
      x.textBaseline = 'bottom';
      text(x, U, b.name, cw / 2, Y - 3);
    }
    x.restore();
  }
  // the death screen: a = how far it has faded in and out (0..1)
  function death(x, cw, ch, U, a, fade) {
    x.save();
    x.fillStyle = 'rgba(0,0,0,' + fade * 0.92 + ')';
    x.fillRect(0, 0, cw, ch);
    x.globalAlpha = a;
    x.fillStyle = U.deathColor;
    x.font = font(U, U.deathSize, true);
    x.textAlign = 'center';
    x.textBaseline = 'middle';
    x.fillText(U.deathText, cw / 2, ch / 2);
    x.restore();
  }
  // A menu screen. m = { kind: 'title' | 'pause', title, subtitle, items: [{ id, label }], sel }. Returns the button boxes [{ id, x, y, w, h }]
  // so the caller can find what the mouse points at.
  function menu(x, cw, ch, U, m, getSheet, time) {
    const hits = [],
      left = U.menuAlign === 'left',
      cx = left ? cw * 0.1 : cw / 2,
      title = m.kind === 'title';
    x.save();
    if (title) {
      x.fillStyle = U.titleBg;
      x.fillRect(0, 0, cw, ch);
      spr(x, U.menuBg, getSheet, time, 0, 0, cw, ch);
    } else {
      x.fillStyle = 'rgba(0,0,0,' + U.pauseDim + ')';
      x.fillRect(0, 0, cw, ch);
    }
    x.textAlign = left ? 'left' : 'center';
    x.textBaseline = 'middle';
    x.fillStyle = U.titleColor;
    let y = ch * 0.1;
    const sh = title && U.menuLogo && getSheet && getSheet(U.menuLogo.sheet);
    if (sh && sh.tw && U.menuLogo) {
      const lh = U.logoH,
        lw = (lh * sh.tw) / sh.th;
      if (spr(x, U.menuLogo, getSheet, time, left ? cx : cx - lw / 2, y, lw, lh)) y += lh + 8;
    } else {
      x.font = font(U, 46, true);
      text(x, U, m.title || '', cx, y + 28);
      y += 62;
    }
    if (m.subtitle) {
      x.font = font(U, 18);
      x.globalAlpha = 0.8;
      text(x, U, m.subtitle, cx, y + 8);
      x.globalAlpha = 1;
    }
    let by = Math.max(y + 30, (ch * U.menuY) / 100);
    const bw = Math.min(U.btnW, cw - 20),
      bh = U.btnH;
    (m.items || []).forEach((it, i) => {
      const bx = left ? cx : cx - bw / 2,
        on = i === m.sel;
      hits.push({ id: it.id, x: bx, y: by, w: bw, h: bh });
      const ic = on ? U.btnImgSel || U.btnImg : U.btnImg;
      if (!spr9(x, ic, getSheet, time, bx, by, bw, bh, U.btnSlice, U.btnScale)) {
        x.fillStyle = on ? U.btnSel : U.btnBg;
        x.fillRect(bx, by, bw, bh);
        x.strokeStyle = on ? U.titleAccent : 'rgba(255,255,255,.18)';
        x.lineWidth = on ? 2 : 1;
        x.strokeRect(bx + 0.5, by + 0.5, bw - 1, bh - 1);
      }
      if (on && U.cursor) {
        const cs = Math.round(bh * 0.8);
        spr(x, U.cursor, getSheet, time, bx - cs - 8, by + (bh - cs) / 2, cs, cs);
      }
      x.fillStyle = U.btnColor;
      x.font = font(U, U.btnFont);
      x.textAlign = 'center';
      text(x, U, it.label, bx + bw / 2, by + bh / 2 + 1);
      by += bh + U.btnGap;
    });
    if (title && U.footer) {
      x.font = font(U, 12);
      x.fillStyle = U.titleColor;
      x.globalAlpha = 0.6;
      x.textAlign = left ? 'left' : 'center';
      x.fillText(U.footer, cx, ch - 14);
      x.globalAlpha = 1;
    }
    x.restore();
    return hits;
  }
  // The rows of the options screen. vol = { master, music, sfx } (0..1). Sliders have a value; buttons do not.
  function optRows(U, vol, canFull, canCtl) {
    const r = [
      { id: 'master', label: U.optMaster, kind: 'slider', value: vol.master },
      { id: 'music', label: U.optMusic, kind: 'slider', value: vol.music },
      { id: 'sfx', label: U.optSfx, kind: 'slider', value: vol.sfx }
    ];
    if (canFull) r.push({ id: 'full', label: U.optFull, kind: 'button' });
    if (canCtl) r.push({ id: 'controls', label: U.optControls, kind: 'button' });
    r.push({ id: 'back', label: U.optBack, kind: 'button' });
    return r;
  }
  // The controls page of the options screen: one row per basic action, showing its first key.
  const CTLN = ['Left', 'Right', 'Up', 'Down', 'Jump'];
  const keyName = c =>
    ({
      ArrowUp: 'Up arrow',
      ArrowDown: 'Down arrow',
      ArrowLeft: 'Left arrow',
      ArrowRight: 'Right arrow',
      Space: 'Space',
      ShiftLeft: 'Shift',
      ShiftRight: 'Shift',
      Enter: 'Enter'
    })[c] || String(c || '-').replace(/^Key|^Digit/, '');
  function ctlRows(U, keys, waiting) {
    const lab = U.optKeys.split(',').map(z => z.trim());
    const r = CTLN.map((k, i) => ({
      id: 'k:' + k,
      label: lab[i] || k,
      kind: 'key',
      value: waiting === k ? U.optPress : keyName((keys[k] || [])[0])
    }));
    r.push({ id: 'reset', label: U.optReset, kind: 'button' }, { id: 'back', label: U.optBack, kind: 'button' });
    return r;
  }
  // The keys with one action's first key replaced (an action that had that key gets the key being freed)
  function setKey(keys, name, code) {
    const out = {};
    CTLN.forEach(k => (out[k] = (keys[k] || []).slice()));
    if (!/^[A-Za-z0-9]{1,16}$/.test(code) || !CTLN.includes(name)) return out;
    const old = out[name][0];
    CTLN.forEach(k => {
      if (k !== name && out[k][0] === code && old) out[k][0] = old;
    });
    out[name] = [code].concat(out[name].filter(c => c !== code)).slice(0, 3);
    return out;
  }
  const stepVal = (v, d) => Math.min(1, Math.max(0, Math.round((v + d * 0.05) * 20) / 20));
  // The options screen (same look as the menus). m = { kind: 'title' | 'pause', rows, sel }. Returns boxes [{ id, x, y, w, h, bar? }].
  function options(x, cw, ch, U, m, getSheet, time) {
    const hits = [];
    x.save();
    if (m.kind === 'title') {
      x.fillStyle = U.titleBg;
      x.fillRect(0, 0, cw, ch);
      spr(x, U.menuBg, getSheet, time, 0, 0, cw, ch);
    } else {
      x.fillStyle = 'rgba(0,0,0,' + Math.max(U.pauseDim, 0.35) + ')';
      x.fillRect(0, 0, cw, ch);
    }
    x.textBaseline = 'middle';
    x.textAlign = 'center';
    x.fillStyle = U.titleColor;
    x.font = font(U, 36, true);
    text(x, U, m.title || U.optTitle, cw / 2, ch * 0.12);
    const bw = Math.min(Math.max(U.btnW, 380), cw - 20),
      bh = U.btnH;
    let by = ch * 0.24;
    (m.rows || []).forEach((q, i) => {
      const bx = (cw - bw) / 2,
        on = i === m.sel;
      const ic = on ? U.btnImgSel || U.btnImg : U.btnImg;
      if (!spr9(x, ic, getSheet, time, bx, by, bw, bh, U.btnSlice, U.btnScale)) {
        x.fillStyle = on ? U.btnSel : U.btnBg;
        x.fillRect(bx, by, bw, bh);
        x.strokeStyle = on ? U.titleAccent : 'rgba(255,255,255,.18)';
        x.lineWidth = on ? 2 : 1;
        x.strokeRect(bx + 0.5, by + 0.5, bw - 1, bh - 1);
      }
      const hit = { id: q.id, x: bx, y: by, w: bw, h: bh };
      x.fillStyle = U.btnColor;
      x.font = font(U, U.btnFont);
      if (q.kind === 'slider') {
        x.textAlign = 'left';
        text(x, U, q.label, bx + 14, by + bh / 2 + 1);
        const sx = bx + bw * 0.52,
          sw = bw * 0.46 - 44,
          sy = by + bh / 2 - 4;
        x.fillStyle = 'rgba(0,0,0,.55)';
        x.fillRect(sx, sy, sw, 8);
        x.fillStyle = U.titleAccent;
        x.fillRect(sx, sy, sw * q.value, 8);
        x.fillStyle = U.btnColor;
        x.fillRect(sx + sw * q.value - 3, sy - 4, 6, 16);
        x.textAlign = 'right';
        text(x, U, Math.round(q.value * 100) + '%', bx + bw - 10, by + bh / 2 + 1);
        hit.bar = { x: sx, w: sw };
      } else if (q.kind === 'key') {
        x.textAlign = 'left';
        text(x, U, q.label, bx + 14, by + bh / 2 + 1);
        x.textAlign = 'right';
        x.fillStyle = U.titleAccent;
        text(x, U, q.value, bx + bw - 14, by + bh / 2 + 1);
      } else {
        x.textAlign = 'center';
        text(x, U, q.label, bx + bw / 2, by + bh / 2 + 1);
      }
      hits.push(hit);
      by += bh + U.btnGap;
    });
    x.restore();
    return hits;
  }
  // the value a mouse click at X sets on a slider box
  const sliderAt = (hit, X) =>
    hit && hit.bar && X >= hit.bar.x - 8 && X <= hit.bar.x + hit.bar.w + 8
      ? Math.min(1, Math.max(0, Math.round(((X - hit.bar.x) / hit.bar.w) * 20) / 20))
      : null;
  const hitAt = (hits, X, Y) => {
    const h = (hits || []).find(q => X >= q.x && X <= q.x + q.w && Y >= q.y && Y <= q.y + q.h);
    return h ? h.id : null;
  };
  // Where a mouse event is on a canvas, in the canvas's own pixels (also when the page letterboxes it with object-fit: contain)
  const point = (c, e) => {
    const r = c.getBoundingClientRect(),
      k = Math.min(r.width / c.width, r.height / c.height) || 1;
    return {
      x: (e.clientX - r.left - (r.width - c.width * k) / 2) / k,
      y: (e.clientY - r.top - (r.height - c.height * k) / 2) / k
    };
  };
  return {
    FIELDS,
    FONTS,
    CORNERS,
    def,
    clean,
    hud,
    messages,
    bossBar,
    death,
    menu,
    options,
    minimap,
    fullMap,
    shop,
    optRows,
    ctlRows,
    setKey,
    keyName,
    family,
    cleanFonts,
    loadFonts,
    stepVal,
    sliderAt,
    hitAt,
    spr,
    spr9,
    point
  };
})();
