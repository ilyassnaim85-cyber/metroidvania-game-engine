// Controls: the player's key and gamepad scheme. Moves and attacks keep their own key (set in their tabs); this module holds the keys of the
// basic actions (Left, Right, Up, Down, Jump), the gamepad buttons, conflict warnings and the defaults.
window.MV = window.MV || {};
MV.Controls = (() => {
  const CORE = ['Left', 'Right', 'Up', 'Down', 'Jump'],
    PADKEYS = ['Jump', 'Interact'];
  const PAD = ['A', 'B', 'X', 'Y', 'LB', 'RB', 'LT', 'RT', 'Back', 'Start', 'Left stick click', 'Right stick click']; // buttons 0 to 11; the D-pad and the left stick always steer
  const def = () => ({
    keys: {
      Left: ['ArrowLeft', 'KeyA'],
      Right: ['ArrowRight', 'KeyD'],
      Up: ['ArrowUp', 'KeyW'],
      Down: ['ArrowDown', 'KeyS'],
      Jump: ['Space', 'ArrowUp', 'KeyW']
    },
    pad: { Jump: 0, Interact: 2 }
  });
  const okCode = c => typeof c === 'string' && /^[A-Za-z0-9]{1,16}$/.test(c);
  const clean = o => {
    const d = def(),
      r = { keys: {}, pad: {} };
    o = o && typeof o === 'object' ? o : {};
    CORE.forEach(k => {
      const l = o.keys && Array.isArray(o.keys[k]) ? o.keys[k] : null;
      r.keys[k] = l
        ? l
            .filter(okCode)
            .filter((c, i, a) => a.indexOf(c) === i)
            .slice(0, 3)
        : d.keys[k];
    });
    const p = o.pad && typeof o.pad === 'object' ? o.pad : {};
    PADKEYS.forEach(k => {
      const v = p[k];
      r.pad[k] = v === undefined ? d.pad[k] : Number.isInteger(v) && v >= 0 && v < PAD.length ? v : -1;
    });
    for (const k in p)
      if (/^[ma]:[\w-]{1,24}$/.test(k) && Number.isInteger(p[k]) && p[k] >= 0 && p[k] < PAD.length) r.pad[k] = p[k];
    return r;
  };
  // Key codes (keyboard and the virtual gamepad code) of a logical key name such as Jump or Left; null for any other name.
  const codes = (ctl, name) => (CORE.includes(name) ? (ctl.keys[name] || []).concat(['Pad:' + name]) : null);
  const nice = c =>
    ({
      ArrowUp: 'Up arrow',
      ArrowDown: 'Down arrow',
      ArrowLeft: 'Left arrow',
      ArrowRight: 'Right arrow',
      Space: 'Space',
      ShiftLeft: 'Shift',
      ShiftRight: 'Shift',
      Enter: 'Enter'
    })[c] || String(c).replace(/^Key|^Digit/, '');
  // Warnings: two things on the same key (with the same second key) or the same gamepad button.
  const conflicts = (ctl, moves, attacks) => {
    const E = [],
      real = c => !/^Pad:/.test(c);
    CORE.forEach(k =>
      E.push({ n: k, c: ctl.keys[k], w: 'None', p: ctl.pad[k] === undefined ? -1 : ctl.pad[k], core: k })
    );
    (moves || []).forEach(m => {
      if (m.type === 'swim' || (m.key === 'None' && ctl.pad['m:' + m.id] === undefined)) return;
      E.push({
        n: m.label,
        c: m.key === 'None' ? [] : CORE.includes(m.key) ? ctl.keys[m.key] : [m.key === 'Shift' ? 'ShiftLeft' : m.key],
        w: m.with || 'None',
        p: ctl.pad['m:' + m.id] === undefined ? -1 : ctl.pad['m:' + m.id],
        jump: m.key === 'Jump'
      });
    });
    (attacks || []).forEach(a =>
      E.push({
        n: a.label,
        c: a.key === 'None' ? [] : CORE.includes(a.key) ? ctl.keys[a.key] : [a.key === 'Shift' ? 'ShiftLeft' : a.key],
        w: a.with || 'None',
        wp: a.weapon || '',
        p: ctl.pad['a:' + a.id] === undefined ? -1 : ctl.pad['a:' + a.id]
      })
    );
    if (ctl.pad.Interact >= 0) E.push({ n: 'Interact', c: [], w: 'None', p: ctl.pad.Interact });
    const out = [];
    for (let i = 0; i < E.length; i++)
      for (let j = i + 1; j < E.length; j++) {
        const a = E[i],
          b = E[j];
        if ((a.core === 'Up' && b.core === 'Jump') || (a.core === 'Jump' && b.core === 'Up')) continue; // W and the Up arrow may jump and look up at once
        if (a.wp && b.wp && a.wp !== b.wp) continue; // attacks of two different weapons never fire together
        if (a.jump || b.jump) continue; // a move on the jump key is meant to share it
        const sw = (a.w || 'None') === (b.w || 'None'),
          sh = a.c.filter(c => b.c.includes(c) && real(c));
        if (sw && sh.length)
          out.push(
            nice(sh[0]) +
              ' is used by "' +
              a.n +
              '" and "' +
              b.n +
              '"' +
              (a.w !== 'None' ? ' (both with ' + nice(a.w) + ')' : '') +
              '. Both would fire.'
          );
        if (sw && a.p >= 0 && a.p === b.p)
          out.push('Gamepad ' + PAD[a.p] + ' is used by "' + a.n + '" and "' + b.n + '". Both would fire.');
      }
    return out;
  };
  return { CORE, PADKEYS, PAD, def, clean, codes, nice, conflicts };
})();
