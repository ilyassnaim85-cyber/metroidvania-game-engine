// Camera input: the keys, the right stick, the mouse wheel and a drag on the canvas go to the rig, which decides what to do with them (pan, zoom or steer the free camera).
function camFeed() {
  if (G.cam.inputLocked() && !G.dlg) {
    G.keys = {};
    G.p.vx = 0;
  }
  const inp = G.camIn || (G.camIn = { wheel: 0, dx: 0, dy: 0, drag: false, lx: 0, ly: 0 });
  const gp = navigator.getGamepads && [...navigator.getGamepads()].find(g => g && g.connected),
    st = gp ? { x: gp.axes[2] || 0, y: gp.axes[3] || 0 } : null,
    zb = gp ? ((gp.buttons[7] && gp.buttons[7].value) || 0) - ((gp.buttons[6] && gp.buttons[6].value) || 0) : 0;
  G.cam.feed({
    keys: c => !!G.keys[c] || !!(G.camKeys && G.camKeys[c]),
    stick: st,
    zoomAxis: zb * 0.6,
    wheel: inp.wheel,
    drag: { dx: inp.dx, dy: inp.dy },
    reset: gp ? !!(gp.buttons[11] && gp.buttons[11].pressed) : false
  });
  inp.wheel = 0;
  inp.dx = 0;
  inp.dy = 0;
}
// The camera keys (pan / free / zoom) are read straight from the keyboard so they work even though they are not game keys.
function camKd(e) {
  if (!G || /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return;
  (G.camKeys || (G.camKeys = {}))[e.code] = true;
}
function camKu(e) {
  if (G && G.camKeys) G.camKeys[e.code] = false;
}
function camWheel(e) {
  if (!G || G.paused || G.inv) return;
  const c = G.cam;
  if (!(c.manual || c.free || c.mode() === 'free') && (camCfg().p || {}).manualPan !== 'yes') return;
  e.preventDefault();
  (G.camIn || (G.camIn = { wheel: 0, dx: 0, dy: 0 })).wheel += e.deltaY;
}
function camMouse(e) {
  if (!G) return;
  const inp = G.camIn || (G.camIn = { wheel: 0, dx: 0, dy: 0, drag: false, lx: 0, ly: 0 });
  if (e.type === 'mousedown' && e.button === 1) {
    inp.drag = true;
    inp.lx = e.clientX;
    inp.ly = e.clientY;
    e.preventDefault();
  } else if (e.type === 'mouseup') inp.drag = false;
  else if (e.type === 'mousemove' && inp.drag) {
    inp.dx += e.clientX - inp.lx;
    inp.dy += e.clientY - inp.ly;
    inp.lx = e.clientX;
    inp.ly = e.clientY;
  }
}
function loop(t) {
  if (!G) return;
  G.raf = requestAnimationFrame(loop);
  const dt = Math.min(0.05, Math.max(0, (t - G.last) / 1000));
  G.last = t;
  if (G.slow) {
    G.slow.t -= (t - (G.slowT || t)) / 1000;
    if (G.slow.t <= 0) G.slow = null;
  }
  G.slowT = t;
  G.ctl = MV.Controls.clean(typeof G.ctlSrc === 'function' ? G.ctlSrc() : G.ctlSrc);
  padPoll();
  G.bd = MV.Attacks.bodyClean(typeof G.bodySrc === 'function' ? G.bodySrc() : G.bodySrc);
  G.mv = MV.Moves.resolve(typeof G.moveSrc === 'function' ? G.moveSrc() : G.moveSrc);
  MV.Moves.sync(G.mv);
  G.at = MV.Attacks.resolve(
    typeof G.atkSrc === 'function' ? G.atkSrc() : G.atkSrc,
    typeof G.tuning === 'function' ? G.tuning() : G.tuning
  );
  G.tune = MV.Tuning.resolve(typeof G.tuning === 'function' ? G.tuning() : G.tuning);
  if (G.p && G.p.ride) rideTune();
  G.items = MV.Inventory.resolve(typeof G.itemSrc === 'function' ? G.itemSrc() : G.itemSrc);
  G.ed = MV.Enemies.resolve(typeof G.edSrc === 'function' ? G.edSrc() : G.edSrc);
  bonus();
  applyTuneSet();
  G.hp = Math.min(G.hp, G.tune.maxHp);
  const n = Math.max(1, Math.ceil(dt * 120));
  let ok = true;
  if (G.dscr) {
    G.dscr.t += dt;
    if (G.dscr.t >= G.dscr.len) {
      G.dscr = null;
      die(true);
    }
  }
  if (G.dfade) {
    G.dfade.t += dt;
    if (G.dfade.t >= G.dfade.len) G.dfade = null;
  }
  if (G.mpf > 0) G.mpf -= dt;
  if (G.nmt > 0) G.nmt -= dt;
  const dts = G.slow ? dt * G.slow.f : dt;
  if (G.dscr) {
    /* the death screen holds the world still */
  } else if (G.dlg) G.dlg.t += dt * 45;
  else if (G.inv) {
    /* the inventory pauses the world */
  } else for (let i = 0; i < n && ok; i++) ok = sim(dts / n); // a conversation pauses the world
  {
    const pa = G.p.act;
    if (pa) {
      pa.t += dt;
      if (pa.t >= pa.len) G.p.act = null;
    }
  }
  {
    const s = G.dlg && anims().talk ? 'talk' : MV.PlayerSprite.state(G.p);
    if (s !== G.p.anim.s) {
      G.p.anim.s = s;
      G.p.anim.t = 0;
    } else G.p.anim.t += dt;
  }
  {
    const f = G.p.fx;
    if (f) {
      f.t += dt;
      if (f.dash ? !G.p.mv || (!f.a.loop && f.t >= f.len) : f.t >= f.len) G.p.fx = null;
    }
  } // the move's own animation
  G.msgs.forEach(m => (m.ttl -= dt));
  G.msgs = G.msgs.filter(m => m.ttl > 0);
  if (G.script) G.script.tick(dt);
  if (G.ev) G.ev.tick(dt); // events: they keep running while a conversation is open (so a conversation can be one of their steps)
  camFeed();
  G.cam.noRotate = (MV.Light.clean(G.room.light) || MV.Light.def()).ambient < 1;
  G.cam.update(dt, G.p.x, G.p.y - G.tune.h / 2, VW, VH, G.room.gw, G.room.gh, camCfg(), false, camPl(), G.tune);
  paint();
}
const isJump = c => codesOf('Jump').includes(c),
  gameKey = c => ['Left', 'Right', 'Up', 'Down', 'Jump'].some(n => codesOf(n).includes(c));
function dlgNext() {
  const d = G.dlg;
  if (!d) return;
  snd('talk');
  const ln = d.lines[d.i];
  if (d.t < ln.text.length) {
    d.t = ln.text.length;
    return;
  }
  d.i++;
  d.t = 0;
  if (d.i >= d.lines.length) {
    G.st.flags['talked:' + d.e.uid] = 1;
    save();
    G.dlg = null;
    G.pr = {};
    G.jb = 0;
    if (d.done) d.done();
  }
}
function kd(e) {
  if (MV.Audio) MV.Audio.unlock();
  if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)) return; // typing in the editor panels
  if (G.paused) return; // game is paused behind another editor tab: leave the keys (Space on buttons, arrows) alone
  if (G.inv) {
    e.preventDefault();
    if (!e.repeat || /^Arrow|^Key[WASD]$/.test(e.code)) invKey(e.code, e.shiftKey);
    return;
  }
  if (codesOf(invDesign().key).includes(e.code) && !G.dlg) {
    e.preventDefault();
    if (!e.repeat) openInv();
    return;
  }
  if (e.code === 'Tab') {
    e.preventDefault();
    if (!e.repeat && !G.dlg) switchWeapon();
    return;
  }
  if (gameKey(e.code)) e.preventDefault();
  if (e.repeat) return;
  press(e.code);
}
function press(code) {
  if (G.ev && !G.dlg && !G.inv) G.ev.emit('key', { code });
  if (G.dlg) {
    if (
      ['Space', 'Enter', 'KeyE', 'KeyF', 'KeyQ', 'ArrowRight', 'ArrowDown', 'Pad:Jump', 'Pad:Interact'].includes(
        code
      ) ||
      (G.dlg.e && code === kc(G.dlg.e.p.key))
    )
      dlgNext();
    return;
  }
  G.keys[code] = true;
  const p = G.p;
  if (p.frz > G.time) return; // a message zone is holding the player still
  if (isJump(code)) G.jb = G.tune.buffer;
  if (code === 'Pad:Interact') for (const c of INTERACT) G.pr[c] = 0.2;
  else G.pr[code] = 0.2; // every key is remembered for a moment so signs, chests, checkpoints and characters can use whichever key you chose
  if (chainPress(code)) return;
  {
    const ch = G.mv
      .concat(G.at)
      .filter(
        o =>
          o.charge > 0 &&
          o.key !== 'Jump' &&
          keyIs(o, code) &&
          withOk(o) &&
          (!('hitboxes' in o) || wOk(o)) &&
          (!o.type || o.type === 'impulse' || TIMED.includes(o.type))
      )
      .sort(specific)[0];
    if (ch && !p.chg) {
      p.chg = { o: ch, t: 0 };
      return;
    }
  }
  {
    const cand = G.mv
      .filter(
        m =>
          (m.type === 'impulse' || m.type === 'throw' || TIMED.includes(m.type)) &&
          ((m.key !== 'Jump' && m.key !== 'None' && codesOf(m.key).includes(code)) || code === 'Pad:m:' + m.id)
      )
      .sort(specific);
    const started = cand.sort(order).find(m => !holdFirst(m) && tryMove(m));
    if (started) claim(started, code);
    if (!started && cand.length && (API.boxes || API.debug)) {
      const why = moveWhy(cand[0]);
      if (why && !G.msgs.some(q => q.ttl > 1 && q.t.startsWith(cand[0].label + ' did not')))
        msg(cand[0].label + ' did not start: ' + why);
    }
  }
  G.at
    .filter(a => (a.key !== 'None' && codesOf(a.key).includes(code)) || code === 'Pad:a:' + a.id)
    .sort(specific)
    .some(a => tryAttack(a));
}
function release(code) {
  G.keys[code] = false;
  if (G.claim) delete G.claim[code];
  const c = G.p && G.p.chg;
  if (c && keyIs(c.o, code)) {
    G.p.chg = null;
    const pw = Math.min(1, c.t / c.o.charge);
    if (isAtk(c.o)) tryAttack(c.o, false, pw);
    else tryMove(c.o, false, pw);
  }
  if (isJump(code) && G.p.vy < -6) G.p.vy *= G.tune.jumpCut;
}
function ku(e) {
  release(e.code);
}
const INTERACT = ['Enter', 'Space'].concat(
  'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(l => 'Key' + l),
  '0123456789'.split('').map(d => 'Digit' + d)
);
// Gamepad: the left stick and the D-pad steer; the buttons chosen in the Controls tab act like keys (virtual codes "Pad:...").
function padPoll() {
  if (!navigator.getGamepads || G.paused) return;
  const gp = [...navigator.getGamepads()].find(g => g && g.connected);
  const now = {};
  if (gp) {
    const b = i => !!(gp.buttons[i] && gp.buttons[i].pressed),
      ax = gp.axes[0] || 0,
      ay = gp.axes[1] || 0;
    now['Pad:Left'] = b(14) || ax < -0.5;
    now['Pad:Right'] = b(15) || ax > 0.5;
    now['Pad:Up'] = b(12) || ay < -0.6;
    now['Pad:Down'] = b(13) || ay > 0.6;
    const pd = G.ctl.pad;
    for (const k in pd) if (pd[k] >= 0 && b(pd[k])) now['Pad:' + k] = true;
  }
  const was = G.padNow || {};
  G.padNow = now;
  for (const c in now) if (now[c] && !was[c] && !G.paused) press(c);
  for (const c in was) if (was[c] && !now[c]) release(c);
}
const bl = () => {
  if (G) G.keys = {};
};
