API.start = o => {
  if (MV.Audio) MV.Audio.setup(o.world);
  API.stop();
  o.canvas.width = VW * Z;
  o.canvas.height = VH * Z;
  G = {
    pr: {},
    bosses: MV.Boss.list(typeof o.bosses === 'function' ? o.bosses() : o.bosses),
    moveSrc: o.moves,
    atkSrc: o.attacks,
    edSrc: o.enemies,
    ed: MV.Enemies.resolve(typeof o.enemies === 'function' ? o.enemies() : o.enemies),
    es: [],
    itemSrc: o.items,
    ctlSrc: o.controls,
    ctl: MV.Controls.clean(typeof o.controls === 'function' ? o.controls() : o.controls),
    bodySrc: o.body,
    bd: MV.Attacks.bodyClean(typeof o.body === 'function' ? o.body() : o.body),
    sprite: o.sprite,
    sheet: o.sheet,
    mv: MV.Moves.resolve(typeof o.moves === 'function' ? o.moves() : o.moves),
    canvas: o.canvas,
    image: o.image,
    tuning: o.tuning,
    tune: MV.Tuning.resolve(typeof o.tuning === 'function' ? o.tuning() : o.tuning),
    world: o.world,
    st: o.state,
    persist: !!o.persist,
    art: o.art,
    cam: new MV.CameraRig().bind({
      ppt: Z,
      profiles: () => G && G.world && G.world.camProfiles,
      entity: uid => (G.en || []).find(e => e.uid === uid),
      entities: () => G.en || [],
      bosses: () => (G.en || []).filter(e => e.type === 'boss' && e.b),
      alive: e => !e.dead && G.en.includes(e)
    }),
    keys: {},
    jb: 0,
    coins: 0,
    msgs: [],
    last: performance.now(),
    raf: 0
  };
  // the player's animation clips (Animation Studio) come from the project being played, in the editor and in an exported game alike
  MV.PlayerSprite.clips = () => (G && G.world && G.world.anims) || [];
  G.vcam = new MV.CameraVcams.Manager(G.cam, {
    entity: id => (G.en || []).find(e => e.uid === G.room.id + ':' + id),
    boss: () => (G.en || []).find(e => e.type === 'boss' && e.b && e.b.awake && !e.dead) || null
  });
  G.ev = new MV.Events.Runner(
    {
      st: o.state,
      world: o.world || {},
      items: () => G.items || MV.Inventory.resolve(typeof o.items === 'function' ? o.items() : o.items),
      roomId: () => G.room && G.room.id,
      coins: v => {
        if (v === undefined) return G.coins;
        G.coins = v;
      },
      hp: v => {
        if (v === undefined) return G.hp;
        G.hp = Math.max(0, Math.min(G.tune.maxHp, v));
      },
      maxHp: () => G.tune.maxHp,
      energy: v => {
        if (v === undefined) return G.mp;
        gain(v);
      },
      upgrade: (k, n) => upgrade(k, n),
      hurt: n => {
        if (hurtP(n, null, false, true) === 'die') die();
      },
      script: (t, d) => {
        if (G && G.script) G.script.emit(t, d);
      },
      scriptCall: (name, arg) => (G && G.script ? G.script.call(String(name), arg) : undefined),
      msg: t => msg(t),
      save: () => save(),
      giveWeapon: id => giveWeapon(id),
      freeze: sec => {
        G.p.frz = G.time + sec;
      },
      shake: a => G.cam.shake(a),
      keyCode: v => kc(v),
      dialogue: (lines, who, done) => {
        G.dlg = { e: { uid: 'ev:' + who, p: { name: who, key: 'E' } }, lines, i: 0, t: 0, done };
        G.keys = {};
        G.p.vx = 0;
      },
      goRoom: (rid, x, y) => {
        const rm = (G.world.areas || []).reduce((f, a) => f || (a.rooms || []).find(r => r.id === rid), null);
        if (!rm) return;
        const has = isFinite(+x) && isFinite(+y) && x !== null && y !== null && x !== '';
        load(rm, null, has ? { a: null, r: rm.id, x: +x, y: +y } : null);
      },
      camfx: (type, a) => {
        const c = G.cam,
          t = Math.max(0.05, +a.secs || 0.8); // the Events tab's camera actions
        if (type === 'camzoom') c.zoomTo(+a.zoom || 1, { time: t, hold: +a.hold || 0 });
        else if (type === 'camtilt') c.rotateTo(+a.deg || 0, { time: t });
        else if (type === 'camfade') {
          if (a.to === 'flash white') c.flash('#fff', t, 0.9);
          else if (a.to === 'back to clear') c.fadeIn(t);
          else c.fadeOut(t, '#000');
        } else if (type === 'camfocus')
          c.override({
            id: 'event-focus',
            target: { x: +a.x || 0, y: +a.y || 0 },
            zoom: +a.zoom || 1,
            ttl: t,
            lockInput: a.lock === 'locked while it looks',
            scope: 'room',
            priority: 5,
            blend: 0.6
          });
      },
      camera: (id, blend) => {
        G.camSet = { id: String(id), blend: isFinite(+blend) && +blend >= 0 ? +blend : 0.8 };
      },
      cameraReset: () => {
        G.camSet = null;
      },
      sound: id => {
        if (MV.Audio) MV.Audio.play(id);
      },
      music: id => {
        if (MV.Audio) MV.Audio.music(id);
      }
    },
    o.world && o.world.events
  );
  MV.Moves.sync(G.mv);
  G.at = MV.Attacks.resolve(
    typeof o.attacks === 'function' ? o.attacks() : o.attacks,
    typeof o.tuning === 'function' ? o.tuning() : o.tuning
  );
  G.items = MV.Inventory.resolve(typeof o.items === 'function' ? o.items() : o.items);
  G.tuneSet = {};
  bonus();
  applyTuneSet();
  G.hp = G.tune.maxHp;
  G.status = {};
  addEventListener('keydown', kd);
  addEventListener('keyup', ku);
  addEventListener('blur', bl);
  addEventListener('keydown', camKd);
  addEventListener('keyup', camKu);
  addEventListener('wheel', camWheel, { passive: false });
  addEventListener('mousedown', camMouse);
  addEventListener('mouseup', camMouse);
  addEventListener('mousemove', camMouse);
  G.quit = typeof o.quit === 'function' ? o.quit : null; // the host game's way back to its title screen
  G.canFull = !!o.fullscreen; // the host game can go full screen (the options screen offers it)
  G.ctlUser = o.ctlUser && typeof o.ctlUser === 'object' ? o.ctlUser : null; // keys the player chose before (the host keeps them)
  G.onCtl = typeof o.onCtl === 'function' ? o.onCtl : null;
  if (MV.UI && MV.UI.loadFonts) MV.UI.loadFonts(o.world && o.world.fonts);
  G.skins = MV.Tiles.cleanSkins(o.world && o.world.tileSkins); // tile pictures from sprite sheets
  G.onVol = typeof o.onVol === 'function' ? o.onVol : null; // the host game keeps the volumes the player chose
  if (o.vol && MV.Audio && MV.Audio.setVol) MV.Audio.setVol(o.vol);
  G.mm = e => {
    // the mouse points at a pause menu button
    if (!G || !G.pm || !G.pmHit) return;
    const p = MV.UI.point(G.canvas, e),
      id = MV.UI.hitAt(G.pmHit, p.x, p.y),
      i = pmList().findIndex(q => q.id === id);
    if (i >= 0) G.pm.sel = i;
    if (e.buttons & 1 && G.pm.page === 'options') {
      const h = G.pmHit.find(q => q.id === id),
        v = MV.UI.sliderAt(h, p.x);
      if (v !== null) pmSetVol(id, v); // dragging a slider
    }
  };
  G.mc = e => {
    if (!G || !G.pm || !G.pmHit) return;
    const p = MV.UI.point(G.canvas, e),
      id = MV.UI.hitAt(G.pmHit, p.x, p.y);
    if (!id) return;
    if (G.pm.page === 'options') {
      const v = MV.UI.sliderAt(
        G.pmHit.find(q => q.id === id),
        p.x
      );
      if (v !== null) {
        pmSetVol(id, v);
        return;
      }
    }
    pmPick(id);
  };
  o.canvas.addEventListener('mousemove', G.mm);
  o.canvas.addEventListener('click', G.mc);
  G.script = new MV.Script.Runtime(o.world && o.world.scripts, scriptApi(), t => msg(t)); // before the first room, so scripts hear it
  load(o.room, null, o.state.cp && o.state.cp.r === o.room.id ? o.state.cp : null);
  G.script.emit('start', {}, []);
  G.raf = requestAnimationFrame(loop);
};
API.stop = () => {
  if (MV.Audio) MV.Audio.stopMusic(true);
  if (!G) return;
  cancelAnimationFrame(G.raf);
  if (G.canvas) {
    G.canvas.removeEventListener('mousemove', G.mm);
    G.canvas.removeEventListener('click', G.mc);
  }
  removeEventListener('keydown', kd);
  removeEventListener('keyup', ku);
  removeEventListener('blur', bl);
  removeEventListener('keydown', camKd);
  removeEventListener('keyup', camKu);
  removeEventListener('wheel', camWheel);
  removeEventListener('mousedown', camMouse);
  removeEventListener('mouseup', camMouse);
  removeEventListener('mousemove', camMouse);
  G = null;
};
API.room = () => G && G.room;
API.door = () => (G && G.go ? { t: G.go.t, open: G.go.open, ride: G.go.ride } : null);
API.area = () => G && G.area;
API.player = () => G && G.p;
API.entities = () => G && G.en;
API.thrown = () => G && G.thr;
API.state = () => G && G.st;
API.messages = () => G && G.msgs;
API.dialog = () => G && G.dlg;
// scripts (see SCRIPTING.md): MV.Game.script.errors() / logs() / call('name', arg) / reload() for the editor and for tests
API.script = {
  errors: () => (G && G.script ? G.script.errors.slice() : []),
  logs: () => (G && G.script ? G.script.logs.slice() : []),
  clear: () => {
    if (G && G.script) {
      G.script.clearErrors();
      G.script.logs = [];
    }
  },
  call: (name, arg) => (G && G.script ? G.script.call(name, arg) : undefined),
  functions: () => (G && G.script ? Object.keys(G.script.fns) : [])
};
API.camera = {
  // swap the camera profile by script: MV.Game.camera.set('boss', 1.2), .reset(), .get()
  set: (id, blend) => {
    if (G) G.camSet = { id: String(id), blend: isFinite(+blend) && +blend >= 0 ? +blend : 0.8 };
  },
  reset: blend => {
    if (G) G.camSet = null;
  },
  get: () =>
    G
      ? {
          profile: G.camSet ? G.camSet.id : (G.room.cam && G.room.cam.profile) || 'default',
          zone: G.camZone ? G.camZone.uid : null,
          ledge: ledgeNear(),
          debug: G.cam.dbg
        }
      : null,
  list: () => MV.Camera.all(G && G.world && G.world.camProfiles).map(q => q.id),
  rig: () => (G ? G.cam : null)
}; // the rest of the rig (modes, targets, framing, lock-on, effects, overrides, rails, cutscenes, settings) is forwarded below; see CAMERA.md
[
  'mode',
  'target',
  'addTarget',
  'removeTarget',
  'clearTargets',
  'frame',
  'bossFrame',
  'lockOn',
  'unlock',
  'lockNext',
  'manualPan',
  'free_',
  'pan',
  'shake',
  'stopShake',
  'recoil',
  'zoomTo',
  'zoomReset',
  'zoomPunch',
  'rotateTo',
  'rotatePunch',
  'fade',
  'fadeOut',
  'fadeIn',
  'flash',
  'transition',
  'override',
  'endOverride',
  'overrides',
  'rail',
  'stopRail',
  'cutscene',
  'endCutscene',
  'skipCutscene',
  'settings',
  'resetSettings',
  'status',
  'toScreen',
  'toWorld',
  'freeze'
].forEach(k => {
  API.camera[k === 'free_' ? 'free' : k] = (...a) => (G ? G.cam[k](...a) : undefined);
});
// virtual cameras (made in Player > Camera): MV.Game.camera.vcam('boss', true) switches one on or off, .vcamPriority('boss', 50), .vcamSolo('boss') makes one live (null puts it back), .vcams() lists them, .vcamActive() says which is live
Object.assign(API.camera, {
  vcam: (id, on) => G && G.vcam && G.vcam.set(String(id), { on: !!on }),
  vcamPriority: (id, n) => G && G.vcam && isFinite(+n) && G.vcam.set(String(id), { priority: +n }),
  vcamSolo: id => G && G.vcam && G.vcam.solo(id),
  vcams: () =>
    G
      ? MV.CameraVcams.clean(G.world && G.world.vcams).map(c => ({
          id: c.id,
          name: c.name,
          on: c.on,
          priority: c.priority,
          room: c.room
        }))
      : [],
  vcamActive: () => (G && G.vcam ? G.vcam.active() : ''),
  debug: on => {
    if (G) G.camDbg = on === undefined ? !G.camDbg : !!on;
  }
});
API.events = {
  log: () => (G ? G.ev.log.slice() : []),
  run: id => {
    if (G) G.ev.call(id, 'script');
  },
  list: () => (G ? G.ev.list.map(e => e.id) : []),
  running: () => (G ? G.ev.run.map(r => r.ev.id) : [])
};
API.enemyShots = () => G && G.es;
API.attackList = () => G && G.at;
API.hurt = n => {
  if (G && hurtP(n, null, false, true) === 'die') die();
};
API.energy = v => G && (v === undefined ? G.mp : (G.mp = v));
API.energyMax = () => G && G.tune.energyMax;
API.maxHp = () => G && G.tune.maxHp;
API.coins = v => G && (v === undefined ? G.coins : (G.coins = v));
API.charms = () => G && G.chm;
API.dying = () => !!(G && G.dscr);
API.status = () => (G ? MV.Status.list(G.status) : []);
API.addStatus = (id, t) => G && MV.Status.add(G.status, id, t);
API.tune = () => G && G.tune;
API.hp = v => G && (v === undefined ? G.hp : (G.hp = v));
API.inventoryOpen = () => !!(G && G.inv);
API.mapOpen = () => !!(G && G.fm);
API.shopOpen = () => !!(G && G.shop);
API.pauseOpen = () => !!(G && G.pm);
API.controls = () => G && G.ctl;
API.size = () => ({ w: VW * Z, h: VH * Z });
API.pause = () => {
  if (!G || G.paused) return;
  G.paused = true;
  cancelAnimationFrame(G.raf);
  G.keys = {};
};
API.resume = () => {
  if (!G || !G.paused) return;
  G.paused = false;
  G.last = performance.now();
  G.raf = requestAnimationFrame(loop);
};
MV.Game = API;
