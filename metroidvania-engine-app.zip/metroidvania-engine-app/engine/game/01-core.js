const VW = 25,
  VH = 14,
  Z = 32,
  API = { debug: false };
let G = null;
const D = () => MV.data,
  ab = id => D().abilities[id],
  can = id => !!G.st.abilities[id] || !!(G.st.items && G.st.items[id] > 0) || !!(G.chm && G.chm.grants[id]);
const save = () => {
  if (G.persist) MV.Progress.save(G.st);
};
const msg = t => G.msgs.push({ t, ttl: 2.5 });
const snd = n => {
  if (MV.Audio) MV.Audio.slot(n);
}; // a sound the player makes by itself (set in the Audio tab)
// Behaviour animations (picking up, landing, getting hurt...) play once on top of the normal movement animation, only when the player sprite has one for it.
const anims = () => (G.sprite && G.sprite() && G.sprite().anims) || {};
function act(s) {
  if (s === 'land' || s === 'pickup' || s === 'checkpoint' || s === 'chest' || s === 'hurt') snd(s);
  const a = anims()[s];
  if (!a || !G.p) return;
  const len = Math.max(0.05, MV.PlayerSprite.len(a));
  G.p.act = { s, t: 0, len };
  if (a.freeze) G.p.frz = Math.max(G.p.frz || 0, G.time + len);
}
// Energy (mana, soul, focus): a second bar that moves and attacks spend. G.mp = what you have, G.tune.energyMax = the size (0 = no bar).
const afford = c => !(c > 0) || (G.tune.energyMax > 0 && G.mp >= c - 1e-6);
const spend = c => {
  if (c > 0) {
    G.mp = Math.max(0, G.mp - c);
    G.mpw = 0;
  }
};
const gain = v => {
  if (G.tune.energyMax > 0 && v) {
    G.mp = Math.max(0, Math.min(G.tune.energyMax, G.mp + v));
    if (v < 0) G.mpw = 0;
  }
};
const noMp = () => {
  G.mpf = 0.45;
  if (!(G.nmt > 0)) {
    msg(G.tune.energyMax > 0 ? 'Not enough energy' : 'This needs energy: set the Energy maximum in Settings');
    G.nmt = 1;
  }
};
// Upgrades (st.stats: permanent bonuses from pickups) and charms (st.equipped: items with the use Charm) add to the tuning every frame.
const STATS = { maxHp: [1, 99], energyMax: [0, 300], charmSlots: [0, 20] };
function charms() {
  const eq = (G.st && G.st.equipped) || {},
    out = { mods: {}, grants: {}, used: 0, on: [] };
  (G.items || []).forEach(d => {
    if (d.use === 'charm' && eq[d.id] && MV.Inventory.count(G.st, d.id) > 0) {
      out.used += d.notches;
      out.on.push(d.id);
      (d.mods || []).forEach(q => {
        out.mods[q.key] = (out.mods[q.key] || 0) + q.add;
      });
      if (d.grant) out.grants[d.grant] = 1;
    }
  });
  return out;
}
function bonus() {
  const T = G.tune,
    s = (G.st && G.st.stats) || {},
    c = (G.chm = charms()),
    m = c.mods,
    add = (k, v, lo, hi) => {
      T[k] = Math.min(hi, Math.max(lo, T[k] + v));
    };
  add('maxHp', (s.maxHp || 0) + (m.maxHp || 0), 1, 99);
  add('energyMax', (s.energyMax || 0) + (m.energyMax || 0), 0, 300);
  add('charmSlots', s.charmSlots || 0, 0, 40);
  if (m.energyRegen) add('energyRegen', m.energyRegen, 0, 100);
  if (m.energyPerHit) add('energyPerHit', m.energyPerHit, 0, 100);
  if (m.run) add('run', m.run, 1, 30);
  if (m.jumpHeight) add('jumpHeight', m.jumpHeight, 0.5, 12);
  if (m.invTime) add('invTime', m.invTime, 0, 8);
  const mx = T.energyMax;
  if (mx > (G.mpm || 0)) G.mp = (G.mp || 0) + mx - (G.mpm || 0);
  G.mpm = mx;
  G.mp = Math.min(G.mp || 0, mx);
  const hm = G.hpm || 0;
  if (T.maxHp > hm && hm) G.hp += T.maxHp - hm;
  G.hpm = T.maxHp;
} // a bigger health bar arrives full
const STATN = { maxHp: 'Max health', energyMax: 'Max energy', charmSlots: 'Charm notches' };
function upgrade(stat, n) {
  if (!STATS[stat]) return false;
  const st = G.st;
  st.stats = st.stats || {};
  st.stats[stat] = Math.max(0, Math.min(STATS[stat][1], (st.stats[stat] || 0) + n));
  bonus();
  msg(STATN[stat] + (n >= 0 ? ' +' : ' ') + n);
  save();
  return true;
}
const dmgB = () => (G.chm && G.chm.mods.damage) || 0;
// Damage: after a hit you are invisible to damage for a while. A hazard also puts you back at the last checkpoint you touched in this room (or where you entered it).
function kill() {
  if (!G.p.dying) snd('die');
  const a = anims().die;
  if (a && !G.p.dying) {
    G.p.dying = Math.max(0.1, MV.PlayerSprite.len(a)) + 0.15;
    G.p.act = { s: 'die', t: 0, len: 99 };
    G.p.vx = 0;
    G.p.at = null;
    G.p.atk = 0;
    return 0;
  }
  return 'die';
}
// The body hitbox can be switched off for part of a move or attack (a dodge): nothing hurts the player then.
function bodyOff() {
  const p = G.p;
  return !!((p.at && MV.Attacks.isOff(p.at.a.body, p.at.t)) || (p.mhb && MV.Attacks.isOff(p.mhb.m.body, p.mhb.el)));
}
function hurtP(dmg, sx, haz, force, ovr) {
  const p = G.p,
    pr = G.tune;
  if (p.dying) return 0;
  if (!force && bodyOff()) return 0;
  const vul = !(p.inv > 0);
  if (!vul && !haz) return 0;
  if (vul) {
    dmg = Math.max(0, Math.round(dmg));
    G.cam.shake(haz ? 0.3 : 0.4);
    if (dmg > 0) {
      G.hp -= dmg;
      if (G.script) G.script.emit('hurt', { dmg });
      if (G.hp <= 0) {
        G.hp = 0;
        return kill();
      }
      act('hurt');
    }
    p.inv = Math.max(0.05, pr.invTime);
  }
  p.mv = null;
  p.mhb = null;
  p.at = null;
  p.atk = 0;
  p.cl = null;
  p.lg = p.rl = p.cn = null;
  if (vul && p.hw)
    G.mv.forEach(m => {
      if (m.type === 'hold' && (m.cost > 0 || m.drain > 0)) {
        delete p.hw[m.id];
        if (p.hd) delete p.hd[m.id];
      }
    }); // being hit breaks a charge that costs energy (a focus heal)
  if (haz) {
    if (API.boxes || API.debug) msg('A hazard (spikes or a fall) hurt you and put you back at the last safe spot.');
    const q = G.hz || p.sp;
    p.x = q.x;
    p.y = q.y;
    p.vx = p.vy = 0;
    p.kt = 0;
    p.on = false;
    p.cy = 0;
  } else if (vul) {
    {
      const kb = ovr ? ovr.k : pr.knockback;
      p.vx = p.kx = (p.x >= sx ? 1 : -1) * kb;
      p.vy = kb > 0 ? -Math.min(7, kb) : 0;
      p.kt = ovr ? ovr.s : pr.stun;
    }
    p.on = false;
    p.cy = 0;
  }
  return 0;
}
// Tile loading: a room with stream = N only keeps the tiles and things within N tiles of the player alive (drawn and running); the rest wait until the player gets close.
function live(e) {
  const s = G.room && G.room.stream;
  return !s || e.type === 'boss' || (Math.abs(e.cx - G.p.x) <= s && Math.abs(e.by - G.p.y) <= s + 1);
}
function tl(x, y) {
  const r = G.room;
  if (x < 0 || x >= r.gw || y < 0) return '#';
  if (y >= r.gh) return '.';
  const c = r.grid[y][x];
  const gh = G.p && G.p.gh;
  if (
    gh &&
    ((c === 's' && (gh === 'all' || gh.indexOf('soil') >= 0)) ||
      (c === 'w' && (gh === 'all' || gh.indexOf('ghost') >= 0)) ||
      (gh === 'all' && (c === '#' || c === '=' || c === '_' || BLOCKISH.indexOf(c) >= 0 || PR[c])))
  )
    return '.';
  return BLOCKISH.indexOf(c) >= 0 ? '#' : c;
} // shade wall, ice, mud, belts, bounce and invisible wall all collide like a wall
const raw = (x, y) => {
  const r = G.room;
  return x < 0 || x >= r.gw || y < 0 || y >= r.gh ? '' : r.grid[y][x];
}; // the tile as painted
// Walkable surface height of a tile at world x (slopes interpolate), or null if the tile is not a floor.
// Interact keys: a property holds a letter (E), a digit or a key code (Space, ArrowUp...). kc gives the key code, kl the label shown in the prompt.
const kc = v => {
    v = String(v || 'E');
    return /^[A-Za-z]$/.test(v) ? 'Key' + v.toUpperCase() : /^[0-9]$/.test(v) ? 'Digit' + v : v;
  },
  KL = {
    ArrowUp: '\u2191',
    ArrowDown: '\u2193',
    ArrowLeft: '\u2190',
    ArrowRight: '\u2192',
    Space: 'Space',
    Enter: 'Enter',
    Tab: 'Tab',
    ShiftLeft: 'Shift',
    ShiftRight: 'Shift',
    Backspace: 'Back'
  },
  kl = v => {
    const c = kc(v);
    return KL[c] || c.replace(/^(Key|Digit|Numpad)/, '');
  };
