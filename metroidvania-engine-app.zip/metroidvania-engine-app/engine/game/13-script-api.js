// ---- Scripts (see SCRIPTING.md): what a script's `game` object can do ----
// Everything here goes through the same functions the Events tab uses, so a script and an event behave the same way.
function scriptApi() {
  const S = () => G.st,
    H = () => G.ev.h,
    num = (v, d) => (isFinite(+v) ? +v : d);
  const proxy = e => {
    const o = {
      uid: e.uid,
      type: e.type,
      kind: e.kd || e.p.kind || '',
      x: e.cx,
      y: e.by,
      w: e.w,
      h: e.h,
      hp: e.hp,
      dead: !!e.dead,
      props: Object.assign({}, e.p),
      remove: () => {
        e.dead = true;
      },
      moveTo: (x, y) => {
        if (isFinite(+x)) e.cx = e.ox = +x;
        if (isFinite(+y)) e.by = e.oy = +y;
      },
      damage: n => {
        e.hp -= Math.max(0, num(n, 0));
        if (e.hp <= 0) e.dead = true;
      }
    };
    // settings of this one enemy or boss (the same names as in the Enemies and Bosses tabs): get(name) reads, set(name, value) changes it for this play
    o.get = name => {
      const d = e.kd ? MV.Enemies.find(G.ed, e.kd) : e.b ? e.b.def : null;
      if (!d || !(name in d) || typeof d[name] === 'object') return undefined;
      return e.ov && name in e.ov ? e.ov[name] : d[name];
    };
    o.set = (name, v) => {
      const table = e.kd ? MV.Enemies.FIELDS : e.b ? MV.data.bossFields : null,
        f = table && table[name];
      if (!f || name === 'brain' || name === 'ai') return false;
      if (f.t === 'number') {
        if (!isFinite(+v)) return false;
        v = Math.min(f.max, Math.max(f.min, +v));
      } else if (f.t === 'select') {
        if (!f.o.includes(v)) return false;
      } else return false;
      if (e.kd) (e.ov = e.ov || {})[name] = v;
      else e.b.def = Object.assign({}, e.b.def, { [name]: v });
      return true;
    };
    if (e.b)
      o.boss = { id: e.b.def.id, state: e.b.state, awake: e.b.awake, hpPercent: Math.round((e.hp / e.b.def.hp) * 100) };
    return o;
  };
  const player = {
    get x() {
      return G.p.x;
    },
    get y() {
      return G.p.y;
    },
    get vx() {
      return G.p.vx;
    },
    get vy() {
      return G.p.vy;
    },
    get face() {
      return G.p.face;
    },
    get onGround() {
      return !!G.p.on;
    },
    get dead() {
      return !!G.p.dying;
    },
    teleport: (x, y) => {
      if (isFinite(+x) && isFinite(+y)) {
        G.p.x = +x;
        G.p.y = +y;
        G.p.vx = G.p.vy = 0;
      }
    },
    push: (vx, vy) => {
      G.p.vx += num(vx, 0);
      G.p.vy += num(vy, 0);
      G.p.on = false;
    },
    freeze: sec => H().freeze(num(sec, 0)),
    // movement settings, for this play only: game.player.tune('jumpHeight') reads, game.player.tune('jumpHeight', 5) sets, tune(name, null) puts it back
    tune: (name, v) => {
      const f = MV.data.playerSchema[name];
      if (!f || typeof f.def !== 'number') return undefined;
      if (v === undefined) return G.tune[name];
      if (v === null) delete G.tuneSet[name];
      else if (isFinite(+v)) G.tuneSet[name] = Math.min(f.max, Math.max(f.min, +v));
      applyTuneSet();
      return G.tune[name];
    },
    tuneNames: () => Object.keys(MV.data.playerSchema).filter(k => typeof MV.data.playerSchema[k].def === 'number'),
    invulnerable: sec => {
      G.p.inv = Math.max(G.p.inv || 0, Math.min(10, Math.max(0, num(sec, 0))));
    },
    setVelocity: (vx, vy) => {
      G.p.vx = Math.min(60, Math.max(-60, num(vx, G.p.vx)));
      G.p.vy = Math.min(60, Math.max(-60, num(vy, G.p.vy)));
      if (G.p.vy < 0) G.p.on = false;
    }
  };
  return {
    player,
    // numbers: game.hp() reads, game.hp(5) sets
    hp: v => H().hp(v === undefined ? undefined : num(v, G.hp)),
    maxHp: () => G.tune.maxHp,
    heal: n => H().hp(Math.min(G.tune.maxHp, G.hp + num(n, 0))),
    hurt: n => H().hurt(num(n, 1)),
    energy: () => G.mp,
    addEnergy: n => H().energy(num(n, 0)),
    coins: v => H().coins(v === undefined ? undefined : Math.max(0, Math.round(num(v, 0)))),
    upgrade: (stat, n) => H().upgrade(String(stat), num(n, 1)),
    // flags and variables (the same ones the Events tab uses)
    flag: (name, on) => {
      const f = S().flags;
      if (on === undefined) return !!f[name];
      if (on) f[name] = 1;
      else delete f[name];
      return !!f[name];
    },
    variable: (name, v) => {
      const st = S();
      st.vars = st.vars || {};
      if (v === undefined) return st.vars[name] || 0;
      st.vars[name] = Math.max(-999999, Math.min(999999, Math.round(num(v, 0))));
      return st.vars[name];
    },
    // items and abilities
    itemCount: id => MV.Inventory.count(S(), id),
    give: (id, n) => {
      const def = MV.Inventory.find(H().items(), id);
      if (!def) return 0;
      const put = MV.Inventory.add(S(), def, Math.max(1, Math.round(num(n, 1))));
      if (put) msg('Got ' + (put > 1 ? put + ' x ' : '') + def.name);
      return put || 0;
    },
    take: (id, n) => MV.Inventory.take(S(), id, Math.max(1, Math.round(num(n, 1)))),
    giveWeapon: id => H().giveWeapon(String(id)),
    ability: (id, on) => {
      const a = S().abilities;
      if (on === undefined) return !!a[id];
      if (on) a[id] = true;
      else delete a[id];
      return !!a[id];
    },
    // talking and showing things
    say: text => msg(String(text)),
    dialogue: (text, who, done) => {
      const L = MV.Dialog.parse(String(text));
      if (L.length) H().dialogue(L, String(who || 'Someone'), typeof done === 'function' ? done : () => {});
    },
    sound: id => H().sound(String(id)),
    music: id => H().music(String(id)),
    shake: a => G.cam.shake(a),
    save: () => save(),
    // the world
    room: () => ({ id: G.room.id, name: G.room.n, w: G.room.gw, h: G.room.gh, area: G.area ? G.area.id : '' }),
    goRoom: (id, x, y) => H().goRoom(String(id), x, y),
    entities: type => G.en.filter(e => !e.dead && (type === undefined || e.type === type)).map(proxy),
    entity: uid => {
      const e = G.en.find(q => q.uid === uid);
      return e ? proxy(e) : null;
    },
    spawn: (type, x, y, props) => {
      if (!MV.data.entities[type] || !isFinite(+x) || !isFinite(+y)) return null;
      const e = mk(
        { type, x: Math.floor(+x), y: Math.floor(+y) - 1, props: props && typeof props === 'object' ? props : {} },
        'script:' + (G.spawnN = (G.spawnN || 0) + 1)
      );
      if (!e) return null;
      e.cx = e.ox = +x;
      e.by = e.oy = +y;
      G.en.push(e);
      return proxy(e);
    },
    event: id => {
      G.ev.call(String(id), 'script');
    },
    // input
    isDown: name => !!(held(name) || G.keys[name]),
    // the camera: the same object as MV.Game.camera
    camera: API.camera,
    random: () => Math.random(),
    tune: () => ({ maxHp: G.tune.maxHp, energyMax: G.tune.energyMax })
  };
}

// ---- Scripted AI and moves (see SCRIPTING.md) ----
// movement settings a script changed (game.player.tune): put back on top of the settings every frame
function applyTuneSet() {
  for (const k in G.tuneSet) G.tune[k] = G.tuneSet[k];
}
const sFin = (v, d) => (v !== null && v !== '' && isFinite(+v) ? +v : d);
const sClamp = (v, a, b) => Math.min(b, Math.max(a, v));
// a projectile that hurts the player, from a script (enemy or boss)
function enemyShot(o, n) {
  o = o || {};
  if (G.es.length >= 60) return;
  G.es.push({
    x: sFin(o.x, 0),
    y: sFin(o.y, 0),
    vx: sClamp(sFin(o.vx, 0), -40, 40),
    vy: sClamp(sFin(o.vy, 0), -40, 40),
    w: sClamp(sFin(o.size, 0.4), 0.1, 4),
    d: Math.max(0, sFin(o.damage, n || 1)),
    k: sFin(o.knock, 5),
    s: sFin(o.stun, 0.2),
    t: 0,
    c: typeof o.color === 'string' ? o.color : '#e24b4a'
  });
}
// Moves = Script on an enemy type: a script function steers it every frame. `me` is what the function can read and do.
function enemyBrain(e, d, dt, dx, dy, dist, see) {
  const p = G.p;
  e.mem = e.mem || {};
  const me = {
    dt,
    t: G.time,
    mem: e.mem,
    dx,
    dy,
    dist,
    sees: !!see,
    x: e.cx,
    y: e.by,
    w: e.w,
    h: e.h,
    hp: e.hp,
    maxHp: d.hp,
    onGround: !!e.on,
    bumpX: e.bump || 0,
    home: { x: e.ox, y: e.oy },
    player: { x: p.x, y: p.y },
    get vx() {
      return e.vx;
    },
    set vx(v) {
      e.vx = sClamp(sFin(v, 0), -40, 40);
    },
    get vy() {
      return e.vy;
    },
    set vy(v) {
      e.vy = sClamp(sFin(v, 0), -40, 40);
    },
    get dir() {
      return e.dir;
    },
    set dir(v) {
      e.dir = sFin(v, 1) < 0 ? -1 : 1;
    },
    fly: on => {
      e.sfly = !!on;
      if (!on) e.vy = e.vy || 0;
    },
    jump: power => {
      if (e.on) e.vy = -sClamp(sFin(power, 8), 0, 30);
    },
    shoot: (vx, vy, o) => {
      e.fire = 0.3;
      enemyShot(
        Object.assign(
          {
            x: e.cx + (e.dir * e.w) / 2,
            y: e.by - e.h / 2,
            damage: d.atkDmg || 1,
            knock: d.knock,
            stun: d.stun,
            color: d.color
          },
          o || {},
          { vx, vy }
        )
      );
    },
    hitbox: (x, y, w, h, dmg) => {
      (e.sbox = e.sbox || []).length < 10 &&
        e.sbox.push({
          sh: 'rect',
          cx: sFin(x, e.cx),
          cy: sFin(y, e.by - e.h / 2),
          w: sClamp(sFin(w, 1), 0.1, 30),
          h: sClamp(sFin(h, 1), 0.1, 30),
          d: sFin(dmg, d.damage)
        });
    },
    sound: id => {
      if (MV.Audio) MV.Audio.play(String(id));
    },
    die: () => {
      e.hp = 0;
      enemyDie(e, d);
    }
  };
  G.script.call(d.brain, me);
}
// Move type "Scripted": one frame of a move a script drives.
function scriptMoveStep(SIM, dt, M, end) {
  const { p, pr, R, L, dn } = SIM,
    m = M.m;
  M.el += dt;
  M.t -= dt;
  if (!m.script || !G.script || !G.script.has(m.script)) {
    if (G.script) G.script.call(m.script || '(none)', null); // reports "no script function called ..."
    end(1);
    return;
  }
  let ended = false,
    keep = m.keep;
  const me = {
    dt,
    t: M.el,
    left: Math.max(0, M.t),
    duration: m.duration,
    mem: M.sc.mem,
    dirX: (R ? 1 : 0) - (L ? 1 : 0),
    dirY: (dn ? 1 : 0) - (held('Up') ? 1 : 0),
    get x() {
      return p.x;
    },
    get y() {
      return p.y;
    },
    get vx() {
      return p.vx;
    },
    set vx(v) {
      p.vx = sClamp(sFin(v, 0), -60, 60);
    },
    get vy() {
      return p.vy;
    },
    set vy(v) {
      p.vy = sClamp(sFin(v, 0), -60, 60);
      if (p.vy < 0) {
        p.on = false;
        p.cy = 0;
      }
    },
    get facing() {
      return p.face;
    },
    set facing(v) {
      p.face = sFin(v, 1) < 0 ? -1 : 1;
    },
    get onGround() {
      return !!p.on;
    },
    get bumpX() {
      return !!p.bumpX;
    },
    get bumpY() {
      return !!p.bumpY;
    },
    held: name => !!held(String(name)),
    gravity: mult => {
      p.vy = Math.min(p.vy + pr.gravity * sClamp(sFin(mult, 1), 0, 10) * dt, pr.maxFall * 2);
    },
    hitbox: (x, y, w, h, dmg) => {
      G.shb = G.shb || [];
      if (G.shb.length < 20)
        G.shb.push({
          cx: p.x + p.face * sFin(x, 1),
          cy: p.y - pr.h / 2 + sFin(y, 0),
          w: sClamp(sFin(w, 1), 0.1, 30),
          h: sClamp(sFin(h, 1), 0.1, 30),
          d: sFin(dmg, m.damage),
          vis: null,
          t: 0
        });
    },
    invulnerable: sec => {
      p.inv = Math.max(p.inv || 0, sClamp(sFin(sec, 0), 0, 5));
    },
    sound: id => {
      if (MV.Audio) MV.Audio.play(String(id));
    },
    shake: a => G.cam.shake(a),
    end: k => {
      ended = true;
      keep = sFin(k, m.keep);
    }
  };
  G.script.call(m.script, me);
  if (!isFinite(p.vx)) p.vx = 0;
  if (!isFinite(p.vy)) p.vy = 0;
  if (ended || M.t <= 0) end(keep);
}
