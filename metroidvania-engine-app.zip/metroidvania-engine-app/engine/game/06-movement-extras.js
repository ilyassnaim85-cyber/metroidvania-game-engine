// Is there room to stand up at the player's spot (used when a roll ends under a low gap)?
// ---- More movement: free boxes and popping out, ledges, ropes (in the grapple code), rails, cannons, mounts and drowning ----
const freeBox = (x, y, w, h) => {
  for (let ty = Math.floor(y - h); ty <= Math.floor(y - 0.05); ty++)
    for (let tx = Math.floor(x - w / 2); tx <= Math.floor(x + w / 2); tx++) if (tl(tx, ty) === '#') return false;
  return true;
};
function popOut(p, w, h) {
  let best = null,
    bd = 1e9; // the nearest spot where the whole body fits
  for (let dy = -14; dy <= 14; dy += 0.25)
    for (let dx = -14; dx <= 14; dx += 0.25) {
      const d = dx * dx + dy * dy;
      if (d >= bd) continue;
      const nx = p.x + dx,
        ny = p.y + dy;
      if (nx < w / 2 || nx > G.room.gw - w / 2 || ny < h || ny > G.room.gh) continue;
      if (freeBox(nx, ny, w, h)) {
        bd = d;
        best = [nx, ny];
      }
    }
  if (!best) return false;
  p.x = best[0];
  p.y = best[1];
  p.vx = p.vy = 0;
  return true;
}
function railGeom(e) {
  const ax = e.ox,
    ay = e.oy - 0.5,
    dx = +e.p.dx || 0,
    dy = +e.p.dy || 0,
    len = Math.max(0.01, Math.hypot(dx, dy));
  return { ax, ay, bx: ax + dx, by: ay + dy, len, ux: dx / len, uy: dy / len };
}
function ledgeTick(dt, dir) {
  const p = G.p,
    L = p.lg,
    m = L.m,
    pr = G.tune;
  L.t += dt;
  p.vx = p.vy = 0;
  p.on = false;
  p.cy = 0;
  p.face = L.s;
  if (L.ph === 'hang') {
    p.xs = 'ledge';
    if (m.slide > 0) {
      L.dy += m.slide * dt;
      p.y = L.y0 + L.dy;
    }
    if (G.jb > 0 && dir === -L.s) {
      G.jb = 0;
      p.lg = null;
      p.lgcd = 0.3;
      p.vy = -Math.sqrt(2 * pr.gravity * pr.jumpHeight) * 0.9;
      p.kx = -L.s * m.kick;
      p.kt = 0.18;
      p.face = -L.s;
      return;
    } // Jump while holding away from the wall: leap off
    if ((G.jb > 0 || held('Up')) && L.canClimb) {
      G.jb = 0;
      L.ph = 'climb';
      L.ct = 0;
      L.cy0 = p.y;
      L.x0 = p.x;
      return;
    }
    if (held('Down') || (m.fuel > 0 && L.t >= m.fuel) || L.dy > m.grab + 0.3) {
      p.lg = null;
      p.lgcd = 0.25;
      G.jb = 0;
    }
  } else {
    p.xs = 'pullup';
    L.ct += dt;
    const f = Math.min(1, L.ct / Math.max(0.05, m.climb)),
      f1 = Math.min(1, f / 0.65),
      f2 = Math.max(0, (f - 0.65) / 0.35);
    p.y = L.cy0 + (L.ty - L.cy0) * f1;
    p.x = L.x0 + (L.tx - L.x0) * f2;
    if (f >= 1) {
      p.x = L.tx;
      p.y = L.ty;
      p.on = true;
      p.cy = pr.coyote;
      p.lg = null;
      p.lgcd = 0.3;
    }
  }
}
function railTick(dt, dir) {
  const p = G.p,
    RL = p.rl,
    e = RL.e,
    q = railGeom(e),
    pr = G.tune,
    H = pr.h * (p.hq || 1),
    hang = e.p.hang !== 'stand on top',
    sp = Math.max(1, +e.p.speed || 9),
    ac = Math.max(1, +e.p.accel || 14);
  RL.t += dt;
  if (e.p.mode === 'steer with Left and Right') {
    const want =
        Math.abs(q.ux) >= 0.2
          ? dir * Math.sign(q.ux)
          : ((held('Down') ? 1 : 0) - (held('Up') ? 1 : 0)) * Math.sign(q.uy),
      tv = want * sp;
    RL.v += Math.max(-ac * dt, Math.min(ac * dt, tv - RL.v));
    if (!want) RL.v *= Math.max(0, 1 - 2 * dt);
  } else RL.v = Math.min(sp, RL.v + ac * dt);
  RL.s += RL.v * dt;
  const out = RL.s >= q.len || RL.s <= 0;
  RL.s = Math.max(0, Math.min(q.len, RL.s));
  const tx = q.ax + q.ux * RL.s,
    ty0 = q.ay + q.uy * RL.s,
    ty = hang ? ty0 + H * 0.98 : ty0;
  p.vx = (tx - p.x) / dt;
  p.vy = (ty - p.y) / dt;
  p.on = false;
  p.cy = 0;
  p.xs = hang ? 'zip' : '';
  if (dir) p.face = dir;
  else if (Math.abs(RL.v * q.ux) > 0.5) p.face = Math.sign(RL.v * q.ux);
  const off = hop => {
    p.rl = null;
    p.rlcd = 0.35;
    p.vx = q.ux * RL.v;
    p.vy = q.uy * RL.v + (hop ? -Math.sqrt(2 * pr.gravity * pr.jumpHeight * 0.7) : 0);
    p.kx = p.vx;
    p.kt = 0.25;
    p.on = false;
  };
  if (G.jb > 0 && !(held('Up') && !hang)) {
    G.jb = 0;
    off(true);
  } else if (hang && held('Down')) off(false);
  else if (out) off(false);
  else if (RL.t > 0.3 && Math.hypot(tx - p.x, ty - p.y) > 1.2) off(false);
}
function cannonAng(e, dt, dir, loaded) {
  const P = e.p,
    base = +P.angle || 0,
    sw = Math.max(0, +P.sweep || 0),
    tr = Math.max(1, +P.turn || 90);
  if (P.aim === 'swings back and forth' && sw > 0) {
    const u = 1 - Math.abs((((((G.time * tr) / (2 * sw)) % 2) + 2) % 2) - 1);
    e.ang = base - sw + 2 * sw * u;
  } else if (P.aim === 'Left and Right') {
    if (e.ang === undefined) e.ang = base;
    if (loaded) e.ang -= dir * tr * dt;
    e.ang = Math.max(base - sw, Math.min(base + sw, e.ang));
  } else e.ang = base;
}
function cannonTick(dt, dir) {
  const p = G.p,
    C = p.cn,
    e = C.e,
    P = e.p,
    pr = G.tune;
  C.t += dt;
  cannonAng(e, dt, dir, true);
  p.x = e.cx;
  p.y = e.by - e.h / 2 + (pr.h * (p.hq || 1)) / 2;
  p.vx = p.vy = 0;
  p.on = false;
  p.cy = 0;
  p.xs = 'cannon';
  const byKey = P.fire === 'press a key',
    kk = kc(P.key);
  e.prompt = byKey ? kl(P.key) : '';
  if (byKey ? G.pr[kk] > 0 && C.t > 0.1 : C.t >= Math.max(0.1, +P.delay || 0.8)) {
    const a = (e.ang * Math.PI) / 180,
      pw = Math.max(1, +P.power || 24);
    p.cn = null;
    e.cd = Math.max(0.2, +P.reload || 1);
    e.fl = 0.25;
    e.prompt = '';
    if (byKey) G.pr[kk] = 0;
    p.vx = Math.cos(a) * pw;
    p.vy = -Math.sin(a) * pw;
    p.kx = p.vx;
    p.kt = Math.max(0, +P.flight || 0.5);
    if (Math.abs(p.vx) > 0.1) p.face = p.vx < 0 ? -1 : 1;
    p.on = false;
    G.cam.shake(0.2);
  }
}
function drownHit() {
  const p = G.p,
    pr = G.tune;
  if (p.dying) return 0;
  G.hp -= Math.max(1, Math.round(pr.drownDmg));
  G.cam.shake(0.25);
  if (G.hp <= 0) {
    G.hp = 0;
    return kill();
  }
  act('hurt');
  return 0;
}
function mountUp(e) {
  const p = G.p,
    P = e.p;
  if (!freeBox(e.cx, e.by, e.w, e.h)) {
    msg('There is no room to ride here');
    return false;
  }
  p.ride = {
    e,
    kind: P.kind === 'flies' || P.kind === 'swims' ? P.kind : 'walks',
    speed: Math.max(1, +P.speed || 8),
    jump: Math.max(0, +P.jump || 0),
    grav: isFinite(+P.gravity) ? Math.max(0, +P.gravity) : 1,
    t: 0
  };
  p.x = e.cx;
  p.y = e.by;
  p.vx = p.vy = 0;
  p.mv = null;
  p.cl = null;
  p.lg = p.rl = p.cn = null;
  p.on = false;
  e.ridden = true;
  msg('Riding ' + (P.name || 'the mount') + ' (' + kl(P.key) + ' to get off)');
  return true;
}
function dismount() {
  const p = G.p,
    RD = p.ride;
  if (!RD) return;
  const e = RD.e;
  p.ride = null;
  e.ridden = false;
  e.cx = e.ox = p.x;
  e.by = e.oy = p.y;
  p.vx = p.vy = 0;
  msg('Got off ' + (e.p.name || 'the mount'));
}
function rideTune() {
  const RD = G.p.ride,
    e = RD.e,
    T = G.tune;
  G.tune = Object.assign({}, T, {
    w: e.w,
    h: e.h,
    run: RD.speed,
    gravity: T.gravity * RD.grav,
    jumpHeight: Math.max(0.5, RD.jump)
  });
}
function roomAbove(p, pr) {
  for (let ty = Math.floor(p.y - pr.h); ty <= Math.floor(p.y - 0.05); ty++)
    for (let tx = Math.floor(p.x - pr.w / 2); tx <= Math.floor(p.x + pr.w / 2); tx++)
      if (tl(tx, ty) === '#') return false;
  return true;
}
// Going through a door: instant by default; a camera profile with a door transition (fade, wipe, iris) hides the room change behind it.
function doorGo(tg, from) {
  const p = camCfg().p || {},
    fx = p.doorFx,
    cam = G.cam;
  if (G.trn) return;
  if (!fx || fx === 'none') {
    load(tg, from);
    return;
  }
  G.trn = true;
  cam.transition(
    fx,
    +p.doorTime || 0.5,
    () => {
      if (G && G.cam === cam) load(tg, from);
    },
    { fx: 0.5, fy: 0.5 }
  );
}
