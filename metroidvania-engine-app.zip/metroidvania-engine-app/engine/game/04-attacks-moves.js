function tryAttack(a, force, pw) {
  const p = G.p;
  if (
    force
      ? p.at || (a.requires && !can(a.requires))
      : p.atk > 0 ||
        p.nj ||
        !withOk(a) ||
        !wOk(a) ||
        (a.requires && !can(a.requires)) ||
        !okWhere(a, p) ||
        (p.acds[a.id] || 0) > 0
  )
    return false;
  if (a.cost > 0 && !afford(a.cost)) {
    if (!force) noMp();
    return false;
  }
  spend(a.cost);
  p.at = { a, t: 0, face: p.face, pw: pw || 0 };
  p.atk = a.duration;
  p.acds[a.id] = a.duration + a.cooldown;
  if (a.anim) p.fx = { a: a.anim, t: 0, dash: false, fit: true, len: a.duration };
  return true;
}
// Start a move if its rules allow it (unlocked, usable here, off cooldown, uses left). Returns true when it started.
const TIMED = ['dash', 'roll', 'grapple', 'bash', 'path', 'sequence', 'scripted']; // moves that play over time
// In the test room: why a move did not start when its key was pressed (so a move that "does nothing" explains itself).
function moveWhy(m) {
  const p = G.p;
  if (!m || !p) return '';
  if (m.requires && !can(m.requires))
    return (
      'it needs the ability "' +
      m.requires +
      '" (the test room gives you every ability a pickup can give, but not ones nothing gives)'
    );
  if (p.mv && TIMED.includes(m.type)) return 'another move is still playing';
  if (m.type === 'bash' && !bashOrb(m)) return 'no ready Bash orb within Hook reach (' + m.reach + ' tiles)';
  if (!withOk(m)) return 'one of its "Also hold" keys is not held';
  if (!okWhere(m, p))
    return (
      'Usable is "' +
      m.where +
      '" and you are ' +
      (m.where === 'water' ? 'not in water' : p.on ? 'on the ground' : 'in the air')
    );
  if ((p.mcd[m.id] || 0) > 0) return 'it is still cooling down (' + p.mcd[m.id].toFixed(1) + ' s left)';
  if (m.uses > 0 && (p.muse[m.id] || 0) >= m.uses)
    return 'it is used up until you land (Uses per air time = ' + m.uses + ')';
  return '';
}
function tryMove(m, force, pw) {
  const p = G.p,
    k = G.keys;
  if (m.type === 'hold' || m.type === 'surface' || m.type === 'swim' || m.type === 'ledge') return false;
  if (m.type === 'throw' && G.thr && G.thr.m.id !== m.id) return false; // (moves are re-read every frame, so compare ids, not objects)
  if (m.type === 'throw' && !force && G.thr && G.thr.m.id === m.id && (!m.requires || can(m.requires)))
    return teleportToItem(m); // second press: go to the thrown item
  if (
    (p.mv && TIMED.includes(m.type)) ||
    (m.requires && !can(m.requires)) ||
    (!force &&
      (!withOk(m) || !okWhere(m, p) || (p.mcd[m.id] || 0) > 0 || (m.uses > 0 && (p.muse[m.id] || 0) >= m.uses)))
  )
    return false;
  if (m.cost > 0 && !afford(m.cost)) {
    if (!force) noMp();
    return false;
  }
  if ((p.lg || p.rl || p.cn) && (m.type !== 'bash' || bashOrb(m))) {
    p.lg = p.rl = p.cn = null;
    p.lgcd = p.rlcd = 0.3;
  } // a move started while you hang, ride or sit in a cannon lets you go first
  let dx = p.face,
    dy = 0;
  if (m.dir === 'up') {
    dx = 0;
    dy = -1;
  } else if (m.dir === 'down') {
    dx = 0;
    dy = 1;
  } else if (m.dir === 'input') {
    const ix = (held('Right') ? 1 : 0) - (held('Left') ? 1 : 0),
      iy = (held('Down') ? 1 : 0) - (held('Up') ? 1 : 0),
      n = Math.hypot(ix, iy);
    if (n) {
      dx = ix / n;
      dy = iy / n;
    }
  } else if (m.dir === 'fixed') {
    const a = (m.angle * Math.PI) / 180;
    dx = Math.cos(a) * p.face;
    dy = -Math.sin(a);
  }
  if (m.sprite && (TIMED.includes(m.type) || m.type === 'impulse'))
    p.fx = {
      a: m.sprite,
      t: 0,
      dash: m.type !== 'impulse',
      len: m.type !== 'impulse' ? Math.max(0.05, m.duration) : m.sprite.frames / m.sprite.fps
    };
  if (m.hit.length || m.body.off.length || m.body.kf.length || m.shots.length || m.effects.length || m.chainTo)
    p.mhb = { m, el: 0, len: Math.max(0.05, m.duration), face: p.face, pw: pw || 0 };
  if (m.type === 'bash') {
    const o = bashOrb(m);
    if (!o) return false; // needs an orb in reach; nothing is spent without one
    o.bsh = G.time + 0.6;
    spend(m.cost);
    p.mcd[m.id] = m.cooldown;
    if (m.uses > 0) p.muse[m.id] = (p.muse[m.id] || 0) + 1;
    p.mv = { m, dx: 0, dy: 0, t: m.duration + m.aim + 1, el: 0, b: { ph: 'aim', o, t: 0 } };
    p.vx = p.vy = 0;
    p.cl = null;
    p.mv.pw = pw || 0;
    return true;
  }
  if (m.type === 'throw') {
    if (G.thr) return false;
    spend(m.cost);
    const n = Math.hypot(dx, dy) || 1;
    if (m.uses > 0) p.muse[m.id] = (p.muse[m.id] || 0) + 1;
    G.thr = {
      m,
      x: p.x,
      y: p.y - G.tune.h / 2,
      vx: (dx / n) * m.speed,
      vy: (dy / n) * m.speed,
      d: 0,
      rest: false,
      t: 0
    };
    return true;
  }
  spend(m.cost);
  p.mcd[m.id] = m.cooldown;
  if (m.uses > 0) p.muse[m.id] = (p.muse[m.id] || 0) + 1;
  if (m.type === 'grapple') {
    // the hook flies out from the middle of the body, sticks to a wall or a Grapple point, then pulls you
    const n = Math.hypot(dx, dy) || 1;
    p.mv = {
      m,
      dx: 0,
      dy: 0,
      t: Math.max(m.duration, m.reach / m.hook + m.reach / Math.max(2, m.pull * 0.3) + 1),
      el: 0,
      g: {
        ph: 'out',
        sx: p.x,
        sy: p.y - G.tune.h / 2,
        ux: dx / n,
        uy: dy / n,
        len: 0,
        tx: p.x,
        ty: p.y - G.tune.h / 2
      }
    };
    if (m.how !== 'swing') p.vx = p.vy = 0;
    p.cl = null;
  } else if (m.type === 'path' || ((m.type === 'dash' || m.type === 'roll') && m.path.length > 1)) {
    p.mv = { m, dx: 0, dy: 0, t: m.duration, el: 0, tau: 0, x0: p.x, y0: p.y, face: p.face, path: true };
    p.cl = null;
    p.on = false;
    p.cy = 0;
  } else if (m.type === 'scripted') {
    p.mv = { m, dx, dy, t: Math.max(0.05, m.duration), el: 0, face: p.face, sc: { mem: {} } };
    p.cl = null;
  } else if (m.type === 'sequence') {
    p.mv = { m, dx: p.face, dy: 0, t: m.duration, el: 0, face: p.face, seq: { i: 0, t: 0 } };
    p.cl = null;
  } else if (m.type === 'dash' || m.type === 'roll') {
    p.mv = { m, dx: m.type === 'roll' ? p.face : dx, dy: m.type === 'roll' ? 0 : dy, t: m.duration, el: 0 };
    p.vx = p.mv.dx * m.speed;
    p.vy = p.mv.dy * m.speed;
  } else {
    p.vx = dx ? dx * m.speed : p.vx * m.keep;
    p.vy = dy ? dy * m.speed : p.vy * m.keep;
    p.on = false;
    p.cy = 0;
  }
  if (p.mv) p.mv.pw = pw || 0;
  return true;
}
// Bash: the closest ready Bash orb within reach. Throw: teleport to the thrown item (a little higher if the spot is tight).
function bashOrb(m) {
  const p = G.p,
    cy = p.y - G.tune.h / 2;
  let best = null,
    bd = m.reach;
  G.en.forEach(e => {
    if (e.type !== 'bashpoint' || e.dead || (e.bcd || 0) > 0) return;
    const d = Math.hypot(e.cx - p.x, e.by - e.h / 2 - cy);
    if (d <= bd) {
      bd = d;
      best = e;
    }
  });
  return best;
}
function teleportToItem(m) {
  const p = G.p,
    it = G.thr,
    pr = G.tune,
    fy = it.y + pr.h / 2;
  let best = null,
    bd = 1e9; // the nearest spot around the item where the whole body fits (an item that landed against a wall puts you beside it)
  for (let dx = -2; dx <= 2; dx += 0.125)
    for (let dy = -2; dy <= 1; dy += 0.125) {
      const d = Math.hypot(dx, dy * 1.2);
      if (d < bd && freeAt(it.x + dx, fy + dy) && it.x + dx > pr.w / 2 && it.x + dx < G.room.gw - pr.w / 2) {
        bd = d;
        best = { x: it.x + dx, y: fy + dy };
      }
    }
  if (!best) {
    if (API.boxes || API.debug) msg('There is no room for you around the item.');
    return false;
  }
  const ty = best.y;
  p.x = best.x;
  p.y = ty;
  p.vx = p.vy = 0;
  p.mv = null;
  p.cl = null;
  p.on = false;
  p.cy = 0;
  G.thr = null;
  p.mcd[m.id] = m.cooldown;
  G.cam.shake(0.04);
  return true;
}
