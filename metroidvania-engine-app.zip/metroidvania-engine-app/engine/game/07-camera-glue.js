// ---- camera: profiles, zones, and the ledge the player stands at ----
// Which profile is in use: a Camera zone around the player's middle (the smallest one wins), else one set by script (MV.Game.camera.set), else the room's own.
function camCfg(at) {
  const r = G.room,
    rc = r.cam || {},
    p = at || G.p;
  let id = G.camSet ? G.camSet.id : rc.profile || (rc.mode === 'fixed' ? 'locked' : 'default'),
    blend = G.camSet ? G.camSet.blend : 0.8,
    box = null,
    brk = false,
    zk = '';
  let z = null,
    za = 1e9;
  if (p)
    G.en.forEach(e => {
      if (e.type !== 'camzone' || e.dead) return;
      const px = p.x,
        py = p.y - G.tune.h / 2;
      if (Math.abs(px - e.cx) <= e.w / 2 && py >= e.by - e.h && py <= e.by && e.w * e.h < za) {
        z = e;
        za = e.w * e.h;
      }
    });
  G.camZone = z;
  if (z) {
    zk = z.uid;
    if (z.p.profile) id = z.p.profile;
    if (isFinite(+z.p.blend) && +z.p.blend >= 0) blend = +z.p.blend;
    if (z.p.bounds === 'limit view to this box') box = [z.cx - z.w / 2, z.by - z.h, z.cx + z.w / 2, z.by];
    else if (z.p.bounds === 'break room limits') brk = true;
  }
  return {
    id: id + '|' + zk,
    blend,
    p: MV.Camera.profile(id, G.world && G.world.camProfiles),
    follow: typeof rc.follow === 'number' ? rc.follow : null,
    box,
    brk,
    mode: rc.mode
  };
}
// Is the player standing at the edge of a drop (in the direction they push or face)? Used by the camera's ledge hint.
function ledgeNear() {
  const p = G.p,
    pr = G.tune;
  if (!p || !p.on || p.dying || p.mv || p.cl || p.lg || p.rl || p.cn || !(pr.camLedgeLook > 0)) return false;
  const dir = (held('Right') ? 1 : 0) - (held('Left') ? 1 : 0),
    s = dir || p.face || 1,
    tx = Math.floor(p.x + s * (pr.w / 2 + (pr.camLedgeReach || 0))),
    y0 = Math.floor(p.y + 0.01),
    need = Math.max(1, Math.round(pr.camLedgeDepth || 3)),
    r = G.room;
  if (tx < 0 || tx >= r.gw) return false;
  for (let d = 0; d < need; d++) {
    const y = y0 + d;
    if (y >= r.gh) return true;
    const c = tl(tx, y);
    if (c === '#' || c === '=' || PR[c]) return false;
  }
  return true;
}
const camPl = () => {
  const p = G.p;
  return {
    face: p.face,
    vx: p.vx,
    vy: p.vy,
    on: p.on,
    up: held('Up'),
    dn: held('Down'),
    dir: (held('Right') ? 1 : 0) - (held('Left') ? 1 : 0),
    ledge: ledgeNear()
  };
};
