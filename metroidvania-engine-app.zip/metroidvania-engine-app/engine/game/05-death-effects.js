// Death: the "You died" screen (if set), then the rules from Settings, Death: health and energy you come back with, coins you drop where you fell.
function die(late) {
  if (!late) {
    if (G.ev) G.ev.emit('death');
    G.cam.shake(0.6);
    if (G.tune.deathScreen > 0) {
      const p = G.p;
      p.vx = p.vy = 0;
      p.dying = 0;
      p.act = null;
      p.mv = null;
      p.mhb = null;
      p.at = null;
      p.atk = 0;
      G.dscr = { t: 0, len: G.tune.deathScreen };
      return true;
    }
  }
  const pr = G.tune,
    st = G.st;
  G.status = {};
  G.hp = Math.max(1, Math.round((pr.maxHp * pr.respawnHp) / 100));
  G.mp = Math.round((pr.energyMax * pr.respawnEnergy) / 100);
  G.hpm = pr.maxHp;
  const lost = Math.floor((G.coins * pr.coinsLost) / 100);
  if (lost > 0) {
    G.coins -= lost;
    if (pr.coinsRecover >= 1 && G.room && G.area) {
      st.lostCoins = { a: G.area.id, r: G.room.id, x: G.p.x, y: G.p.y, n: lost };
      save();
      msg('You dropped ' + lost + ' coin' + (lost > 1 ? 's' : '') + ' where you fell');
    } else msg('You lost ' + lost + ' coin' + (lost > 1 ? 's' : ''));
  }
  if (G.p.hw) G.p.hw = {};
  G.p.hd = {};
  G.dfade = { t: 0, len: 0.5 };
  G.en.forEach(e => {
    if (e.type === 'boss' && e.b && !e.dead && e.b.awake && e.b.def.restart === 'yes') MV.Boss.reset(e);
  }); // a boss you did not beat starts over
  const cp = G.st.cp,
    rm = cp && MV.Progress.find(G.world, cp.a, cp.r);
  if (rm) {
    load(rm, null, cp);
    return false;
  }
  const p = G.p;
  p.x = p.sp.x;
  p.y = p.sp.y;
  p.vx = p.vy = 0;
  p.mv = null;
  p.mhb = null;
  p.at = null;
  p.atk = 0;
  p.act = null;
  p.lg = p.rl = p.cn = null;
  p.ride = null;
  p.air = undefined;
  p.gh = '';
  p.dying = 0;
  p.inv = 0;
  p.kt = 0;
  return true;
}
// ---- Events, effects, shots, combos and charging ----
const isAtk = o => 'hitboxes' in o,
  chainTarget = id => {
    const n = String(id).slice(2);
    return id[0] === 'm' ? G.mv.find(m => m.id === n) : G.at.find(a => a.id === n);
  };
const keyIs = (o, code) =>
  (o.key !== 'None' && codesOf(o.key).includes(code)) || code === 'Pad:' + (isAtk(o) ? 'a:' : 'm:') + o.id;
const startChain = (o, pw) => (isAtk(o) ? tryAttack(o, true, pw) : tryMove(o, true, pw));
const freeAt = (x, y) => {
  const pr = G.tune;
  for (let ty = Math.floor(y - pr.h); ty <= Math.floor(y - 0.05); ty++)
    for (let tx = Math.floor(x - pr.w / 2); tx <= Math.floor(x + pr.w / 2); tx++) if (tl(tx, ty) === '#') return false;
  return true;
};
function spawnShot(s, q) {
  const a = (s.angle * Math.PI) / 180,
    f = q.face || G.p.face,
    sp = s.speed * (1 + (q.pw || 0) * 0.5);
  if (G.shots.length < 60)
    G.shots.push({
      s,
      x: G.p.x + f * s.ox,
      y: G.p.y + s.oy,
      vx: f * Math.cos(a) * sp,
      vy: -Math.sin(a) * sp,
      t: 0,
      ty: q.o.dtype,
      inf: q.o.inflict,
      it: q.o.inflictTime,
      d: s.damage * (1 + ((q.o.chargeMult || 1) - 1) * (q.pw || 0))
    });
}
function fireFx(q, on) {
  (q.o.effects || []).forEach(f => {
    if (f.on === on) applyFx(f);
  });
}
function applyFx(f) {
  const p = G.p;
  if (f.do === 'bounce') {
    p.mv = null;
    p.vy = -Math.abs(f.value);
    p.on = false;
    p.cy = 0;
  } else if (f.do === 'refill') {
    p.muse = {};
    for (const k in p.mcd) p.mcd[k] = 0;
    for (const k in p.acds) p.acds[k] = 0;
  } else if (f.do === 'sound') {
    if (MV.Audio) MV.Audio.play(f.snd);
  } else if (f.do === 'slow') G.slow = { f: Math.min(1, Math.max(0.05, Math.abs(f.value))), t: 0.35 };
  else if (f.do === 'teleport') {
    for (let d = Math.abs(f.value); d > 0; d -= 0.25) {
      const nx = p.x + p.face * d;
      if (freeAt(nx, p.y)) {
        p.x = nx;
        break;
      }
    }
  } else if (f.do === 'knock') {
    p.vx = p.kx = -p.face * f.value;
    p.kt = 0.15;
  } else if (f.do === 'energy') gain(f.value);
  else if (f.do === 'heal') G.hp = Math.min(G.tune.maxHp, G.hp + Math.round(f.value));
  else if (f.do === 'endmove') {
    p.mv = null;
    p.at = null;
    p.atk = 0;
    p.mhb = null;
  }
}
function onHit() {
  gain(G.tune.energyPerHit);
  (G.own || []).forEach(q => {
    if (q.hcd <= 0) {
      q.hcd = 0.12;
      fireFx(q, 'hit');
    }
  });
}
// A key pressed near the end of a move or attack (or just after it) that is the key of the one it chains to starts that one at once, or as soon as the first ends.
function chainPress(code) {
  const p = G.p;
  for (const q of G.own || []) {
    const o = q.o;
    if (!o.chainTo) continue;
    const t = chainTarget(o.chainTo);
    if (!t || !keyIs(t, code) || o.duration - q.clk > o.chainWin) continue;
    p.cq = { from: o, t };
    return true;
  }
  const le = p.lastEnd;
  if (le && le.o.chainTo && G.time - le.t <= le.o.chainWin) {
    const t = chainTarget(le.o.chainTo);
    if (t && keyIs(t, code) && startChain(t, 0)) {
      p.lastEnd = null;
      return true;
    }
  }
  return false;
}
