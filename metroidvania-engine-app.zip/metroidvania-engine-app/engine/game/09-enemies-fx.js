// Light zones: the shape (a circle or a polygon, like a lamp) and whether a point is inside it.
const lzShape = e => MV.Light.geom({ x: e.ox - 0.5, y: e.oy - 1, props: e.p });
function lzIn(e, px, py) {
  const g = lzShape(e);
  if (g.shape !== 'polygon') return Math.hypot(px - g.x, py - g.y) <= g.r;
  let c = false;
  const P = g.pts;
  for (let i = 0, j = P.length - 1; i < P.length; j = i++)
    if (P[i][1] > py !== P[j][1] > py && px < ((P[j][0] - P[i][0]) * (py - P[i][1])) / (P[j][1] - P[i][1]) + P[i][0])
      c = !c;
  return c;
}
// Entity skins: most entities can play one of your Animations clips per state (MV.data.skins says which states); sign, sign (press key) and ladder show one still sprite.
// Without a clip an entity keeps its built-in look (stone bricks that crack for walls and collapsing ground, coloured boxes for the rest).
const ty = e => e.sk || e.type,
  SKINS = () => D().skins || {},
  TILED = () => D().skinTiled || [],
  REST = t => Object.keys(SKINS()[t] || {})[0];
const SK_HOLD = { open: 1, on: 1, revealed: 1, active: 1 },
  SK_ONCE = { hit: 1, bounce: 1, fall: 1, fire: 1, used: 1, collected: 1, triggered: 1 },
  SK_DIM = { open: 0.5, used: 0.3 };
// ---- Enemies made in the Enemies tab (types in G.ed). The damage rules shared with bosses are in MV.Actor. ----
const SOLE = '#_' + BLOCKISH,
  rcell = (tx, ty2) => {
    const r = G.room;
    return tx < 0 || tx >= r.gw || ty2 < 0 ? '#' : ty2 >= r.gh ? '.' : r.grid[ty2][tx];
  };
const eSolid = (x, y) => SOLE.indexOf(rcell(Math.floor(x), Math.floor(y))) >= 0;
function eHit(e, cx, by) {
  const x0 = Math.floor(cx - e.w / 2 + 1e-3),
    x1 = Math.floor(cx + e.w / 2 - 1e-3),
    y0 = Math.floor(by - e.h + 1e-3),
    y1 = Math.floor(by - 1e-3);
  for (let ty2 = y0; ty2 <= y1; ty2++)
    for (let tx = x0; tx <= x1; tx++) if (SOLE.indexOf(rcell(tx, ty2)) >= 0) return true;
  return false;
}
const eFloor = (e, x, by) => {
  const c = rcell(Math.floor(x), Math.floor(by + 0.1));
  return SOLE.indexOf(c) >= 0 || c === '=';
};
function eMove(e, dt, grav) {
  const ox = e.cx;
  e.cx += e.vx * dt;
  e.bump = 0;
  if (eHit(e, e.cx, e.by)) {
    e.cx = ox;
    e.bump = e.vx > 0 ? 1 : -1;
    e.vx = 0;
  }
  if (grav) e.vy = Math.min(25, e.vy + 40 * dt);
  const oy = e.by;
  e.by += e.vy * dt;
  if (eHit(e, e.cx, e.by)) {
    if (e.vy > 0) {
      e.by = Math.floor(e.by - 1e-3);
    } else if (e.vy < 0) {
      e.by = Math.floor(e.by - e.h) + 1 + e.h;
    } else e.by = oy;
    e.vy = 0;
  } else if (grav && e.vy > 0) {
    const row = Math.floor(e.by - 1e-3);
    if (rcell(Math.floor(e.cx), row) === '=' && oy <= row + 1e-3) {
      e.by = row;
      e.vy = 0;
    }
  }
  e.on =
    e.vy >= 0 &&
    (eHit(e, e.cx, e.by + 0.06) ||
      (rcell(Math.floor(e.cx), Math.floor(e.by + 0.06)) === '=' &&
        Math.floor(e.by + 0.06) >= e.by - 1e-3 &&
        Math.abs(e.by - Math.round(e.by)) < 0.02));
}
const eSnd = (d, k) => {
  const id = d.snds && d.snds[k];
  if (id && MV.Audio) MV.Audio.play(id);
};
function enemyDie(e, d) {
  e.dead = true;
  eSnd(d, 'dieSnd');
  const st = G.st;
  if (d.coins > 0) G.coins += d.coins;
  if (d.energy > 0) gain(d.energy);
  if (d.dropItem && Math.random() * 100 < d.dropPct) {
    const def = MV.Inventory.find(G.items, d.dropItem);
    if (def && MV.Inventory.add(st, def, 1)) msg('Got ' + def.name);
  }
  const cl = d.clips.die && MV.Anim.find(G.world.anims, d.clips.die);
  if (cl && cl.frames.length)
    G.fx.push({
      k: 'clip',
      cl,
      t: 0,
      e: { sk: 'enemy', type: 'enemy', w: e.w * d.scale, h: e.h * d.scale },
      cx: e.cx,
      by: e.by
    });
  else
    for (let i = 0; i < 10; i++)
      G.fx.push({
        k: 'chip',
        t: 0,
        x: e.cx + (Math.random() - 0.5) * e.w,
        y: e.by - Math.random() * e.h,
        vx: (Math.random() - 0.5) * 5,
        vy: -1 - Math.random() * 4,
        s: 0.08 + Math.random() * 0.08,
        a: Math.random() * 6,
        l: 0.6 + Math.random() * 0.4,
        c: d.color
      });
  if (G.ev) G.ev.emit('enemy', { kind: d.id });
  save();
}
function enemyTick(e, dt, hitD) {
  let d = MV.Enemies.find(G.ed, e.kd);
  if (!d) return null;
  if (e.ov) d = Object.assign({}, d, e.ov); // settings a script changed for this one enemy
  const p = G.p,
    pr = G.tune;
  e.w = d.w;
  e.h = d.h;
  e.hp0 = d.hp;
  if (e.hp > d.hp) e.hp = d.hp;
  e.stun = Math.max(0, (e.stun || 0) - dt);
  e.wkT = Math.max(0, (e.wkT || 0) - dt);
  if (!e.dir) e.dir = 1;
  e.cool = Math.max(0, (e.cool || 0) - dt);
  e.fire = Math.max(0, (e.fire || 0) - dt);
  const dm = hitD(e); // your attacks
  if (dm > 0 && e.inv <= 0) {
    const r = MV.Actor.hit(e, { dmg: dm, fromX: p.x, knock: d.hurtKnock, flinch: d.flinch, invul: d.invul });
    if (r.hit) {
      G.cam.shake(0.15);
      onHit();
      eSnd(d, 'hurtSnd');
      if (e.wkNow) {
        e.wkT = 0.45;
        G.cam.shake(0.25);
      }
      e.as = null;
      e.at = 0;
      e.hitN = (e.hitN || 0) + 1;
      if (d.hurtKnock > 0 && e.on) e.vy = -Math.min(5, d.hurtKnock * 0.5);
      if (r.dead) {
        enemyDie(e, d);
        return null;
      }
    }
  }
  const dx = p.x - e.cx,
    dy = p.y - pr.h / 2 - (e.by - e.h / 2),
    dist = Math.hypot(dx, dy),
    see = d.sight > 0 && dist <= d.sight,
    fly = d.move === 'fly' || !!e.sfly;
  if (e.stun > 0) {
    e.vx *= Math.max(0, 1 - 8 * dt);
  } else if (e.as === 'wind') {
    e.vx = 0;
    if (fly) e.vy = 0;
    e.at += dt;
    if (e.at >= d.atkWind) {
      e.at = 0;
      if (d.attack === 'shoot') {
        const n = Math.hypot(dx, dy) || 1,
          ux = d.atkAim === 'forward' ? e.dir : dx / n,
          uy = d.atkAim === 'forward' ? 0 : dy / n;
        eSnd(d, 'atkSnd');
        e.fire = 0.3;
        e.as = null;
        e.cool = d.atkCool;
        if (G.es.length < 60)
          G.es.push({
            x: e.cx + (e.dir * e.w) / 2,
            y: e.by - e.h / 2,
            vx: ux * d.atkSpeed,
            vy: uy * d.atkSpeed,
            w: d.atkSize,
            d: d.atkDmg,
            k: d.knock,
            s: d.stun,
            t: 0,
            c: d.color
          });
      } else if (d.attack === 'strike') {
        e.as = 'strike';
        e.at = 0;
        eSnd(d, 'atkSnd');
      } else {
        e.as = 'dash';
        eSnd(d, 'atkSnd');
      }
    }
  } else if (e.as === 'strike') {
    e.vx = 0;
    if (fly) e.vy = 0;
    e.at += dt;
    if (e.at >= d.atkDur) {
      e.as = null;
      e.cool = d.atkCool;
    }
  } else if (e.as === 'dash') {
    e.at += dt;
    e.vx = e.dir * d.atkSpeed;
    if (e.bump || e.at >= d.atkDur) {
      e.as = null;
      e.cool = d.atkCool;
      e.vx = 0;
    }
  } else {
    const turn = () => {
      if (e.bump) e.dir = -e.bump;
      else if (Math.abs(e.cx - e.ox) > d.range && Math.sign(e.cx - e.ox) === e.dir) e.dir *= -1;
      else if (d.edge === 'yes' && !fly && e.on && !eFloor(e, e.cx + e.dir * (e.w / 2 + 0.15), e.by)) e.dir *= -1;
    };
    if (d.move === 'script') {
      if (d.brain && G.script) enemyBrain(e, d, dt, dx, dy, dist, see);
      if (e.dead) return null;
    } else if (d.move === 'patrol' && d.range > 0) {
      turn();
      e.vx = e.dir * d.speed;
    } else if (d.move === 'stand still') e.vx = 0;
    else if (d.move === 'chase') {
      if (see) {
        e.dir = dx >= 0 ? 1 : -1;
        const ledge = d.edge === 'yes' && e.on && !eFloor(e, e.cx + e.dir * (e.w / 2 + 0.15), e.by);
        e.vx = Math.abs(dx) < 0.5 || ledge || e.bump === e.dir ? 0 : e.dir * d.speed;
      } else if (d.range > 0) {
        turn();
        e.vx = e.dir * d.speed * 0.6;
      } else e.vx = 0;
    } else if (fly) {
      if (see && dist > 0.8) {
        e.dir = dx >= 0 ? 1 : -1;
        e.vx = (dx / dist) * d.speed;
        e.vy = (dy / dist) * d.speed;
      } else if (see) {
        e.vx = e.vy = 0;
      } else {
        turn();
        e.vx = e.dir * d.speed * 0.5;
        e.vy = Math.sin(G.time * 2 + e.ox) * 0.8 + (e.oy - e.h / 2 - (e.by - e.h / 2)) * 1.5;
      }
    } else if (d.move === 'hop') {
      e.hop = (e.hop || 0) - dt;
      if (e.on && e.hop <= 0) {
        e.dir = see ? (dx >= 0 ? 1 : -1) : Math.random() < 0.5 ? 1 : -1;
        if (!see && Math.abs(e.cx - e.ox) > d.range) e.dir = e.cx > e.ox ? -1 : 1;
        e.vy = -d.hopPower;
        e.vx = e.dir * d.speed;
        e.hop = d.hopEvery;
      } else if (e.on) e.vx = 0;
    }
    if (d.attack !== 'none' && e.cool <= 0 && dist <= d.atkRange && (d.attack === 'shoot' || e.on || fly)) {
      e.dir = dx >= 0 ? 1 : -1;
      e.as = 'wind';
      e.at = 0;
      e.vx = 0;
    }
  }
  eMove(e, dt, !fly);
  if (e.by > G.room.gh + 3) {
    e.dead = true;
    return null;
  }
  if (e.dead) return null;
  const pb = p.bshape;
  let ov = null;
  if ((d.touch === 'yes' || e.as === 'dash') && ovBody(e, d)) ov = { d: d.damage, k: d.knock, s: d.stun };
  if (e.as === 'strike' && pb)
    for (const r of MV.Enemies.strikeWorld(e, d, e.at))
      if (r.d > 0 && MV.Attacks.shapeHit(r, pb)) {
        ov = { d: r.d, k: d.knock, s: d.stun };
        break;
      }
  if (e.sbox && pb) {
    for (const r of e.sbox)
      if (r.d > 0 && MV.Attacks.shapeHit(r, pb)) {
        ov = { d: r.d, k: d.knock, s: d.stun };
        break;
      }
  }
  e.sbox = null;
  return ov ? { touch: true, ov } : null;
}
const ovBody = (e, d) => {
  const b = G.p && G.p.bshape;
  return !!(b && MV.Attacks.shapeHit(b, MV.Enemies.bodyShape(e, d)));
};
function enemyDraw(x, e, Z) {
  const d = MV.Enemies.find(G.ed, e.kd);
  if (!d) return;
  const wind = e.as === 'wind';
  const nm =
      e.hurt > 0 && d.clips.hurt
        ? 'hurt'
        : wind && d.clips.warn
          ? 'warn'
          : (e.as === 'dash' || e.fire > 0) && d.clips.attack
            ? 'attack'
            : Math.abs(e.vx) > 0.3 && d.clips.walk
              ? 'walk'
              : 'idle',
    id = d.clips[nm] || d.clips.idle;
  if (e.cs !== nm) {
    e.cs = nm;
    e.ct0 = G.time;
  }
  const cl = id && MV.Anim.find(G.world.anims, id),
    sh = cl && cl.frames.length && G.sheet && G.sheet(cl.frames[0].sheet);
  let drawn = false;
  x.globalAlpha = e.inv > 0 && e.hurt <= 0 ? 0.75 : 1;
  if (sh) {
    const sm = MV.Anim.sample(cl, G.time - e.ct0);
    drawn = MV.Anim.draw(x, cl, sm, G.sheet, e.cx * Z, e.by * Z, {
      scale: (e.w * d.scale * Z) / sh.tw,
      flipX: e.dir < 0
    });
  }
  if (!drawn) {
    x.fillStyle = e.hurt > 0 ? '#ffffff' : wind && Math.floor(G.time * 14) % 2 ? '#ffe08a' : d.color;
    x.fillRect((e.cx - e.w / 2) * Z, (e.by - e.h) * Z, e.w * Z, e.h * Z);
    x.fillStyle = '#fff';
    const ex = e.cx + e.dir * e.w * 0.2;
    x.fillRect((ex - 0.1) * Z, (e.by - e.h * 0.7) * Z, 0.2 * Z, 0.2 * Z);
    x.fillStyle = '#111';
    x.fillRect((ex + e.dir * 0.03 - 0.04) * Z, (e.by - e.h * 0.7 + 0.06) * Z, 0.08 * Z, 0.08 * Z);
  } else if (wind && Math.floor(G.time * 14) % 2) {
    x.globalAlpha = 0.35;
    x.fillStyle = '#ffe08a';
    x.fillRect((e.cx - e.w / 2) * Z, (e.by - e.h) * Z, e.w * Z, e.h * Z);
  }
  x.globalAlpha = 1;
  if (wind) {
    x.fillStyle = '#ffd24a';
    x.font = 'bold 16px system-ui,sans-serif';
    x.textAlign = 'center';
    x.fillText('!', e.cx * Z, (e.by - e.h - 0.2) * Z);
    x.textAlign = 'left';
  }
  if (d.attack === 'strike') {
    const A = MV.Attacks;
    if (wind)
      (d.strike || []).forEach(h =>
        A.rects([h], h.from, e.dir, e.cx, e.by - e.h / 2, h.dmg).forEach(r => {
          x.setLineDash([4, 3]);
          x.strokeStyle = 'rgba(255,210,74,.9)';
          x.lineWidth = 2;
          A.trace(x, r, Z);
          x.stroke();
          x.setLineDash([]);
        })
      );
    if (e.as === 'strike')
      MV.Enemies.strikeWorld(e, d, e.at).forEach(r => {
        x.fillStyle = 'rgba(226,75,74,.5)';
        A.trace(x, r, Z);
        x.fill();
        x.strokeStyle = '#ff8a85';
        x.lineWidth = 2;
        x.stroke();
      });
  }
  if (e.wkT > 0) {
    x.fillStyle = '#ffd24a';
    x.font = 'bold 13px system-ui,sans-serif';
    x.textAlign = 'center';
    x.fillText('Weak spot!', e.cx * Z, (e.by - e.h - 0.5 - (0.45 - e.wkT)) * Z);
    x.textAlign = 'left';
  }
  if (API.debug || API.boxes) {
    x.lineWidth = 1.5;
    x.strokeStyle = '#ef9f27';
    MV.Attacks.trace(x, MV.Enemies.bodyShape(e, d), Z);
    x.stroke();
    x.strokeStyle = '#ffe08a';
    MV.Enemies.weakWorld(e, d).forEach(w => {
      MV.Attacks.trace(x, w, Z);
      x.stroke();
    });
  }
  if (d.bar === 'always' || (d.bar === 'after a hit' && e.hp < e.hp0)) {
    const bw = Math.max(0.8, e.w);
    x.fillStyle = 'rgba(0,0,0,.55)';
    x.fillRect((e.cx - bw / 2) * Z, (e.by - e.h - 0.35) * Z, bw * Z, 0.12 * Z);
    x.fillStyle = '#e24b4a';
    x.fillRect((e.cx - bw / 2) * Z, (e.by - e.h - 0.35) * Z, bw * Z * Math.max(0, e.hp / e.hp0), 0.12 * Z);
  }
}
function skinState(e) {
  switch (ty(e)) {
    case 'breakable':
      return e.hurt > 0 ? 'hit' : 'idle';
    case 'collapse':
      return e.st === 'gone' ? 'gone' : e.st === 'fall' ? 'fall' : e.st === 'shake' ? 'shake' : 'idle';
    case 'switch':
      return G.st.flags[e.p.flag] ? 'on' : 'off';
    case 'chest':
      return e.open ? 'open' : 'closed';
    case 'spring':
      return e.sq > 0 ? 'bounce' : 'idle';
    case 'checkpointkey':
    case 'checkpoint':
      return e.on ? 'active' : 'idle';
    case 'secret':
      return e.rev ? 'revealed' : 'idle';
    case 'dashpad':
      return e.fl > 0 ? 'fire' : 'idle';
    case 'stickwall':
      return e.act > 0 ? 'climb' : 'idle';
    case 'msgzone':
      return e.was ? 'triggered' : 'idle';
    case 'teleporter':
      return e.cd > 0 ? 'used' : 'idle';
    case 'blink':
      return e.st === 'gone' ? 'gone' : 'idle';
    case 'npc':
      return G.dlg && G.dlg.e === e ? 'talk' : 'idle';
    case 'orb':
      return e.cd > 0 ? 'used' : 'idle';
    case 'bashpoint':
      return e.bsh > G.time ? 'bashed' : e.bcd > 0 ? 'used' : 'idle';
    case 'grapplepoint':
      return e.hk > G.time ? 'hooked' : 'idle';
    case 'rail':
      return G.p && G.p.rl && G.p.rl.e === e ? 'ride' : 'idle';
    case 'cannon':
      return e.fl > 0 ? 'fire' : 'idle';
    case 'mount':
      return G.p && G.p.ride && G.p.ride.e === e && (Math.abs(G.p.vx) > 0.5 || Math.abs(G.p.vy) > 1) ? 'move' : 'idle';
  }
  return SKINS()[ty(e)] ? 'idle' : null;
}
// the clip an entity plays in a state; a state without its own clip shows the resting one (a vanished blink or collapse shows nothing)
function skinClip(e, nm) {
  const m = SKINS()[ty(e)];
  if (!m) return null;
  let pr = m[nm],
    id = pr && e.p[pr];
  if (!id && nm !== 'gone') id = e.p[m[REST(ty(e))]];
  return id ? MV.Anim.find(G.world.anims, id) || null : null;
}
const skinWorn = e => {
  const nm = skinState(e);
  if (!nm) return false;
  const cl = skinClip(e, nm);
  return !!(cl && cl.frames.length);
};
function skinCells(e, cx, by) {
  // tiled things repeat the picture once per tile; the rest draw one picture
  if (!TILED().includes(ty(e))) return [[cx, by, e.w, e.h, 0]];
  const o = [];
  for (let i = 0; i < e.w; i++)
    for (let j = 0; j < e.h; j++) o.push([cx - e.w / 2 + i + 0.5, by - e.h + j + 1, 1, 1, 1]);
  return o;
}
const skinFit = (sh, c, Z) => (c[4] ? Math.min((c[2] * Z) / sh.tw, (c[3] * Z) / sh.th) : (c[2] * Z) / sh.tw); // a tile cell fits inside itself; a single picture is as wide as the entity
function skinDraw(x, e, Z) {
  const nm = skinState(e);
  if (!nm || !G.sheet) return false;
  const cl = skinClip(e, nm);
  if (!cl || !cl.frames.length) return false;
  const sh = G.sheet(cl.frames[0].sheet);
  if (!sh) return false;
  const own = SKINS()[ty(e)][nm] && e.p[SKINS()[ty(e)][nm]];
  if (e.skn !== nm) {
    e.skt = e.skn === undefined && SK_HOLD[nm] ? -1e6 : G.time;
    e.skn = nm;
  }
  x.globalAlpha = 1;
  let smp = MV.Anim.sample(cl, G.time - e.skt);
  if ((SK_HOLD[nm] || SK_ONCE[nm]) && smp.cycle >= 1) smp = { frame: cl.frames[cl.frames.length - 1] };
  const shk =
      e.type === 'breakable' && e.hurt > 0
        ? (Math.sin(G.time * 90) * 0.04 * e.hurt) / 0.35
        : e.type === 'collapse' && e.st === 'shake'
          ? Math.sin(G.time * 70) * 0.05
          : 0,
    fl = e.type === 'collapse' && e.st === 'fall' ? e.fy : 0;
  if (e.type === 'collapse' && e.st === 'fall') x.globalAlpha = Math.max(0, 1 - e.ft / 0.9);
  else if (!own && SK_DIM[nm]) x.globalAlpha = SK_DIM[nm];
  let ok = false;
  skinCells(e, e.cx + shk, e.by + fl).forEach(c => {
    ok =
      MV.Anim.draw(x, cl, smp, G.sheet, c[0] * Z, c[1] * Z, {
        scale: skinFit(sh, c, Z),
        flipX: e.type === 'mount' && e.fc < 0
      }) || ok;
  });
  return ok;
}
// a still sprite from the room's sprite list: "sheet|col|row|w|h"
function spriteDraw(x, e, Z) {
  const v = String(e.p.sprite || '');
  if (!v || !G.sheet) return false;
  x.globalAlpha = 1;
  const q = v.split('|');
  if (q.length < 5) return false;
  const sh = G.sheet(q[0]);
  if (!sh || !sh.img || sh.img.complete === false || !(sh.img.naturalWidth || sh.img.width)) return false;
  const c0 = +q[1],
    r0 = +q[2],
    w = Math.max(1, +q[3]),
    h = Math.max(1, +q[4]),
    sw = w * sh.tw,
    shh = h * sh.th;
  x.imageSmoothingEnabled = false;
  skinCells(e, e.cx, e.by).forEach(c => {
    const k = c[4] ? Math.min((c[2] * Z) / sw, (c[3] * Z) / shh) : (c[2] * Z) / sw;
    x.drawImage(sh.img, c0 * sh.tw, r0 * sh.th, sw, shh, c[0] * Z - (sw * k) / 2, c[1] * Z - shh * k, sw * k, shh * k);
  });
  return true;
}
function fxClip(e, nm) {
  const cl = skinClipOwn(e, nm);
  if (!cl) return false;
  G.fx.push({ k: 'clip', cl, t: 0, e: { sk: ty(e), type: e.type, w: e.w, h: e.h }, cx: e.cx, by: e.by });
  return true;
}
function skinClipOwn(e, nm) {
  const m = SKINS()[ty(e)],
    id = m && m[nm] && e.p[m[nm]];
  return id ? MV.Anim.find(G.world.anims, id) || null : null;
}
function debris(e) {
  if (e.type === 'breakable' && skinClipOwn(e, 'broken')) return; // your own break animation replaces the rubble
  const n = Math.min(70, Math.round(8 * e.w * e.h));
  for (let i = 0; i < n; i++)
    G.fx.push({
      k: 'chip',
      t: 0,
      x: e.cx - e.w / 2 + Math.random() * e.w,
      y: e.by - Math.random() * e.h,
      vx: (Math.random() - 0.5) * 5,
      vy: -1 - Math.random() * 5,
      s: 0.07 + Math.random() * 0.1,
      a: Math.random() * 6,
      l: 0.8 + Math.random() * 0.6,
      c: e.type === 'collapse' ? '#8a6a45' : i % 3 ? '#8b8a84' : '#6b6a65'
    });
}
function fxTick(dt) {
  for (let i = G.fx.length - 1; i >= 0; i--) {
    const f = G.fx[i];
    f.t += dt;
    if (f.k === 'chip') {
      f.vy += 24 * dt;
      f.x += f.vx * dt;
      f.y += f.vy * dt;
      f.a += f.vx * dt * 3;
      if (f.t >= f.l) G.fx.splice(i, 1);
    } else if (MV.Anim.sample(f.cl, f.t).cycle >= 1 || MV.Anim.sample(f.cl, f.t).done) G.fx.splice(i, 1);
  }
}
function fxDraw(x, Z) {
  G.fx.forEach(f => {
    if (f.k === 'chip') {
      x.save();
      x.globalAlpha = Math.min(1, (f.l - f.t) * 3);
      x.fillStyle = f.c;
      x.translate(f.x * Z, f.y * Z);
      x.rotate(f.a);
      x.fillRect((-f.s * Z) / 2, (-f.s * Z) / 2, f.s * Z, f.s * Z);
      x.restore();
    } else {
      const sh = G.sheet && G.sheet(f.cl.frames[0].sheet);
      if (sh) {
        const sm = MV.Anim.sample(f.cl, f.t);
        skinCells(f.e, f.cx, f.by).forEach(c =>
          MV.Anim.draw(x, f.cl, sm, G.sheet, c[0] * Z, c[1] * Z, { scale: skinFit(sh, c, Z) })
        );
      }
    }
  });
}
function stoneDraw(x, e, Z, shk, fl) {
  const brk = e.type === 'breakable',
    dmg = brk ? 1 - Math.max(0, e.hp) / (e.hp0 || 1) : e.st === 'shake' ? 0.6 : 0.15,
    base = brk ? ['#8b8a84', '#7d7c76'] : ['#8a6a45', '#7b5d3b'];
  for (let i = 0; i < e.w; i++)
    for (let j = 0; j < e.h; j++) {
      const px = (e.cx - e.w / 2 + i + shk) * Z,
        py = (e.by - e.h + j + fl) * Z,
        bh = Z / 3;
      let r = (((i + 1) * 73856093) ^ ((j + 1) * 19349663) ^ (Math.round(e.ox * 7 + e.oy * 13) * 83492791)) >>> 0;
      const rnd = () => (r = (r * 1664525 + 1013904223) >>> 0) / 4294967296;
      x.fillStyle = base[(i + j) & 1];
      x.fillRect(px, py, Z, Z);
      x.strokeStyle = 'rgba(0,0,0,.28)';
      x.lineWidth = 1;
      x.beginPath();
      for (let k = 1; k < 3; k++) {
        x.moveTo(px, py + k * bh + 0.5);
        x.lineTo(px + Z, py + k * bh + 0.5);
      }
      for (let k = 0; k < 3; k++) {
        const off = (k + i + j) % 2 ? Z * 0.28 : Z * 0.72;
        x.moveTo(px + off + 0.5, py + k * bh);
        x.lineTo(px + off + 0.5, py + (k + 1) * bh);
      }
      x.stroke();
      x.fillStyle = 'rgba(255,255,255,.14)';
      x.fillRect(px, py, Z, 2);
      x.fillStyle = 'rgba(0,0,0,.2)';
      x.fillRect(px, py + Z - 2, Z, 2);
      const n = Math.round(dmg * 4);
      x.strokeStyle = 'rgba(25,18,12,.8)';
      x.lineWidth = 1.5;
      x.lineJoin = 'round';
      for (let c = 0; c < n; c++) {
        let cx = px + (0.2 + rnd() * 0.6) * Z,
          cy = py + (rnd() < 0.5 ? 0.05 : 0.4 + rnd() * 0.3) * Z;
        x.beginPath();
        x.moveTo(cx, cy);
        for (let k = 0; k < 3; k++) {
          cx += (rnd() - 0.5) * Z * 0.35;
          cy += (0.12 + rnd() * 0.2) * Z;
          x.lineTo(Math.max(px, Math.min(px + Z, cx)), Math.min(py + Z, cy));
        }
        x.stroke();
      }
      if (e.hurt > 0) {
        x.fillStyle = 'rgba(255,255,255,' + ((e.hurt / 0.35) * 0.55).toFixed(3) + ')';
        x.fillRect(px, py, Z, Z);
      }
    }
  x.strokeStyle = 'rgba(0,0,0,.35)';
  x.lineWidth = 1;
  x.strokeRect((e.cx - e.w / 2 + shk) * Z + 0.5, (e.by - e.h + fl) * Z + 0.5, e.w * Z - 1, e.h * Z - 1);
}
// Animated sprites (Entities > Animated sprite): plays one of your Animations clips; behind or in front of the player.
const AS_TG = {
  'breakable wall hit': 'breakable',
  'breakable wall broken': 'breakable',
  'collapsing ground shakes': 'collapse',
  'switch toggled': 'switch',
  'chest opened': 'chest'
};
function asTick(e, dt, inside) {
  const w = e.p.when || 'always';
  if (w === 'always') return;
  const st = G.st,
    cl = MV.Anim.find(G.world.anims, e.p.clip);
  let tg = null,
    gone = false;
  if (AS_TG[w]) {
    // the nearest thing of that kind in the room (within "near" tiles) is what this sprite listens to
    if (e.tgu === undefined) {
      let best = null,
        bd = Math.max(1, +e.p.near || 6);
      (G.room.ent || []).forEach(s => {
        if (s.type !== AS_TG[w]) return;
        const d = Math.hypot(s.x + 0.5 - e.ox, s.y + 1 - e.oy);
        if (d <= bd) {
          bd = d;
          best = s;
        }
      });
      e.tgu = best ? G.room.id + ':' + best.id : '';
    }
    if (e.tgu) {
      tg = G.en.find(q => q.uid === e.tgu) || null;
      if (!tg) gone = true;
    } // not there any more: it was already broken in an earlier visit
  }
  let fire = false,
    hold = null;
  if (e.seen === undefined) {
    e.seen = true;
    e.pHit = tg ? tg.hitN || 0 : 0;
    e.pTog = tg ? tg.togN || 0 : 0;
    e.pIn = false; // something that already happened in an earlier visit shows its end state without playing
    if (
      (w === 'flag set' && st.flags[e.p.flag]) ||
      (w === 'breakable wall broken' && gone) ||
      (w === 'chest opened' && tg && tg.open)
    ) {
      e.fin = true;
      e.latch = true;
    } else if (w === 'room start') fire = true;
  }
  if (w === 'player touches') {
    fire = inside && !e.pIn;
    e.pIn = inside;
  } else if (w === 'player stands in it') hold = inside;
  else if (w === 'breakable wall hit') {
    if (tg && (tg.hitN || 0) !== e.pHit) {
      fire = true;
      e.pHit = tg.hitN || 0;
    }
  } else if (w === 'breakable wall broken') {
    if (!e.latch && ((tg && tg.dead) || gone)) {
      fire = true;
      e.latch = true;
    }
  } else if (w === 'collapsing ground shakes') hold = !!tg && (tg.st === 'shake' || tg.st === 'fall');
  else if (w === 'switch toggled') {
    if (tg && (tg.togN || 0) !== e.pTog) {
      fire = true;
      e.pTog = tg.togN || 0;
    }
  } else if (w === 'chest opened') {
    if (!e.latch && tg && tg.open) {
      fire = true;
      e.latch = true;
    }
  } else if (w === 'flag set') {
    if (!e.latch && st.flags[e.p.flag]) {
      fire = true;
      e.latch = true;
    }
  }
  if (fire) {
    e.act = true;
    e.pt = 0;
    e.fin = false;
  }
  if (hold !== null) {
    if (hold) {
      if (!e.act) {
        e.act = true;
        e.pt = 0;
      }
    } else {
      e.act = false;
      e.pt = 0;
    }
  }
  if (e.act) {
    e.pt += dt;
    if (hold === null && cl && cl.frames.length && MV.Anim.sample(cl, e.pt).cycle >= 1) {
      e.act = false;
      e.fin = true;
    }
  } // one-shot events play the clip once
}
function animPass(x, Z, front) {
  G.en.forEach(e => {
    if (e.type !== 'animsprite' || e.dead || !live(e) || (e.p.layer === 'in front of player') !== front) return;
    const cl = MV.Anim.find(G.world.anims, e.p.clip);
    if (!cl || !cl.frames.length || !G.sheet) return;
    const sh = G.sheet(cl.frames[0].sheet);
    if (!sh) return;
    const w = e.p.when || 'always';
    let smp;
    if (w === 'always') smp = MV.Anim.sample(cl, G.time - e.t0);
    else if (e.act) smp = MV.Anim.sample(cl, e.pt);
    else if (e.fin && e.p.finish === 'hold last frame') smp = { frame: cl.frames[cl.frames.length - 1] };
    else if (!e.fin && e.p.idle === 'first frame') smp = { frame: cl.frames[0] };
    else return;
    MV.Anim.draw(x, cl, smp, G.sheet, e.cx * Z, e.by * Z, {
      scale: (Math.max(0.2, +e.p.width || 2) * Z) / sh.tw,
      flipX: e.p.flip === 'yes'
    });
  });
}
function cannonDraw(x, e, Z) {
  const cx = e.cx * Z,
    cy = (e.by - e.h / 2) * Z,
    r = Math.min(e.w, e.h) * 0.5 * Z,
    a = ((e.ang || 0) * Math.PI) / 180,
    ld = G.p && G.p.cn && G.p.cn.e === e;
  x.save();
  x.translate(cx, cy);
  x.fillStyle = '#4a4f57';
  x.beginPath();
  x.arc(0, 0, r * 0.95, 0, 7);
  x.fill();
  x.rotate(-a);
  const rec = e.fl > 0 ? e.fl * 1.2 * r : 0;
  x.fillStyle = ld ? '#aab3bd' : '#7d848d';
  x.fillRect(-r * 0.3 - rec, -r * 0.45, r * 2 - rec, r * 0.9);
  x.fillStyle = '#2c3036';
  x.fillRect(r * 1.55 - rec, -r * 0.55, r * 0.3, r * 1.1);
  if (ld) {
    x.setLineDash([4, 6]);
    x.strokeStyle = 'rgba(255,255,255,.65)';
    x.lineWidth = 2;
    x.beginPath();
    x.moveTo(r * 1.9, 0);
    x.lineTo(r * 1.9 + 3 * Z, 0);
    x.stroke();
  }
  if (e.fl > 0) {
    x.fillStyle = 'rgba(255,220,120,.85)';
    x.beginPath();
    x.arc(r * 1.95, 0, r * 0.5 * (e.fl / 0.25), 0, 7);
    x.fill();
  }
  x.restore();
}
function mountDraw(x, e, Z) {
  const L = e.cx - e.w / 2,
    T = e.by - e.h;
  x.fillStyle = e.ridden ? '#e8b36e' : '#d99a5b';
  x.beginPath();
  if (x.roundRect) x.roundRect(L * Z, T * Z, e.w * Z, e.h * Z, 0.25 * Z);
  else x.rect(L * Z, T * Z, e.w * Z, e.h * Z);
  x.fill();
  const f = e.fc < 0 ? -1 : 1;
  x.fillStyle = '#12324a';
  x.fillRect((e.cx + f * e.w * 0.3 - 0.08) * Z, (T + e.h * 0.25) * Z, 0.16 * Z, 0.16 * Z);
  x.fillStyle = 'rgba(255,255,255,.85)';
  x.font = '11px system-ui,sans-serif';
  x.textAlign = 'center';
  x.textBaseline = 'middle';
  x.fillText(e.p.name || 'Mount', e.cx * Z, (e.by - e.h * 0.35) * Z);
  x.textAlign = 'left';
  x.textBaseline = 'top';
}
function railDraw(x, e, Z) {
  const q = railGeom(e),
    hang = e.p.hang !== 'stand on top';
  x.save();
  x.lineCap = 'round';
  if (hang) {
    x.strokeStyle = '#6b6f75';
    x.lineWidth = 3;
    x.beginPath();
    x.moveTo(q.ax * Z, q.ay * Z);
    x.lineTo(q.bx * Z, q.by * Z);
    x.stroke();
    x.strokeStyle = 'rgba(255,255,255,.4)';
    x.lineWidth = 1;
    x.stroke();
  } else {
    x.strokeStyle = '#6f6240';
    x.lineWidth = 2;
    for (let d = 0; d <= q.len; d += 0.6) {
      const px = q.ax + q.ux * d,
        py = q.ay + q.uy * d;
      x.beginPath();
      x.moveTo((px - q.uy * 0.14) * Z, (py + q.ux * 0.14) * Z);
      x.lineTo((px + q.uy * 0.14) * Z, (py - q.ux * 0.14) * Z);
      x.stroke();
    }
    x.strokeStyle = '#cfd3d8';
    x.lineWidth = 3;
    x.beginPath();
    x.moveTo(q.ax * Z, q.ay * Z);
    x.lineTo(q.bx * Z, q.by * Z);
    x.stroke();
  }
  x.fillStyle = '#c9b37a';
  x.strokeStyle = '#3a3320';
  x.lineWidth = 1.5;
  [
    [q.ax, q.ay],
    [q.bx, q.by]
  ].forEach(c => {
    x.beginPath();
    x.arc(c[0] * Z, c[1] * Z, 0.2 * Z, 0, 7);
    x.fill();
    x.stroke();
  });
  x.fillStyle = '#fff';
  x.beginPath();
  const mx = q.bx - q.ux * 0.45,
    my = q.by - q.uy * 0.45;
  x.moveTo((mx + q.ux * 0.22) * Z, (my + q.uy * 0.22) * Z);
  x.lineTo((mx - q.uy * 0.13) * Z, (my + q.ux * 0.13) * Z);
  x.lineTo((mx + q.uy * 0.13) * Z, (my - q.ux * 0.13) * Z);
  x.fill();
  x.restore();
}
function airDraw(x, e, Z) {
  x.fillRect((e.cx - e.w / 2) * Z, (e.by - e.h) * Z, e.w * Z, e.h * Z);
  x.globalAlpha = 0.6;
  x.strokeStyle = '#d8f6ff';
  x.lineWidth = 1.5;
  for (let i = 0; i < 6; i++) {
    const f = (G.time * 0.5 + i * 0.17) % 1,
      bx = (e.cx - e.w / 2 + e.w * (((i * 37) % 10) / 10 + 0.05)) * Z,
      by = (e.by - f * e.h) * Z;
    x.beginPath();
    x.arc(bx, by, (0.06 + 0.05 * ((i * 7) % 3)) * Z, 0, 7);
    x.stroke();
  }
  x.globalAlpha = 1;
}
