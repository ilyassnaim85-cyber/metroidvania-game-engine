// One simulation step, part 2: the movement modes of the player (ladder, walking, moves, wall moves, ledges, landing, doors).
// Each function gets SIM (the variables sim() keeps for the frame) and dt. It returns undefined, or [value] to end the step early.
// climbing a ladder: no gravity, up and down move you
function simLadder(SIM, dt) {
  const { p, dnk, upk, pr } = SIM;

  // climbing a ladder: no gravity, up and down move you along it, jump lets go
  const sp = +p.cl.p.speed || 4;
  p.vy = ((dnk ? 1 : 0) - (upk ? 1 : 0)) * sp;
  p.vx = SIM.dir * pr.run * 0.3;
  p.mv = null;
  if (G.jb > 0) {
    p.cl = null;
    p.clcd = 0.25;
    p.vy = -Math.sqrt(2 * pr.gravity * pr.jumpHeight);
    p.on = false;
    G.jb = 0;
  }
}

// a move or attack that is playing and steering you (dash, glide, wall moves, grapple ...)
function simMoves(SIM, dt) {
  const { p, pr, H, R, L, dn } = SIM;

  // timed move: dash, roll, grapple, path moves, super dash, down dash, upper dash...
  const M = p.mv,
    m = M.m,
    end = kv => {
      p.vx *= kv;
      p.vy *= kv;
      p.mv = null;
    };
  if (M.b) {
    // bash: the world slows, you hold on the orb and aim with the direction keys, then you are launched
    const b = M.b,
      ox = b.o.cx,
      oy = b.o.by - b.o.h / 2;
    M.el += dt;
    if (b.ph === 'aim') {
      b.t += dt / 0.12;
      G.slow = { f: 0.12, t: 0.05 };
      p.vx = p.vy = 0;
      p.x += (ox - p.x) * Math.min(1, dt * 30);
      p.y += (oy + H / 2 - p.y) * Math.min(1, dt * 30);
      const ix = (R ? 1 : 0) - (L ? 1 : 0),
        iy = (dn ? 1 : 0) - (held('Up') ? 1 : 0);
      b.ix = ix;
      b.iy = iy;
      if (!(heldKey(m.key) || G.keys['Pad:m:' + m.id]) || b.t >= m.aim) {
        const n = Math.hypot(ix, iy);
        b.dx = n ? ix / n : p.face;
        b.dy = n ? iy / n : 0;
        b.ph = 'go';
        b.t = 0;
        b.o.bcd = +b.o.p.respawn || 1.5;
        p.muse = {};
        p.face = b.dx < 0 ? -1 : b.dx > 0 ? 1 : p.face;
        G.cam.shake(0.08);
      }
    } else {
      b.t += dt;
      p.vx = b.dx * m.speed;
      p.vy = b.dy * m.speed;
      if (b.t >= m.duration || (m.stop === 'yes' && b.t > 0.03 && (p.bumpX || (p.bumpY && p.vy < 0)))) {
        end(m.keep);
        if (m.keep > 0) {
          p.kx = p.vx;
          p.kt = 0.12 + 0.3 * m.keep;
        }
      }
    } // the launch goes on flying: Keep speed is how much of the launch speed you keep, and you coast for a moment instead of stopping dead
  } else if (M.g) {
    // grapple
    const g = M.g,
      cyp = p.y - H / 2,
      sw = m.how === 'swing';
    M.el += dt;
    M.t -= dt;
    if (!sw) p.vx = p.vy = 0;
    if (g.ph === 'out') {
      if (sw) p.vy = Math.min(p.vy + pr.gravity * (m.gravity > 0 ? m.gravity : 1) * dt, pr.maxFall); // a swing keeps falling while the hook flies
      g.len += m.hook * dt;
      g.tx = g.sx + g.ux * g.len;
      g.ty = g.sy + g.uy * g.len;
      const pt =
          m.anchor === 'walls only'
            ? null
            : G.en.find(
                e => e.type === 'grapplepoint' && !e.dead && Math.hypot(e.cx - g.tx, e.by - e.h / 2 - g.ty) < 0.8
              ),
        wall = tl(Math.floor(g.tx), Math.floor(g.ty)) === '#';
      if (pt) {
        pt.hk = G.time + 0.35;
        g.ph = 'pull';
        g.ax = pt.cx;
        g.ay = pt.by - pt.h / 2;
        G.cam.shake(0.05);
      } else if (wall) {
        if (m.anchor === 'grapple points only') {
          p.mv = null;
        } else {
          g.ph = 'pull';
          g.ax = g.tx;
          g.ay = g.ty;
          G.cam.shake(0.05);
        }
      } else if (g.len >= m.reach || M.t <= 0) p.mv = null;
      if (p.mv && sw && g.ph === 'pull') {
        g.ph = 'swing';
        g.L = Math.max(1, Math.min(m.reach, Math.hypot(g.ax - p.x, g.ay - cyp)));
        g.sw = 0;
      } // caught: the rope is as long as the gap
    } else if (g.ph === 'swing') {
      // rope: gravity and the rope length decide where you go; Left and Right pump the swing, Up and Down shorten and lengthen the rope
      const gr = pr.gravity * (m.gravity > 0 ? m.gravity : 1),
        hd = heldKey(m.key) || G.keys['Pad:m:' + m.id];
      g.sw += dt;
      p.xs = 'swing';
      g.tx = g.ax;
      g.ty = g.ay;
      if (held('Up')) G.jb = 0;
      const vx = p.vx + SIM.dir * (m.accel > 0 ? m.accel : 25) * dt,
        vy = Math.min(p.vy + gr * dt, pr.maxFall * 2);
      g.L = Math.max(1, Math.min(m.reach, g.L + ((dn ? 1 : 0) - (held('Up') ? 1 : 0)) * 3 * dt));
      let nx = p.x + vx * dt,
        ny = cyp + vy * dt;
      const dx2 = nx - g.ax,
        dy2 = ny - g.ay,
        d2 = Math.hypot(dx2, dy2) || 1;
      if (d2 > g.L) {
        nx = g.ax + (dx2 / d2) * g.L;
        ny = g.ay + (dy2 / d2) * g.L;
      }
      p.vx = (nx - p.x) / dt;
      p.vy = (ny - cyp) / dt;
      const sp2 = Math.hypot(p.vx, p.vy);
      if (sp2 > 40) {
        p.vx *= 40 / sp2;
        p.vy *= 40 / sp2;
      }
      if (SIM.dir) p.face = SIM.dir;
      if (!hd || (G.jb > 0 && m.key !== 'Jump') || (m.fuel > 0 && g.sw >= m.fuel) || (p.on && g.sw > 0.25)) {
        G.jb = 0;
        p.mv = null;
        p.kx = p.vx;
        p.kt = 0.2;
      } // let go: you keep the speed you have
    } else {
      const ex = g.ax - p.x,
        ey = g.ay - cyp,
        d = Math.hypot(ex, ey) || 1,
        v = m.pull * MV.Attacks.curveAt(m.curve, M.el);
      if (G.jb > 0) {
        G.jb = 0;
        end(0);
        p.vx = (ex / d) * m.pull * m.keep;
        p.vy = (ey / d) * m.pull * m.keep;
        p.mv = null;
      } else if (d < 0.8 || M.t <= 0 || (M.el > 0.06 && (p.bumpX || p.bumpY) && d < 2)) {
        p.vx = (ex / d) * m.pull * m.keep;
        p.vy = (ey / d) * m.pull * m.keep;
        p.mv = null;
      } else {
        p.vx = (ex / d) * v;
        p.vy = (ey / d) * v;
        g.tx = g.ax;
        g.ty = g.ay;
      }
    }
  } else if (M.path) {
    // follow the Player movement track; the speed curve changes how fast the track plays
    M.tau += dt * MV.Attacks.curveAt(m.curve, M.el);
    M.el += dt;
    M.t -= dt;
    const q = MV.Attacks.sample(m.path, M.tau);
    if (m.gravity > 0) {
      // gravity pulls the player down on top of the route: the route's own up and down motion plus a falling speed that grows until you land
      const q0 = M.q0 || q;
      M.q0 = q;
      M.gv = p.on ? 0 : Math.min((M.gv || 0) + pr.gravity * m.gravity * dt, pr.maxFall);
      p.vx = (M.x0 + M.face * q.x - p.x) / dt;
      p.vy = (q.y - q0.y) / dt + M.gv;
    } else {
      p.vx = (M.x0 + M.face * q.x - p.x) / dt;
      p.vy = (M.y0 + q.y - p.y) / dt;
    }
    if (
      M.t <= 0 ||
      (m.stop === 'yes' && M.el > 0.03 && ((p.bumpX && Math.abs(p.vx) > 0.5) || (p.bumpY && p.vy < -0.5)))
    ) {
      const vx = p.vx,
        vy = p.vy;
      p.vx = Math.max(-pr.maxFall * 2, Math.min(pr.maxFall * 2, vx)) * m.keep;
      p.vy = Math.max(-pr.maxFall * 2, Math.min(pr.maxFall, vy)) * m.keep;
      p.mv = null;
    }
  } else if (M.sc) {
    scriptMoveStep(SIM, dt, M, end);
  } else if (M.seq) {
    // multi-step move: each step sets its own velocity, gravity and steering; a step ends when its time is up or its condition is met
    const Q = M.seq,
      S1 = m.steps[Q.i],
      hold = heldKey(m.key) || G.keys['Pad:m:' + m.id];
    M.el += dt;
    Q.t += dt;
    if (!Q.init) {
      Q.init = 1;
      if (S1.aim === 'input') {
        const ix = (R ? 1 : 0) - (L ? 1 : 0),
          iy = (dn ? 1 : 0) - (held('Up') ? 1 : 0),
          n = Math.hypot(ix, iy);
        Q.ax = n ? ix / n : M.face;
        Q.ay = n ? iy / n : 0;
        if (Q.ax) M.face = Q.ax < 0 ? -1 : 1;
        p.face = M.face;
      } else {
        Q.ax = M.face;
        Q.ay = 0;
      }
      if (S1.vy !== 0 || S1.gravity === 0) p.vy = S1.vy;
      if (S1.vy < 0 || Q.ay < 0) {
        p.on = false;
        p.cy = 0;
      }
    }
    if (!p.on) Q.air = 1; // "until you land" only counts once the step has been in the air, so the same roll works on the ground too (it then lasts its full time)
    const ssp = S1.vx + S1.accel * Q.t;
    p.vx = Q.ax * ssp + SIM.dir * pr.run * S1.steer;
    if (Q.ay) p.vy = Q.ay * ssp;
    else if (S1.gravity > 0) p.vy = Math.min(p.vy + pr.gravity * S1.gravity * dt, pr.maxFall * 2);
    else p.vy = S1.vy;
    if (
      Q.t >= S1.dur ||
      (Q.t > 0.05 &&
        ((S1.until === 'land' && p.on && Q.air) ||
          (S1.until === 'wall' && p.bumpX) ||
          (S1.until === 'ceiling' && p.bumpY && !p.on) ||
          (S1.until === 'release' && !hold) ||
          (S1.until === 'jump' && G.jb > 0)))
    ) {
      if (S1.until === 'jump') G.jb = 0;
      Q.i++;
      Q.t = 0;
      Q.init = 0;
      if (Q.i >= m.steps.length) {
        Q.rep = (Q.rep || 0) + 1;
        if (Q.rep < Math.max(1, Math.floor(m.repeat || 1))) Q.i = 0;
        else {
          p.vx *= m.keep;
          p.vy *= m.keep;
          p.mv = null;
        }
      }
    }
  } else {
    const sp = Math.max(0, m.speed + m.accel * M.el) * MV.Attacks.curveAt(m.curve, M.el);
    M.el += dt;
    M.t -= dt;
    p.vx = M.dx * sp;
    p.vy = M.dy ? M.dy * sp : m.gravity > 0 ? Math.min(p.vy + pr.gravity * m.gravity * dt, pr.maxFall) : 0;
    if (M.t <= 0 || (m.stop === 'yes' && M.el > 0.03 && ((M.dx && p.bumpX) || (M.dy && p.bumpY)))) {
      p.vx = M.dx * sp * m.keep;
      p.vy = M.dy ? M.dy * sp * m.keep : m.gravity > 0 ? p.vy : 0;
      p.mv = null;
    }
  }
  if (!p.mv && m.type === 'roll' && !roomAbove(p, pr)) {
    // something is overhead: keep rolling until there is room to stand
    p.mv = { m, dx: p.face, dy: 0, t: 0.1, el: 0, stay: (M.stay || 0) + 0.1 };
    p.vx = p.face * Math.max(2, m.speed * 0.35);
    if (p.mv.stay > 3) p.mv = null;
  }
}

// an attack whose path drives your body
function simPathAttack(SIM, dt) {
  const { p } = SIM;

  // an attack that moves you along its Player movement track (a dash slash): the speed curve changes how fast the track plays
  const A = p.at.a,
    Q = p.at;
  if (Q.x0 === undefined) {
    Q.x0 = p.x;
    Q.y0 = p.y;
    Q.tau = 0;
  }
  Q.tau += dt * MV.Attacks.curveAt(A.curve, Q.t);
  const q = MV.Attacks.sample(A.path, Q.tau);
  p.vx = (Q.x0 + Q.face * q.x - p.x) / dt;
  p.vy = (Q.y0 + q.y - p.y) / dt;
  p.on = false;
  p.cy = 0;
  if (A.stop === 'yes' && Q.t > 0.03 && ((p.bumpX && Math.abs(p.vx) > 0.5) || (p.bumpY && p.vy < -0.5))) {
    Q.done = true;
    p.vx *= A.keep;
    p.vy *= A.keep;
  }
}

// normal movement: running, jumping, swimming, gravity, ice and mud
function simWalk(SIM, dt) {
  const { pr, mvs, p, swim, dnk, up } = SIM;

  // While-held moves. In the air: glide, jetpack, hover (gravity, lift, fall cap). On the ground (Works = ground): sprint, crouch, crawl, morph (run speed, body size, no jumping or attacking). Nothing runs out on the ground.
  const HF = {
    gm: 1,
    cap: pr.maxFall,
    lift: 0,
    hs: 1,
    runs: 0,
    sq: 1,
    sw: 1,
    nj: false,
    st: '',
    fly: 0,
    ph: '',
    sp: null,
    bo: null
  };
  mvs.forEach(m => {
    if (m.type !== 'hold') return;
    if (
      !(heldKey(m.key) || G.keys['Pad:m:' + m.id]) ||
      !withOk(m) ||
      (m.requires && !can(m.requires)) ||
      holdBlocked(m)
    ) {
      if (p.hw) delete p.hw[m.id];
      if (p.hd) delete p.hd[m.id];
      return;
    }
    const on = m.on || 'air',
      here = on === 'air' ? !p.on : on === 'ground' ? p.on : true,
      needs = m.cost > 0 || m.drain > 0 || m.effects.length > 0;
    if (needs) {
      p.hw = p.hw || {};
      p.hd = p.hd || {}; // a move that costs energy or has effects: it only counts where it works, and it is paid when the charge is complete
      if (!here || !okWhere(m, p)) {
        delete p.hw[m.id];
        delete p.hd[m.id];
        return;
      }
      if (!p.hd[m.id]) {
        if ((m.cost > 0 && !afford(m.cost)) || (m.drain > 0 && !afford(0.01))) {
          p.hw[m.id] = 0;
          noMp();
          return;
        }
        if (m.windup > 0) {
          p.hw[m.id] = (p.hw[m.id] || 0) + dt;
          if (p.hw[m.id] < m.windup) {
            if (m.chargeLock === 'yes') {
              HF.runs = 0.01;
              HF.nj = true;
            }
            return;
          }
        }
        p.hd[m.id] = 1;
        spend(m.cost);
        (m.effects || []).forEach(f => {
          if (f.on === 'charged') applyFx(f);
        });
        if (m.recharge === 'yes' && m.windup > 0) {
          p.hw[m.id] = 0;
          delete p.hd[m.id];
          return;
        }
      }
      if (m.drain > 0) {
        if (G.mp <= 0) return;
        gain(-m.drain * dt);
      }
    } else if (m.windup > 0) {
      p.hw = p.hw || {};
      p.hw[m.id] = (p.hw[m.id] || 0) + dt;
      if (p.hw[m.id] < m.windup) return;
    }
    if (!here || !okWhere(m, p)) return;
    if (
      !(m.fly > 0) &&
      (m.accel > 0 || p.vy > 0) &&
      (!p.on || m.accel > 0) &&
      !(m.fuel > 0 && (p.muse['f:' + m.id] || 0) >= m.fuel)
    ) {
      HF.gm = m.gravity;
      if (m.speed > 0 && on !== 'ground') HF.cap = m.speed;
      HF.lift += m.accel;
      HF.hs = Math.min(HF.hs, m.side);
      if (m.fuel > 0) p.muse['f:' + m.id] = (p.muse['f:' + m.id] || 0) + dt;
    }
    if (m.runs > 0) HF.runs = HF.runs ? Math.min(HF.runs, m.runs) : m.runs;
    if (m.fly > 0 && !(m.fuel > 0 && (p.muse['f:' + m.id] || 0) >= m.fuel)) {
      HF.fly = Math.max(HF.fly, m.fly);
      HF.hs = Math.min(HF.hs, m.side);
      if (m.fuel > 0) p.muse['f:' + m.id] = (p.muse['f:' + m.id] || 0) + dt;
    } // flying: Up and Down move you, nothing pulls you down
    if (m.phase === 'walls') HF.ph = 'all';
    else if ((m.phase === 'soil' || m.phase === 'ghost') && HF.ph !== 'all' && HF.ph.indexOf(m.phase) < 0)
      HF.ph = HF.ph ? HF.ph + '+' + m.phase : m.phase;
    if (m.sprite) HF.sp = m.sprite;
    if (m.body && m.body.shape) HF.bo = m.body;
    HF.sq = Math.min(HF.sq, m.squash);
    HF.sw = Math.min(HF.sw, m.sqw);
    if (m.nojump === 'yes') HF.nj = true;
    if (m.state && m.state !== 'auto') HF.st = m.state;
  });
  if (p.ride) {
    const RD = p.ride;
    if (RD.kind === 'flies' || (RD.kind === 'swims' && p.water)) HF.fly = Math.max(HF.fly, RD.speed);
    if (RD.jump <= 0) HF.nj = true;
  }
  if (!HF.st) {
    if (HF.ph.indexOf('soil') >= 0 && p.hid) HF.st = 'burrow';
    else if (HF.ph === 'all') HF.st = 'phase';
    else if (HF.fly > 0) HF.st = 'fly';
  }
  if (HF.sq >= 1 && HF.sw >= 1 && ((p.hq || 1) < 1 || (p.hwid || 1) < 1) && !roomAbove(p, pr)) {
    HF.sq = p.hq || 1;
    HF.sw = p.hwid || 1;
    HF.st = p.hst || '';
  } // low ceiling overhead: stay small until there is room to stand
  p.hsp = HF.sp;
  p.hbo = HF.bo;
  p.hph = HF.ph;
  p.hq = HF.sq;
  p.hwid = HF.sw;
  p.hst = HF.st;
  p.nj = HF.nj;
  if (HF.nj) G.jb = 0;
  const top = (swim ? swim.speed : HF.runs > 0 ? HF.runs : pr.run) * SIM.mud;
  if (p.arr) {
    p.arr.t += dt;
    if ((p.on && p.arr.t > 0.25) || p.arr.t > 2.5) p.arr = null;
    else if (p.y <= p.arr.y - 0.15) {
      p.kx = p.arr.vx;
      p.kt = Math.max(p.kt, 0.08);
    }
  }
  if (p.kt > 0)
    p.vx = p.kx; // wall-jump kick overrides input for a moment
  else {
    // accelerate toward the target speed; air control scales the rate
    const rate =
        (SIM.dir ? (swim ? swim.accel : pr.accel) : pr.decel) *
        (p.on || swim ? 1 : pr.airControl) *
        (p.on && !swim ? (SIM.dir ? Math.min(1, SIM.ice * 4) : SIM.ice) : 1) *
        dt,
      dv = SIM.dir * top - p.vx;
    p.vx = Math.abs(dv) <= rate ? SIM.dir * top : p.vx + Math.sign(dv) * rate;
  }
  p.kt = Math.max(0, p.kt - dt);
  const gm = HF.gm,
    cap = HF.cap,
    lift = HF.lift,
    hs = HF.hs;
  if (hs < 1) p.vx = Math.max(-pr.run * hs, Math.min(pr.run * hs, p.vx));
  if (HF.fly > 0) {
    const ty3 = (dnk ? 1 : 0) - (up ? 1 : 0),
      tv = ty3 * HF.fly,
      rt = Math.max(30, HF.fly * 8) * dt;
    p.vy = Math.abs(tv - p.vy) <= rt ? tv : p.vy + Math.sign(tv - p.vy) * rt;
  } else if (swim) {
    const ty = (dnk ? 1 : 0) - (up ? 1 : 0);
    if (ty) {
      const r2 = swim.accel * dt,
        d2 = ty * swim.speed - p.vy;
      p.vy = Math.abs(d2) <= r2 ? ty * swim.speed : p.vy + Math.sign(d2) * r2;
    } else p.vy = Math.min(p.vy + pr.gravity * swim.gravity * dt, swim.speed);
  } else p.vy = Math.min(p.vy + (pr.gravity * gm - lift) * dt, cap);
  const wj = ab('wallJump');
  if (p.wall && can('wallJump') && p.vy > wj.slide && SIM.dir === p.wall) p.vy = wj.slide;
  if (G.jb > 0 && !swim) {
    if (p.on || p.cy > 0) {
      p.vy = -Math.sqrt(2 * pr.gravity * pr.jumpHeight);
      p.on = false;
      p.cy = 0;
      G.jb = 0;
      snd('jump');
    } else if (p.wall && can('wallJump')) {
      p.vy = -wj.kickY;
      p.kx = -p.wall * wj.kickX;
      p.kt = wj.kickTime;
      p.face = -p.wall;
      G.jb = 0;
      p.muse = {};
    } else {
      const st2 = mvs
        .slice()
        .sort(order)
        .find(m => m.key === 'Jump' && (m.type === 'impulse' || TIMED.includes(m.type)) && !holdFirst(m) && tryMove(m));
      if (st2) {
        claim(st2, '');
        G.jb = 0;
      }
    }
  }
}

// wall and ceiling moves (cling, climb, run) while their key is held
function simWallMoves(SIM, dt) {
  const { p, H, swim, W, mvs, pr, dn } = SIM;

  // wall and ceiling moves (cling, climb, run): while the key is held and the player is in the air beside a wall or under a ceiling
  p.sfcd = Math.max(0, (p.sfcd || 0) - dt);
  let sf = null,
    sfw = 0;
  const ceil = tl(Math.floor(p.x), Math.floor(p.y - H - 0.08)) === '#';
  let stW = 0,
    stC = false;
  G.en.forEach(e => {
    if (e.type !== 'sticky' || e.dead) return;
    const ox = Math.min(p.x + W / 2 + 0.1, e.cx + e.w / 2) - Math.max(p.x - W / 2 - 0.1, e.cx - e.w / 2),
      oy = Math.min(p.y + 0.05, e.by) - Math.max(p.y - H - 0.1, e.by - e.h);
    if (ox <= 0 || oy <= 0) return;
    if (Math.abs(p.y - H - e.by) < 0.2 && p.x + W / 2 > e.cx - e.w / 2 && p.x - W / 2 < e.cx + e.w / 2) stC = true;
    else stW = e.cx > p.x ? 1 : -1;
  });
  if (!p.mv && !p.cl && !p.lg && !p.rl && !p.cn && !swim && !p.on && !(p.sfcd > 0))
    for (const m of mvs) {
      if (
        m.type !== 'surface' ||
        !(heldKey(m.key) || G.keys['Pad:m:' + m.id]) ||
        !withOk(m) ||
        (m.requires && !can(m.requires)) ||
        (m.fuel > 0 && (p.muse['f:' + m.id] || 0) >= m.fuel)
      )
        continue;
      const any = m.only !== 'sticky only',
        wl = (any && p.wall) || stW;
      if ((m.surface === 'wall' && wl) || (m.surface === 'ceiling' && ((any && ceil) || stC))) {
        sf = m;
        sfw = wl;
        break;
      }
    }
  if (sf) {
    p.on = false;
    p.cy = 0;
    if (!p.mhb || !p.mhb.surf || p.mhb.m.id !== sf.id) p.mhb = { m: sf, el: 0, len: 1e9, face: p.face, pw: 0, surf: 1 };
    else {
      p.mhb.face = p.face;
      p.mhb.m = sf;
      if (sf.loop === 'yes' && p.mhb.el > sf.duration) p.mhb.el %= Math.max(0.05, sf.duration);
    }
    if (sf.fuel > 0) p.muse['f:' + sf.id] = (p.muse['f:' + sf.id] || 0) + dt;
    const cs = MV.Attacks.curveAt(sf.curve, p.mhb.el);
    if (sf.path.length > 1 && (sf.loop === 'yes' || p.mhb.el < sf.duration)) {
      const R0 =
        p.sfp && p.sfp.id === sf.id
          ? p.sfp
          : (p.sfp = { id: sf.id, x0: p.x, y0: p.y, tau: 0, face: sf.surface === 'wall' ? sfw : p.face });
      R0.tau += dt * cs;
      if (R0.tau > sf.duration && sf.loop === 'yes') {
        R0.tau = 0;
        R0.x0 = p.x;
        R0.y0 = p.y;
      }
      const q = MV.Attacks.sample(sf.path, Math.min(R0.tau, sf.duration));
      p.vx = (R0.x0 + R0.face * q.x - p.x) / dt;
      p.vy = (R0.y0 + q.y - p.y) / dt;
      if (sf.surface === 'wall') {
        p.face = sfw;
        p.sw = sfw;
        p.vx += sfw * 1.5;
        if (G.jb > 0) {
          p.vy = -Math.sqrt(2 * pr.gravity * pr.jumpHeight) * 0.9;
          p.kx = -sfw * sf.kick;
          p.kt = 0.18;
          p.face = -sfw;
          G.jb = 0;
          p.sfcd = 0.25;
          p.sfp = null;
        }
      } else {
        p.vy -= 2;
        if (G.jb > 0) {
          G.jb = 0;
          p.sfcd = 0.25;
          p.sfp = null;
        }
      }
    } else if (sf.surface === 'wall') {
      p.face = sfw;
      p.sw = sfw;
      p.vx = sfw * 1.5;
      {
        const cv = (dn ? 1 : 0) - (held('Up') ? 1 : 0);
        p.vy = sf.mode === 'run' ? -sf.speed * cs : sf.mode === 'climb' && cv ? cv * sf.speed * cs : sf.slide;
      }
      if (G.jb > 0) {
        p.vy = -Math.sqrt(2 * pr.gravity * pr.jumpHeight) * 0.9;
        p.kx = -sfw * sf.kick;
        p.kt = 0.18;
        p.face = -sfw;
        G.jb = 0;
        p.sfcd = 0.25;
        {
          const k = {};
          for (const q in p.muse) if (q.startsWith('f:')) k[q] = p.muse[q];
          p.muse = k;
        }
      }
    } else {
      p.vy = -2;
      p.vx = sf.mode === 'stick' ? 0 : sf.mode === 'run' ? p.face * sf.speed * cs : SIM.dir * sf.speed * cs;
      if (G.jb > 0) {
        G.jb = 0;
        p.sfcd = 0.25;
      }
    }
  } else {
    p.sfp = null;
    if (p.mhb && p.mhb.surf) p.mhb = null;
    if (p.sw && !p.wall && p.vy < 0 && !p.on) {
      p.vy = -4;
      p.vx = p.kx = p.sw * 3;
      p.kt = 0.15;
    }
    p.sw = 0;
  } // reaching the top of a wall: hop over the edge
}

// ledge grab: falling beside a wall with the ledge free
function simLedgeGrab(SIM, dt) {
  const { p, swim, mvs, W, H } = SIM;
  if (!p.lg && !p.rl && !p.cn && !p.cl && !p.mv && !swim && !p.on && p.vy >= -1 && p.wall && !(p.lgcd > 0))
    for (const m of mvs) {
      // ledge grab: falling beside a wall with its top edge in reach
      if (m.type !== 'ledge' || (m.requires && !can(m.requires)) || !withOk(m)) continue;
      const side = p.wall,
        want = m.key === 'None' ? SIM.dir === side : heldKey(m.key) || G.keys['Pad:m:' + m.id];
      if (!want) continue;
      const cx = Math.floor(p.x + side * (W / 2 + 0.08)),
        top = p.y - H;
      let got = false;
      for (let r = Math.floor(top - 0.2); r <= Math.floor(top + m.grab) && !got; r++) {
        if (tl(cx, r) !== '#' || tl(cx, r - 1) === '#' || tl(cx, r - 2) === '#' || top < r - 0.2 || top > r + m.grab)
          continue;
        const nx = side > 0 ? cx - W / 2 - 0.001 : cx + 1 + W / 2 + 0.001,
          ny = r + 0.3 + H;
        if (!freeBox(nx, ny, W, H)) continue;
        p.lg = {
          m,
          s: side,
          r,
          x0: nx,
          y0: ny,
          dy: 0,
          ph: 'hang',
          t: 0,
          ct: 0,
          canClimb: freeBox(cx + 0.5, r, W, H),
          tx: cx + 0.5,
          ty: r,
          cy0: ny
        };
        p.x = nx;
        p.y = ny;
        p.vx = p.vy = 0;
        p.muse = {};
        p.on = false;
        got = true;
      }
      if (got) break;
    }
}

// falling onto floors, platforms and moving platforms; landing effects
function simLanding(SIM, dt) {
  const { p, wasOn, solids, plats, py, dn, W, pr, H } = SIM;
  if (p.vy >= 0) {
    let best = null;
    // When the middle of the player is on a slope, the slope alone sets the height: blocks under the next slope tile or a flat edge behind you no longer lift or hold you in steps.
    const cx0 = Math.floor(p.x),
      onSl = [Math.floor(p.y - 0.01), Math.floor(p.y)].some(ry => {
        const c0 = tl(cx0, ry);
        return sloped(c0);
      });
    const rows = [];
    for (let ry = Math.floor(py - 0.01); ry <= Math.floor(p.y) && rows.length < 10; ry++) rows.push(ry);
    if (!rows.length) rows.push(Math.floor(p.y - 0.01), Math.floor(p.y)); // every row crossed this frame, so a fast fall cannot skip a thin platform
    for (const ry of rows)
      for (let tx = onSl ? cx0 : Math.floor(SIM.l); tx <= (onSl ? cx0 : Math.floor(SIM.rr)); tx++) {
        const c = tl(tx, ry),
          slope = sloped(c);
        if (slope && tx !== Math.floor(p.x)) continue;
        const sy = surf(c, tx, ry, p.x);
        if (sy === null) continue;
        if (p.y >= sy - 0.001 && py <= sy + (c === '=' ? 0.02 : 0.5) && !(c === '=' && dn))
          best = best === null ? sy : Math.min(best, sy);
      }
    // Stick to slopes: walking down a slope keeps you on its surface instead of dropping you off each tile in steps.
    if (best === null && wasOn && p.vy < 12) {
      const tx = Math.floor(p.x);
      for (const ry of [Math.floor(p.y), Math.floor(p.y + 0.7)]) {
        const c = tl(tx, ry);
        if (!sloped(c)) continue;
        const sy = surf(c, tx, ry, p.x);
        if (sy !== null && sy >= p.y - 0.001 && sy <= p.y + 0.7) best = best === null ? sy : Math.min(best, sy);
      }
    }
    let pf = null;
    solids.concat(plats).forEach(e => {
      const top = e.by - e.h;
      if (
        p.x + W / 2 > e.cx - e.w / 2 &&
        p.x - W / 2 < e.cx + e.w / 2 &&
        py <= top + 0.1 + Math.abs(e.pdy) &&
        p.y >= top - 0.001 &&
        (best === null || top < best)
      ) {
        best = top;
        pf = e.type === 'platform' ? e : null;
      }
    });
    if (best !== null) {
      const fall = p.vy;
      if (!wasOn && fall > 8 && !p.act) act('land');
      p.y = best;
      p.vy = 0;
      p.on = true;
      p.muse = {};
      p.bumpY = 1;
      p.cy = pr.coyote;
      p.plat = pf;
      if (fall > 2 && raw(Math.floor(p.x), Math.floor(best + 0.02)) === 'u') {
        p.vy = -Math.sqrt(2 * pr.gravity * 6.5);
        p.on = false;
        p.cy = 0;
        G.cam.shake(0.06);
      }
    } // bounce tile: land on it hard and you are thrown up
  } else {
    const ty = Math.floor(p.y - H);
    for (let tx = Math.floor(SIM.l); tx <= Math.floor(SIM.rr); tx++) {
      const c = tl(tx, ty); // head: a wall, or the solid part of a half block or slope
      if (c === '#' || (PR[c] && p.y - H >= surf(c, tx, ty, Math.min(tx + 1, Math.max(tx, p.x))) - 0.001)) {
        p.y = ty + 1 + H + 0.001;
        p.vy = 0;
        p.bumpY = 1;
        break;
      }
    }
    solids.forEach(e => {
      if (e.type !== 'platform' || e.p.solid !== 'yes' || p.vy > 0) return; // a solid platform also blocks you from below: you bump your head on it
      if (
        p.x + W / 2 > e.cx - e.w / 2 &&
        p.x - W / 2 < e.cx + e.w / 2 &&
        p.y - H < e.by &&
        py - H >= e.by - 0.02 - Math.abs(e.pdy)
      ) {
        p.y = e.by + H + 0.001;
        p.vy = 0;
        p.bumpY = 1;
      }
    });
  }
}

// Walking into a door tile starts a transition. A doorway set to "press" waits for Up (or Down) and plays its open animation first;
// a doorway with a ride time carries you for that long (the lift shakes) before the room changes.
function simDoors(SIM, dt) {
  const { p } = SIM;
  const tr = () => G.room.tr || [];
  G.dprompt = null;
  if (G.go) {
    const g = G.go;
    g.t += dt;
    p.frz = G.time + dt * 3;
    p.vx = 0;
    if (g.ride > 0 && !g.rumble) {
      g.rumble = true;
      G.cam.shake({ amount: 0.06, time: g.ride, freq: 18 });
    }
    if (g.t >= g.open + g.ride) {
      doorGo(g.tg, g.from, g.e);
      G.go = null;
    }
    return [false];
  }
  if (SIM.dr) {
    const e = tr().find(t => t.x === SIM.dr.x && t.y === SIM.dr.y),
      press = e && e.mode === 'press';
    if (press || !p.inD) {
      const tg = e && MV.Progress.find(G.world, e.a, e.r);
      if (tg) {
        const mine = tr().filter(
          t => t.a === e.a && t.r === e.r && G.room.grid[t.y] && G.room.grid[t.y][t.x] === 'D'
        );
        let fr = 0.5;
        if (mine.length > 1) {
          const g = doorGroup(mine, e),
            wide = g.x1 - g.x0 >= g.y1 - g.y0;
          fr = wide
            ? g.x1 > g.x0
              ? (p.x - g.x0 - 0.5) / (g.x1 - g.x0)
              : 0.5
            : g.y1 > g.y0
              ? (p.y - 0.5 - g.y0 - 0.5) / (g.y1 - g.y0)
              : 0.5;
          fr = Math.max(0, Math.min(1, fr));
        }
        const from = { a: G.area.id, r: G.room.id, fr };
        if (press) {
          const dn = e.key === 'down';
          G.dprompt = { x: SIM.dr.x, y: SIM.dr.y, k: dn ? '\u2193' : '\u2191' };
          if (!p.inD && (dn ? SIM.dnk : SIM.upk)) {
            G.go = { t: 0, open: 0.35, ride: Math.max(0, Math.min(10, +e.ride || 0)), tg, from, e, x: SIM.dr.x, y: SIM.dr.y };
            snd('door');
          }
          if (!SIM.upk && !SIM.dnk) p.inD = false;
          return;
        }
        if (+e.ride > 0) {
          G.go = { t: 0, open: 0, ride: Math.min(10, +e.ride), tg, from, e, x: SIM.dr.x, y: SIM.dr.y };
          return [false];
        }
        doorGo(tg, from, e);
        return [false];
      }
    }
  } else p.inD = false;
}
