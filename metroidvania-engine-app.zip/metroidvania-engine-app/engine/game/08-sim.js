function sim(dt) {
  const SIM = {};
  const p = G.p;
  const k = G.keys;
  const pr = G.tune;
  const st = G.st;
  SIM.p = p;
  SIM.k = k;
  SIM.pr = pr;
  SIM.st = st;
  if (p.mv || p.cl) {
    p.hq = 1;
    p.hwid = 1;
    p.hst = '';
  }
  const W = pr.w * (p.hwid || 1);
  const H = pr.h * (p.mv ? p.mv.m.squash : 1) * (p.hq || 1);
  SIM.W = W;
  SIM.H = H;
  p.sq = H / pr.h;
  const L = held('Left');
  const R = held('Right');
  const dn = held('Down');
  SIM.L = L;
  SIM.R = R;
  SIM.dn = dn;
  p.xs = '';
  p.hph = '';
  SIM.dir = (R ? 1 : 0) - (L ? 1 : 0);
  if (p.dying > 0) {
    p.dying -= dt;
    p.vx = 0;
    if (p.dying <= 0) {
      p.dying = 0;
      p.act = null;
      return die();
    }
    return true;
  } // the death animation plays, then you respawn
  {
    const mx = pr.energyMax;
    if (
      mx > 0 &&
      pr.energyRegen > 0 &&
      G.mp < mx &&
      (G.mpw = (G.mpw === undefined ? 99 : G.mpw) + dt) >= pr.energyDelay
    )
      G.mp = Math.min(mx, G.mp + pr.energyRegen * dt);
    const lc = st.lostCoins;
    if (
      lc &&
      G.room &&
      lc.r === G.room.id &&
      Math.abs(lc.x - p.x) < 0.9 &&
      Math.abs(lc.y - 0.5 - (p.y - pr.h / 2)) < 1.2
    ) {
      G.coins += lc.n;
      msg('You got your ' + lc.n + ' coins back');
      delete st.lostCoins;
      act('pickup');
      save();
    }
  }
  const fc = p.force;
  SIM.fc = fc;
  if (fc) {
    // after a transition you walk two tiles on your own, out of the doorway
    fc.t += dt;
    if (Math.abs(p.x - fc.x0) >= 2 || fc.t > 1.2) p.force = null;
    else {
      SIM.dir = fc.dir;
      p.face = SIM.dir;
    }
  }
  if (p.frz > G.time) {
    SIM.dir = 0;
    G.jb = 0;
    p.vx = 0;
  }
  G.time += dt;
  fxTick(dt);
  for (const c in G.pr) G.pr[c] = Math.max(0, G.pr[c] - dt);
  G.en.forEach(e => {
    if (e.type === 'platform') {
      const len = Math.hypot(e.p.dx, e.p.dy) || 1,
        u = 1 - Math.abs((((((G.time * e.p.speed) / len) % 2) + 2) % 2) - 1);
      const nx = e.ox + e.p.dx * u,
        ny = e.oy + e.p.dy * u;
      e.pdx = nx - e.cx;
      e.pdy = ny - e.by;
      e.cx = nx;
      e.by = ny;
    }
  });
  G.en.forEach(e => {
    if (e.type === 'bashpoint') {
      e.bcd = Math.max(0, (e.bcd || 0) - dt);
      e.inv = e.bcd > 0 ? 1 : 0;
    }
  });
  if (G.thr) {
    const it = G.thr,
      lm = G.mv.find(q => q.id === it.m.id) || it.m;
    it.age = (it.age || 0) + dt;
    if (lm.life > 0 && it.age >= lm.life) {
      G.thr = null;
      G.p.mcd[lm.id] = lm.cooldown;
    }
  } // the item fades away after its lifetime and the move cools down
  if (G.thr && !G.thr.rest) {
    const it = G.thr,
      m = it.m,
      sub = 4;
    for (let i = 0; i < sub && !it.rest; i++) {
      const h = dt / sub;
      if (m.gravity > 0) it.vy = Math.min(it.vy + G.tune.gravity * m.gravity * h, G.tune.maxFall);
      const nx = it.x + it.vx * h,
        ny = it.y + it.vy * h;
      it.d += Math.hypot(nx - it.x, ny - it.y);
      if (tl(Math.floor(nx), Math.floor(ny)) === '#') {
        it.rest = true;
        it.vx = it.vy = 0;
      } else {
        it.x = nx;
        it.y = ny;
        if (it.d >= m.reach) {
          it.rest = true;
          it.vx = it.vy = 0;
        }
      }
    }
  }
  for (const id in p.mcd) p.mcd[id] = Math.max(0, p.mcd[id] - dt);
  p.atk = Math.max(0, p.atk - dt);
  p.acd = Math.max(0, (p.acd || 0) - dt);
  p.inv = Math.max(0, (p.inv || 0) - dt);
  if (p.at) {
    p.at.t += dt;
    if (p.at.t >= p.at.a.duration) {
      if (p.at.a.path.length > 1 && !p.at.done) {
        p.vx *= p.at.a.keep;
        p.vy *= p.at.a.keep;
      }
      p.at = null;
    }
  }
  if (p.mhb) {
    p.mhb.el += dt;
    if (p.mhb.el > p.mhb.len) p.mhb = null;
  }
  for (const id in p.acds) p.acds[id] = Math.max(0, p.acds[id] - dt);
  p.cy = Math.max(0, p.cy - dt);
  G.jb = Math.max(0, G.jb - dt);
  if (p.chg) {
    p.chg.t += dt;
    if (p.chg.o.chargeLock === 'yes') SIM.dir = 0;
  }
  if (SIM.dir && !(p.at && p.at.a.lock === 'yes')) p.face = SIM.dir;
  if (p.plat && p.on) {
    p.x += p.plat.pdx;
    p.y += p.plat.pdy;
  }
  const mvs = G.mv;
  const up = held('Jump') || held('Up');
  const dnk = held('Down');
  SIM.mvs = mvs;
  SIM.up = up;
  SIM.dnk = dnk;
  p.water = tl(Math.floor(p.x), Math.floor(p.y - H / 2)) === '~';
  if (p.water) p.muse = {};
  if (p.water && !p.wasW) snd('splash');
  p.wasW = p.water;
  if (MV.Audio)
    MV.Audio.step(dt, !!p.on && !p.mv && !p.cl && Math.abs(p.vx) > 1 && !p.water, Math.abs(p.vx) / Math.max(1, pr.run));
  if (pr.oxygen > 0) {
    // air under water: it runs out while your head is under, comes back above water or in an Air pocket; with no air you take damage now and then
    const head = tl(Math.floor(p.x), Math.floor(p.y - H + 0.15)) === '~',
      pocket = G.en.some(
        e =>
          e.type === 'airpocket' &&
          !e.dead &&
          Math.abs(e.cx - p.x) < e.w / 2 + 0.1 &&
          p.y - H < e.by &&
          p.y - H + 0.3 > e.by - e.h
      ),
      gill = can('waterBreath');
    if (p.air === undefined) p.air = pr.oxygen;
    if (head && !pocket && !gill) p.air = Math.max(0, p.air - dt);
    else p.air = Math.min(pr.oxygen, p.air + dt * pr.airRefill);
    if (p.air <= 0 && head && !pocket && !gill) {
      p.dwn = (p.dwn || 0) + dt;
      p.xs = 'drown';
      if (p.dwn >= pr.drownEvery) {
        p.dwn = 0;
        if (drownHit() === 'die') return die();
      }
    } else p.dwn = 0;
  }
  SIM.ice = 1;
  SIM.mud = 1;
  G.en.forEach(e => {
    if (
      !e.dead &&
      (e.type === 'icezone' || e.type === 'mudzone') &&
      Math.abs(e.cx - p.x) < (e.w + W) / 2 &&
      ((e.by > p.y - H && e.by - e.h < p.y) || (p.on && Math.abs(p.y - (e.by - e.h)) < 0.15))
    ) {
      if (e.type === 'icezone') SIM.ice = Math.min(SIM.ice, Math.max(0.003, +e.p.slip || 0.02));
      else SIM.mud = Math.min(SIM.mud, Math.max(0.05, +e.p.slow || 0.45));
    }
  }); // ice: you slide, mud: you are slow
  if (p.under === 'i') SIM.ice = Math.min(SIM.ice, 0.02);
  else if (p.under === 'm') SIM.mud = Math.min(SIM.mud, 0.45); // the same from ice and mud tiles
  const swim = p.water ? mvs.find(m => m.type === 'swim' && (!m.requires || can(m.requires))) : null;
  SIM.swim = swim;
  p.swimming = !!swim;
  p.swimSp = swim ? swim.sprite : null;
  p.swimBody = swim ? swim.body : null;
  const upk = held('Up');
  SIM.upk = upk;
  p.clcd = Math.max(0, (p.clcd || 0) - dt);
  p.lgcd = Math.max(0, (p.lgcd || 0) - dt);
  p.rlcd = Math.max(0, (p.rlcd || 0) - dt);
  const lad =
    p.mv || p.lg || p.rl || p.cn || swim || p.clcd > 0
      ? null
      : G.en.find(
          e =>
            e.type === 'ladder' &&
            !e.dead &&
            Math.abs(e.cx - p.x) < 0.45 &&
            p.y >= e.by - e.h - 0.01 &&
            p.y - H < e.by + 0.01 &&
            (p.cl === e || upk || (dnk && p.y < e.by - 0.02))
        );
  SIM.lad = lad;
  if (lad && p.on && !upk && dnk && p.y >= lad.by - 0.02) p.cl = null;
  else if (lad) p.cl = lad;
  else p.cl = null;
  if (p.cl) {
    simLadder(SIM, dt);
  } else if (p.lg) {
    ledgeTick(dt, SIM.dir);
  } else if (p.rl) {
    railTick(dt, SIM.dir);
  } else if (p.cn) {
    cannonTick(dt, SIM.dir);
  } else if (p.mv) {
    simMoves(SIM, dt);
  } else if (p.at && p.at.a.path.length > 1 && !p.at.done) {
    simPathAttack(SIM, dt);
  } else if (p.at && (p.at.a.lock === 'yes' || p.at.a.speed > 0)) {
    // an attack that holds you or pushes you along its speed curve
    const A = p.at.a;
    p.vx = p.at.face * A.speed * MV.Attacks.curveAt(A.curve, p.at.t);
    p.vy = A.gravity > 0 ? Math.min(p.vy + pr.gravity * A.gravity * dt, pr.maxFall) : 0;
  } else {
    simWalk(SIM, dt);
  }
  {
    simWallMoves(SIM, dt);
  }
  {
    simLedgeGrab(SIM, dt);
  }
  {
    // phasing: a move can let you ghost through walls (or only through soft ground); when it ends inside something solid you pop out at the nearest free spot
    let GH = '';
    const pm = p.mv && p.mv.m.phase,
      addG = v => {
        if (!v || v === 'no') return;
        v = v === 'walls' ? 'all' : v;
        if (GH === 'all' || v === 'all') {
          GH = 'all';
          return;
        }
        if (GH.indexOf(v) < 0) GH += (GH ? '+' : '') + v;
      };
    addG(pm);
    (p.hph || '').split('+').forEach(addG);
    if (!GH && p.gh) {
      const was = p.gh;
      p.gh = '';
      if (!freeBox(p.x, p.y, W, H) && !popOut(p, W, H)) GH = was;
    }
    p.gh = GH;
    p.hid = GH.indexOf('soil') >= 0 && raw(Math.floor(p.x), Math.floor(p.y - H / 2)) === 's';
    p.xst = p.xs || (p.ride ? 'ride' : '');
  }
  p.bumpX = p.bumpY = 0;
  const solids =
    p.gh === 'all'
      ? []
      : G.en.filter(
          e =>
            !e.dead &&
            (e.type === 'door' ||
              e.type === 'breakable' ||
              e.type === 'conveyor' ||
              e.type === 'stickwall' ||
              e.type === 'sticky' ||
              (e.type === 'collapse' && (e.st === 'idle' || e.st === 'shake')) ||
              (e.type === 'blink' && e.st === 'idle') ||
              (e.type === 'platform' && e.p.solid === 'yes'))
        );
  const plats = p.gh === 'all' ? [] : G.en.filter(e => e.type === 'platform');
  SIM.solids = solids;
  SIM.plats = plats;
  p.x += p.vx * dt;
  SIM.l = p.x - W / 2;
  SIM.rr = p.x + W / 2;
  const t = p.y - H;
  const b = p.y - 0.001;
  SIM.t = t;
  SIM.b = b;
  // Step up: walking up a slope into the side of a block, or onto a ledge up to .6 of a tile high, lifts you onto it instead of stopping you.
  // What blocks sideways: a wall, or a flat half block once your feet are below its top. solidTop gives the height you would step up to.
  const solidTop = (c, q) => (c === '#' ? q : PR[c] && PR[c][0] === PR[c][1] ? q + PR[c][0] : null);
  SIM.solidTop = solidTop;
  const blk = (col, q) => {
    const c = tl(col, q);
    return c === '#' || (PR[c] && PR[c][0] === PR[c][1] && b > q + PR[c][0] + 0.001);
  };
  SIM.blk = blk;
  const stepUp = col => {
    if (!(p.on || p.cy > 0)) return false;
    let r0 = null;
    for (let q = Math.floor(t); q <= Math.floor(b); q++)
      if (blk(col, q)) {
        r0 = solidTop(tl(col, q), q);
        break;
      }
    if (r0 === null) return false;
    const hh = p.y - r0;
    if (hh <= 0 || hh > 0.6) return false;
    for (let q = Math.floor(r0 - H); q <= Math.floor(r0); q++)
      for (let c = Math.floor(SIM.l); c <= Math.floor(SIM.rr); c++) {
        const s = solidTop(tl(c, q), q);
        if (s !== null && s < r0 - 0.001) return false;
      }
    const up = Number.isInteger(r0) ? tl(col, r0 - 1) : '';
    if (sloped(up)) return true; // the block is the foot of the next slope tile: keep walking and the slope surface lifts you smoothly, no snap
    p.y = r0;
    return true;
  };
  SIM.stepUp = stepUp;
  for (let ty = Math.floor(t); ty <= Math.floor(b); ty++) {
    if (p.vx > 0 && blk(Math.floor(SIM.rr), ty)) {
      if (stepUp(Math.floor(SIM.rr))) break;
      p.x = Math.floor(SIM.rr) - W / 2 - 0.001;
      p.vx = 0;
      p.bumpX = 1;
      break;
    }
    if (p.vx < 0 && blk(Math.floor(SIM.l), ty)) {
      if (stepUp(Math.floor(SIM.l))) break;
      p.x = Math.floor(SIM.l) + 1 + W / 2 + 0.001;
      p.vx = 0;
      p.bumpX = 1;
      break;
    }
  }
  solids.forEach(e => {
    if (p.x + W / 2 > e.cx - e.w / 2 && p.x - W / 2 < e.cx + e.w / 2 && b > e.by - e.h && t < e.by) {
      const right = e.type === 'platform' ? p.x < e.cx : p.vx > 0;
      p.x = right ? e.cx - e.w / 2 - W / 2 - 0.001 : e.cx + e.w / 2 + W / 2 + 0.001;
      p.vx = 0;
      p.bumpX = 1;
    }
  }); // a solid moving platform pushes you out toward the nearest side
  p.wall = 0;
  if (!p.on) {
    const hit = x => {
      for (let ty = Math.floor(t); ty <= Math.floor(b); ty++) if (tl(Math.floor(x), ty) === '#') return true;
      return false;
    };
    if (hit(p.x - W / 2 - 0.06)) p.wall = -1;
    else if (hit(p.x + W / 2 + 0.06)) p.wall = 1;
  }
  const py = p.y;
  const wasOn = p.on && !swim;
  SIM.py = py;
  SIM.wasOn = wasOn;
  p.y += p.vy * dt;
  SIM.l = p.x - W / 2;
  SIM.rr = p.x + W / 2;
  p.on = false;
  p.plat = null;
  {
    simLanding(SIM, dt);
  }
  p.under = p.on ? raw(Math.floor(p.x), Math.floor(p.y + 0.02)) : ''; // the tile you stand on: ice, mud and belts act on you
  if (p.on && (p.under === '>' || p.under === '<')) {
    const dx = (p.under === '>' ? 2 : -2) * dt,
      ex = (dx > 0 ? p.x + W / 2 : p.x - W / 2) + dx;
    let free = true;
    for (let ty = Math.floor(p.y - H); ty <= Math.floor(p.y - 0.001); ty++)
      if (tl(Math.floor(ex), ty) === '#') free = false;
    if (free) p.x += dx;
  } // conveyor belt tile
  if (p.y > G.room.gh + 2) {
    if (hurtP(pr.hazardDamage, null, true, true) === 'die') return die();
  }
  // The moves and attacks playing now ("owners"): start and end events, shots, effects, combos and the body hitbox timeline hang on them.
  const own = [];
  const addOwn = (o, clk, face, pw) => {
    const q = own.find(z => z.o === o);
    if (q) {
      if (clk > q.clk) q.clk = clk;
    } else own.push({ o, clk, face, pw: pw || 0 });
  };
  SIM.own = own;
  SIM.addOwn = addOwn;
  if (p.at) addOwn(p.at.a, p.at.t, p.at.face, p.at.pw);
  if (p.mv) addOwn(p.mv.m, p.mv.el, p.mv.face || p.face, p.mv.pw);
  if (p.mhb) addOwn(p.mhb.m, p.mhb.el, p.mhb.face, p.mhb.pw);
  const prevOwn = G.own || [];
  const landed = p.on && !G.wasOn;
  SIM.prevOwn = prevOwn;
  SIM.landed = landed;
  G.wasOn = p.on;
  G.own = own;
  own.forEach(q => {
    const r = prevOwn.find(z => z.o === q.o);
    q.pc = r ? r.clk : -1;
    q.hcd = r ? Math.max(0, r.hcd - dt) : 0;
    q.wl = r ? r.wl : false;
  });
  own.forEach(q => {
    if (q.pc < 0) fireFx(q, 'start');
    (q.o.shots || []).forEach(sh => {
      if (sh.at > q.pc && sh.at <= q.clk) spawnShot(sh, q);
    });
    if (landed) fireFx(q, 'land');
    if (p.bumpX && !q.wl) {
      q.wl = true;
      fireFx(q, 'wall');
    }
  });
  prevOwn.forEach(r => {
    if (!own.some(q => q.o === r.o)) {
      fireFx(r, 'end');
      p.lastEnd = { o: r.o, t: G.time };
      if (p.cq && p.cq.from === r.o) {
        const t = p.cq.t,
          pw = r.pw;
        p.cq = null;
        startChain(t, pw);
      }
    }
  });
  SIM.bk =
    (p.at && MV.Attacks.bodyKf(p.at.a.body, p.at.t)) ||
    (p.mv && MV.Attacks.bodyKf(p.mv.m.body, p.mv.el)) ||
    (p.mhb && MV.Attacks.bodyKf(p.mhb.m.body, p.mhb.el)) ||
    null;
  {
    const bo =
      (p.at && p.at.a.body) || (p.mv && p.mv.m.body) || (p.mhb && p.mhb.m.body) || (p.swimming && p.swimBody) || p.hbo;
    if (bo && bo.shape) {
      const B0 = MV.Attacks.body(G.bd, pr);
      SIM.bk = Object.assign({ w: B0.w * (p.hwid || 1), h: B0.h, x: 0, y: 0 }, SIM.bk || {}, { shape: bo.shape });
    }
  } // the shape a move gives the body only lasts while it plays
  G.shots = (G.shots || []).filter(h => {
    h.t += dt;
    h.vy += pr.gravity * h.s.gravity * dt;
    h.x += h.vx * dt;
    h.y += h.vy * dt;
    return (
      !h.dead &&
      h.t < h.s.life &&
      tl(Math.floor(h.x), Math.floor(h.y)) !== '#' &&
      h.x > -2 &&
      h.x < G.room.gw + 2 &&
      h.y < G.room.gh + 2
    );
  });
  const bodyShape = MV.Attacks.bodyWorld(G.bd, pr, p.x, p.y, p.face, p.sq || 1, SIM.bk);
  const bodyAt = (x0, y0, x1, y1) => MV.Attacks.hits(bodyShape, x0, y0, x1, y1);
  const bodyE = e => bodyAt(e.cx - e.w / 2, e.by - e.h, e.cx + e.w / 2, e.by);
  SIM.bodyShape = bodyShape;
  SIM.bodyAt = bodyAt;
  SIM.bodyE = bodyE;
  p.bshape = bodyShape;
  // In play and in the test the picture matches the body hitbox: when a keyframe moves or resizes the hitbox, the player picture moves and stretches with it.
  {
    const B0 = MV.Attacks.body(G.bd, pr),
      sq0 = p.sq || 1;
    p.stk = SIM.bk
      ? {
          cx: p.x + p.face * B0.ox,
          cy: p.y - (pr.h * sq0) / 2 + B0.oy * sq0,
          dx: p.face * SIM.bk.x,
          dy: SIM.bk.y * sq0,
          sx: SIM.bk.w / B0.w,
          sy: SIM.bk.h / B0.h
        }
      : null;
  }
  const T2 = p.y - H;
  const B2 = p.y;
  SIM.T2 = T2;
  SIM.B2 = B2;
  SIM.hz = 0;
  SIM.hzs = null;
  SIM.ct = 0;
  SIM.csx = p.x;
  SIM.dr = null;
  SIM.ctO = null; // hz: touching a hazard, ct: touched by something that fights you
  for (let ty = Math.floor(T2); ty <= Math.floor(B2 - 0.001); ty++)
    for (let tx = Math.floor(p.x - W / 2); tx <= Math.floor(p.x + W / 2); tx++) {
      const c = tl(tx, ty);
      if (c === '^' && B2 > ty + 0.5 && bodyAt(tx, ty + 0.5, tx + 1, ty + 1)) SIM.hz = 1;
      else if (c === 'D') SIM.dr = { x: tx, y: ty };
    }
  // What the player's attacks and moves hit right now: the rectangles of the hitboxes that are active at this moment of their timelines.
  const cm = (o, pw) => 1 + ((o.chargeMult || 1) - 1) * (pw || 0);
  const hbs = [];
  SIM.cm = cm;
  SIM.hbs = hbs;
  if (p.at)
    hbs.push(
      ...MV.Attacks.rects(p.at.a.hitboxes, p.at.t, p.at.face, p.x, p.y, p.at.a.damage * cm(p.at.a, p.at.pw)).map(r =>
        Object.assign(r, { ty: p.at.a.dtype, inf: p.at.a.inflict, it: p.at.a.inflictTime })
      )
    );
  if (p.mhb)
    hbs.push(
      ...MV.Attacks.rects(p.mhb.m.hit, p.mhb.el, p.mhb.face, p.x, p.y, p.mhb.m.damage * cm(p.mhb.m, p.mhb.pw)).map(r =>
        Object.assign(r, { ty: p.mhb.m.dtype, inf: p.mhb.m.inflict, it: p.mhb.m.inflictTime })
      )
    );
  G.shots.forEach(h =>
    hbs.push({ cx: h.x, cy: h.y, w: h.s.w, h: h.s.h, d: h.d, vis: null, t: h.t, sh: h.s.shape, r: h.s.r, shot: h, ty: h.ty, inf: h.inf, it: h.it })
  );
  if (p.mv && p.mv.g && p.mv.m.damage > 0)
    hbs.push({ cx: p.mv.g.tx, cy: p.mv.g.ty, w: 0.5, h: 0.5, d: p.mv.m.damage, vis: null, t: 0 });
  if (G.shb) {
    hbs.push(...G.shb);
    G.shb = null;
  }
  p.hbs = hbs;
  const hitD = e => {
    let d = 0;
    const ed = e.kd ? MV.Enemies.find(G.ed, e.kd) : e.b ? e.b.def : null,
      bs = MV.Enemies.bodyShape(e, ed),
      wk = ed ? MV.Enemies.weakWorld(e, ed) : [];
    e.wkNow = false;
    let best = null; // the box that does the most damage: its type and status come along
    for (const r of hbs)
      if (r.d > 0 && MV.Attacks.shapeHit(r, bs)) {
        let m = 1;
        if (wk.length) {
          m = ed.weakOnly === 'yes' ? 0 : 1;
          wk.forEach(w => {
            if (w.mult >= m && MV.Attacks.shapeHit(r, w)) {
              m = w.mult;
              e.wkNow = m > 1;
            }
          });
        }
        if (r.d * m > d) {
          d = r.d * m;
          best = r;
          if (r.shot) r.shot.touch = true;
        }
      }
    e.hitMeta = best ? { ty: best.ty, inf: best.inf, it: best.it } : null;
    return d > 0 ? Math.max(0, d + dmgB()) : 0;
  };
  SIM.hitD = hitD;
  const hit = e => hitD(e) > 0;
  SIM.hit = hit;
  const ov = e => Math.abs(e.cx - p.x) < (e.w + W) / 2 && e.by > T2 && e.by - e.h < B2;
  SIM.ov = ov;
  const near = e => Math.abs(e.cx - p.x) < (e.w + W) / 2 + 0.3 && e.by > T2 && e.by - e.h < B2;
  SIM.near = near;
  G.en.forEach(e => {
    if (e.dead || !live(e)) return;
    if (e.inv > 0) e.inv -= dt;
    if (e.hurt > 0) e.hurt -= dt;
    const T = e.type;
    if (T === 'enemy' && e.kd) {
      simEnemyKd(SIM, dt, e);
    } else if (T === 'enemy') {
      simEnemy(SIM, dt, e);
    } else if (T === 'collapse') {
      simCollapse(SIM, dt, e);
    } else if (T === 'spring') {
      simSpring(SIM, dt, e);
    } else if (T === 'conveyor') {
      // conveyor belt: carries you along while you stand on it (negative speed = left)
      if (p.on && Math.abs(p.y - e.by + e.h) < 0.1 && p.x + W / 2 > e.cx - e.w / 2 && p.x - W / 2 < e.cx + e.w / 2)
        p.x += (+e.p.speed || 0) * dt;
    } else if (T === 'secret') {
      // secret wall: looks like a wall; walk into it and it fades to show the passage (and stays open)
      if (!e.rev && near(e)) {
        e.rev = true;
        st.opened[e.uid] = 1;
        save();
      }
    } else if (T === 'sign') {
      simSign(SIM, dt, e);
    } else if (T === 'dashpad') {
      simDashpad(SIM, dt, e);
    } else if (T === 'stickwall') {
      simStickwall(SIM, dt, e);
    } else if (T === 'current') {
      simCurrent(SIM, dt, e);
    } else if (T === 'lowgrav') {
      // low gravity zone: you fall slowly and jump higher
      if (ov(e)) {
        const f = Math.max(0, Math.min(1, +e.p.gravity));
        p.vy -= pr.gravity * (1 - f) * dt;
        p.vy = Math.min(p.vy, pr.maxFall * Math.max(0.25, f));
      }
    } else if (T === 'msgzone') {
      simMsgzone(SIM, dt, e);
    } else if (T === 'lightzone') {
      simLightzone(SIM, dt, e);
    } else if (T === 'teleporter') {
      simTeleporter(SIM, dt, e);
    } else if (T === 'evzone') {
      // event zone: walking in or out can start an event
      const inz = Math.abs(p.x - e.cx) <= e.w / 2 && p.y - pr.h / 2 >= e.by - e.h && p.y - pr.h / 2 <= e.by;
      if (inz !== !!e.zin) {
        e.zin = inz;
        if (G.ev) G.ev.emit(inz ? 'zone' : 'zoneleave', { tag: String(e.p.tag || '') });
      }
    } else if (T === 'rail') {
      simRail(SIM, dt, e);
    } else if (T === 'cannon') {
      simCannon(SIM, dt, e);
    } else if (T === 'mount') {
      simMount(SIM, dt, e);
    } else if (T === 'blink') {
      // blinking platform: solid for "on" seconds, gone for "off" seconds
      const on = Math.max(0.1, +e.p.on || 2),
        per = on + Math.max(0.1, +e.p.off || 1.5),
        ph = (((G.time + (+e.p.offset || 0)) % per) + per) % per;
      e.st = ph < on ? 'idle' : 'gone';
      e.warn = ph < on && on - ph < 0.5;
    } else if (T === 'chest') {
      simChest(SIM, dt, e);
    } else if (T === 'npc') {
      simNpc(SIM, dt, e);
    } else if (T === 'animsprite') {
      // animated sprite: plays always, or only after an event (a wall hit or broken, ground shaking, a switch, a chest, a flag, touching it...)
      asTick(
        e,
        dt,
        Math.abs(e.cx - p.x) < (Math.max(1, +e.p.width || 2) + W) / 2 &&
          e.by > T2 &&
          e.by - Math.max(1, +e.p.width || 2) < B2
      );
    } else if (T === 'orb') {
      // refill orb: touch it to get your dash and air moves back, it returns after the respawn time
      e.cd = Math.max(0, (e.cd || 0) - dt);
      if (e.cd <= 0 && ov(e)) {
        p.muse = {};
        p.mcd = {};
        e.cd = Math.max(0.2, +e.p.respawn || 2);
        G.cam.shake(0.05);
      }
    } else if (T === 'hazard') {
      if (ov(e) && bodyE(e)) {
        SIM.hz = 1;
        SIM.hzs = { i: e.p.inflict, it: e.p.inflictTime };
      }
    } else if (T === 'boss') {
      simBoss(SIM, dt, e);
    } else if (T === 'pickup' && ov(e)) {
      const r = simPickup(SIM, dt, e);
      if (r) return r[0];
    } else if (T === 'checkpoint') {
      simCheckpoint(SIM, dt, e);
    } else if (T === 'switch' && hit(e) && e.inv <= 0) {
      simSwitchEnt(SIM, dt, e);
    } else if (T === 'door' && Math.abs(e.cx - p.x) < 1.6) {
      if (MV.Progress.has(st, e.p.requires)) {
        // a door that uses up its key: the key is an item, taken from the bag when the door opens
        const rq = e.p.requires || '';
        if (e.p.consume === 'yes' && !/^flag:/.test(rq) && st.items && st.items[rq] > 0) MV.Inventory.take(st, rq, 1);
        e.dead = true;
        st.opened[e.uid] = 1;
        fxClip(e, 'open');
        msg('Door opened');
        save();
      } else if (!(e.wt > G.time)) {
        const d = MV.Inventory.find(G.items, (e.p.requires || '').replace(/^flag:/, ''));
        msg(e.p.needMsg || 'Locked: needs ' + (d ? d.name : (e.p.requires || '').replace(/^flag:/, '')));
        e.wt = G.time + 2.5;
      }
    } else if (T === 'breakable' && e.inv <= 0 && hit(e)) {
      simBreakable(SIM, dt, e);
    }
  });
  G.shots = G.shots.filter(h => !(h.touch && h.s.pierce !== 'yes'));
  G.shots.forEach(h => {
    h.touch = false;
  });
  for (let i = G.es.length - 1; i >= 0; i--) {
    const q = G.es[i],
      r = G.room;
    q.t += dt;
    q.x += q.vx * dt;
    q.y += q.vy * dt; // shots fired by enemies
    if (q.t > 5 || q.x < -2 || q.x > r.gw + 2 || q.y > r.gh + 2 || q.y < -6 || eSolid(q.x, q.y)) {
      G.es.splice(i, 1);
      continue;
    }
    if (!bodyOff() && bodyAt(q.x - q.w / 2, q.y - q.w / 2, q.x + q.w / 2, q.y + q.w / 2)) {
      SIM.ct = 1;
      SIM.csx = q.x - q.vx * 0.05;
      SIM.ctO = { d: q.d, k: q.k, s: q.s, i: q.i, it: q.it };
      G.es.splice(i, 1);
    }
  }
  if (SIM.hz || SIM.ct) {
    const wasVul = !(p.inv > 0),
      inf = SIM.hz ? SIM.hzs : SIM.ctO;
    if (
      hurtP(
        SIM.hz ? pr.hazardDamage : SIM.ctO ? SIM.ctO.d : pr.contactDamage,
        SIM.hz ? null : SIM.csx,
        !!SIM.hz,
        false,
        SIM.hz || !SIM.ctO ? undefined : SIM.ctO
      ) === 'die'
    )
      return die();
    if (wasVul && inf && inf.i && inf.i !== 'none') {
      MV.Status.add(G.status, inf.i, inf.it);
      msg(MV.Status.INFO[inf.i].label + '!');
    }
  }
  {
    // poison and burn hurt over time (they cannot take the last health point when "can kill you" is 0)
    const dot = MV.Status.step(G.status, dt, pr);
    if (dot > 0 && !p.dying) {
      const take = pr.statusKills ? dot : Math.min(dot, Math.max(0, G.hp - 1));
      if (take > 0) {
        G.hp -= take;
        act('hurt');
        if (G.hp <= 0) {
          G.hp = 0;
          if (kill() === 'die') return die();
        }
      }
    }
  }
  {
    const r = simDoors(SIM, dt);
    if (r) return r[0];
  }
  return true;
}
