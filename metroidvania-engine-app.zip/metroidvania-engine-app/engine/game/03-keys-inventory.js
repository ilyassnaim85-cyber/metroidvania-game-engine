// Keys: Jump, Shift, Up, Down, Left, Right are groups (arrows and WASD); anything else is one physical key.
const KEYS = {
  Jump: ['Space', 'ArrowUp', 'KeyW'],
  Shift: ['ShiftLeft', 'ShiftRight'],
  Up: ['ArrowUp', 'KeyW'],
  Down: ['ArrowDown', 'KeyS'],
  Left: ['ArrowLeft', 'KeyA'],
  Right: ['ArrowRight', 'KeyD']
};
const codesOf = key => (G && G.ctl && MV.Controls.codes(G.ctl, key)) || KEYS[key] || [key];
const held = name => codesOf(name).some(c => G.keys[c]);
const heldKey = key => key && key !== 'None' && codesOf(key).some(c => G.keys[c]);
const withOk = m => (!m.with || m.with === 'None' || heldKey(m.with)) && (m.more || []).every(k => heldKey(k)); // Also hold, plus any more keys added with Add key
const nKeys = m => (m.with && m.with !== 'None' ? 1 : 0) + (m.more || []).length;
const specific = (a, b) => nKeys(b) - nKeys(a); // the combo with the most keys wins over a plain move
// Moves that share a key: the combo with more keys goes first, then the one with the higher Order number. A press is claimed by the first move that can use it; a while-held move on the same key waits for the next press.
const prio = m => +m.priority || 0,
  order = (a, b) => nKeys(b) - nKeys(a) || prio(b) - prio(a);
const shareKey = (a, b) => a.key !== 'None' && b.key !== 'None' && codesOf(a.key).some(c => codesOf(b.key).includes(c));
function holdCan(m) {
  const p = G.p;
  if (!(heldKey(m.key) || G.keys['Pad:m:' + m.id]) || !withOk(m) || (m.requires && !can(m.requires))) return false;
  const on = m.on || 'air',
    here = on === 'air' ? !p.on : on === 'ground' ? p.on : true;
  if (!here || !okWhere(m, p)) return false;
  return !((m.cost > 0 && !afford(m.cost)) || (m.drain > 0 && !afford(0.01)));
}
const holdFirst = m =>
  (G.mv || []).some(h => h !== m && h.type === 'hold' && shareKey(h, m) && order(h, m) < 0 && holdCan(h)); // a while-held move on this key outranks m and can work right now
const holdBlocked = m => {
  const cl = G.claim;
  if (cl && codesOf(m.key).some(c => G.keys[c] && cl[c] && cl[c] !== m.id)) return true;
  return (G.mv || []).some(h => h !== m && h.type === 'hold' && shareKey(h, m) && order(h, m) < 0 && holdCan(h));
};
const claim = (m, code) => {
  G.claim = G.claim || {};
  codesOf(m.key).forEach(c => {
    if (G.keys[c] || c === code) G.claim[c] = m.id;
  });
};
// Start an attack if its rules allow it (not already attacking, unlocked, usable here, off cooldown). Returns true when it started.
const wOk = a => !a.weapon || !!(G.st.weapons && G.st.weapons[a.weapon] && G.st.weapon === a.weapon); // an attack of a weapon only works while that weapon is in your hand
function giveWeapon(id) {
  const st = G.st;
  st.weapons = st.weapons || {};
  st.weapons[id] = 1;
  st.weapon = id;
  msg('Got the weapon "' + id + '" (Tab switches weapons)');
}
function switchWeapon() {
  const st = G.st,
    own = Object.keys(st.weapons || {});
  if (own.length < 2) {
    if (own.length === 1 && st.weapon !== own[0]) st.weapon = own[0];
    return;
  }
  const order = G.at
    .map(a => a.weapon)
    .filter((w, i, l) => w && l.indexOf(w) === i)
    .concat(own)
    .filter((w, i, l) => own.includes(w) && l.indexOf(w) === i);
  st.weapon = order[(order.indexOf(st.weapon) + 1) % order.length];
  msg('Weapon: ' + st.weapon);
  save();
}
// Inventory: opens with the key set in the Items tab (I by default). Tabs show your items, weapons and abilities; the world is paused while it is open.
const invDesign = () => MV.Inventory.cleanDesign(G.world && G.world.inv);
const invList = () => {
  const D = invDesign();
  G.inv.tab = Math.max(0, Math.min(G.inv.tab || 0, D.tabs.length - 1));
  return MV.Inventory.entries(D, G.st, G.items, G.inv.tab, MV.data.abilities);
};
function openInv() {
  G.inv = { sel: 0, tab: 0, cols: 1 };
  G.keys = {};
  G.p.vx = 0;
}
function invKey(code, shift) {
  const D = invDesign(),
    I = G.inv;
  let l = invList(),
    n = l.length;
  const cols = D.layout === 'grid' ? Math.max(1, I.cols || 1) : 1,
    setTab = d => {
      I.tab = (I.tab + d + D.tabs.length) % D.tabs.length;
      I.sel = 0;
    };
  if (codesOf(D.key).includes(code) || code === 'Escape') {
    G.inv = null;
    G.keys = {};
    return;
  }
  if (code === 'Tab') setTab(shift ? -1 : 1);
  else if (code === 'KeyQ' || code === 'PageUp') setTab(-1);
  else if (code === 'KeyE' || code === 'PageDown') setTab(1);
  else if (code === 'ArrowLeft' || code === 'KeyA') {
    if (cols === 1) setTab(-1);
    else I.sel = Math.max(0, I.sel - 1);
  } else if (code === 'ArrowRight' || code === 'KeyD') {
    if (cols === 1) setTab(1);
    else I.sel = Math.min(n - 1, I.sel + 1);
  } else if (code === 'ArrowUp' || code === 'KeyW') I.sel = Math.max(0, I.sel - cols);
  else if (code === 'ArrowDown' || code === 'KeyS') I.sel = Math.min(n - 1, I.sel + cols);
  else if ((code === 'Enter' || code === 'Space') && l[I.sel]) {
    const q = l[I.sel];
    if (q.k === 'w') {
      G.st.weapon = q.id;
      msg('Weapon: ' + q.id);
      save();
    } else if (q.k === 'i') {
      const d = MV.Inventory.find(G.items, q.id);
      // using an item: take one unless it is a keeper, then tell the script hooks
      const used = () => {
        if (d.keep !== 'yes') MV.Inventory.take(G.st, d.id, 1);
        if (G.script) G.script.emit('use', { item: d.id });
        save();
      };
      if (d.use === 'heal') {
        if (G.hp >= G.tune.maxHp) msg('Your health is already full');
        else {
          G.hp = Math.min(G.tune.maxHp, G.hp + d.amount);
          msg('Used ' + d.name + ' (+' + d.amount + ' health)');
          used();
        }
      } else if (d.use === 'energy') {
        if (!(G.tune.energyMax > 0)) msg('You have no energy bar');
        else if (G.mp >= G.tune.energyMax - 1e-6) msg('Your energy is already full');
        else {
          gain(d.amount);
          msg('Used ' + d.name + ' (+' + d.amount + ' energy)');
          used();
        }
      } else if (d.use === 'upgrade') {
        if (upgrade(d.stat, d.amount)) used();
      } else if (d.use === 'script') {
        msg('Used ' + d.name);
        if (G.script && d.fn) G.script.call(d.fn, { item: d.id });
        used();
      } else if (d.use === 'charm') {
        const eq = (G.st.equipped = G.st.equipped || {});
        if (eq[d.id]) {
          delete eq[d.id];
          msg(d.name + ' taken off');
        } else if (charms().used + d.notches > G.tune.charmSlots)
          msg('Not enough notches (' + charms().used + ' of ' + G.tune.charmSlots + ' used)');
        else {
          eq[d.id] = 1;
          msg(d.name + ' equipped');
        }
        save();
      } else msg(d.name + ' cannot be used');
    }
  }
  n = invList().length;
  if (I.sel >= n) I.sel = Math.max(0, n - 1);
  if (I.sel < 0) I.sel = 0;
}
// The pause menu (Esc): Resume, Inventory, Options (volume, full screen) and, when the host game gives a way out, Quit to title.
// Looks come from the UI tab. G.pm = { sel, page: 'main' | 'options' }.
function pmItems() {
  const U = uiNow(),
    l = [
      { id: 'resume', label: U.pauseResume },
      { id: 'inv', label: U.pauseInv }
    ];
  if (U.mapScreen === 'yes') l.push({ id: 'map', label: U.pauseMap });
  if (U.optionsOn === 'yes') l.push({ id: 'options', label: U.optionsLabel });
  if (G.quit) l.push({ id: 'quit', label: U.pauseQuit });
  return l;
}
const pmVol = () => (MV.Audio && MV.Audio.getVol ? MV.Audio.getVol() : { master: 1, music: 0.7, sfx: 1 });
const pmRows = () => MV.UI.optRows(uiNow(), pmVol(), !!G.canFull, true);
const pmCtl = () => MV.UI.ctlRows(uiNow(), G.ctl.keys, G.pm && G.pm.wait);
const pmList = () => (G.pm.page === 'controls' ? pmCtl() : G.pm.page === 'options' ? pmRows() : pmItems());
// the player picked another key for an action (kept by the host game, if it keeps them)
function pmBind(name, code) {
  G.ctlUser = MV.UI.setKey(G.ctl.keys, name, code);
  if (G.onCtl) G.onCtl(G.ctlUser);
}
function pmSetVol(id, v) {
  if (!MV.Audio || !MV.Audio.setVol) return;
  MV.Audio.setVol(Object.assign({}, MV.Audio.getVol(), { [id]: v }));
  if (G.onVol) G.onVol(MV.Audio.getVol());
}
function openPause() {
  G.pm = { sel: 0, page: 'main' };
  G.keys = {};
  G.p.vx = 0;
}
function pmPick(id) {
  if (G.pm.page === 'controls') {
    if (id === 'back') G.pm = { sel: pmRows().findIndex(q => q.id === 'controls'), page: 'options' };
    else if (id === 'reset') {
      G.ctlUser = null;
      if (G.onCtl) G.onCtl(null);
    } else if (/^k:/.test(id)) G.pm.wait = id.slice(2);
    return;
  }
  if (G.pm.page === 'options') {
    if (id === 'controls') G.pm = { sel: 0, page: 'controls' };
    else if (id === 'back') G.pm = { sel: pmItems().findIndex(q => q.id === 'options'), page: 'main' };
    else if (id === 'full' && G.canFull) {
      if (document.fullscreenElement) document.exitFullscreen();
      else document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
    }
    return;
  }
  if (id === 'resume') {
    G.pm = null;
    G.keys = {};
  } else if (id === 'inv') {
    G.pm = null;
    openInv();
  } else if (id === 'map') {
    G.pm = null;
    openMap();
  } else if (id === 'options') G.pm = { sel: 0, page: 'options' };
  else if (id === 'quit' && G.quit) {
    const q = G.quit;
    G.pm = null;
    q();
  }
}
function pmKey(code) {
  const l = pmList(),
    P = G.pm,
    wait = P.wait,
    left = ['ArrowLeft', 'KeyA', 'Pad:Left'].includes(code),
    right = ['ArrowRight', 'KeyD', 'Pad:Right'].includes(code);
  if (wait) {
    // waiting for the new key of an action
    P.wait = null;
    if (code !== 'Escape' && !/^Pad:/.test(code)) pmBind(wait, code);
  } else if (code === 'Escape' || code === 'Pad:Pause')
    pmPick(P.page === 'options' || P.page === 'controls' ? 'back' : 'resume');
  else if (code === 'ArrowUp' || code === 'KeyW' || code === 'Pad:Up') P.sel = (P.sel + l.length - 1) % l.length;
  else if (code === 'ArrowDown' || code === 'KeyS' || code === 'Pad:Down') P.sel = (P.sel + 1) % l.length;
  else if ((left || right) && P.page === 'options' && l[P.sel] && l[P.sel].kind === 'slider')
    pmSetVol(l[P.sel].id, MV.UI.stepVal(l[P.sel].value, left ? -1 : 1));
  else if (['Enter', 'Space', 'KeyE', 'Pad:Jump', 'Pad:Interact'].includes(code) && l[P.sel]) pmPick(l[P.sel].id);
}
function drawPause(x, c) {
  const U = uiNow();
  G.pmHit =
    G.pm.page === 'controls'
      ? MV.UI.options(
          x,
          c.width,
          c.height,
          U,
          { kind: 'pause', title: U.optControls, rows: pmCtl(), sel: G.pm.sel },
          G.sheet,
          G.time
        )
      : G.pm.page === 'options'
        ? MV.UI.options(x, c.width, c.height, U, { kind: 'pause', rows: pmRows(), sel: G.pm.sel }, G.sheet, G.time)
        : MV.UI.menu(
            x,
            c.width,
            c.height,
            U,
            { kind: 'pause', title: U.pauseTitle, items: pmItems(), sel: G.pm.sel },
            G.sheet,
            G.time
          );
}
// A shop: a character with a Shop setting, one line per item: "itemId: price" (a comma works too). G.shop = { e, list, sel, msg }.
function shopList(e) {
  if (!e || !e.p || e.type !== 'npc') return [];
  const out = [];
  String(e.p.shop || '')
    .split(/[\n,]+/)
    .forEach(l => {
      const m = /^\s*([\w-]{1,24})\s*[:=]\s*(\d{1,6})\s*$/.exec(l),
        d = m && MV.Inventory.find(G.items, m[1]);
      if (d && out.length < 12) out.push({ d, price: +m[2] });
    });
  return out;
}
function openShop(e) {
  const list = shopList(e);
  if (!list.length) return;
  G.shop = { e, list, sel: 0, msg: '' };
  G.keys = {};
  G.p.vx = 0;
}
function shopKey(code) {
  const S2 = G.shop,
    n = S2.list.length;
  if (code === 'Escape' || code === 'Pad:Pause' || code === 'Pad:Back') G.shop = null;
  else if (['ArrowUp', 'KeyW', 'Pad:Up'].includes(code)) S2.sel = (S2.sel + n - 1) % n;
  else if (['ArrowDown', 'KeyS', 'Pad:Down'].includes(code)) S2.sel = (S2.sel + 1) % n;
  else if (['Enter', 'Space', 'KeyE', 'Pad:Jump', 'Pad:Interact'].includes(code)) {
    const it = S2.list[S2.sel],
      U = uiNow();
    if (G.coins < it.price) S2.msg = U.shopNoCoins;
    else if (!MV.Inventory.add(G.st, it.d, 1)) S2.msg = U.shopFull;
    else {
      G.coins -= it.price;
      S2.msg = 'Bought ' + it.d.name;
      snd('pickup');
      save();
    }
  }
}
function drawShop(x, c) {
  const S2 = G.shop,
    U = uiNow();
  MV.UI.shop(x, c.width, c.height, U, {
    title: U.shopTitle,
    coins: G.coins,
    sel: S2.sel,
    msg: S2.msg,
    hint: 'Up / Down: choose   Enter: buy   Esc: leave',
    rows: S2.list.map(q => ({
      name: q.d.name,
      desc: q.d.desc,
      price: q.price,
      owned: MV.Inventory.count(G.st, q.d.id),
      can: G.coins >= q.price
    }))
  });
}
// The full-screen map (M, or Map in the pause menu): the areas you have been in, room by room, with rest points, bosses and items you have not taken.
// G.fm = { i: which visited area }. Left and Right (or Q and E) change area, Esc or M closes it.
function mapAreas() {
  const seen = G.st.seen || {};
  return (G.world.areas || []).filter(a => (a.rooms || []).some(r => r === G.room || seen[r.id]));
}
function openMap() {
  if (uiNow().mapScreen !== 'yes') return;
  const i = mapAreas().indexOf(G.area);
  G.fm = { i: Math.max(0, i) };
  G.keys = {};
  G.p.vx = 0;
}
function fmKey(code) {
  const L = mapAreas(),
    F = G.fm;
  if (code === 'Escape' || code === 'KeyM' || code === 'Pad:Pause' || code === 'Pad:Map') G.fm = null;
  else if (L.length > 1 && ['ArrowLeft', 'KeyA', 'KeyQ', 'Pad:Left'].includes(code))
    F.i = (F.i + L.length - 1) % L.length;
  else if (L.length > 1 && ['ArrowRight', 'KeyD', 'KeyE', 'Pad:Right'].includes(code)) F.i = (F.i + 1) % L.length;
}
function mapData() {
  const L = mapAreas(),
    st = G.st,
    seen = st.seen || {},
    a = L[Math.min(G.fm.i, L.length - 1)] || G.area;
  return {
    area: a ? a.n : '',
    count: L.length,
    rooms: ((a && a.rooms) || []).map(r => ({
      x: r.x || 0,
      y: r.y || 0,
      w: r.w || r.gw,
      h: r.h || r.gh,
      here: r === G.room,
      seen: !!seen[r.id],
      marks: (r.ent || [])
        .map(s => {
          const uid = r.id + ':' + s.id,
            k =
              s.type === 'checkpoint' || s.type === 'checkpointkey'
                ? 'rest'
                : s.type === 'boss' && !st.opened[uid]
                  ? 'boss'
                  : (s.type === 'pickup' && !st.collected[uid]) || (s.type === 'chest' && !st.flags['chest:' + uid])
                    ? 'item'
                    : '';
          return k ? { k, x: (s.x + 0.5) / r.gw, y: (s.y + 0.5) / r.gh } : null;
        })
        .filter(Boolean)
    })),
    px: G.p.x / G.room.gw,
    py: G.p.y / G.room.gh,
    hint: (mapAreas().length > 1 ? 'Left / Right: area   ' : '') + 'M or Esc: close'
  };
}
function drawMap(x, c) {
  MV.UI.fullMap(x, c.width, c.height, uiNow(), mapData());
}
function drawInv(x, c) {
  const D = invDesign(),
    l = invList(),
    I = G.inv;
  if (I.sel >= l.length) I.sel = Math.max(0, l.length - 1);
  const r = MV.Inventory.draw(
    x,
    c.width,
    c.height,
    D,
    { tab: I.tab, sel: I.sel, list: l },
    G.sheet,
    G.time,
    (G.tune.charmSlots > 0 ? 'Notches ' + charms().used + '/' + G.tune.charmSlots + '   ' : '') +
      'Arrows: choose   Q / E or Tab: tab   Enter: use or equip   ' +
      kl(D.key) +
      ' or Esc: close'
  );
  I.cols = r.cols;
}
