// Keys: Jump, Shift, Up, Down, Left, Right are groups (arrows and WASD); anything else is one physical key.
const KEYS = {
  Jump: ['Space', 'ArrowUp', 'KeyW'],
  Shift: ['ShiftLeft', 'ShiftRight'],
  Up: ['ArrowUp', 'KeyW'],
  Down: ['ArrowDown', 'KeyS'],
  Left: ['ArrowLeft', 'KeyA'],
  Right: ['ArrowRight', 'KeyD']
};
const codesOf = key => (G && G.ctl && MV.Controls.codes(G.ctl, key)) || KEYS[key] || [key];
const held = name => codesOf(name).some(c => G.keys[c]);
const heldKey = key => key && key !== 'None' && codesOf(key).some(c => G.keys[c]);
const withOk = m => (!m.with || m.with === 'None' || heldKey(m.with)) && (m.more || []).every(k => heldKey(k)); // Also hold, plus any more keys added with Add key
const nKeys = m => (m.with && m.with !== 'None' ? 1 : 0) + (m.more || []).length;
const specific = (a, b) => nKeys(b) - nKeys(a); // the combo with the most keys wins over a plain move
// Moves that share a key: the combo with more keys goes first, then the one with the higher Order number. A press is claimed by the first move that can use it; a while-held move on the same key waits for the next press.
const prio = m => +m.priority || 0,
  order = (a, b) => nKeys(b) - nKeys(a) || prio(b) - prio(a);
const shareKey = (a, b) => a.key !== 'None' && b.key !== 'None' && codesOf(a.key).some(c => codesOf(b.key).includes(c));
function holdCan(m) {
  const p = G.p;
  if (!(heldKey(m.key) || G.keys['Pad:m:' + m.id]) || !withOk(m) || (m.requires && !can(m.requires))) return false;
  const on = m.on || 'air',
    here = on === 'air' ? !p.on : on === 'ground' ? p.on : true;
  if (!here || !okWhere(m, p)) return false;
  return !((m.cost > 0 && !afford(m.cost)) || (m.drain > 0 && !afford(0.01)));
}
const holdFirst = m =>
  (G.mv || []).some(h => h !== m && h.type === 'hold' && shareKey(h, m) && order(h, m) < 0 && holdCan(h)); // a while-held move on this key outranks m and can work right now
const holdBlocked = m => {
  const cl = G.claim;
  if (cl && codesOf(m.key).some(c => G.keys[c] && cl[c] && cl[c] !== m.id)) return true;
  return (G.mv || []).some(h => h !== m && h.type === 'hold' && shareKey(h, m) && order(h, m) < 0 && holdCan(h));
};
const claim = (m, code) => {
  G.claim = G.claim || {};
  codesOf(m.key).forEach(c => {
    if (G.keys[c] || c === code) G.claim[c] = m.id;
  });
};
// Start an attack if its rules allow it (not already attacking, unlocked, usable here, off cooldown). Returns true when it started.
const wOk = a => !a.weapon || !!(G.st.weapons && G.st.weapons[a.weapon] && G.st.weapon === a.weapon); // an attack of a weapon only works while that weapon is in your hand
function giveWeapon(id) {
  const st = G.st;
  st.weapons = st.weapons || {};
  st.weapons[id] = 1;
  st.weapon = id;
  msg('Got the weapon "' + id + '" (Tab switches weapons)');
}
function switchWeapon() {
  const st = G.st,
    own = Object.keys(st.weapons || {});
  if (own.length < 2) {
    if (own.length === 1 && st.weapon !== own[0]) st.weapon = own[0];
    return;
  }
  const order = G.at
    .map(a => a.weapon)
    .filter((w, i, l) => w && l.indexOf(w) === i)
    .concat(own)
    .filter((w, i, l) => own.includes(w) && l.indexOf(w) === i);
  st.weapon = order[(order.indexOf(st.weapon) + 1) % order.length];
  msg('Weapon: ' + st.weapon);
  save();
}
// Inventory: opens with the key set in the Items tab (I by default). Tabs show your items, weapons and abilities; the world is paused while it is open.
const invDesign = () => MV.Inventory.cleanDesign(G.world && G.world.inv);
const invList = () => {
  const D = invDesign();
  G.inv.tab = Math.max(0, Math.min(G.inv.tab || 0, D.tabs.length - 1));
  return MV.Inventory.entries(D, G.st, G.items, G.inv.tab, MV.data.abilities);
};
function openInv() {
  G.inv = { sel: 0, tab: 0, cols: 1 };
  G.keys = {};
  G.p.vx = 0;
}
function invKey(code, shift) {
  const D = invDesign(),
    I = G.inv;
  let l = invList(),
    n = l.length;
  const cols = D.layout === 'grid' ? Math.max(1, I.cols || 1) : 1,
    setTab = d => {
      I.tab = (I.tab + d + D.tabs.length) % D.tabs.length;
      I.sel = 0;
    };
  if (codesOf(D.key).includes(code) || code === 'Escape') {
    G.inv = null;
    G.keys = {};
    return;
  }
  if (code === 'Tab') setTab(shift ? -1 : 1);
  else if (code === 'KeyQ' || code === 'PageUp') setTab(-1);
  else if (code === 'KeyE' || code === 'PageDown') setTab(1);
  else if (code === 'ArrowLeft' || code === 'KeyA') {
    if (cols === 1) setTab(-1);
    else I.sel = Math.max(0, I.sel - 1);
  } else if (code === 'ArrowRight' || code === 'KeyD') {
    if (cols === 1) setTab(1);
    else I.sel = Math.min(n - 1, I.sel + 1);
  } else if (code === 'ArrowUp' || code === 'KeyW') I.sel = Math.max(0, I.sel - cols);
  else if (code === 'ArrowDown' || code === 'KeyS') I.sel = Math.min(n - 1, I.sel + cols);
  else if ((code === 'Enter' || code === 'Space') && l[I.sel]) {
    const q = l[I.sel];
    if (q.k === 'w') {
      G.st.weapon = q.id;
      msg('Weapon: ' + q.id);
      save();
    } else if (q.k === 'i') {
      const d = MV.Inventory.find(G.items, q.id);
      if (d.use === 'heal') {
        if (G.hp >= G.tune.maxHp) msg('Your health is already full');
        else {
          MV.Inventory.take(G.st, d.id, 1);
          G.hp = Math.min(G.tune.maxHp, G.hp + d.amount);
          msg('Used ' + d.name + ' (+' + d.amount + ' health)');
          save();
        }
      } else if (d.use === 'charm') {
        const eq = (G.st.equipped = G.st.equipped || {});
        if (eq[d.id]) {
          delete eq[d.id];
          msg(d.name + ' taken off');
        } else if (charms().used + d.notches > G.tune.charmSlots)
          msg('Not enough notches (' + charms().used + ' of ' + G.tune.charmSlots + ' used)');
        else {
          eq[d.id] = 1;
          msg(d.name + ' equipped');
        }
        save();
      } else msg(d.name + ' cannot be used');
    }
  }
  n = invList().length;
  if (I.sel >= n) I.sel = Math.max(0, n - 1);
  if (I.sel < 0) I.sel = 0;
}
function drawInv(x, c) {
  const D = invDesign(),
    l = invList(),
    I = G.inv;
  if (I.sel >= l.length) I.sel = Math.max(0, l.length - 1);
  const r = MV.Inventory.draw(
    x,
    c.width,
    c.height,
    D,
    { tab: I.tab, sel: I.sel, list: l },
    G.sheet,
    G.time,
    (G.tune.charmSlots > 0 ? 'Notches ' + charms().used + '/' + G.tune.charmSlots + '   ' : '') +
      'Arrows: choose   Q / E or Tab: tab   Enter: use or equip   ' +
      kl(D.key) +
      ' or Esc: close'
  );
  I.cols = r.cols;
}
