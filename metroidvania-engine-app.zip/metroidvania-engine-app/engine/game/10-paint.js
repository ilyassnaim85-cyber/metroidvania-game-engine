// Camera debug (MV.Game.camera.debug(true), or the "Show camera" box in Player > Camera): the view, dead zone, soft zone, look-ahead, limits and camera zones
function paintCamDebug(x, Z) {
  const d = G.cam.dbg || {},
    v = d.view;
  if (!v) return;
  const R = (cx, cy, hw, hh) => x.strokeRect((cx - hw) * Z, (cy - hh) * Z, hw * 2 * Z, hh * 2 * Z),
    F = (cx, cy, hw, hh) => x.fillRect((cx - hw) * Z, (cy - hh) * Z, hw * 2 * Z, hh * 2 * Z);
  x.save();
  x.lineWidth = 2;
  x.font = '12px sans-serif';
  x.setLineDash([]);
  x.strokeStyle = '#4fc3f7';
  R(v[0], v[1], v[2] / 2, v[3] / 2); // what the camera shows
  x.fillStyle = '#4fc3f7';
  x.fillText(
    'view' + (G.vcam && G.vcam.active() ? ' (' + G.vcam.active() + ')' : ''),
    (v[0] - v[2] / 2) * Z + 4,
    (v[1] - v[3] / 2) * Z + 14
  );
  const dz = d.dz || [0, 0],
    sz = d.sz || [0, 0],
    cx = d.x,
    cy = d.y;
  if (dz[0] > 0 || dz[1] > 0) {
    x.fillStyle = 'rgba(93,202,165,.18)';
    F(cx, cy, dz[0], dz[1]);
    x.strokeStyle = '#5dcaa5';
    R(cx, cy, dz[0], dz[1]); // dead zone: the player moves freely here
  }
  if (sz[0] > 0 || sz[1] > 0) {
    x.setLineDash([6, 4]);
    x.strokeStyle = '#ef9f27';
    R(cx, cy, dz[0] + sz[0], dz[1] + sz[1]); // soft zone: the camera follows gradually, the player cannot go past this
    x.setLineDash([]);
  }
  if (d.look) {
    x.strokeStyle = x.fillStyle = '#e040fb';
    x.beginPath();
    x.moveTo(cx * Z, cy * Z);
    x.lineTo((cx + d.look[0]) * Z, (cy + d.look[1]) * Z);
    x.stroke();
    x.beginPath();
    x.arc((cx + d.look[0]) * Z, (cy + d.look[1]) * Z, 4, 0, 7);
    x.fill(); // look-ahead
  }
  if (d.bounds) {
    x.setLineDash([3, 5]);
    x.strokeStyle = '#ffffff';
    x.strokeRect(d.bounds[0] * Z, d.bounds[1] * Z, (d.bounds[2] - d.bounds[0]) * Z, (d.bounds[3] - d.bounds[1]) * Z); // where the middle of the view may go
    x.setLineDash([]);
  }
  x.strokeStyle = '#ff7043';
  x.fillStyle = '#ff7043';
  G.en.forEach(e => {
    if (e.type !== 'camzone' || e.dead) return;
    x.strokeRect((e.cx - e.w / 2) * Z, (e.by - e.h) * Z, e.w * Z, e.h * Z);
    x.fillText(
      'camera zone' + (e.p && e.p.profile ? ': ' + e.p.profile : ''),
      (e.cx - e.w / 2) * Z + 4,
      (e.by - e.h) * Z + 14
    );
  });
  x.strokeStyle = x.fillStyle = '#ffd54f';
  MV.CameraVcams.clean(G.world && G.world.vcams).forEach(c => {
    if (!c.bounds || (c.room && c.room !== G.room.id)) return;
    x.setLineDash([10, 5]);
    x.strokeRect(c.bounds[0] * Z, c.bounds[1] * Z, (c.bounds[2] - c.bounds[0]) * Z, (c.bounds[3] - c.bounds[1]) * Z);
    x.fillText('camera "' + c.name + '"', c.bounds[0] * Z + 4, c.bounds[1] * Z + 14);
  });
  x.restore();
}
function paint() {
  const c = G.canvas,
    x = c.getContext('2d'),
    r = G.room,
    p = G.p,
    pr = G.tune,
    o = G.cam.offset(),
    V = G.cam.view(),
    K = Z * V.zoom;
  const bg = r.bg || MV.Background.def(),
    imgOf = id => (G.image && id ? G.image(id) : null),
    bgArgs = [r.gw * Z, r.gh * Z, c.width, c.height, G.cam.x * Z, G.cam.y * Z];
  MV.Background.draw(x, bg, imgOf, ...bgArgs, false, 1, { k: Z, time: G.time });
  x.save();
  if (V.plain) x.translate(-Math.round(o[0] * Z), -Math.round(o[1] * Z));
  else {
    x.translate(c.width / 2, c.height / 2);
    x.rotate(V.rot);
    x.scale(V.zoom, V.zoom);
    x.translate(-V.cx * Z, -V.cy * Z);
  }
  const x0 = Math.max(0, Math.floor(V.rx) - 1),
    x1 = Math.min(r.gw - 1, Math.ceil(V.rx + V.rw) + 1),
    y0 = Math.max(0, Math.floor(V.ry) - 1),
    y1 = Math.min(r.gh - 1, Math.ceil(V.ry + V.rh) + 1);
  const sr = r.stream | 0,
    wx0 = sr ? Math.max(x0, Math.floor(p.x) - sr) : x0,
    wx1 = sr ? Math.min(x1, Math.floor(p.x) + sr) : x1,
    wy0 = sr ? Math.max(y0, Math.floor(p.y) - sr) : y0,
    wy1 = sr ? Math.min(y1, Math.floor(p.y) + sr) : y1;
  for (let ty = wy0; ty <= wy1; ty++)
    for (let tx = wx0; tx <= wx1; tx++) {
      const ch = r.grid[ty][tx];
      x.fillStyle = '#5b6b7a';
      if (G.cov.has(ty * r.gw + tx) && MV.Tiles.GROUND.includes(ch)) continue;
      if (
        ch !== '.' &&
        ch !== '^' &&
        ch !== 'D' &&
        MV.Tiles.draw(x, ch, tx * Z, ty * Z, Z, { time: G.time, tx, ty, at: raw, skins: G.skins, sheet: G.sheet })
      ) {
        /* painted by the shared tile painter */
      } else if (ch === '^') {
        x.fillStyle = '#d85a30';
        x.beginPath();
        x.moveTo(tx * Z, (ty + 1) * Z);
        x.lineTo((tx + 0.5) * Z, (ty + 0.4) * Z);
        x.lineTo((tx + 1) * Z, (ty + 1) * Z);
        x.fill();
      }
    }
  x.imageSmoothingEnabled = false;
  if (G.art) G.art(x, r, Z);
  // press-to-enter doorways: a closed door panel that slides open while you go in, and an arrow prompt when you stand in one
  (r.tr || []).forEach(t => {
    if (t.mode !== 'press' || !r.grid[t.y] || r.grid[t.y][t.x] !== 'D') return;
    const g = G.go && G.go.x === t.x && G.go.y === t.y ? Math.min(1, G.go.t / (G.go.open || 0.01)) : 0,
      w = Z * (1 - g * 0.9);
    x.fillStyle = '#2a1f17';
    x.fillRect(t.x * Z, t.y * Z, Z, Z);
    x.fillStyle = '#6b4a2f';
    x.fillRect(t.x * Z + (Z - w) / 2, t.y * Z + 1, w, Z - 2);
    x.fillStyle = '#d9b26b';
    if (g < 0.5) x.fillRect(t.x * Z + Z * 0.7, t.y * Z + Z * 0.5, Z * 0.08, Z * 0.08);
  });
  if (G.dprompt) {
    x.fillStyle = '#fff';
    x.font = 'bold ' + Math.round(Z * 0.7) + 'px sans-serif';
    x.textAlign = 'center';
    x.fillText(G.dprompt.k, (G.dprompt.x + 0.5) * Z, (G.dprompt.y - 0.3 + Math.sin(G.time * 6) * 0.1) * Z);
  }
  G.en.forEach(e => {
    if (e.type === 'enemy' && e.kd && !e.dead && live(e)) {
      enemyDraw(x, e, Z);
      return;
    }
    if (
      e.dead ||
      !live(e) ||
      e.type === 'light' ||
      e.type === 'lamp' ||
      e.type === 'darkness' ||
      e.type === 'lightzone' ||
      e.type === 'spawn' ||
      e.type === 'animsprite' ||
      e.type === 'camzone' ||
      e.type === 'evzone'
    )
      return;
    if ((e.type === 'msgzone' || (e.st === 'gone' && (e.type === 'collapse' || e.type === 'blink'))) && !skinWorn(e))
      return;
    if (e.type === 'boss') {
      MV.Boss.draw(x, e, Z, G.sheet, API.debug, { anims: G.world.anims });
      return;
    }
    x.fillStyle = D().entities[e.type].color;
    x.globalAlpha =
      e.inv > 0 && e.type !== 'breakable'
        ? 0.5
        : e.type === 'secret' && e.rev
          ? 0.22
          : e.type === 'current' || e.type === 'lowgrav'
            ? 0.22
            : e.type === 'icezone' || e.type === 'mudzone'
              ? 0.55
              : e.type === 'chest' && e.open
                ? 0.4
                : e.type === 'airpocket'
                  ? 0.22
                  : e.type === 'orb' && e.cd > 0
                    ? 0.15
                    : e.type === 'blink' && e.warn && Math.floor(G.time * 14) % 2
                      ? 0.35
                      : 1;
    const cs = e.type === 'collapse',
      shk =
        cs && e.st === 'shake'
          ? Math.sin(G.time * 70) * 0.05
          : e.type === 'breakable' && e.hurt > 0
            ? (Math.sin(G.time * 90) * 0.04 * e.hurt) / 0.35
            : 0,
      fl = cs && e.st === 'fall' ? e.fy : 0;
    if (cs && e.st === 'fall') x.globalAlpha = Math.max(0, 1 - e.ft / 0.9);
    const sk = !!skinDraw(x, e, Z) || (!!e.p.sprite && (D().spriteOnly || []).includes(ty(e)) && spriteDraw(x, e, Z));
    if (sk) {
      x.globalAlpha = 1;
    } else if (e.type === 'breakable' || cs) stoneDraw(x, e, Z, shk, fl);
    else if (e.type === 'cannon') cannonDraw(x, e, Z);
    else if (e.type === 'mount') mountDraw(x, e, Z);
    else if (e.type === 'rail') railDraw(x, e, Z);
    else if (e.type === 'airpocket') airDraw(x, e, Z);
    else x.fillRect((e.cx - e.w / 2 + shk) * Z, (e.by - e.h + fl) * Z, e.w * Z, e.h * Z);
    if (e.type === 'ladder') {
      x.strokeStyle = 'rgba(40,25,10,.8)';
      x.lineWidth = 3;
      const l0 = (e.cx - 0.3) * Z,
        l1 = (e.cx + 0.3) * Z,
        t0 = (e.by - e.h) * Z;
      x.beginPath();
      x.moveTo(l0, t0);
      x.lineTo(l0, e.by * Z);
      x.moveTo(l1, t0);
      x.lineTo(l1, e.by * Z);
      for (let j = 0.25; j < e.h; j += 0.5) {
        x.moveTo(l0, t0 + j * Z);
        x.lineTo(l1, t0 + j * Z);
      }
      x.stroke();
    }
    if (e.type === 'dashpad' || e.type === 'stickwall') {
      x.strokeStyle = '#fff';
      x.lineWidth = 2;
      x.globalAlpha = e.fl > 0 || e.act > 0 ? 0.95 : 0.55;
      const up = e.p.dir === 'up',
        dn2 = e.p.dir === 'down',
        lf = e.p.dir === 'left',
        pad = e.type === 'dashpad',
        n = pad ? Math.max(1, Math.round(e.w)) : Math.max(1, Math.floor(e.h)),
        ph = ((G.time * 1.5) % 1) * (up ? -1 : 1) * 0.3;
      for (let i = 0; i < n; i++) {
        const ax = pad ? (e.cx - e.w / 2 + i + 0.5) * Z : e.cx * Z,
          ay = pad ? (e.by - e.h / 2) * Z : (e.by - e.h + i + 0.5 + (pad ? 0 : dn2 || up ? ph : 0)) * Z;
        if (ay < (e.by - e.h) * Z - 1 || ay > e.by * Z + 1) continue;
        x.beginPath();
        if (up || dn2) {
          const s2 = up ? -1 : 1;
          x.moveTo(ax - 6, ay - 4 * s2);
          x.lineTo(ax, ay + 4 * s2);
          x.lineTo(ax + 6, ay - 4 * s2);
        } else {
          const s2 = lf ? -1 : 1;
          x.moveTo(ax - 3 * s2, ay - 5);
          x.lineTo(ax + 3 * s2, ay);
          x.lineTo(ax - 3 * s2, ay + 5);
        }
        x.stroke();
      }
    }
    if (e.type === 'current') {
      x.strokeStyle = '#fff';
      x.lineWidth = 2;
      x.globalAlpha = 0.6;
      const dx = e.p.dir === 'right' ? 1 : e.p.dir === 'left' ? -1 : 0,
        dy = e.p.dir === 'down' ? 1 : e.p.dir === 'up' ? -1 : 0,
        off = (G.time * (+e.p.power || 8) * 0.25) % 1;
      for (let i = 0; i < e.w; i++)
        for (let j = 0; j < e.h; j++) {
          const ax = (e.cx - e.w / 2 + i + 0.5 + dx * (off - 0.5)) * Z,
            ay = (e.by - e.h + j + 0.5 + dy * (off - 0.5)) * Z;
          x.beginPath();
          x.moveTo(ax - dx * 4 - dy * 5, ay - dy * 4 + dx * 5);
          x.lineTo(ax + dx * 4, ay + dy * 4);
          x.lineTo(ax - dx * 4 + dy * 5, ay - dy * 4 - dx * 5);
          x.stroke();
        }
    }
    if (e.type === 'conveyor') {
      x.strokeStyle = 'rgba(255,255,255,.55)';
      x.lineWidth = 2;
      const sp = +e.p.speed || 0,
        off = (((G.time * sp) % 1) + 1) % 1;
      for (let i = -1; i < e.w; i++) {
        const bx = (e.cx - e.w / 2 + i + off) * Z;
        if (bx < (e.cx - e.w / 2) * Z || bx > (e.cx + e.w / 2) * Z) continue;
        x.beginPath();
        x.moveTo(bx, (e.by - e.h + 0.2) * Z);
        x.lineTo(bx, (e.by - 0.2) * Z);
        x.stroke();
      }
    }
    if (e.type === 'spring' && e.sq > 0 && !sk) {
      x.fillStyle = '#fff';
      x.globalAlpha = 0.6;
      x.fillRect((e.cx - e.w / 2) * Z, (e.by - e.h) * Z, e.w * Z, 3);
    }
    x.globalAlpha = 1;
    if (e.type === 'npc' && e.pt > 0 && !G.dlg)
      MV.Dialog.bubble(x, e.ptxt || '', e.cx * Z, (e.by - e.h) * Z - (e.prompt ? 28 : 0), Math.min(1, e.pt * 2));
    if (e.prompt) {
      const bx = e.cx * Z,
        by2 = (e.by - e.h) * Z - 22;
      x.font = 'bold 14px system-ui,sans-serif';
      const bw = Math.max(22, Math.ceil(x.measureText(e.prompt).width) + 12);
      x.fillStyle = 'rgba(0,0,0,.7)';
      x.fillRect(bx - bw / 2, by2 - 11, bw, 22);
      x.strokeStyle = '#fff';
      x.lineWidth = 1.5;
      x.strokeRect(bx - bw / 2 + 0.5, by2 - 11 + 0.5, bw - 1, 21);
      x.fillStyle = '#fff';
      x.textAlign = 'center';
      x.textBaseline = 'middle';
      x.fillText(e.prompt, bx, by2 + 1);
    }
  });
  fxDraw(x, Z);
  G.es.forEach(q => {
    x.fillStyle = q.c;
    x.beginPath();
    x.arc(q.x * Z, q.y * Z, (q.w * Z) / 2, 0, 7);
    x.fill();
    x.strokeStyle = 'rgba(255,255,255,.7)';
    x.lineWidth = 1.5;
    x.stroke();
  });
  animPass(x, Z, false);
  x.save();
  if (p.inv > 0 && Math.floor(performance.now() / 70) % 2) x.globalAlpha = 0.35; // blinking while you cannot be hurt
  if (p.hid) x.globalAlpha = Math.min(x.globalAlpha, 0.5);
  else if (p.gh === 'all') x.globalAlpha = Math.min(x.globalAlpha, 0.6);
  if (p.ride) x.translate(0, -(+p.ride.e.p.seat || 0) * Z);
  if (p.cn && !anims().cannon) x.globalAlpha = 0; // underground and ghosting you are see-through, a rider sits on its mount, a cannon hides you
  if (p.stk) {
    const k = p.stk;
    x.translate((k.cx + k.dx) * Z, (k.cy + k.dy) * Z);
    x.scale(k.sx, k.sy);
    x.translate(-k.cx * Z, -k.cy * Z);
  }
  const xs = p.fx ? null : (p.mhb && p.mhb.surf && p.mhb.m.sprite) || (p.swimming && p.swimSp) || p.hsp || null;
  if (xs !== p.xsp) {
    p.xsp = xs;
    p.xst0 = G.time;
  }
  const spr =
    G.sprite &&
    G.sheet &&
    (xs
      ? MV.PlayerSprite.frame(
          x,
          { w: G.sprite().w, h: G.sprite().h, anims: { fx: xs } },
          G.sheet,
          'fx',
          G.time - p.xst0,
          p.x * Z,
          p.y * Z,
          p.face,
          Z
        )
      : p.fx
        ? MV.PlayerSprite.frame(
            x,
            {
              w: G.sprite().w,
              h: G.sprite().h,
              anims: {
                fx: Object.assign(
                  {},
                  p.fx.a,
                  p.fx.a.fit && (p.fx.dash || p.fx.fit) ? { fps: p.fx.a.frames / p.fx.len } : {}
                )
              }
            },
            G.sheet,
            'fx',
            p.fx.t,
            p.x * Z,
            p.y * Z,
            p.face,
            Z
          )
        : MV.PlayerSprite.frame(x, G.sprite(), G.sheet, p.anim.s, p.anim.t, p.x * Z, p.y * Z, p.face, Z));
  if (!spr) {
    x.fillStyle = p.mv ? '#fff' : '#5dcaa5';
    x.fillRect((p.x - pr.w / 2) * Z, (p.y - pr.h * (p.sq || 1)) * Z, pr.w * Z, pr.h * (p.sq || 1) * Z);
  }
  if (!spr) {
    x.fillStyle = '#12324a';
    x.fillRect((p.x + p.face * 0.15 - 0.08) * Z, (p.y - pr.h + 0.3) * Z, 0.16 * Z, 0.16 * Z);
  }
  {
    const lc = G.st.lostCoins;
    if (lc && lc.r === r.id) {
      const pu = 1 + Math.sin(G.time * 4) * 0.12;
      x.fillStyle = 'rgba(255,210,74,.25)';
      x.beginPath();
      x.arc(lc.x * Z, (lc.y - 0.4) * Z, 0.6 * Z * pu, 0, 7);
      x.fill();
      x.fillStyle = '#ffd24a';
      x.beginPath();
      x.arc(lc.x * Z, (lc.y - 0.3) * Z, 0.26 * Z, 0, 7);
      x.fill();
    }
  } // the bag of coins you dropped
  x.restore();
  if (p.hw)
    for (const id in p.hw) {
      const hm = G.mv.find(q => q.id === id);
      if (hm && hm.windup > 0 && p.hw[id] < hm.windup) {
        const f = p.hw[id] / hm.windup;
        x.fillStyle = 'rgba(0,0,0,.5)';
        x.fillRect((p.x - 0.5) * Z, (p.y - pr.h - 0.35) * Z, Z, 0.15 * Z);
        x.fillStyle = '#5dcaa5';
        x.fillRect((p.x - 0.5) * Z, (p.y - pr.h - 0.35) * Z, Z * f, 0.15 * Z);
      }
    } // hold-move charge bar
  if (pr.oxygen > 0 && p.air !== undefined && p.air < pr.oxygen - 0.01) {
    const f = Math.max(0, p.air / pr.oxygen),
      by0 = (p.y - pr.h * (p.sq || 1) - 0.6) * Z;
    x.fillStyle = 'rgba(0,0,0,.5)';
    x.fillRect((p.x - 0.5) * Z, by0, Z, 0.15 * Z);
    x.fillStyle = f > 0.3 || Math.floor(G.time * 6) % 2 ? '#7ee0ff' : '#ff6b6b';
    x.fillRect((p.x - 0.5) * Z, by0, Z * f, 0.15 * Z);
  } // air bar
  if (p.chg) {
    const f = Math.min(1, p.chg.t / p.chg.o.charge);
    x.fillStyle = 'rgba(0,0,0,.5)';
    x.fillRect((p.x - 0.5) * Z, (p.y - pr.h - 0.35) * Z, Z, 0.15 * Z);
    x.fillStyle = f >= 1 ? '#ffd24a' : '#5dcaa5';
    x.fillRect((p.x - 0.5) * Z, (p.y - pr.h - 0.35) * Z, Z * f, 0.15 * Z);
  } // charge bar
  if (p.mv && p.mv.g) {
    const g = p.mv.g;
    x.strokeStyle = '#e8c34a';
    x.lineWidth = 3;
    x.beginPath();
    x.moveTo(p.x * Z, (p.y - pr.h / 2) * Z);
    x.lineTo(g.tx * Z, g.ty * Z);
    x.stroke();
    x.fillStyle = '#ffe9a0';
    x.beginPath();
    x.arc(g.tx * Z, g.ty * Z, 0.18 * Z, 0, 7);
    x.fill();
  } // the grapple rope
  if (G.thr) {
    const it = G.thr,
      lm = G.mv.find(q => q.id === it.m.id) || it.m;
    if (lm.life > 0 && lm.life - (it.age || 0) < 1.5) x.globalAlpha = 0.35 + 0.35 * Math.sin(G.time * 20);
    x.fillStyle = '#7ee0ff';
    x.strokeStyle = '#fff';
    x.lineWidth = 2;
    x.beginPath();
    x.arc(it.x * Z, it.y * Z, 0.22 * Z, 0, 7);
    x.fill();
    x.stroke();
    if (it.rest) {
      x.globalAlpha = 0.5 + 0.3 * Math.sin(G.time * 8);
      x.beginPath();
      x.arc(it.x * Z, it.y * Z, 0.4 * Z, 0, 7);
      x.stroke();
      x.globalAlpha = 1;
    }
  }
  if (p.mv && p.mv.b && p.mv.b.ph === 'aim') {
    const b = p.mv.b,
      n = Math.hypot(b.ix || 0, b.iy || 0) || 1,
      ax = n && (b.ix || b.iy) ? b.ix / n : p.face,
      ay = b.ix || b.iy ? b.iy / n : 0,
      cx = b.o.cx * Z,
      cy = (b.o.by - b.o.h / 2) * Z;
    x.strokeStyle = '#ffd37a';
    x.lineWidth = 3;
    x.beginPath();
    x.moveTo(cx, cy);
    x.lineTo(cx + ax * 1.6 * Z, cy + ay * 1.6 * Z);
    x.stroke();
  }
  (p.hbs || []).forEach(r => {
    const fc = p.at ? p.at.face : p.mhb ? p.mhb.face : p.face,
      art =
        G.sheet &&
        r.vis &&
        MV.PlayerSprite.frame(
          x,
          { w: r.w, h: r.h, anims: { idle: r.vis } },
          G.sheet,
          'idle',
          r.t,
          r.cx * Z,
          (r.cy + r.h / 2) * Z,
          fc,
          Z
        );
    if (!art) {
      x.fillStyle = 'rgba(255,255,255,.55)';
      MV.Attacks.trace(x, r, Z);
      x.fill();
    }
    if (API.debug || API.boxes) {
      x.strokeStyle = '#ffd24a';
      x.lineWidth = 1.5;
      MV.Attacks.trace(x, r, Z);
      x.stroke();
    }
  });
  if ((API.debug || API.boxes) && p.bshape) {
    x.strokeStyle = bodyOff() ? 'rgba(180,178,169,.8)' : '#5dcaa5';
    x.lineWidth = 1.5;
    x.setLineDash(bodyOff() ? [4, 3] : []);
    MV.Attacks.trace(x, p.bshape, Z);
    x.stroke();
    x.setLineDash([]);
  } // the body hitbox: green, dashed grey while it is switched off
  animPass(x, Z, true);
  if (G.camDbg) paintCamDebug(x, Z);
  if (API.debug) {
    // collision shape inspector
    x.lineWidth = 1.5;
    x.strokeStyle = '#ef9f27';
    for (let ty = y0; ty <= y1; ty++)
      for (let tx = x0; tx <= x1; tx++) {
        const ch = r.grid[ty][tx];
        if (MV.Tiles.BLOCKS.includes(ch) || ch === 'g') x.strokeRect(tx * Z, ty * Z, Z, Z);
        else if (ch === '=') x.strokeRect(tx * Z, ty * Z, Z, Z / 2);
        else if (MV.Light.PROFILES[ch]) {
          const pf = MV.Light.PROFILES[ch];
          x.beginPath();
          x.moveTo(tx * Z, (ty + pf[0]) * Z);
          x.lineTo((tx + 1) * Z, (ty + pf[1]) * Z);
          x.stroke();
        }
      }
    x.strokeStyle = '#e24b4a';
    G.en.forEach(e => {
      if (!e.dead) x.strokeRect((e.cx - e.w / 2) * Z, (e.by - e.h) * Z, e.w * Z, e.h * Z);
    });
    x.strokeStyle = '#fff';
    x.strokeRect((p.x - pr.w / 2) * Z, (p.y - pr.h) * Z, pr.w * Z, pr.h * Z);
  }
  x.restore();
  MV.Background.draw(x, bg, imgOf, ...bgArgs, true, 1, { k: Z, time: G.time });
  {
    // darkness: the room's light level, the player's own light and any Light entities cut holes in it
    const L = MV.Light.clean(r.light) || MV.Light.def(),
      ox = Math.round(V.rx * K),
      oy = Math.round(V.ry * K);
    const lights = MV.Light.fromEntities(r.ent)
      .concat([{ x: p.x, y: p.y - pr.h / 2, r: L.pr, level: L.pl }])
      .map(l => MV.Light.scale(l, K, ox, oy));
    // light zones are darkness zones (walls stop them, like any shade) whose strength follows how lit you have made them; with invert, the room outside goes dark while you are inside and the zone stays lit
    let amb = L.ambient;
    const lzs = [],
      zl = MV.Light.zonesFromEntities(r.ent).map(z => {
        if (!z.lz) return z;
        const e = G.en.find(q => q.type === 'lightzone' && q.uid === r.id + ':' + z.id),
          lv = e && e.lv !== undefined ? e.lv : 0,
          inv = e && e.p.invert === 'yes';
        if (inv) {
          lzs.push({ z, lv });
          return Object.assign({}, z, { amount: z.amount * (1 - lv) });
        }
        return Object.assign({}, z, { amount: z.amount * (1 - lv) });
      });
    lzs.forEach(q => {
      amb *= 1 - q.z.amount * q.lv;
    });
    lzs.forEach(q => {
      const den = 1 - amb,
        lvl = den > 0 ? Math.max(0, Math.min(1, 1 - (1 - L.ambient) / den)) : 0;
      if (q.lv > 0.003 && lvl > 0)
        lights.push(
          MV.Light.scale(Object.assign({}, q.z, { level: lvl, shadows: q.z.walls, color: undefined }), K, ox, oy)
        );
    });
    const zones = zl.map(l => MV.Light.scale(l, K, ox, oy));
    MV.Light.draw(
      x,
      {
        w: c.width,
        h: c.height,
        ambient: amb,
        tint: L.tint,
        lights,
        zones,
        solid: (tx, ty) => {
          const c = G.room.grid[ty] && G.room.grid[ty][tx];
          return tx < 0 || tx >= G.room.gw || ty < 0 ? true : MV.Light.tileSolid(c);
        },
        zsolid: (tx, ty) => {
          const c = G.room.grid[ty] && G.room.grid[ty][tx];
          return tx < 0 || tx >= G.room.gw || ty < 0 ? true : MV.Light.tileZsolid(c);
        },
        slope: (tx, ty) => {
          const c = G.room.grid[ty] && G.room.grid[ty][tx];
          return MV.Light.PROFILES[c] ? c : null;
        },
        k: K,
        ox,
        oy,
        time: G.time
      },
      G.lightCache || (G.lightCache = {})
    ); // does nothing in a lit room without coloured lamps
    if (L.ambient < 1 && L.hz > 0) {
      x.save();
      x.translate(-ox, -oy);
      x.scale(V.zoom, V.zoom);
      x.globalAlpha = L.hz * 0.55;
      x.fillStyle = '#d85a30'; // hazards stay easy to see in the dark
      for (let ty = y0; ty <= y1; ty++)
        for (let tx = x0; tx <= x1; tx++)
          if (r.grid[ty][tx] === '^') {
            x.beginPath();
            x.moveTo(tx * Z, (ty + 1) * Z);
            x.lineTo((tx + 0.5) * Z, (ty + 0.4) * Z);
            x.lineTo((tx + 1) * Z, (ty + 1) * Z);
            x.fill();
          }
      G.en.forEach(e => {
        if (!e.dead && e.type === 'hazard') x.fillRect((e.cx - e.w / 2) * Z, (e.by - e.h) * Z, e.w * Z, e.h * Z);
      });
      x.restore();
    }
  }
  const UI = uiNow();
  MV.Boss.hud(x, G, c.width, UI);
  MV.UI.hud(
    x,
    c.width,
    c.height,
    UI,
    {
      hp: G.hp,
      maxHp: G.tune.maxHp,
      mp: G.mp,
      mpMax: G.tune.energyMax,
      mpFlash: G.mpf,
      room: r.n,
      coins: G.coins,
      abilities: Object.keys(G.st.abilities),
      weapon: G.st.weapon || '',
      items: hudItems(UI),
      status: MV.Status.list(G.status)
    },
    G.sheet,
    G.time
  );
  MV.UI.minimap(x, c.width, c.height, UI, mapNow(UI));
  if (API.boxes || API.debug) {
    const ks = Object.keys(G.keys).filter(k => G.keys[k] && !/^Pad:[am]:/.test(k));
    x.fillStyle = 'rgba(0,0,0,.55)';
    x.fillRect(c.width - 330, 6, 324, 20);
    x.fillStyle = ks.length ? '#7ee0ff' : '#8fa3b3';
    x.textAlign = 'right';
    x.fillText('Keys held: ' + (ks.join(' + ') || 'none') + (ks.length >= 3 ? '' : ''), c.width - 10, 9);
    x.textAlign = 'left';
    const lg = G.ev ? G.ev.log.slice(-4) : [];
    if (lg.length) {
      x.fillStyle = 'rgba(0,0,0,.55)';
      x.fillRect(c.width - 330, 28, 324, 4 + lg.length * 13);
      x.fillStyle = '#ffd98a';
      x.textAlign = 'right';
      lg.forEach((q, i) => x.fillText(q.ev + ': ' + q.text, c.width - 10, 31 + i * 13));
      x.textAlign = 'left';
    }
  } // test room: what the browser says you are holding (a keyboard that cannot send three keys at once shows up here)
  MV.UI.messages(x, c.width, UI, G.msgs);
  if (G.dfade) {
    x.fillStyle = 'rgba(0,0,0,' + (1 - G.dfade.t / G.dfade.len) + ')';
    x.fillRect(0, 0, c.width, c.height);
  }
  if (G.dscr) {
    const a = Math.min(1, G.dscr.t / 0.5),
      b = Math.min(1, Math.max(0, G.dscr.len - G.dscr.t) / 0.3);
    MV.UI.death(x, c.width, c.height, UI, a * b, a);
    x.textAlign = 'left';
    x.textBaseline = 'top';
  }
  if (G.inv) drawInv(x, c);
  if (G.fm) drawMap(x, c);
  if (G.shop) drawShop(x, c);
  if (G.pm) drawPause(x, c);
  if (G.dlg) {
    const d = G.dlg,
      ln = d.lines[d.i],
      DG = MV.Dialog.clean(G.world && G.world.dialog);
    MV.Dialog.draw(
      x,
      DG,
      G.sheet,
      { x: 12, y: c.height - 132, w: c.width - 24, h: 120 },
      ln.who,
      ln.who === 'me' ? DG.name : d.e.p.name || '',
      ln.text,
      Math.floor(d.t),
      performance.now() / 1000
    );
  }
  G.cam.drawOverlay(x, c.width, c.height);
}

// The screen settings from the UI tab (cleaned once per world object), and the item counters the HUD shows.
function uiNow() {
  const w = G.world || {};
  if (G.uiSrc !== w.ui || !G.uiClean) {
    G.uiSrc = w.ui;
    G.uiClean = MV.UI.clean(w.ui);
  }
  return G.uiClean;
}
function hudItems(U) {
  return U.hudItems
    ? U.hudItems.split(', ').map(id => {
        const d = MV.Inventory.find(G.items, id);
        return { name: d ? d.name : id, count: MV.Inventory.count(G.st, id), icon: (d && d.icon) || null };
      })
    : [];
}

// The rooms the minimap shows: the ones of this area you have been in (and the others as outlines when the UI tab says so).
function mapNow(U) {
  if (U.mapShow !== 'yes' || !G.area || !G.area.rooms) return { rooms: [] };
  const seen = G.st.seen || {};
  return {
    rooms: G.area.rooms
      .filter(r => r === G.room || seen[r.id] || U.mapAll === 'yes')
      .map(r => ({
        x: r.x || 0,
        y: r.y || 0,
        w: r.w || r.gw,
        h: r.h || r.gh,
        here: r === G.room,
        seen: !!seen[r.id]
      })),
    px: G.p.x / G.room.gw,
    py: G.p.y / G.room.gh
  };
}
