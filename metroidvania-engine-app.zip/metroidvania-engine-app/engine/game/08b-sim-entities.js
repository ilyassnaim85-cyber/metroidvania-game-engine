// One simulation step, part 3: what each kind of placed entity does every frame (collapsing floors, springs, signs, chests, bosses ...).
// sim() calls these from its entity loop. Same contract as part 2, plus the entity `e`; [value] ends that entity's turn early.
// an enemy made in the Enemies tab (its own damage rules)
function simEnemyKd(SIM, dt, e) {
  const { hitD } = SIM;

  const r = enemyTick(e, dt, hitD);
  if (r && r.touch) {
    SIM.ct = 1;
    SIM.csx = e.cx;
    SIM.ctO = r.ov;
  }
}

// an old-style enemy
function simEnemy(SIM, dt, e) {
  const { hit, ov, bodyE, hitD } = SIM;

  if (hit(e) && e.inv <= 0) {
    e.hp -= hitD(e);
    e.inv = 0.3;
    G.cam.shake(0.15);
    onHit();
    if (e.hp <= 0) e.dead = true;
  } else {
    const sp = +e.p.speed || 0;
    if (sp) {
      e.cx += e.dir * sp * dt;
      const x2 = Math.floor(e.cx + (e.dir * e.w) / 2),
        g = tl(x2, Math.floor(e.by + 0.1));
      if (
        Math.abs(e.cx - e.ox) > (+e.p.range || 3) ||
        tl(x2, Math.floor(e.by - 0.5)) === '#' ||
        !MV.Tiles.GROUND.includes(g)
      )
        e.dir *= -1;
    }
  }
  if (!e.dead && ov(e) && bodyE(e)) {
    SIM.ct = 1;
    SIM.csx = e.cx;
  }
}

// a floor that collapses once you stand on it
function simCollapse(SIM, dt, e) {
  const { p, W, T2, B2 } = SIM;

  // collapsing ground: stand on it and it shakes for the delay, then falls away; it comes back after the respawn time (0 = never)
  const top = e.by - e.h;
  if (
    e.st === 'idle' &&
    p.on &&
    Math.abs(p.y - top) < 0.1 &&
    p.x + W / 2 > e.cx - e.w / 2 &&
    p.x - W / 2 < e.cx + e.w / 2
  ) {
    e.st = 'shake';
    e.t = Math.max(0, +e.p.delay || 0);
  } else if (e.st === 'shake') {
    e.t -= dt;
    if (e.t <= 0) {
      e.st = 'fall';
      e.fy = 0;
      e.fv = 0;
      e.ft = 0;
      G.cam.shake(0.15);
    }
  } else if (e.st === 'fall') {
    e.fv += 40 * dt;
    e.fy += e.fv * dt;
    e.ft += dt;
    if (e.ft > 0.9) {
      if ((+e.p.respawn || 0) > 0) {
        e.st = 'gone';
        e.rt = +e.p.respawn;
      } else e.dead = true;
    }
  } else if (e.st === 'gone') {
    e.rt -= dt;
    if (e.rt <= 0 && !(Math.abs(e.cx - p.x) < (e.w + W) / 2 && e.by > T2 && e.by - e.h < B2)) {
      e.st = 'idle';
      e.fy = 0;
    }
  }
}

// a spring throws you up
function simSpring(SIM, dt, e) {
  const { p, ov, pr } = SIM;

  // bounce pad: land on it and you are thrown up by Power tiles
  if (e.sq > 0) e.sq -= dt;
  if (p.vy >= 0 && ov(e) && p.y > e.by - e.h - 0.15 && p.y <= e.by + 0.1) {
    p.vy = -Math.sqrt(2 * pr.gravity * Math.max(0.5, +e.p.power || 6));
    p.on = false;
    p.cy = 0;
    e.sq = 0.25;
    G.cam.shake(0.06);
  }
}

// a sign shows its text when you are near
function simSign(SIM, dt, e) {
  const { near } = SIM;

  // sign: shows its text when you stand near it
  const kmode = !!e.keyed,
    k2 = kc(e.p.key);
  e.prompt = kmode && near(e) ? kl(e.p.key) : '';
  if (near(e) && !(e.wt > G.time) && (!kmode || G.pr[k2] > 0)) {
    msg(e.p.text || '');
    e.wt = G.time + 3;
    G.pr[k2] = 0;
    if (kmode) act('sign');
  }
}

// a dash pad launches you
function simDashpad(SIM, dt, e) {
  const { ov, p } = SIM;

  // dash pad: touch it and you are thrown along its direction
  e.cd = Math.max(0, (e.cd || 0) - dt);
  if (e.cd <= 0 && ov(e)) {
    const d = e.p.dir,
      dx = d === 'right' ? 1 : d === 'left' ? -1 : 0,
      dy = d === 'up' ? -1 : d === 'down' ? 1 : 0,
      du = Math.max(0.05, +e.p.duration || 0.25),
      spd = Math.max(1, +e.p.speed || 18);
    p.mv = {
      m: { type: 'dash', speed: spd, accel: 0, duration: du, keep: 0.35, gravity: 0, stop: 'no' },
      dx,
      dy,
      t: du,
      el: 0
    };
    p.vx = dx * spd;
    p.vy = dy * spd;
    p.on = false;
    p.cl = null;
    if (dx) p.face = dx;
    e.cd = 0.4;
    e.fl = 0.25;
    G.cam.shake(0.08);
  }
  if (e.fl > 0) e.fl -= dt;
}

// a wall you can stick to
function simStickwall(SIM, dt, e) {
  const { W, p, H } = SIM;

  // climb wall: hold toward it while touching its side and you are carried up (or down)
  const gap = (e.w + W) / 2,
    side = Math.sign(e.cx - p.x),
    top = e.by - e.h;
  if (SIM.dir && SIM.dir === side && Math.abs(Math.abs(e.cx - p.x) - gap) < 0.12 && p.y > top && p.y - H < e.by) {
    const sp = +e.p.speed || 4;
    p.vy = e.p.dir === 'down' ? sp : -sp;
    p.on = false;
    p.cy = 0;
    e.act = 0.15;
  }
  if (e.act > 0) e.act -= dt;
}

// a water current pushes you
function simCurrent(SIM, dt, e) {
  const { ov, p, H, W, pr } = SIM;

  // water current: pushes you along while you are inside it
  if (ov(e)) {
    const pw = +e.p.power || 0,
      d = e.p.dir;
    if (d === 'right' || d === 'left') {
      const sg = d === 'right' ? 1 : -1,
        nx = p.x + sg * pw * dt;
      let bl = false;
      for (let ty = Math.floor(p.y - H); ty <= Math.floor(p.y - 0.01); ty++)
        if (tl(Math.floor(nx + (sg * W) / 2), ty) === '#') bl = true;
      if (!bl) p.x = nx;
    } else if (d === 'up') {
      p.vy = Math.max(p.vy - (pw + pr.gravity) * dt, -pw);
      p.on = false;
    } else p.vy = Math.min(p.vy + pw * 3 * dt, Math.max(pw, p.vy));
  }
}

// a message zone
function simMsgzone(SIM, dt, e) {
  const { ov, p } = SIM;

  // message zone: shows its text when you walk in
  const inside = ov(e);
  if (inside && !e.was && !(e.p.once === 'yes' && e.done)) {
    msg(e.p.text || '');
    e.done = 1;
    if (e.p.stop === 'yes') {
      p.frz = G.time + Math.max(0.2, +e.p.hold || 2);
      p.vx = 0;
      p.mv = null;
    }
  }
  e.was = inside;
}

// a light zone you stand in
function simLightzone(SIM, dt, e) {
  const { p, pr, st } = SIM;

  // light zone: dark from outside, lit while you are inside its shape
  e.inside = lzIn(e, p.x, p.y - pr.h / 2);
  if (e.inside && !e.seen) {
    e.seen = true;
    if (e.p.stay === 'yes') {
      st.flags['lz:' + e.uid] = 1;
      save();
    }
  }
  const want = e.inside || (e.p.stay === 'yes' && e.seen) ? 1 : 0,
    stp = dt / Math.max(0.01, +e.p.fade || 0);
  e.lv = e.lv === undefined ? want : e.lv + Math.max(-stp, Math.min(stp, want - e.lv));
}

// a teleporter sends you to its partner
function simTeleporter(SIM, dt, e) {
  const { ov, p } = SIM;

  // teleporter: touch it and you arrive at the other teleporter with the same channel
  e.cd = Math.max(0, (e.cd || 0) - dt);
  if (e.cd <= 0 && ov(e)) {
    const o = G.en.find(
      q => q !== e && q.type === 'teleporter' && !q.dead && String(q.p.channel) === String(e.p.channel)
    );
    if (o) {
      p.x = o.cx;
      p.y = o.by;
      p.mv = null;
      p.cl = null;
      p.lg = p.rl = p.cn = null;
      const ln = +o.p.launch || 0;
      if (ln > 0) {
        const a = ((+o.p.angle || 0) * Math.PI) / 180;
        p.vx = Math.cos(a) * ln;
        p.vy = -Math.sin(a) * ln;
        p.kx = p.vx;
        p.kt = 0.3;
        p.on = false;
        p.cy = 0;
        if (Math.abs(p.vx) > 0.1) p.face = p.vx < 0 ? -1 : 1;
      } else if (o.p.keep !== 'yes') p.vx = p.vy = 0;
      e.cd = o.cd = 1;
      G.cam.shake(0.1);
    }
  }
}

// a rail you ride
function simRail(SIM, dt, e) {
  const { p, swim, H } = SIM;

  // zipline or rail: touch it (or press its key) and you ride it along its line
  const q = railGeom(e),
    hang = e.p.hang !== 'stand on top',
    kk = e.p.grab === 'press a key' ? kc(e.p.key) : null;
  if (!p.rl && !p.lg && !p.cn && !p.mv && !p.cl && !swim && !(p.rlcd > 0) && (!kk || G.pr[kk] > 0)) {
    const gx = p.x,
      gy = hang ? p.y - H : p.y,
      t = Math.max(0, Math.min(1, ((gx - q.ax) * q.ux + (gy - q.ay) * q.uy) / q.len)),
      qx = q.ax + q.ux * t * q.len,
      qy = q.ay + q.uy * t * q.len;
    if (Math.hypot(gx - qx, gy - qy) < (hang ? 0.6 : 0.3) && (hang ? !p.on : p.vy >= 0 && gy <= qy + 0.2)) {
      p.rl = { e, s: t * q.len, v: Math.max(-40, Math.min(40, p.vx * q.ux + p.vy * q.uy)), t: 0 };
      if (e.p.mode !== 'steer with Left and Right') p.rl.v = Math.max(0, p.rl.v);
      if (kk) G.pr[kk] = 0;
      p.muse = {};
      p.on = false;
    }
  }
}

// a cannon you can enter
function simCannon(SIM, dt, e) {
  const { p, ov, H } = SIM;

  // cannon: touch it and you are loaded; it fires you along its angle
  e.cd = Math.max(0, (e.cd || 0) - dt);
  if (e.fl > 0) e.fl -= dt;
  if (!(p.cn && p.cn.e === e)) cannonAng(e, dt, 0, false);
  if (!p.cn && !p.rl && !p.lg && !p.mv && !p.cl && !p.dying && e.cd <= 0 && ov(e)) {
    p.cn = { e, t: 0 };
    p.vx = p.vy = 0;
    p.on = false;
    p.x = e.cx;
    p.y = e.by - e.h / 2 + H / 2;
    p.muse = {};
  }
}

// a mount you can ride
function simMount(SIM, dt, e) {
  const { p, near } = SIM;

  // mount: press its key near it to ride, press it again to get off
  const RD = p.ride,
    mine = !!RD && RD.e === e,
    kk = kc(e.p.key);
  e.ridden = mine;
  if (mine) {
    RD.t += dt;
    e.cx = p.x;
    e.by = p.y;
    e.fc = p.face;
    e.prompt = '';
    if (G.pr[kk] > 0 && RD.t > 0.3) {
      G.pr[kk] = 0;
      dismount();
    }
  } else {
    if (e.p.kind !== 'flies') {
      e.fv = (e.fv || 0) + 40 * dt;
      const ny = e.by + e.fv * dt;
      if (tl(Math.floor(e.cx), Math.floor(ny)) === '#' && ny > e.by) {
        e.by = Math.floor(ny);
        e.fv = 0;
      } else if (ny < G.room.gh + 3) e.by = ny;
    }
    e.prompt = !RD && near(e) && !(e.p.needs && !can(e.p.needs)) ? kl(e.p.key) : '';
    if (!RD && near(e) && G.pr[kk] > 0 && !p.mv && !p.cl && !p.dying) {
      G.pr[kk] = 0;
      mountUp(e);
    }
  }
}

// a chest opens and gives its item
function simChest(SIM, dt, e) {
  const { near, st } = SIM;

  // chest: stand near and press its key to open it once
  const kk = kc(e.p.key);
  e.prompt = !e.open && near(e) ? kl(e.p.key) : '';
  if (!e.open && near(e) && G.pr[kk] > 0) {
    e.open = true;
    G.pr[kk] = 0;
    st.flags['chest:' + e.uid] = 1;
    const n = Math.max(1, Math.round(+e.p.amount || 1)),
      gv = e.p.give;
    const nm = String(e.p.name || '').trim() || gv || 'a key',
      custom = String(e.p.message || '').trim();
    if (e.p.reward === 'coins') {
      G.coins += n;
      msg(custom || 'Found ' + n + ' coin' + (n > 1 ? 's' : ''));
    } else if (e.p.reward === 'key' || e.p.reward === 'flag') {
      if (gv) st.flags[gv] = 1;
      msg(custom || 'You obtained ' + nm);
    } else if (e.p.reward === 'weapon') {
      if (gv) giveWeapon(gv);
    } else if (e.p.reward === 'upgrade') {
      if (!upgrade(gv, n)) {
        e.open = false;
        delete st.flags['chest:' + e.uid];
        msg('The chest is empty (unknown upgrade)');
      }
    } else if (e.p.reward === 'energy') {
      gain(n);
      msg(custom || 'Energy +' + n);
    } else if (e.p.reward === 'item') {
      const def = MV.Inventory.find(G.items, gv),
        put = def ? MV.Inventory.add(st, def, n) : 0;
      if (put) msg(custom || 'Got ' + def.name + (put > 1 ? ' x' + put : ''));
      else {
        e.open = false;
        delete st.flags['chest:' + e.uid];
        msg(def ? 'Your ' + def.name + ' is full' : 'The chest is empty');
      }
    } else if (MV.Progress.unlock(st, gv)) msg(custom || 'Unlocked ' + (ab(gv) ? ab(gv).label : gv));
    else {
      e.open = false;
      delete st.flags['chest:' + e.uid];
      msg('The chest will not open yet');
    }
    if (e.open) act('chest');
    G.cam.shake(0.12);
    save();
  }
}

// a character you can talk to
function simNpc(SIM, dt, e) {
  const { st, near, p } = SIM;

  // character: stand near and press its key to talk
  const kk = kc(e.p.key),
    DL = MV.Dialog,
    again = st.flags['talked:' + e.uid] && String(e.p.after || '').trim(),
    script = DL.parse(again ? e.p.after : e.p.dialogue),
    pass = DL.parse(e.p.passing);
  e.prompt = script.length && near(e) ? kl(e.p.key) : '';
  if (script.length && near(e) && G.pr[kk] > 0) {
    G.pr[kk] = 0;
    G.dlg = { e, lines: script, i: 0, t: 0 };
    G.keys = {};
    p.vx = 0;
    e.pt = 0;
  } else if (pass.length) {
    const Rg = Math.max(1, +e.p.range || 4),
      inr = Math.abs(e.cx - p.x) < Rg && Math.abs(e.by - p.y) < 3; // walking past: it says one of its passing lines, then waits until you leave and come back
    if (inr && !e.pw) {
      e.pw = true;
      e.ptxt = pass[(e.pi || 0) % pass.length].text;
      e.pi = (e.pi || 0) + 1;
      e.pt = 4;
    }
    if (!inr) {
      e.pw = false;
      e.pt = 0;
    }
    e.pt = Math.max(0, (e.pt || 0) - dt);
  }
}

// a boss: runs its brain and hurts you
function simBoss(SIM, dt, e) {
  const { p, W, H, bodyAt, st, hit, bodyShape, hitD } = SIM;

  MV.Boss.tick(e, dt, {
    room: { gw: G.room.gw, gh: G.room.gh },
    blocked: (cx, by, w, h) => eHit({ w, h }, cx, by),
    emit: (t, d) => {
      if (G.script) G.script.emit(t, d);
    },
    brain: (name, me) => {
      if (G.script) G.script.call(name, me);
    },
    shoot: o => enemyShot(o, 1),
    on: p.on,
    anims: G.world.anims,
    die: (e2, def) => {
      const cl = def.clips.die && MV.Anim.find(G.world.anims, def.clips.die);
      if (cl && cl.frames.length)
        G.fx.push({
          k: 'clip',
          cl,
          t: 0,
          e: { sk: 'enemy', type: 'enemy', w: def.sprite.w, h: def.sprite.h },
          cx: e2.cx,
          by: e2.by
        });
    },
    p,
    W,
    H,
    body: bodyAt,
    bodyS: r => MV.Attacks.shapeHit(r, bodyShape),
    onHit,
    st,
    hit,
    msg,
    save,
    shake: a => G.cam.shake(a),
    snd: id => {
      if (MV.Audio) MV.Audio.play(id);
    },
    hurt: o => {
      SIM.ct = 1;
      SIM.csx = e.cx;
      SIM.ctO = o;
    },
    dmg: e => hitD(e)
  });
}

// an item or coin you can pick up
function simPickup(SIM, dt, e) {
  const { st } = SIM;

  const g = e.p.give,
    kd = e.p.kind;
  if (kd === 'ability') {
    if (!MV.Progress.unlock(st, g)) {
      if (!(e.wt > G.time)) {
        msg('Needs ' + ((ab(g) && ab(g).requires) || []).join(', ') + ' first');
        e.wt = G.time + 2;
      }
      return [undefined];
    }
    msg('Unlocked ' + (ab(g) ? ab(g).label : g));
  } else if (kd === 'weapon') giveWeapon(g);
  else if (kd === 'upgrade') {
    if (!upgrade(g, Math.max(1, Math.round(+e.p.amount || 1)))) {
      if (!(e.wt > G.time)) {
        msg('Unknown upgrade "' + g + '" (use maxHp, energyMax or charmSlots)');
        e.wt = G.time + 2;
      }
      return [undefined];
    }
  } else if (kd === 'energy') {
    gain(Math.max(1, +e.p.amount || 1));
    msg('Energy +' + Math.max(1, +e.p.amount || 1));
  } else if (kd === 'item' && MV.Inventory.find(G.items, g)) {
    const def = MV.Inventory.find(G.items, g),
      n = Math.max(1, Math.round(+e.p.amount || 1)),
      put = MV.Inventory.add(st, def, n);
    if (!put) {
      if (!(e.wt > G.time)) {
        msg('Your ' + def.name + ' is full');
        e.wt = G.time + 2;
      }
      return [undefined];
    }
    msg('Got ' + def.name + (put > 1 ? ' x' + put : ''));
  } else if (kd === 'flag') st.flags[g] = 1;
  else G.coins++;
  st.collected[e.uid] = 1;
  e.dead = true;
  fxClip(e, 'collected');
  act('pickup');
  save();
}

// a checkpoint saves your place
function simCheckpoint(SIM, dt, e) {
  const { near, ov, st } = SIM;

  // touch it, or stand near and press its key (E by default), to save here
  const kmode = !!e.keyed,
    pr2 = G.pr[kc(e.p.key)] > 0;
  e.prompt = kmode && !e.on && near(e) ? kl(e.p.key) : '';
  if (kmode ? near(e) && pr2 : ov(e) && !e.on) {
    const first = !e.on;
    e.on = true;
    G.en.forEach(o => {
      if (o.type === 'checkpoint' && o !== e) o.on = false;
    });
    st.cp = { a: G.area.id, r: G.room.id, x: e.cx, y: e.by };
    if (kmode) {
      G.hp = G.tune.maxHp;
      G.mp = G.tune.energyMax;
      act('checkpoint');
    } else G.hz = { x: e.cx, y: e.by };
    msg(first ? 'Checkpoint saved' : 'Checkpoint saved again');
    if (first) G.cam.shake(0.3);
    G.pr[kc(e.p.key)] = 0;
    save();
  }
}

// a switch you hit
function simSwitchEnt(SIM, dt, e) {
  const { st } = SIM;

  e.inv = 0.5;
  snd('switch');
  e.togN = (e.togN || 0) + 1;
  const f = e.p.flag;
  if (st.flags[f]) delete st.flags[f];
  else st.flags[f] = 1;
  msg('Switch ' + (st.flags[f] ? 'on' : 'off'));
  save();
}

// a wall that breaks when hit
function simBreakable(SIM, dt, e) {
  const { st, hitD } = SIM;

  // only a hitbox with damage hurts a wall: a move with no attack box or 0 damage does nothing
  if (e.p.needs && !MV.Progress.has(st, e.p.needs)) {
    e.inv = 1;
    msg('Needs ' + e.p.needs);
  } else {
    onHit();
    e.hp -= hitD(e);
    e.inv = 0.3;
    e.hitN = (e.hitN || 0) + 1;
    e.hurt = 0.35;
    G.cam.shake(0.2);
    if (e.hp <= 0) {
      e.dead = true;
      st.opened[e.uid] = 1;
      fxClip(e, 'broken');
      debris(e);
      save();
    }
  }
}
