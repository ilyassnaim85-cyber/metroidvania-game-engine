// Runtime: room loading, player controller, collision (solids, slopes, one-way, moving platforms, hazards),
// entities, transitions, checkpoints/respawn, rendering and collision debug overlay.
(function () {
