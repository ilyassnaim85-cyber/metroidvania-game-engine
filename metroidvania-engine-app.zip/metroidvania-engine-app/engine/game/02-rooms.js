const PR = MV.Light.PROFILES,
  BLOCKISH = 'gim><uxysw',
  sloped = c => !!PR[c] && PR[c][0] !== PR[c][1];
const surf = (c, tx, ty, x) =>
  c === '#' || c === '=' ? ty : PR[c] ? ty + PR[c][0] + (PR[c][1] - PR[c][0]) * (x - tx) : null;
function mk(s, uid) {
  const d = D().entities[s.type];
  if (!d) return null;
  const p = {};
  for (const k in d.props) {
    const v = s.props && s.props[k];
    p[k] = v === undefined ? d.props[k].d : v;
  }
  if (s.type === 'lightzone' && s.props && s.props.pts) p.pts = s.props.pts; // the corners of a polygon zone
  const e = {
    type: s.type,
    uid,
    p,
    w: d.w,
    h: d.h,
    cx: s.x + 0.5,
    by: s.y + 1,
    ox: s.x + 0.5,
    oy: s.y + 1,
    hp: +p.hp || 1,
    hp0: +p.hp || 1,
    sk: s.type,
    dir: 1,
    dead: false,
    pdx: 0,
    pdy: 0,
    inv: 0
  };
  if (s.type === 'enemy' && p.kind) {
    const kd = MV.Enemies.find(G.ed, p.kind);
    if (kd) {
      e.kd = kd.id;
      e.w = kd.w;
      e.h = kd.h;
      e.hp = e.hp0 = kd.hp;
      e.vx = e.vy = 0;
      e.as = null;
      e.cool = 1;
    }
  } // an enemy of a type made in the Enemies tab
  if (s.type === 'boss') {
    const bd = MV.Boss.find(G.bosses, p.boss);
    if (!bd) return null;
    e.w = bd.w;
    e.h = bd.h;
    e.hp = bd.hp;
    e.b = MV.Boss.init(bd);
    e.arena = MV.Boss.arenaOf(p.arena, s.x, s.y, bd, G.room);
  }
  if (
    s.type === 'breakable' ||
    s.type === 'collapse' ||
    s.type === 'blink' ||
    s.type === 'current' ||
    s.type === 'lowgrav' ||
    s.type === 'msgzone' ||
    s.type === 'icezone' ||
    s.type === 'mudzone' ||
    s.type === 'conveyor' ||
    s.type === 'secret' ||
    s.type === 'stickwall' ||
    s.type === 'sticky'
  ) {
    e.w = Math.max(1, Math.round(+p.width || 1));
    e.h = Math.max(1, Math.round(+p.height || 1));
    e.cx = e.ox = s.x + e.w / 2;
    e.st = 'idle';
    e.t = 0;
    e.fy = 0;
    e.fv = 0;
  } // placed at its bottom-left tile; width and height count tiles
  if (s.type === 'checkpointkey' || s.type === 'signkey') {
    e.type = s.type === 'signkey' ? 'sign' : 'checkpoint';
    e.keyed = true;
  } // the press-a-key versions behave like the touch ones but wait for the key
  if (s.type === 'chest' && G.st.flags['chest:' + uid]) e.open = true;
  if (s.type === 'lightzone' && G.st.flags['lz:' + uid] && p.stay === 'yes') {
    e.seen = true;
    e.lv = 1;
  }
  if (s.type === 'animsprite') e.t0 = G.time || 0;
  if (s.type === 'ladder') {
    e.w = 1;
    e.h = Math.max(1, Math.round(+p.height || 3));
  }
  if (s.type === 'spring' || s.type === 'dashpad') {
    e.w = Math.max(0.5, +p.width || 1);
    e.cx = e.ox = s.x + e.w / 2;
    e.sq = 0;
  }
  if (s.type === 'secret' && G.st.opened[uid]) e.rev = true;
  if (s.type === 'hazard') {
    e.w = Math.max(0.1, +p.width || 1);
    e.h = Math.max(0.1, +p.height || 0.5);
  }
  if (s.type === 'evzone') {
    e.w = Math.max(1, Math.round(+p.width || 3));
    e.h = Math.max(1, Math.round(+p.height || 3));
    e.cx = e.ox = s.x + e.w / 2;
  }
  if (s.type === 'camzone') {
    e.w = Math.max(1, Math.round(+p.width || 4));
    e.h = Math.max(1, Math.round(+p.height || 3));
    e.cx = e.ox = s.x + e.w / 2;
  }
  if (s.type === 'airpocket') {
    e.w = Math.max(1, Math.round(+p.width || 3));
    e.h = Math.max(1, Math.round(+p.height || 2));
    e.cx = e.ox = s.x + e.w / 2;
  }
  if (s.type === 'mount') {
    e.w = Math.max(0.5, +p.width || 1.6);
    e.h = Math.max(0.5, +p.height || 1.2);
  }
  if (s.type === 'cannon') e.ang = +p.angle || 0;
  return e;
}
function floorAt(c) {
  const r = G.room;
  for (let y = r.gh - 1; y >= 0; y--) if (tl(c, y) !== '#' && tl(c, y + 1) === '#') return y + 1;
  return r.gh - 1;
}
// The tiles of a doorway that belong together (touching tiles with the same target), starting from tile t.
function doorGroup(list, t) {
  const key = q => q.x + ',' + q.y,
    has = new Map(list.map(q => [key(q), q])),
    seen = new Set([key(t)]),
    tiles = [t];
  for (let i = 0; i < tiles.length && tiles.length < 900; i++) {
    const q = tiles[i];
    [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1]
    ].forEach(d => {
      const k = q.x + d[0] + ',' + (q.y + d[1]);
      if (!seen.has(k) && has.has(k)) {
        seen.add(k);
        tiles.push(has.get(k));
      }
    });
  }
  return {
    tiles,
    x0: Math.min(...tiles.map(q => q.x)),
    x1: Math.max(...tiles.map(q => q.x)),
    y0: Math.min(...tiles.map(q => q.y)),
    y1: Math.max(...tiles.map(q => q.y))
  };
}
// Arriving through a hole in the floor: hop up onto the nearest ledge beside or above it (the control is yours again once you are above it).
function arriveJump(sp) {
  const p = G.p,
    g = G.tune.gravity || 40,
    run = G.tune.run || 8,
    sx = sp.x,
    sy = sp.y;
  let best = null;
  for (let dx = -8; dx <= 8; dx++) {
    const cx = Math.floor(sx) + dx;
    for (let y = Math.floor(sy) - 1; y >= Math.max(0, Math.floor(sy) - 9); y--) {
      const c = tl(cx, y);
      if ((c === '#' || c === '=') && tl(cx, y - 1) !== '#' && tl(cx, y - 2) !== '#') {
        const dy = sy - y;
        if (dy < 0.5) continue;
        const sc = dy + 0.8 * Math.abs(dx) + (dx === 0 ? 4 : 0);
        if (!best || sc < best.sc) best = { sc, cx, y, dy };
        break;
      }
    }
  }
  const dy = best ? best.dy : 3,
    vy0 = Math.sqrt(2 * g * (dy + 1)),
    T = vy0 / g + Math.sqrt(2 / g),
    dxT = best ? best.cx + 0.5 - sx : 0;
  p.vy = -vy0;
  p.on = false;
  p.arr = { y: best ? best.y : sy - 3, vx: Math.abs(dxT) < 0.6 ? 0 : Math.max(-run, Math.min(run, dxT / T)), t: 0 };
  if (p.arr.vx) p.face = p.arr.vx < 0 ? -1 : 1;
}
function load(room, from, cp) {
  const prevFace = G && G.p ? G.p.face : 1;
  if (G.ev && G.room && G.room !== room) G.ev.leaveRoom(G.room.id);
  const st = G.st;
  (st.seen = st.seen || {})[room.id] = 1;
  G.room = room;
  G.area = MV.Progress.areaOf(G.world, room);
  G.en = [];
  G.fx = [];
  G.es = [];
  G.time = 0;
  G.shots = [];
  G.own = [];
  G.thr = null;
  if (!room.grid) {
    room.grid = [];
    for (let y = 0; y < room.gh; y++) room.grid.push((y >= room.gh - 2 ? '#' : '.').repeat(room.gw));
  }
  G.cov = new Set();
  (room.art || []).forEach(a => {
    for (let yy = a.y; yy < a.y + a.h; yy++) for (let xx = a.x; xx < a.x + a.w; xx++) G.cov.add(yy * room.gw + xx);
  }); // tiles under a sprite are not drawn (collision stays)
  let fd = null;
  room.grid.forEach((row, y) => {
    if (row.indexOf('D') < 0 && row.indexOf('e') < 0 && row.indexOf('B') < 0 && row.indexOf('*') < 0) return;
    for (let x = 0; x < room.gw; x++) {
      const c = row[x],
        uid = room.id + ':' + x + ',' + y;
      let e = null;
      if (c === 'D' && !fd) fd = { x, y };
      // legacy tiles still work: e/B enemies, * coin pickup
      if (c === 'e') e = mk({ type: 'enemy', x, y }, uid);
      else if (c === 'B') e = mk({ type: 'enemy', x, y, props: { hp: 8, speed: 0 } }, uid);
      else if (c === '*') e = mk({ type: 'pickup', x, y, props: { kind: 'item', give: 'coin' } }, uid);
      if (e && !st.collected[uid]) G.en.push(e);
    }
  });
  (room.ent || []).forEach(s => {
    const uid = room.id + ':' + s.id,
      e = mk(s, uid);
    if (e && !st.opened[uid] && !st.collected[uid]) G.en.push(e);
  });
  let sp = null;
  if (cp && cp.r === room.id) sp = { x: cp.x, y: cp.y };
  let arr = null; // how you arrive through a doorway in the ceiling (you fall out of it) or in the floor (you hop up onto the nearest ledge), like Hollow Knight
  if (from) {
    const mt = (room.tr || []).filter(
      t => t.a === from.a && t.r === from.r && room.grid[t.y] && room.grid[t.y][t.x] === 'D'
    );
    let t = mt[0] || fd;
    if (t && mt.length > 1) {
      const g = doorGroup(mt, t),
        wide = g.x1 - g.x0 >= g.y1 - g.y0,
        fr = from.fr === undefined ? 0.5 : from.fr,
        c = wide ? g.x0 + Math.round(fr * (g.x1 - g.x0)) : g.y0 + Math.round(fr * (g.y1 - g.y0));
      t = g.tiles.filter(q => (wide ? q.x === c : q.y === c)).sort((a, b) => b.y - a.y)[0] || t;
    }
    if (t) {
      sp = { x: t.x + 0.5, y: t.y + 1 };
      const g = mt.length > 1 ? doorGroup(mt, t) : { x0: t.x, x1: t.x, y0: t.y, y1: t.y };
      if (g.x0 >= 1 && g.x1 <= room.gw - 2 && g.x1 - g.x0 >= g.y1 - g.y0)
        arr = g.y0 <= 1 ? 'fall' : g.y1 >= room.gh - 2 ? 'jump' : null;
    }
  }
  if (!sp) {
    const sn = (room.ent || []).find(s => s.type === 'spawn');
    if (sn) sp = { x: sn.x + 0.5, y: sn.y + 1 };
  }
  if (!sp) sp = { x: 2.5, y: floorAt(2) };
  G.hz = null;
  G.p = {
    x: sp.x,
    y: sp.y,
    vx: 0,
    vy: 0,
    on: false,
    cy: 0,
    face: 1,
    muse: {},
    mcd: {},
    acds: {},
    inv: 0,
    mv: null,
    anim: { s: 'idle', t: 0 },
    water: false,
    swimming: false,
    bumpX: 0,
    bumpY: 0,
    atk: 0,
    acd: 0,
    wall: 0,
    kt: 0,
    kx: 0,
    inD: !!from,
    plat: null,
    sp
  };
  if (arr && !cp) {
    G.p.inD = true;
    if (arr === 'fall') G.p.vy = 1.5;
    else arriveJump(sp);
  } else if (from && !cp) {
    const gx = Math.floor(sp.x);
    G.p.force = { dir: gx < 3 ? 1 : gx > room.gw - 4 ? -1 : prevFace || 1, x0: sp.x, t: 0 };
  }
  if (MV.Audio) {
    MV.Audio.music(room.music || '');
    if (from) snd('door');
  }
  G.camSet = null;
  G.camZone = null;
  G.trn = false;
  G.go = null;
  G.cam.sceneChange();
  if (G.script) G.script.sceneChange();
  if (G.ev) G.ev.enterRoom(room.id, !!cp && !from);
  G.cam.update(0, sp.x, sp.y - G.tune.h / 2, VW, VH, room.gw, room.gh, camCfg(sp), true, null, G.tune);
}
const okWhere = (m, p) =>
  m.where === 'any' ||
  (m.where === 'ground' && (p.on || p.cy > 0)) ||
  (m.where === 'air' && !p.on) ||
  (m.where === 'water' && p.water);
