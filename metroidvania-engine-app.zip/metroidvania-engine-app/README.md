# Metroidvania Engine (desktop app)

1. Install Node.js (nodejs.org), then open a terminal in this folder.
2. `npm install`
3. `npm start` runs the app.
4. `npm run dist` builds an installer into the `dist` folder
   (a Windows .exe if you run it on Windows, a .dmg if you run it on a Mac).

Your map saves automatically inside the app. File > Export / Import (Ctrl+S / Ctrl+O)
saves and loads the map as a .json file.

Sprites: in Aseprite use File > Export Sprite Sheet, save as PNG, then import it in a room.
Transitions: pick the Transition tool, choose where it leads, click the room. Click Play this room to test.

See DOCS.md for the engine layout, data files and workflows.

On first launch you get a start screen to create a project or open an existing one. See DOCS.md.

Animation clips and the animation API: see ANIMATION.md and examples/animation-demo.html.

Zoom and pan, and room lighting: see DOCS.md.

## 2.9.1 (cleanup)
- Deleting a sprite sheet now also removes it from room backgrounds (it used to leave them pointing at it), the player sprite, move animations, boss animations and hitbox looks.
- Deleting an area or room removes transitions that led to it. Deleting a boss removes its placements in rooms.
- A paused playtest no longer swallows Space and the arrow keys in other tabs.
- Removed unused code. Checked in a real browser: project create/open/reload, painting, lighting, zoom, sprite import and delete, undo/redo, all tabs, boss placing and deleting, and a playtest.

## 2.10.0
- New **Lamp** item: drag it into a room, choose a circle or a polygon with 3 to 16 sides, drag its corners into any shape, set the radius and light level, and pick its colour with the colour picker or R, G, B boxes.

## 2.11.0
- Better light: walls now cast shadows, the fade is smooth, shadow edges are soft, coloured lamps glow, polygon lamps keep their shape, and lamps can flicker.

## 2.11.1
- A sprite placed on wall tiles now replaces how those tiles look: its transparent parts show the background, not the grey wall. Collision is unchanged (turn on Show collision shapes to see it).

## 2.12.0
- Player settings > Camera: follow delay, dead zones, separate horizontal and vertical smoothing, look ahead, look down when falling and a vertical offset. A room's Smoothing can now be left empty to use them.

## 2.12.1
- Lamp light level now sets how bright the lamp's area is: level 0 darkens the place, 1 lights it up. The old Light item and the player's light only ever add light.

## 2.12.2
- Lamps stay inside their area: new **Edge softness** setting (0 sharp edge at the radius or polygon, 1 fades from the middle). The default keeps the effect solid inside and gone at the outline.

## 2.12.3
- Darkness looks like shade, not a black patch: it now multiplies the scene (shapes stay visible), full darkness is a deep blue-grey, dark lamps default to a softer edge (0.5) and coloured glows are less blown out.

## 3.11.0 (Hitbox tab removed)
- The separate Hitbox tab in Player settings is gone. The hitbox is edited in the **Hitbox** section of each move and attack (Moves and abilities, Attacks). The normal hitbox (shape: rectangle, circle or polygon, and size) is still there: in that section, choose "The normal hitbox" in the **Editing** menu above the picture.

## 3.10.3 (gravity with a route)
- **Gravity x** now works on a move with a route: gravity pulls the player down on top of the route (the route's own up and down motion plus a falling speed that grows until you land). Direction, Angle, Speed and Acceleration are still replaced by the route.

## 3.10.2 (routes and Stop when blocked)
- Fixed: a move or attack with a drawn route (Path and speed) and **Stop when blocked** on ended at once on the ground, because the floor under the player counted as "blocked". Only a wall in the way or a ceiling above stops it now.
- A route needs two points to go anywhere. A route of one point is ignored, so the normal settings work.
- When a move or attack has a route, its Movement settings (Direction, Angle, Speed, Acceleration, Gravity) do nothing, because the route decides the movement. The move now says so, with buttons to delete or edit the route.

## 3.10.1 (test room fix)
- The movement test room had spikes only 1.5 tiles to the right of the start, so a roll or dash on the ground ran into them and the game put the player back at the start (it looked like the move did nothing on the ground; in the air you jumped over them). The ground right of the start is now clear for 10 tiles, and the spikes and breakable walls moved further along. When a hazard hurts and moves you back, the test room now says so.

## 3.10.0 (sprite tools)
- The Sprites section of the world editor now has tools like the Tiles section: **Place**, **Pencil**, **Line**, **Rectangle**, **Outline**, **Ellipse**, **Ellipse outline**, **Pick sprite** (or hold Alt), **Select** (drag to select, drag inside to move, Copy, Cut, Paste, Delete, Flip left-right and up-down, Ctrl+C / X / V) and **Erase sprite** (drag to erase).
- Options: **Fit to sprite size** (shapes space the sprites by their own size so big sprites sit side by side), **Replace** (a sprite placed on top of one that starts on the same tile replaces it) and **Mirror left-right**.

## 3.9.0 (moves and attacks rebuilt around the hitbox)
- Every move and every attack is now split into sections, so each screen is about one thing: **Move / Attack** (its settings), **Hitbox**, and in the Advanced view **Attack boxes**, **Path and speed**, **Shots and effects**, **Animation**. Basic shows the first two.
- The **Hitbox** section is the player hitbox editor, right inside the move or attack: scrub the time, drag the green box to move it, drag a white corner square to resize it. Every change is a keyframe and the box glides between keyframes. Add invincible periods as a from and to time (for example 0.05 to 0.16 s), by typing or dragging the orange bars.
- In the editor only the hitbox moves; the picture stays. In Test movement and the playtest the player picture matches the hitbox, so it moves and stretches with it.
- The old cluttered timeline picture was split: attack boxes, the player's own route and the speed curve each have their own section and no longer mix with the hitbox.

## 3.8.0 (hitbox you move on the screen)
- The Hitbox tab now shows the player and the green body hitbox on screen. Pick "Normal body" or a move or attack, scrub the time, then drag the box to move it and drag a white corner square to resize it. Every change makes a keyframe and the box glides between keyframes.
- Invincible periods are set as a from and to time (for example 0.05 to 0.16 s). Type the times or drag the orange bars on the time strip. Nothing can hurt the player in those moments.
- In the Hitbox tab only the hitbox moves and resizes. In Test movement and the playtest the player picture matches the hitbox: it moves and stretches with it.

## 3.7.0 (clearer Moves and Attacks)
- The intro and the "How do I build...?" guides now say plainly that the timeline, shots and effects are in the **Advanced** view.
- **Usable** (ground, air, water) is now in the Basic view of moves and attacks, so a double jump can be built without switching.
- New moves are called "Move 1", "Move 2"... (attacks "Attack 1"...), with the Name box selected so you can type a name at once. While a move still has its automatic name, changing its type renames it ("Push", "Multi-step move"...).
- **Ability picker:** "Unlocked by" and a pickup's (or chest's) "give" now choose from one shared list of ability ids, shown with what each unlocks and how many pickups give it ("no pickup gives it yet" warns of a mismatch). "New ability..." adds one.
- "Delete all moves" and "Delete all attacks" ask first and say how many will be removed.

## 3.6.0 (more kinds of moves, body hitbox over time)
- **Body hitbox over time.** In the timeline of a move or attack, the Body hitbox row now has size keyframes: move the slider, type a width, height and offset, click "Set size here", and the hitbox glides between keyframes (a crouch, a roll, a stretched dash). You can still switch it off for periods. Click the row and use Delete to remove a keyframe.
- **Multi-step moves** (new type): a leap, a hang and a slam are steps, each with its own speed, gravity, steering and an end condition (time, you land, hit a wall or ceiling, release the key).
- **Wall and ceiling moves** (new type "Wall or ceiling"): cling, climb or run up a wall, or cling to and move along a ceiling, while a key is held. Jump lets go with a wall kick; reaching the top of a wall hops you over.
- **Combos**: a move or attack can chain into another; press the next key near the end (or just after) and it starts even when it is on cooldown.
- **Charge and release**: hold the key to charge, release to fire; the damage and shot speed grow with the charge.
- **Shots**: things that fly out with their own attack box, speed, angle, gravity, life and damage.
- **Effects** on events (start, hit, land, hit a wall, end): bounce (a pogo), refill, slow time, teleport, push back, heal, end the move.
- The test room has spikes and patrolling enemies so you can try the hitbox, and "Show hitboxes" draws your body hitbox and attack boxes.

## 3.5.0 (Controls tab: keyboard and gamepad)
- New **Controls** tab in Player settings: up to 3 keyboard keys for Left, Right, Up, Down and Jump (click a key button, press the key; Backspace clears), and one gamepad button for Jump and Interact. Every move and attack also gets its key, its "also hold" key and a gamepad button in one table.
- **Gamepad**: the left stick and D-pad steer; buttons A to Right stick click (0 to 11) can be chosen with a dropdown or "Press a button". It works in Playtest and Test movement. Interact also advances dialogue.
- **Conflict warnings** when two actions share a key (with the same second key) or a gamepad button. Up and Jump may share W / Up arrow, and moves on the Jump key share it on purpose.
- **Reset to defaults** restores the default keys and gamepad buttons (the keys of your moves and attacks stay).

## 3.4.0 (hitbox and attack box, shapes, everything from scratch)
- **Body hitbox and attack box are separate.** The body hitbox (new **Hitbox** tab) is the part of the player that gets hurt; attack boxes are what the player hits with. In the timeline of every move and attack there is a **Body hitbox** row: switch it off for a period (drag the edges of the dark bar, or type the times) and nothing can hurt the player then (enemies, boss attacks, spikes), like the shade dash in Hollow Knight. The old "Cannot be hurt" setting became this.
- **Rectangle, circle and polygon** shapes for both the body hitbox and every attack box. Drag the white dots in the picture to move polygon corners (Shift+click removes one). Hits use the real shape, not its bounding box. "Collision shapes" in the test room draws them.
- **No ready-made moves or attacks.** The preset lists are gone and a new project starts with no moves and no attacks: you build every one yourself. The types are now Timed move, Instant push, While held and Swimming (a dash, a roll, a leap, a slide are all timed moves); any timed move can have a low body ("Body height while it plays"). Each tab has a short "How do I build...?" guide. Projects that already have roll, grapple or path moves keep working.
- Boss damage, knockback, stun and hazard damage are no longer in the Player tab; they will live in the Bosses and Enemies tabs. The player keeps Health and Invisibility time. Until then they keep their old default values.

## 3.3.0 (moves and abilities, test room, clips, basic view)
- The Movement tab is now **Moves and abilities**. **Core movement** (run speed, acceleration, jump height, gravity) is the first item in the move list, next to dash, roll, grapple and the rest, with a jump-arc picture.
- **Test movement** (button at the top of the Player tab) opens a small test room with flat ground, platforms, gaps, a tunnel, wall-jump walls, breakables and grapple points. It uses the normal game physics and every change you make applies at once. Falling in a gap puts you back at the start.
- Every player state (idle, run, hurt, pickup, checkpoint...) can use an **Animation Studio clip**. Existing sprite sheet animations keep working.
- **Basic / Advanced view** for moves and attacks: Basic shows only the few settings that matter; Advanced adds the timeline and all fields. Every preset has a one-line explanation.

## 3.2.1 (new layout for Movement and Attacks)
- Player settings now has the tabs Settings, **Movement**, **Attacks** and Sprite and animations. In Movement and in Attacks the list of moves (or attacks) is on the left; at the top right is the hitbox preview with its timeline; the settings are in a panel below it. The preset buttons are under the list.

## 3.2.0 (moves and attacks made on a timeline: roll, grapple, dash slash)
- **Player movement track.** Moves and attacks now have a "Player movement" row in the hitbox timeline. Select it, then drag the player in the preview to where it should be at the current time; each drag adds a point and the player glides between points. Hitboxes follow the player along the route, and the speed curve changes how fast the route plays. This is how you make a **dash slash** (new presets: Dash slash, Rising slash), a backflip, a leap and so on. With no points, the old speed settings are used.
- **New move types** (Player settings > Moves): **Roll** (a dash along the ground with a lower body that fits under low gaps and stays low until there is room to stand), **Grapple** (a hook that flies out in a direction, sticks to a wall or to a new **Grapple point** entity and pulls you there; Jump lets go; the hook hurts what it hits), and **Path** (the player just follows its Player movement track). Presets: Roll, Grapple, Backflip.
- **Layout:** in Moves and Attacks the hitbox timeline now comes first and the movement settings are below it. Each move type shows only the settings that apply to it.
- New settings: "Cannot be hurt while it plays" (a dodge) for moves and attacks, "Keep speed after" and "Stop when blocked" for attacks, "Body height while rolling", hook reach, hook speed, pull speed and what the hook sticks to for grapples.

## 3.1.0 (player: attacks, behaviour animations, damage)
- **Attacks tab** (Player settings > Attacks): each attack is a timeline like a boss pattern. Hitboxes move by keyframes (scrub the time, drag the box, each drag is a keyframe), each has a "hurts from / until" window, a **speed curve** changes how fast the player moves during the attack, and each attack can have its own animation. Presets: Slash, Upward slash, Down strike, Lunge, Spin. Set the key, an optional second key, where it can be used (any, ground, air), damage, cooldown, forward push, hold-still and gravity. Up to 12 attacks. Dashes and impulses in the Moves tab can carry hitboxes and a speed curve too.
- **Behaviour animations** (Sprite and animations): land, hurt, die, pick up, interactive checkpoint, chest, interactive sign and talk, besides run, jump, fall, dash, wall, attack and swim. The one-shot ones play once when it happens and can freeze the player while they play.
- **Damage** (Settings > Damage): invisibility time after a hit (the player blinks), knockback, stun, enemy damage and hazard damage. A hazard puts you back at the last checkpoint you touched in the room that is not interactive (or where you came in); the press-a-key checkpoints heal you and save the game.

## 3.0.0 (world editor finished; player tab updates start here)
No feature change: the World editor is done. From here on the Player settings tab gets the updates.

## 2.34.1 (light zone stops at walls)
The Light zone shade now behaves like a Darkness zone: walls stop it, with the same soft shade at the first wall and corners. When you enter, the shade fades to light; with invert the outside shade fades in, also stopped by walls.

## 2.34.0 (light zone: any shape, invert)
- **Light zone can be any shape**, like a lamp: choose Circle or Polygon, set the size and number of sides, then select the zone (click its row, or click it with the Entity tool) and drag its corner handles on the room. Place it from Entities > Light zone; it starts as a 4 x 3 rectangle.
- It is a dark area from outside (like a secret room) and lights up while the player is inside its shape. Settings: **darkness from outside** (0 to 1), **fade time**, **stay lit once entered** (saved with the game) and colour.
- **New setting: Darken the outside while you are inside (invert).** With it on, the zone is dark and the rest of the room is lit while you are outside it; when you walk in, it flips: the zone is lit and everything outside it goes dark (like a spotlight cave).
- Fixed: polygon corners are now kept when the game loads a zone.

## 2.32.0 (animation for every entity, any key, message zone stop)
- **Every entity can wear an animation** except Light, Lamp, Darkness and the plain (touch) Checkpoint. Pick a clip from your Animations tab in each state's slot in the entity's properties: for example Door (idle, open), Switch (off, on), Breakable wall (idle, hit, broken), Collapsing ground (idle, shake, fall), Chest (closed, open), Bounce pad (idle, bounce), Character (idle, talk), Pickup (idle, collected), Teleporter (idle, used), Orb (idle, used), Secret wall (idle, revealed), Dash pad (idle, fire), Sticky wall (idle, climb), Blinking platform (on, off), Checkpoint (press key) (idle, active), and the idle clip for belts, platforms, currents, low gravity, ice, mud and message zones. Wide and tall things (walls, zones, belts, ladders) repeat the picture once per tile. The room editor shows the resting clip.
- **Sign, Sign (press key) and Ladder take one still sprite**, not an animation: pick a sprite from the sprites placed in the room (Sprites tab). The ladder repeats it up its height.
- **Message zone: "stop" option.** Set stop to yes and the player is held still for "hold" seconds when entering the zone while the message shows. If you are still holding a direction, you carry on as soon as the hold ends.
- **Any key for interactive entities.** Checkpoint (press key), Sign (press key), Chest and Character have a key button: click it, then press any key (letters, digits, Space, arrows, F-keys...). Escape cancels. Older projects that saved a letter keep working.

## 2.31.1 (projects open again)
- **Fixed: opening a project showed "its saved data is damaged".** A helper used when loading rooms was out of reach, so every project that had a room failed to load. Your projects were never damaged: saving was fine and the data in them is untouched. They open normally in this version, with the same tiles, entities, pins and templates.
- If a project ever cannot be read again, the message now says what went wrong instead of always saying "damaged".

## 2.31.0 (room layers)
- **Layers button in the room editor** (next to Map, above the room). Three layers, each can be hidden or locked:
  - **Tiles**: terrain, slopes, water, belts and the other tiles.
  - **Scenery**: sprites placed on the room, and the background.
  - **Gameplay objects**: entities, bosses, lamps and transition tiles.
- Hidden layers disappear from the editor only; the game is not changed. A hidden layer is also protected: you cannot paint into it.
- A locked layer cannot be painted, erased, filled, pasted, moved or deleted (including Clear room and the room flips). A short message tells you which layer is in the way. The entity and transition lists grey out while Gameplay objects is locked.
- Handy buttons in the popover: Show all, Unlock all, and Only tiles (hides scenery and objects). The button shows an amber dot while anything is hidden or locked. Your layer choices are remembered.
- World editor checked against the ten-point list: zoom, fit and reset view; select, move, resize (handles), rename, delete; duplicate and copy/paste of rooms, areas and room contents; snap, grid, align and distribute; connecting rooms with doors, missing-destination markers and connection lists; search and filters; the World check panel (broken transitions, unreachable rooms, no entrance, likely softlocks); templates; notes and markers. Only the layers were missing.

## 2.30.5 (invisible transitions)
- **Transition tiles are invisible in the game.** The orange outline is gone from playtest; in the editor you still see them so you can place and edit them.
- **Two forced steps after a transition.** When you arrive through a transition you automatically walk about two tiles out of the doorway (away from the nearest room edge, otherwise the way you were facing), so you do not stand in the doorway or walk straight back into it. Your own input resumes after that. Respawning at a checkpoint does not do this.

## 2.30.4 (animation size fix)
- Entity animations no longer spill outside their tiles. The sprite now fits inside the entity's footprint instead of being scaled up to cover it. Breakable walls and collapsing ground draw the animation once per tile, so a 3x2 wall shows six tiles of it. Door, switch, chest and bounce pad draw one sprite that fits their size, bottom centre. Same in the room editor.

## 2.30.3 (animated entities, better belts)
- **Entities can play your animations.** Locked door (idle, open), Switch (off, on), Breakable wall (idle, hit, broken), Collapsing ground (idle, shake, fall), Chest (closed, open) and Bounce pad (idle, bounce) each got animation slots in their properties. Pick a clip from the Animations tab for any slot; leave a slot empty to use the idle clip or the built-in look. The clip is scaled to cover the entity's size, and the room editor shows the resting clip right on the room.
- Hit, bounce and fall clips play once when it happens, open and on clips hold their last frame, and a chest you already opened or a switch that is already on shows its end state when you come back.
- A broken wall plays its Broken clip where it stood. If it has none, it bursts into rubble.
- Without any clip, Breakable wall and Collapsing ground now look like stone bricks: breakable walls crack more with each hit, flash and shake when struck, and collapsing ground shakes and crumbles.
- Conveyor belt tiles were redrawn: moving tread plates at the real belt speed, rounded end rollers and joined runs.

## 2.30.2 (map button)
- The room minimap no longer sits over the room. It is closed by default; press **Map** in the bar above the room to open it (it hangs under the button). Click or drag it to jump. It closes by itself when you click the room, so it never gets in the way of building, or press Esc or the button again.

## 2.30.1 (steering big rooms)
- **Moving around large rooms (like 1000x1000) is now controllable.** The scrollbar of a huge room jumps dozens of tiles per pixel, so it was hard to steer. New in the room editor:
  - **Minimap** (open it with the Map button above the room): the whole room with a box for what you see and dots for entities. Click or drag it to jump anywhere.
  - **Arrow keys pan** at a steady speed (about 14 tiles per second, hold Shift for 4x).
  - **Tile readout** next to the zoom buttons shows the tile under the mouse and its name.
  - **Go to**: type a tile like 500, 320 and press Enter to centre the view on it.
- Wheel still zooms, Shift + wheel scrolls sideways, Space + drag or middle-drag pans.
- Removed the Ladder, Breakable block and Crumble block tiles added in 2.30.0 (they duplicated entities). Ice, Mud, Belt and Bounce tiles stay.

## 2.30.0 (more tiles and tile tools)
- **New tiles:** **Glass** (solid, see-through, light passes) and **Back wall** (scenery only, nothing collides). Ladders, breakable walls and crumbling ground stay entities (Entities tab).
- **Ramp tool:** drag from one end of a slope to the other. It picks the right pieces for you (steep 45 degree slopes, or gentle two-tile slopes when the drag is shallow), going up either way, and with **Fill under ramps** on it fills the empty tiles below with walls. Mirror drawing works with it.
- **Frame room:** draws the chosen tile (wall if none) around the edge of the room.
- Found and kept: a tile system added to the files earlier today (half block, invisible wall, gentle slopes, ice, mud, belts, bounce, brush size, mirror drawing, selection tools). Checked it works with slopes, lighting and saving.

## 2.29.2 (slopes)
- **Slopes no longer feel like stairs.** Walking up a slope used to snap you up at every tile edge (the block under the next slope tile, or the flat edge behind you, lifted or held your feet). The slope under the middle of the player now sets the height, so the climb is smooth: the biggest height change in one frame is just your walking speed.
- **Walking down a slope keeps you on it.** Before, you left the ground and fell off each tile in steps (22 airborne frames over a 6-tile slope, now 0). Walking off a flat ledge still makes you fall, and jumping from a slope works.
- **Light and darkness follow the slope.** A slope tile used to count as a full block for light, so lamps lit stair-shaped blocks and bright squares sat inside the solid part. Light rays now stop at the diagonal, and a darkness zone shades only the open triangle above the slope and bleeds into the solid half. This applies in the editor preview and in playtest.
- Tall walls and 1-tile ledges still block you; ledges up to 0.6 tile are still stepped onto.

## 2.29.1 (audit and fixes)
- Full check of every file: syntax, undefined names, duplicate or missing element ids, save/load round trips (including packed 10000-tile rooms), undo/redo, all 34 entity types, every tab, and playtest of all 13 template areas, a streamed 10000x10000 room, a boss fight and old-format projects. No corrupted files were found.
- **Fixed:** File > New project and File > Close project in the desktop menu did nothing (the editor functions they call were missing). New project now returns to the start screen with the name box selected; Close project returns to the start screen.
- Docs: added the newer entities (low gravity, message zone, teleporter, ice, mud, chest, orb, character, animated sprite) to DOCS.md.

## 2.29.0
- **Slopes no longer stop you.** Walking up a slope into the side of a block (a ramp that leads onto a platform, a staircase of slopes and blocks) used to freeze the player half a tile too low. You are now lifted onto ledges up to 0.6 of a tile high when you are on the ground and there is room above. Tall walls still block you.
- **Animated sprites can wait for an event.** Entities > Animated sprite > **when**: always, room start, player touches, player stands in it, breakable wall hit, breakable wall broken, collapsing ground shakes, switch toggled, chest opened, flag set. Wall, ground, switch and chest events listen to the nearest one of that kind in the room within **near** tiles (put the sprite next to it). **flag** names the flag for "flag set". One-shot events play the clip once; "player stands in it" and "collapsing ground shakes" play while it lasts. **idle** (hidden or first frame) is what shows before it plays and **finish** (hide or hold last frame) is what is left after a one-shot. Things that already happened (a wall broken, a chest opened) show their end state when you come back to the room.

## 2.28.0
- **Ice and Mud now work whether you place them on the floor tile or the tile above it** (they act while you stand on top of them or are inside them). Ice is much more slippery by default (Slip 0.02; smaller = more slippery), so you slide and are slow to start and stop. Mud slows your top speed (Slow 0.45).
- **Chest:** the message now says what you got. Set Reward to **key** (or flag), put the key's id in **give** (a Locked door that requires `flag:thatid` opens with it) and a readable **name**, and you see "You obtained <name>". **message** replaces the text completely.
- **Character (talk)** is now a real conversation. Fields: **name** (shown on top of the talk box), **dialogue** (one line per turn; a line that starts with `>` is your character talking, shown with your character's name on top), **after** (what it says on later talks; empty = the same), **passing** (small speech bubbles when you walk past; one is said each time, they take turns) and **range** (how close you have to be for the passing talk). Press the key (E, F or Q) near it to talk; Space, Enter, E, F or Q advance; the first press finishes the typing, the next goes to the next line. The world pauses while you talk.
- **Player settings > Dialogue box:** your character's name, a **Box sprite** (choose any image, or import one; its border is kept and the middle stretches, set the border size and scale), text and name colours, with a live preview.

## 2.27.0
- **Animated sprites:** Entities > **Animated sprite** places one of your clips from the Animations tab in the room. Pick the clip, how many tiles wide it is, flip, and whether it draws behind or in front of the player. It animates in the editor and in Play. It sits on the tile you click (bottom centre of the clip's pivot).
- **Background layers can be placed freely:** Fit > **Free (drag and resize)**. Click **Move and resize on the room**, then drag the image to move it or drag a yellow corner to resize it (keeps its shape; hold Shift for free stretch). X, Y, Width and Height (in tiles) can also be typed. A free layer starts with Scroll 1 so it stays exactly where you put it; lower values make it drift with the camera.

## 2.26.0
- **Enemy, Hazard and Boss are no longer in the Entities list** (an Enemies tab is planned). Maps that already contain them still load and play exactly as before.
- **New entities:** Water current (pushes you along, any direction), Low gravity zone, Message zone (shows text when you walk in, optionally once), Teleporter (two with the same channel are linked), Blinking platform (on and off seconds), Player start (where the room begins), Ice (slippery) and Mud (slow) zones, Chest (press its key: coins, a flag or an ability), Character (press its key to talk) and Refill orb (gives back dash and air moves, returns after a respawn time).
- Zones, blinking platforms and the new items flip correctly with Flip left-right / up-down.

## 2.25.0
- **Entities are no longer a dropdown list.** Every entity is a button in Entities (with its colour); click one, then click the room to place it.
- **Rooms can be up to 10000 x 10000 tiles**, so a whole game can be one room. The editor only draws what you can see (scroll or zoom as usual; the lowest zoom is 10%), painting, lines, rectangles, lamps and entities work anywhere in the room, and Play this room starts normally.
- Big rooms (over 1,000,000 tiles) are saved packed, so a blank 10000 x 10000 room is tiny in your project and in undo; smaller rooms are saved exactly as before. Import reads both.
- **Tile loading distance** (Level Settings > Room): only the tiles, enemies and other things within that many tiles of the player (above, below, behind and in front) are drawn and run; the rest wait until the player gets close. 0 loads the whole room. Rooms made bigger than 1,000,000 tiles start at 5.
- Rectangle/Outline and Fill refuse areas over 1.5 million tiles (use smaller pieces).

## 2.24.1
- The normal **Checkpoint** and **Sign** are back to how they were: a checkpoint saves when you touch it, and a sign shows its text when you walk up.
- Two new items sit next to them in Entities: **Checkpoint (press key)** and **Sign (press key)**. Stand near one and a small key box appears above it; press the key to save or to read. Their **Key** setting is E, F or Q (default E).

## 2.23.0
- **Front layer** (Level Settings > Background): a fourth image layer that is drawn **in front of the player** and everything in the room, for leaves, fog, foreground rocks or bars. It has its own image, fit and scroll speed (default 1.15, a little faster than the room for depth). The Far, Middle and Near layers keep their "In front of the player" option as before. Older maps get the new layer empty, so nothing changes until you give it an image.

## 2.22.0
- **Ladder** (Entities): **Height** in tiles and climbing **Speed**. Stand at it and press Up or Down to grab it, then Up and Down move you along it with no gravity. Left and Right step off, and Jump lets go with a jump.
- **Dash pad** (Entities): **Width**, **Direction** (right, left, up or down), **Speed** and **Duration**. Touch it and you are thrown along its direction like a dash.
- **Climb wall** (Entities, "Climb wall (up or down)"): a solid wall with **Width**, **Height**, **Direction** (up or down) and **Speed**. Stick to its side by holding toward it and it carries you up, or down. Place one of each to make a lift shaft.
- Flip left-right / up-down also mirrors dash pad and climb wall directions.

## 2.21.0
More level design features.
- **Drawing tools** (Tiles palette, row under the tiles): **Pencil**, **Line**, **Rectangle**, **Outline** and **Fill**. Pick a tile, pick a tool, then drag in the room (Fill: click an empty area to fill all connected matching tiles). Each action is one undo step.
- **Flip left-right / Flip up-down** (next to Clear room): mirrors the whole room: tiles, slopes, entities, transitions, lamp shapes, moving platforms and conveyors. Sprites move to the mirrored spot but are not flipped themselves.
- **Bounce pad** (Entities): **Width** and **Power** (how many tiles high it throws you).
- **Conveyor belt** (Entities): a solid belt of **Width** tiles that carries you along while you stand on it. **Speed** is tiles per second; a negative speed runs left.
- **Secret wall** (Entities): looks like a wall, **Width** and **Height** in tiles. Walk into it and it fades to show the passage, and stays open.
- **Sign** (Entities): shows its **Text** when you stand near it.

## 2.20.0
- **Collapsing ground** (Entities > Collapsing ground): a solid block that holds you up until you stand on it. It then shakes for the **Delay** (seconds), falls away and fades, and comes back after **Respawn** seconds (0 = never). It will not come back while you are standing where it would reappear. **Width** and **Height** set its size in tiles.
- **Breakable wall** (Entities > Breakable wall): **Width** and **Height** set how many tiles it covers (for example 2 wide, 3 tall). **Hits** is how many strikes break it, and **Needs** names an ability or flag required to break it. Once broken it stays broken.
- Both are placed by their bottom-left tile and drawn at their real size in the editor, with a tile grid so you can count.

## 2.19.0
- **Darkness reworked as one smooth shade.** The room's darkness is now a single soft field instead of separate pieces:
  - It fills the whole open area of its radius and stops at the first wall; it never goes behind it or into the room next door (Shade walls still let it through).
  - It melts into the **first wall only** (never the walls behind it). The edge is the room itself blurred, so every turn and corner is naturally round and oval, with a soft fade at the end and no straight strips or notches.
  - **Wall bleed** (0 to 1) is how far it melts into that wall: 0 = stops dead at the wall face, 1 = reaches the far side of the wall tile.
  - Very dark by default (amount 1, near-black); lamps and the player's light fade smoothly into it.
  - The edge at the radius stays a smooth fade, and Egg shape (off by default) still makes the area egg-shaped.

## 2.18.2
- **Oval shade in the wall**: along each wall face the shade now bulges into the first wall as a smooth oval, thickest in the middle and tapering toward both ends (including around corners), instead of a straight band with rounded corners. The outer edge has a small soft fade so it feels natural. It still never goes past the first wall tile.

## 2.18.1
- **Rounded wall rim**: the shade that goes into the first wall now has smooth, rounded turns and corners instead of straight strips with hard square corners. It is still only the first wall tile (Wall bleed: 0 none, 1 the whole tile).
- **Very dark by default**: new Darkness items are amount 1 in near-black, so you cannot see anything in the room outside lamps and the player's light, shaded walls included. Items still using the old default values (amount 0.8 or 0.85, or the old blue and grey colours) switch to this; values you chose yourself are kept.
- **Egg shape is off by default** (0). It is still available as a setting on circle Darkness items.

## 2.18.0
- **Egg-shaped darkness**: Darkness items (circle) now have an **Egg shape** setting (0 = round circle, 1 = very oval, default 0.25). The shade is wider than tall, narrower on top and fuller below, like an egg, which feels more natural than a perfect circle. Drag the radius handle as before; the radius is the base size.

## 2.17.1
- **Wall bleed only touches the first wall**: the shade goes into the first wall tile next to the room (0 = none, 1 = the whole tile) and never into the walls behind it, however thick the wall is.
- **Wall corners are shaded**: the wall tile at each corner of the room now takes shade, fading out from the corner like the wall edges, instead of staying lighter.

## 2.17.0
- **Atmospheric room lighting**: each room's darkness now has its own **Darkness colour** (Level Settings > Lighting), a dark blue-black by default, so a dim room still shows its platforms and walls. Room light level (ambient darkness), player light radius and level, and the colour are all separate settings.
- **Warm lamp**: a lamp's default colour is a soft warm white-orange, with a gentle glow that fades smoothly into the dark. Position, Radius, Level, Edge softness (falloff) and Colour are separate per-lamp settings.
- **Hazards stay visible in the dark**: new room setting **Keep hazards visible** (0 to 1, default 0.6) redraws spikes and Hazard entities faintly over the darkness in the game.

## 2.16.1
- **Darkness fills its whole circle**: the shade is now even across the whole radius (only the very rim fades), instead of strong in the middle and weak toward the edges. It still stops at the first wall.
- **Corner walls get shade too**: where two walls meet at an inside corner of the room, the notch between the wall strips is filled, so the corner is shaded like the rest of the wall edge (scaled by Wall bleed).

## 2.16.0
- **Wall bleed** (Darkness item, 0 to 1): how far the darkness soaks into a normal wall, fading out. 0 = fully blocked at the wall face, 1 = reaches the far side of the wall. It is measured against the wall's thickness, so 0.2 on a 5-tile wall is 1 tile. Default 0.2.

## 2.15.1
- **Grey darkness**: the default shade is now a dim grey (#2c2f36) at amount 0.85, so the room reads as dark rather than a black or navy background. Darkness items still using the old blue default switch to the grey; any colour you picked yourself is kept.
- **Light fades into the dark**: a Lamp's default Edge softness is now 0.9, so its light fades gradually from the middle into the shade instead of a bright disc with a thin edge. Lamps where you set the softness yourself are unchanged.

## 2.15.0
- **Loading screen** when the app starts: the engine logo in the middle, the name below it, and "ilyass naim" in the lower-left corner. It shows for about two seconds, then fades out.

## 2.14.0
- **Darkness is back to the soft look** (deep blue-grey, fades smoothly toward the edge and away with light), instead of a flat black room. It still stops at walls with no blur past them.
- **New tile: Shade wall** (Tiles palette, purple). It is a normal solid wall for the player and for light, but **darkness passes through it**. Use it as a window or gap where you want the dark to flow into the next room.

## 2.13.1
- **Pitch-black darkness**: new Darkness items default to amount 1 and black, so you see nothing in the room except what lamps light. The edge at the radius is a smooth fade (no tile blocks); only walls give a hard edge.
- **Darkness now stops at walls**: it fills the room it sits in with hard wall edges (no blur or spill past a wall) instead of a soft dark blob. The wall tiles stay unshaded. Lamps still cut light through it.

## 2.13.0
- Light and darkness are now separate items. **Lamp** only adds light (level 0 = off). New **Darkness** item shades a circle or polygon area, edited like a lamp; it is not blocked by walls unless you ask, and lamps inside it still shine. Lamps you had set to level 0 to make darkness are now just off: replace them with Darkness items.

## 2.13.1
- The version number now shows on the start screen, in the toolbar and in the window title, so you can tell which build is running.

## 3.12.0 (attack periods, more shapes, key combos)
- Attack boxes: set the time the box hurts ("Hurts from" / "until", for example 0.5 to 0.6). A time past the end makes the move or attack longer instead of being cut off. Circle and Polygon shapes now also show in Basic view.
- Invincible periods and hitbox keyframes also lengthen the move or attack when needed.
- Key combos: every move and attack has Key and Also hold, plus an "Add key" button for up to 5 more keys held together (for example X + Space + Down). The combo with the most keys wins.

## 3.13.0 (movement entities: grapple, bash, throw)
- New move types in Moves and abilities: Grapple hook (sticks to a wall or a Grapple point, pulls you), Bash (launch off a Bash orb, aiming with the direction keys while the world slows) and Throw an item, then teleport to it (press the key again).
- Entities to place in a room: Grapple point, Bash orb (comes back after its respawn time) and Sticky surface. The Movement test room has Grapple points and Bash orbs.
- Fixed: the thrown item could not be teleported to, and the grapple hook gave up after the move's short Duration.

## 3.14.0 (better multi-step, While held and Wall/ceiling moves)
- Multi-step: "Repeat all steps", per-step "Speeds up", "Goes" (the way you face, or the way you hold the arrow keys), a new end condition "you press jump", and a Duplicate step button.
- While held: "Time it works" (fills up when you land) and "Left/right speed while held". The unused Cooldown field is gone from it.
- Wall or ceiling: "Slide down speed" (slip down instead of hanging still), "Time it works" (stamina that fills up when you land) and "Jump-off push". Jumping off a wall no longer refills the stamina.

## 3.15.0 (charge time for While held, hitbox animation for Wall or ceiling)
- While held: "Charge time (s)": hold the key that long before it starts working; a bar fills above the player.
- Wall or ceiling: the Hitbox and Attack boxes sections now work here. While you cling, the body hitbox keyframes, invincible periods and attack boxes play (Duration is the length, "Repeat the hitbox animation" starts it again).

## 3.16.0 (Path and speed for Wall or ceiling)
- Wall or ceiling moves have a Path and speed section (Advanced view): a route you follow while clinging, drawn from where you grabbed the surface (forward is toward the wall, so use up and down), and a speed curve that changes how fast the route plays or how fast you climb or run. Duration is the length and "Repeat" makes it start again.

## 3.17.0 (weapons)
- Attacks have a "Weapon id" (for example sword). An attack with a weapon only works while you hold that weapon; attacks without one always work. Attacks of different weapons can share a key (no conflict warning).
- Get a weapon from a Pickup or a Chest of kind weapon (give = the weapon id). The newest weapon is in your hand; Tab switches weapons; the top bar of the game shows it. The Movement test room gives you every weapon.
- Attacks tab: the list shows each attack's weapon, a filter shows one weapon's attacks, and a note explains how to hand out weapons. The weapon you own and hold is saved with your progress.

## 3.18.0 (inventory)
- New Items tab in Player settings: define items (id, name, description, stack size, what using it does: nothing or heal N).
- Pickups and Chests of kind item give them (give = item id, amount = how many); a full stack leaves the pickup where it is.
- In the game press I to open the inventory: your weapons (Enter puts one in your hand) and your items (Enter uses one, for example a potion heals). The world pauses while it is open. Items are saved with your progress.
- An item id written in a move or attack's "Unlocked by" makes it need that item. The Movement test room gives you 3 of each item.

## 3.18.1 (throw item fixes)
- Fixed: "The item landed in a spot too tight to fit in". Teleporting now puts you at the nearest free spot around the item, so an item that landed against a wall puts you beside it.
- New "Item stays (s)" on Throw moves: the item fades away after that long (it blinks first) and the move then cools down. 0 = it stays until you teleport.

## 3.18.2 (stronger Bash)
- Bash now keeps flying after the launch: Keep speed is the share of the launch speed you keep, and you coast for a moment instead of stopping dead.
- A new move switched to the Bash type starts with stronger numbers (Speed 32, Duration 0.22, Keep speed 0.5). Keep speed is in the Basic view too. Existing Bash moves keep their numbers: raise Speed, Duration and Keep speed for a bigger launch.

## 3.18.3 (keys held, in the test room)
- With Show boxes or Debug on in the Movement test, the top right shows the keys the browser says you are holding ("Keys held: ArrowUp + ArrowLeft + ShiftLeft"). If a key combination never shows up there, the keyboard is not sending it (keyboard ghosting), not the game.

## 3.19.0 (no wall sticking by default)
- The built-in wall slide and wall kick belong to the ability "wallJump", and the playtest and the Movement test no longer switch it on for you. The player falls past walls like any other surface until you give wallJump with a Pickup, or tick Wall jump in the playtest abilities list. Wall or ceiling moves you build yourself are not affected.

## 3.20.0 (a better inventory: tabs, sprites, transparency, design)
- The Items tab is now an Inventory editor with four sections and a live preview: **Items** (each item can have a sprite picture and the tab it is shown in), **Tabs** (add up to 8 pages: each shows items, your weapons or your abilities, with its own name and picture), **Weapons and abilities** (a display name, description and picture for each) and **Design**.
- Design: open key, grid or list layout, columns, slot size, panel size, panel opacity (see-through to solid), how much the game behind is darkened, slot opacity, text size, corner roundness, border, six colours, and a panel picture (a sprite whose corners are kept as the frame).
- In the game: Q / E or Tab (Shift+Tab goes back) change tab, the arrows choose, Enter uses or equips, the open key or Esc closes. Left and Right also change tab in the list layout.

## 3.21.0 (every movement: hold moves, ledges, ropes, rails, cannons, mounts, air, ghost and burrow)
- **While held works on the ground too.** New "Works" setting on a While held move: in the air only, in the air and on the ground, or on the ground only. New settings: **Run speed while held** (a sprint is faster than your run, a crawl is slower), **Body width while held**, **Blocks jumping and attacks** (a morph ball), and **Plays animation** (crouch, sprint, morph, fly, burrow or phase clip from the Sprite tab). Nothing runs out unless you set "Time it works", so crouch, crawl, sprint and ball last as long as you hold the key. If there is no room to stand up when you let go you stay low until there is.
- **Fly, hover, levitate:** "Fly speed" on a While held move. Up and Down fly you at that speed, nothing pulls you down, and "Run speed while held" sets the sideways speed.
- **Passes through** on a While held move: ghost through every wall, floor and ceiling, or only through the new **Soft ground** tile (burrow). When you let go inside something solid you pop out at the nearest free spot.
- **New move type "Ledge grab and climb".** You catch the edge of a block as you fall beside it and hang (Grab reach). Up or Jump pulls you up over the edge (Climb time), Down lets go, Jump while holding away leaps off. Slide down speed, Time it works and Jump-off push are in the form.
- **Grapple can swing.** "Grapple works as" Pull or Swing: a rope that stays as long as it was when it caught, gravity swings you like a pendulum, Left and Right pump the swing, Up and Down shorten and lengthen the rope, and you keep your speed when you let go.
- **New entities:** **Zipline or rail** (a line from its spot to dx, dy tiles away; hang below or stand on top; ride to the end or steer with Left and Right; touch it or press a key; Jump hops off), **Cannon (barrel)** (touch it and you are loaded; fixed angle, swinging back and forth, or aimed with Left and Right; fires after a delay or on a key; power, flight time and reload), **Mount (creature or vehicle)** (press its key to ride and again to get off; walks, flies or swims; its speed, jump, gravity and body size replace yours) and **Air pocket**.
- **Air under water.** Player > Settings > Water: "Air under water" (seconds; 0 = unlimited), refill speed, and drowning damage and interval. A bar shows above the player while the air is going; Air pockets and the ability `waterBreath` stop it.
- **Portals** (the Teleporter entity) can fling you out of the other end: "launch" speed and "angle" (0 = right, 90 = up).
- The editor draws rails, cannons and mounts, and the move forms show the new settings.

## 3.22.0 (camera: direction bias, velocity look, bounds, ledge hint, room profiles)
- **Direction bias** (Player > Camera > Look ahead): the view leans toward where you are going. "Direction bias follows" in a profile picks the way you face, the way you move, or the keys you hold. "Direction bias delay" makes the camera wait before it swings to the other side (no jitter when you tap back and forth), "Look-ahead speed" is how fast it swings, and "Bias grows with speed" makes the lean smaller when you walk slowly.
- **Vertical velocity look:** "Look down when falling" and "Look up when rising" slide the view with your vertical speed, eased smoothly between "Speed where it starts" and "Speed for the full amount". "Vertical smoothing at top speed" makes the camera catch up faster while you fall fast.
- **Camera bounds:** a profile's "Room limits" is Stay inside the room, Allow some extra room (Extra room tiles), or No limit. A **Camera zone** entity can also limit the view to its own box, or **break room limits** while you are inside it (the limits glide, they do not jump).
- **Ledge hint:** stand at the edge of a drop at least "Ledge hint: smallest drop" tiles deep, wait "Ledge hint: wait" seconds, and the view slides down "Ledge hint: look down" tiles so the player sees they can fall. Looking up and down by holding Up or Down while standing still ("Look up and down") is there too.
- **Camera profiles:** Player > Camera > Camera profiles. Built in: Follow, Vertically centered, Vertically locked, Horizontally locked, Fully locked, No bounds. Make your own (tick only the settings it changes: sideways and up/down mode, locked position, bounds, bias, smoothing, dead zones...). A room picks one in World editor > Level Settings > Camera profile. A **Camera zone** swaps profile while you are inside it (the smallest zone wins), blending over its "blend" seconds. A script swaps it with `MV.Game.camera.set('locked', 0.6)` and goes back with `MV.Game.camera.reset()`; `MV.Game.camera.get()` and `.list()` read the current one.

## 3.23.0 (Phase 1: events, sound, background layers, checks, tests)
- **Events tab.** Build "when this happens, only if these are true, then do these steps" without code. Triggers: a room is entered or left, time spent in a room, an item or ability is gained, a flag is set or cleared (switch, chest, pickup), a boss is defeated, a conversation ends, the player walks into or out of an **Event zone** (a new entity you name), the player dies, a key is pressed, or another event calls it. Conditions: flags, items, abilities, weapons, room, coins, health, boss defeated, random chance. Steps: set, clear or toggle a flag; give or take items, abilities, weapons and coins; show a message or a conversation; wait; freeze or heal or hurt the player; move the player to a room; change or reset the camera profile; shake the screen; play a sound; change the music; run another event; turn an event on or off. Steps run in order, and Wait and conversations hold the list until they end. "Only once" is remembered in the save.
- Every event shows **Checks**: a room, item, boss, character, event, sound or camera profile that was deleted or renamed is flagged as an error, a flag nothing ever sets, an event nothing calls, an empty event and events that start themselves in a loop are warnings. The same problems are listed in the World editor's World check. In a playtest with "Show collision shapes" ticked, the last events that started (or were skipped, and why) are listed in the top right corner. The "key" trigger uses the click-then-press key picker.
- **Audio tab.** A sound library saved inside your project (import wav, ogg or mp3 up to 3 MB each, or "Make a sound" with the built-in sound maker: shape, pitch slide, length, fade, wobble), volumes for everything, music and sound effects, and a sound for each thing the player does by itself: jump, landing, footsteps, hurt, death, pickup, checkpoint, chest, water splash, conversation line, going through a transition, switch. Moves and attacks play sounds through an effect ("Do: Play a sound"), a room picks its music in Level Settings, and events have Play a sound and Change the music steps. Every sound that plays is written to a log, so you can check it without speakers.
- **Background layers** (World editor > room > Background): as many layers as you want (up to 256), each with its own picture, fit, camera scroll speed, opacity, **blur (0 to 40)** and **fog** (amount, colour, even or fading in from the top or bottom), in front of or behind the game, reordered, duplicated and hidden one by one.
- **Project file format and checker.** `FORMAT.md` documents everything the project file holds. `node tools/validate.js project.json` (or `npm run validate -- project.json`) checks a saved project without the editor: rooms and transitions, events, sounds, and the shape of every part. Exit code 1 on errors, `--json` for other tools.
- **Tests.** `npm test` runs 13 unit checks (no browser) and 44 playtest scenarios in a real browser (movement, ledges, ropes, rails, cannons, oxygen, burrow, mounts, camera, events, audio, the editor itself). For the browser tests run `npm i -D playwright` and `npx playwright install chromium` once.
- **The editor is no longer one huge file.** The script that was inside `index.html` is now `editor/app-01.js` to `app-04.js` (they run in order and share one scope, so nothing changed), next to `editor/events_ui.js` and `editor/audio_ui.js`. `index.html` is only the page.

## 3.24.0 (Phase 2: energy, upgrades, charms, death rules, templates)
- **Energy (mana, soul, focus).** Settings > Energy: maximum (0 = no bar), regrowth per second and the pause before it starts, and energy gained per hit you land. A blue bar shows under the hearts. Moves and attacks get an **Energy cost**; you cannot use them with less. Checkpoints you press a key at refill it.
- **Held moves can charge and pay.** A While held move with a Charge time can now spend an Energy cost each time the charge completes, **Charge again while held** (a repeating heal), **Hold still while charging**, **Energy used per second** (a jetpack that runs dry) and a new **Charge effects** section: when the charge is complete, Heal, Give energy, Play a sound and so on. Being hurt breaks a charge that costs energy. New effect: **Give energy** (also available on any move or attack).
- **A focus-heal loop with no code:** Player > Moves > Core movement > "Add move: Focus heal". Hold F, 1.1 s later you heal 1 and spend 33 energy, and it repeats while you hold. Hit enemies to fill the bar.
- **Upgrades.** Pickup or chest kind **upgrade** (give maxHp, energyMax or charmSlots, amount N), kind **energy**, and the Events actions **Permanent upgrade** and **Give energy** (plus the condition "energy is at least"). More max health arrives full. Upgrades are saved.
- **Charms.** Items with the use **Charm**: notches, an ability granted while worn, and up to 6 changes (max health, max energy, energy regrowth, energy per hit, run speed, jump height, invisibility time, damage of your hits). Equip them with Enter in the inventory; the screen shows notches used.
- **Death rules.** Settings > Death: health and energy you come back with (% of max), coins dropped (% of your coins), a glowing bag at the spot that gives them back when touched (or lost for good), and an optional **YOU DIED** screen.
- **Optional templates** (Player > Moves > Core movement): Feel presets (tight, floaty, heavy, back to defaults) and starter moves (double jump, dash, sprint, glide, focus heal). Nothing is added unless you click, and everything can be edited or deleted.
- The checker warns when something costs energy but there is no energy bar, when charm items exist with no notches, when an upgrade id is unknown, and mentions when energy can never refill.
- Tests: `npm test` now runs 18 unit checks and 79 browser checks (in 15 playtest scenarios).

## 3.25.0 (Phase 3: shared actor rules and the Enemies tab)
- **New Enemies tab.** Build enemy types from scratch (nothing is preset): size and health; how it moves (stands still, patrols, chases when it sees you, flies, hops) with speed, patrol distance, sight and ledge behaviour; an optional attack (shoots a shot, or charges at you) with a **warning time** where it stops and flashes, its own range, cooldown, speed, damage and shot size; **damage, push-back and stun when it touches you**; how it reacts when you hit it (pushed back, flinch time, safe time); drops (coins, energy, an item with a chance); colour, picture size, health bar, animations (standing, moving, warning, attacking, hurt, dying) and sounds. A picture shows the size and how far it sees and attacks.
- **Place them:** World editor > Entities > Enemy > **Type**. Leave Type empty for the old simple enemy (it still works exactly as before).
- **Events:** new trigger **An enemy is defeated** (a type, or any).
- **Shared rules (MV.Actor):** taking damage with safe time, push-back and flinch is one function that enemies use now and bosses will use in Phase 4.
- The checker warns about an enemy that uses a type that was deleted (error), a drop item, animation or sound that no longer exists, a chaser or flyer that can never see you, energy drops with no energy bar, and unused types.
- Still to come: the Bosses rework (Phase 4). The player's own Damage settings (hidden) and hazard damage stay as they are until their own tab.
- Tests: `npm test` now runs 22 unit checks and 92 browser checks.

## 3.26.0 (Phase 4: hitboxes for enemies and bosses, and the Bosses rework)
- **Shapes everywhere.** An enemy or boss body can be a rectangle, circle or polygon (drag the corners in the picture). Hits are tested shape against shape, so a circle is not hurt in the empty corner of its box. `MV.Attacks.shapeHit` does this for player attacks, shots, enemy strikes and boss hitboxes.
- **Enemy strikes.** A new enemy attack, *Strikes with hitboxes*: after the warning a timeline plays (length = Charge / strike length) with hitboxes you draw: shape, size, start and end position, hurts from/until, damage per hitbox. A timeline slider and Play button in the Enemies tab show them. *Hurts by touching* can be turned off.
- **Weak spots** (enemies and bosses): boxes that take a damage multiplier; *Only weak spots hurt it* makes the rest of the body armour. Hitting one shows "Weak spot!".
- **Bosses:** per-hitbox damage, push-back and stun (no more one fixed damage), shaped hitboxes, a **warning time** per pattern (hitboxes show as dashed outlines first, nothing hurts yet), **phase changes** (the boss is untouchable for *Phase change time*, with a Phase change animation, shake and sound), **restart on death** (full health, asleep again; can be turned off), sounds (wake, hit, phase, defeated, and per pattern), safe time after a hit, a health bar with phase marks that goes grey while it cannot be hurt, and the shared MV.Actor damage rule.
- The Bosses tab shows dashed ghosts of hitboxes that have not started yet, weak spots, and the new fields.
- The checker finds: strike enemies with no hitboxes, enemies and bosses that can never be killed, bosses that cannot hurt you or never attack, patterns with no warning, and missing sounds.
- Tests: `npm test` runs 27 unit checks and 104 browser checks.
- Next: your Phase 4 report, then Phase 5 (Items, UI).

## 3.27.0 (your 3.24.0 report: what was already done, and what is new)
Already in the build before this version (check them in 3.27.0): doorway width and height (World editor > Transitions list), ceiling doorways drop you and floor doorways hop you onto the nearest ledge, Bash orb / Grapple point / Zipline animation slots, solid moving platforms, Phase walls plus the move setting that passes through them, erase working with shapes, breakable walls needing real damage, the Player size setting, key order and "Down + key" combos, Air time of a full jump, a body shape that only applies while a move plays, held and swim animations, wall and ceiling path and speed, item icons and weapon choosing in the inventory, world-change events (change tiles for good, remove or show a placed thing, skip a boss, boss-defeated trigger), and no sound maker (import files only).
New in 3.27.0:
- **Animations: frames of any size.** A frame can be a grid cell or a free pixel rectangle (Animations tab: sheet bar > Pick frames by > Free rectangle, or select a frame > Use a free rectangle). All frames draw at the same pixel scale and share the pivot (as a fraction of each frame), so a 16x16 frame followed by a 10x20 one keeps its proportions and its bottom-centre point.
- **Bosses use the Animations tab.** The old boss animation form is gone. Pick a clip per state (asleep, waking, normal, attacking, warning, changing phase, stunned, hurt, defeated), a clip per pattern and a look clip per hitbox. Old bosses keep drawing their old animations where no clip is set, and a button removes them.
- **Boss invincibility:** each pattern can have invincible moments (the boss shimmers and takes no damage, shown as a blue band on the timeline), on top of the safe time after a hit.
- **Boss stagger:** after losing a set percentage of its health (default off; set it in Boss > Stunned after losing this much health) the boss is stunned for a set time, cannot attack, takes extra damage (multiplier) and plays its stun clip and sound.
- **Camera:** the default camera is now Hollow Knight style (follow the floor you last stood on, look ahead, look up/down, ledge hint). "Plain smooth follow" is a preset for the old behaviour.
- **Help:** the Shots and effects section starts with a plain explanation and examples; the Player sprite preview and the dialogue preview are smaller and fold away.
- Checker: boss animation missing, boss with no art, pointless stagger multiplier.
- Tests: `npm test` runs 29 unit checks and 135 browser checks.

## 3.28.0 (camera system)
The camera is now a full system. Read **CAMERA.md** for the API.
- **Rig:** `engine/camera_rig.js` wraps the old camera. New: modes (follow, side-scrolling, top-down, fixed, free), zoom and tilt, shake with curves, recoil, fades, wipe and iris transitions, flashes, lock-on, multi-target and boss framing, soft room limits, screen-edge margin, temporary overrides with priorities, rails and cutscenes, manual pan and a free camera.
- **Profiles:** Player > Camera profiles have new fields (mode, zoom, tilt, edge margin, soft limits, look-around, boss framing, door transition, fade on entering a room).
- **Player options:** sensitivity, stick dead zone, invert, mouse, zoom, smoothing, shake strength, flashes and reduce motion. Saved in the browser. Keyboard (J I K L pan, + - zoom, Backspace reset), gamepad right stick and triggers, mouse wheel and middle-button drag.
- **Events tab:** actions for camera zoom, tilt, fade, flash and look-at-a-spot.
- **Script:** `MV.Game.camera` forwards all of it.
- **Not supported:** isometric and first-person modes (the renderer is a flat 2D tile view); `mode()` says so.
- Fixed in the rig before release: two state fields hid the `pan()` and `target()` methods.

## 3.29.0 (boss AI: containment, collision, targeting, rules)
- **Collision and containment:** a boss's body path used to set its position directly, so it could cross walls and leave the room. Now every move is made in small steps against the room's solid tiles, one axis at a time, so the boss slides along walls. It also stays inside the room, and the new **Never goes farther than this from its spot** setting (leash) keeps it inside an arena.
- **Walking and gravity:** **Walks toward you at** and **Walks until it is this close** make the boss approach between attacks. **Floats / Stands on the floor** makes a boss fall to the floor (its attack paths are measured from where it stands).
- **Rule-based attacks:** set **Picks attacks** to *By rules*. Each pattern then has: only when you are at least / at most this far, only when you are on the ground or in the air, only below or above a health percentage, a cooldown, and a weight. If nothing fits for 3 seconds it picks any pattern that is not on cooldown, so it never freezes. *In order* keeps the old behaviour (existing bosses are unchanged).
- **Targeting:** a pattern can **keep turning to face you during the warning**, and its body movement can be **stretched to end where you stand** when the warning is over (up to 2x its drawn length).
- **Checker:** warns about rules that can never be met (min farther than max, health range empty, all weights 0).
- New bosses start with By rules, walking, and example distance rules. Tests: 55 unit checks and 152 browser checks.
- **Added to 3.29.0 (AI foundation):** the Patterns panel of every boss now has an **Attack choice (AI rules)** section (with a button to switch an old boss to rules). New rules: **Only when you are above / level with / below the boss**, and **Most times in a row** (repeat limit). Example: a close slash 0 to 4 tiles, a projectile 5 to 20 tiles with a cooldown, and weights to shape how often each happens.
- **Arena containment:** placing a boss from the Bosses tab stamps its arena bounds on the boss (Arena property, "x0,y0,x1,y1"); the boss can never leave that box, and walls stop it inside it. Older placements work out the box from their spawn tile and the boss's arena size.
- **Not yet:** retreating, jumping over obstacles and pathfinding. The boss approaches in a straight line and stops at walls.

## 3.29.1 (boss patterns aim at you)
- Boss patterns already mirrored to face you; they ran along the path exactly as drawn, so a projectile or lunge never pointed at you. New pattern setting **Aim: Turn the whole path toward you**: hitbox paths and the body path are turned about the boss's middle so "forward" points at you (up or down as well), and keep turning while the warning shows. **Aim: most it may turn** limits the angle (default 80 degrees) so it never aims backwards.
- The Patterns preview in the editor always shows the path facing right, because there is no player in it.

## 3.30.0 (code cleanup, no new features)
- All code is formatted (prettier, `.prettierrc`), so lines are no longer up to 1,800 characters long.
- `engine/game.js` is built from 12 topic files in `engine/game/`; the editor's four big scripts are built from 47 numbered files in `editor/app-01` to `editor/app-04`. See **STRUCTURE.md**.
- `npm start`, `npm test` and `npm run dist` rebuild `engine/game.js` first. Edit `engine/game/*.js`, not `engine/game.js`.
- A unit check makes sure the built file matches its pieces and every script in `index.html` exists.
- Behaviour is unchanged: the same 59 unit and 155 browser checks pass.
- Still to do: `engine/game/08-sim.js` is one 1,800-line function.

## 3.30.1 (sim split, a real bug found)
- `sim` (the one-frame simulation, 1,800 lines) is now a short function plus 8 player movement functions (`engine/game/08a-sim-player.js`) and 21 entity functions (`engine/game/08b-sim-entities.js`). The split was done by a script that rewrites variable references with scope analysis, then checked by all tests; behaviour is unchanged.
- **Bug fixed:** two editor functions were both called `bgMove`: dragging or resizing a background layer in the room editor called the layer-reorder one (the later definition wins), which could scramble the room's background layers. The reorder function is now `bgSwap`.
- A new check fails the build if two editor functions ever share a name again.

## 3.31.0 (JavaScript scripting)

* New **Scripts** tab: write JavaScript saved in the project. Scripts listen to game events with `on('room', ...)` and use a safe `game` object (health, flags, variables, items, entities, timers, camera, dialogue and more). See `SCRIPTING.md`.
* New Events action **Run a script function** calls a function a script offers with `fn('name', ...)`.
* Errors are caught and shown in the Scripts tab console; a handler that fails five times in a row is switched off for that play.
* The World check and `tools/validate.js` report scripts that do not compile, unknown hooks and missing functions.
* Opening a project file that has scripts asks you to confirm you trust it.
* Limits: an endless loop freezes the game, and hiding `window` and similar names is not a security wall.
* New: `engine/script.js`, `engine/game/13-script-api.js`, `editor/scripts_ui.js`, `SCRIPTING.md`, 6 unit tests and 2 browser scenarios.

## 3.32.0 (scripted AI, bosses and moves)

* **Enemies:** *Moves = Script* with an AI script function. The function steers the enemy every frame (walk, jump, fly, shoot, its own hit boxes). The enemy's health, drops, contact damage and built-in attack still apply.
* **Bosses:** *AI = Script*. The function decides when to walk, jump, use a pattern (`me.attack('slam')`, your patterns made in the Bosses tab) and can also do its own attacks and shots. It still cannot leave the arena or pass walls.
* **Moves:** new type *Scripted move*. The function steers the player every frame for as long as the move lasts.
* `game.player.tune(...)`, `game.player.setVelocity(...)`, and `entity.get(...)` / `entity.set(...)` change movement, enemy and boss settings for the current play (range-checked).
* The checker reports a Script AI or move that names a function no script defines.
* See SCRIPTING.md. 1 more unit test and 1 more browser scenario.
