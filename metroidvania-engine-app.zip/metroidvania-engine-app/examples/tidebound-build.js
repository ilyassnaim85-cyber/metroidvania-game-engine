// Builds examples/tidebound.json: a small three-level showcase game made only with the engine's own data
// (no scripts, no art files): 3 levels, 3 movement abilities (dash, double jump, wall jump), 4 enemy types and a boss.
//   node examples/tidebound-build.js        (writes tidebound.json next to this file)
const fs = require('fs'),
  path = require('path');
const MV = require('../tools/validate.js').engine();

class Room {
  constructor(id, n, gw, gh, fill) {
    this.id = id;
    this.n = n;
    this.gw = gw;
    this.gh = gh;
    this.g = Array.from({ length: gh }, () => Array(gw).fill(fill || '.'));
    this.ent = [];
    this.tr = [];
    this.k = 0;
  }
  put(x, y, c) {
    if (x >= 0 && y >= 0 && x < this.gw && y < this.gh) this.g[y][x] = c;
  }
  box(x0, y0, x1, y1, c) {
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) this.put(x, y, c);
  }
  e(type, x, y, props) {
    this.ent.push({ id: this.id + '_' + type + this.k++, type, x, y, props: props || {} });
  }
  door(x, y0, y1, a, r, o) {
    for (let y = y0; y <= y1; y++) {
      this.put(x, y, 'D');
      this.tr.push(Object.assign({ x, y, a, r }, o || {}));
    }
  }
  out() {
    return {
      id: this.id,
      n: this.n,
      x: 0,
      y: 0,
      w: 4,
      h: 2,
      gw: this.gw,
      gh: this.gh,
      grid: this.g.map(r => r.join('')),
      ent: this.ent,
      tr: this.tr,
      bg: this.bg || null,
      light: this.light || null,
      music: '',
      art: this.art || [],
      table: []
    };
  }
}
// ---- pictures: every sheet comes from examples/tidebound-art (run `python3 examples/tidebound-art.py` to redraw them)
const ART = path.join(__dirname, 'tidebound-art');
const png = n => 'data:image/png;base64,' + fs.readFileSync(path.join(ART, n + '.png')).toString('base64');
const sheets = [];
const addSheet = (id, tw, th, file) => sheets.push({ id, name: (file || id) + '.png', url: png(file || id), tw, th });
addSheet('player', 16, 16);
addSheet('crab', 16, 16);
addSheet('eel', 32, 16);
addSheet('puffer', 16, 16);
addSheet('urchin', 16, 16);
addSheet('boss', 64, 48, 'kingcrab');
addSheet('items', 16, 16);
addSheet('tiles', 16, 16);
addSheet('deco', 16, 16);
addSheet('title', 480, 270);
addSheet('logo', 360, 90);
['wreck', 'reef', 'shaft', 'lair'].forEach(k => ['far', 'mid', 'near'].forEach(l => addSheet('bg-' + k + '-' + l, 320, 180)));
addSheet('bubbles', 128, 128, 'bg-bubbles');
addSheet('embers', 128, 128, 'bg-embers');
// animation clips: a clip is a list of frames { sheet, col, row, dur (ms) }
const clips = [];
const clip = (id, name, sheet, cells, dur, mode) =>
  clips.push({ id, name, mode: mode || 'loop', frames: cells.map(([col, row]) => ({ sheet, col, row, dur })) });
const seq = (row, n, from) => Array.from({ length: n }, (_, i) => [(from || 0) + i, row]);
clip('p_idle', 'Hero idle', 'player', seq(0, 4), 220);
clip('p_run', 'Hero run', 'player', seq(1, 6), 80);
clip('p_jump', 'Hero jump', 'player', seq(2, 1), 100);
clip('p_fall', 'Hero fall', 'player', seq(3, 1), 100);
clip('p_dash', 'Hero dash', 'player', seq(4, 2), 60);
clip('p_wall', 'Hero wall slide', 'player', seq(5, 1), 100);
clip('p_attack', 'Hero slash', 'player', seq(6, 4), 60, 'once');
clip('p_hurt', 'Hero hurt', 'player', seq(7, 1), 150, 'once');
clip('crab_walk', 'Crab walk', 'crab', seq(0, 2), 200);
clip('crab_hurt', 'Crab hurt', 'crab', [[2, 0]], 150);
clip('crab_die', 'Crab defeated', 'crab', [[3, 0], [4, 0]], 160, 'once');
clip('eel_idle', 'Eel swim', 'eel', seq(0, 2), 260);
clip('eel_warn', 'Eel warns', 'eel', [[2, 0]], 150);
clip('eel_bite', 'Eel bites', 'eel', [[3, 0]], 150);
clip('eel_hurt', 'Eel hurt', 'eel', [[4, 0]], 150);
clip('eel_die', 'Eel defeated', 'eel', [[5, 0]], 200, 'once');
clip('puf_idle', 'Puffer idle', 'puffer', [[0, 0]], 300);
clip('puf_warn', 'Puffer inflates', 'puffer', [[1, 0], [2, 0]], 200);
clip('puf_shoot', 'Puffer fires', 'puffer', [[2, 0]], 150);
clip('puf_hurt', 'Puffer hurt', 'puffer', [[3, 0]], 150);
clip('puf_die', 'Puffer defeated', 'puffer', [[4, 0]], 200, 'once');
clip('urchin', 'Urchin', 'urchin', seq(0, 2), 420);
clip('king_idle', 'King Crab idle', 'boss', seq(0, 2), 420);
clip('king_warn', 'King Crab warns', 'boss', [[2, 0]], 150);
clip('king_hit', 'King Crab strikes', 'boss', [[3, 0]], 150);
clip('king_stun', 'King Crab dazed', 'boss', [[4, 0]], 150);
clip('king_hurt', 'King Crab hurt', 'boss', [[5, 0]], 150);
clip('king_die', 'King Crab defeated', 'boss', [[6, 0]], 200, 'once');
clip('king_phase', 'King Crab roars', 'boss', [[7, 0], [2, 0]], 160);
clip('orb_dash', 'Dash orb', 'items', seq(0, 2, 0), 260);
clip('orb_dj', 'Double jump orb', 'items', seq(0, 2, 2), 260);
clip('orb_wj', 'Wall jump orb', 'items', seq(0, 2, 4), 260);
clip('orb_gone', 'Orb gone', 'items', [[0, 2]], 100);
clip('lamp_off', 'Lantern', 'items', [[6, 0]], 200);
clip('lamp_on', 'Lantern lit', 'items', [[7, 0], [0, 1]], 140);
clip('raft', 'Raft', 'items', [[1, 1]], 200);
// decorations placed in rooms as sprites: name -> [column, row, width, height] in tiles of the deco sheet
const DECO = {
  weedA: [0, 0, 1, 2], weedB: [1, 0, 1, 2], coralP: [2, 0, 2, 2], coralO: [4, 0, 2, 2], barrel: [6, 0, 1, 1], crate: [7, 0, 1, 1],
  anchor: [0, 2, 2, 2], chain: [2, 2, 1, 2], wheel: [3, 2, 2, 2], glow: [5, 2, 1, 1], spire: [6, 2, 1, 2], board: [7, 2, 1, 1],
  statue: [8, 2, 2, 2], shell: [5, 3, 1, 1]
};
// a decoration standing on the ground row g (or at an explicit top row with y)
Room.prototype.deco = function (kind, x, g, top) {
  const [c, r, w, h] = DECO[kind];
  (this.art = this.art || []).push({ x, y: top === undefined ? g - h : top, s: 'deco', c, r, w, h });
};
// the four picture layers of a room's background: far, middle, near and a drifting layer in front of the game
const backdrop = (theme, color, fogCol) => ({
  color,
  layers: [
    { name: 'Far', sheet: 'bg-' + theme + '-far', mode: 'cover', parallax: 0.1 },
    { name: 'Middle', sheet: 'bg-' + theme + '-mid', mode: 'cover', parallax: 0.3 },
    { name: 'Near', sheet: 'bg-' + theme + '-near', mode: 'cover', parallax: 0.6, fog: fogCol ? 0.25 : 0, fogColor: fogCol || '#9fb4c8', fogDir: 'bottom' },
    { name: 'Drifting bubbles', sheet: theme === 'lair' ? 'embers' : 'bubbles', mode: 'tile', parallax: 1.15, front: true, alpha: 0.7, driftY: theme === 'lair' ? -1.2 : -1.6, sway: 0.4, swayHz: 0.3 }
  ]
});

// a floor with pits: pit = [x0, x1]; the pit is 2 deep with spikes at the bottom, so you can always jump out
function ground(r, G, pits) {
  r.box(0, G, r.gw - 1, r.gh - 1, '#');
  (pits || []).forEach(([a, b]) => {
    r.box(a, G, b, G + 1, '.');
    for (let x = a; x <= b; x++) r.put(x, G + 1, '^');
  });
}
const plank = (r, x0, x1, y) => r.box(x0, y, x1, y, '=');

// ---------------------------------------------------------------- level 1: the wreck (jump, fight, learn the dash)
const R1 = new Room('wreck', 'The Wreck', 90, 24);
{
  const r = R1,
    G = 20;
  ground(r, G, [
    [14, 16],
    [72, 79]
  ]);
  r.box(1, 9, 88, 19, 'o'); // back wall (not solid): the hold of the ship, open to the sea above
  r.box(0, 0, 89, 0, '#');
  r.box(0, 0, 0, 23, '#');
  r.box(89, 0, 89, 17, '#');
  // hanging planks from the broken deck above
  [[8, 11, 2], [22, 27, 3], [44, 50, 2], [60, 66, 3]].forEach(([a, b, h]) => r.box(a, 1, b, h, '#'));
  r.box(34, 18, 36, 19, '#'); // a step
  plank(r, 28, 32, 16);
  plank(r, 54, 58, 17);
  plank(r, 56, 60, 14);
  r.e('spawn', 3, 19);
  r.e('sign', 6, 19, { sprite: 'deco|7|2|1|1', text: 'Move: arrows or A and D.  Jump: Space.  Attack: X.  Press E at a checkpoint key.' });
  r.e('enemy', 22, 19, { kind: 'crab' });
  r.e('enemy', 38, 19, { kind: 'crab' });
  r.e('enemy', 46, 19, { kind: 'urchin' });
  r.e('checkpointkey', 52, 19, { key: 'E', rest: 'yes', idle: 'lamp_off', active: 'lamp_on' });
  r.e('sign', 62, 19, { sprite: 'deco|7|2|1|1', text: 'A gap too wide to jump. The sea gives you a gift ahead...' });
  r.e('pickup', 66, 19, { kind: 'ability', give: 'dash', idle: 'orb_dash', collected: 'orb_gone' });
  r.e('sign', 69, 19, { sprite: 'deco|7|2|1|1', text: 'Jump, then press Shift in the air to DASH across.' });
  r.e('enemy', 84, 19, { kind: 'crab' });
  r.door(89, 18, 19, 'reef', 'reef1', { fx: 'iris', fxTime: 0.7 });
  r.deco('weedA', 8, G);
  r.deco('weedB', 12, G);
  r.deco('barrel', 9, G);
  r.deco('crate', 10, G);
  r.deco('shell', 30, G);
  r.deco('anchor', 41, G);
  r.deco('weedA', 50, G);
  r.deco('wheel', 18, G, 12);
  r.deco('chain', 24, 0, 4);
  r.deco('chain', 47, 0, 3);
  r.deco('barrel', 64, G);
  r.deco('weedB', 82, G);
  r.deco('crate', 86, G);
  r.bg = backdrop('wreck', '#102a3c');
}
// ---------------------------------------------------------------- level 2: the reef (double jump, eels, shooters)
const R2 = new Room('reef1', 'Urchin Reef', 110, 26);
{
  const r = R2,
    G = 22;
  ground(r, G, [
    [44, 62],
    [78, 90]
  ]);
  r.box(0, 0, 109, 1, '#');
  r.box(0, 0, 0, 21, '#');
  r.box(109, 0, 109, 19, '#');
  r.box(24, 18, 26, 21, '#'); // four tiles high: needs the double jump
  [[30, 36], [66, 74], [96, 104]].forEach(([a, b]) => r.box(a, 2, b, 4, '#'));
  plank(r, 48, 51, 19);
  plank(r, 54, 57, 17);
  plank(r, 58, 61, 19);
  r.e('sign', 4, 21, { sprite: 'deco|7|2|1|1', text: 'Urchin Reef. Urchins sting and poison. Do not touch them.' });
  r.e('enemy', 11, 21, { kind: 'urchin' });
  r.e('pickup', 16, 21, { kind: 'ability', give: 'doublejump', idle: 'orb_dj', collected: 'orb_gone' });
  r.e('sign', 19, 21, { sprite: 'deco|7|2|1|1', text: 'Press Jump again in mid-air to double jump.' });
  r.e('enemy', 34, 21, { kind: 'eel' });
  r.e('checkpointkey', 40, 21, { key: 'E', rest: 'yes', idle: 'lamp_off', active: 'lamp_on' });
  r.e('enemy', 64, 21, { kind: 'puffer' });
  r.e('enemy', 70, 21, { kind: 'crab' });
  r.e('platform', 80, 20, { dx: 9, dy: 0, speed: 2.2, solid: 'no', idle: 'raft' });
  r.e('enemy', 94, 21, { kind: 'eel' });
  r.e('enemy', 100, 21, { kind: 'urchin' });
  r.e('enemy', 103, 21, { kind: 'puffer' });
  r.door(0, 20, 21, 'wreck', 'wreck');
  r.door(109, 20, 21, 'lair', 'shaft', { mode: 'press', fx: 'fade', fxTime: 0.6 });
  [[7, 'coralP'], [13, 'coralO'], [28, 'coralP'], [38, 'coralO'], [66, 'coralP'], [72, 'coralO'], [92, 'coralP'], [97, 'coralO'], [105, 'coralP']].forEach(([x, k]) => r.deco(k, x, G));
  [[9, 'weedA'], [22, 'weedB'], [31, 'weedA'], [63, 'weedB'], [75, 'weedA'], [88, 'weedB']].forEach(([x, k]) => r.deco(k, x, G));
  [[18, 'glow'], [36, 'glow'], [65, 'glow'], [101, 'glow']].forEach(([x, k]) => r.deco(k, x, G));
  r.bg = backdrop('reef', '#0e2f3a');
}
// ---------------------------------------------------------------- level 3a: the shaft (wall jump)
const R3 = new Room('shaft', 'Sunken Shaft', 44, 40, '#');
{
  const r = R3;
  r.box(1, 31, 18, 35, '.'); // entry hall
  r.box(15, 7, 18, 35, '.'); // the shaft: 4 wide, walls both sides
  r.box(15, 3, 42, 7, '.'); // the top hall (its floor is row 8 right of the shaft)
  r.e('sign', 4, 35, { sprite: 'deco|7|2|1|1', text: 'The shaft ahead has no ledges. Wall jump: jump while sliding down a wall, then push the other way.' });
  r.e('pickup', 9, 35, { kind: 'ability', give: 'wallJump', idle: 'orb_wj', collected: 'orb_gone' });
  r.e('enemy', 15, 24, { kind: 'urchin' });
  r.e('enemy', 18, 17, { kind: 'urchin' });
  r.e('checkpointkey', 22, 7, { key: 'E', rest: 'yes', idle: 'lamp_off', active: 'lamp_on' });
  r.e('enemy', 28, 7, { kind: 'eel' });
  r.e('enemy', 35, 7, { kind: 'puffer' });
  r.door(0, 34, 35, 'reef', 'reef1', { mode: 'press', fx: 'slide', fxTime: 0.5 });
  r.door(43, 6, 7, 'lair', 'arena', { ride: 2.5, fx: 'dissolve', fxTime: 0.8 });
  [[3, 'spire'], [8, 'spire'], [11, 'glow']].forEach(([x, k]) => r.deco(k, x, 36));
  [[22, 'spire'], [26, 'glow'], [33, 'spire'], [38, 'glow'], [40, 'spire']].forEach(([x, k]) => r.deco(k, x, 8));
  r.bg = backdrop('shaft', '#0a1d2a');
}
// ---------------------------------------------------------------- level 3b: the lair (boss)
const R4 = new Room('arena', "King Crab's Lair", 40, 18);
{
  const r = R4,
    G = 15;
  r.box(0, G, 39, 17, '#');
  r.box(0, 0, 39, 1, '#');
  r.box(0, 0, 0, 17, '#');
  r.box(39, 0, 39, 17, '#');
  plank(r, 5, 9, 11);
  plank(r, 30, 34, 11);
  r.e('checkpointkey', 4, 14, { key: 'E', rest: 'yes', idle: 'lamp_off', active: 'lamp_on' });
  r.e('boss', 28, 14, { boss: 'kingcrab', arena: '1,2,39,15' });
  r.door(0, 13, 14, 'lair', 'shaft');
  r.deco('statue', 9, G);
  r.deco('statue', 20, G);
  r.deco('statue', 34, G);
  r.deco('glow', 3, G);
  r.deco('glow', 14, G);
  r.deco('glow', 26, G);
  r.bg = backdrop('lair', '#1a1020');
}

// the transitions point at area ids; fix them up here
const ROOMS = { wreck: 'wreck', reef1: 'reef', shaft: 'lair', arena: 'lair' };
[R1, R2, R3, R4].forEach(r =>
  r.tr.forEach(t => {
    const room = t.r;
    t.a = ROOMS[room];
  })
);
const area = (id, n, c, x, rooms) => ({ id, n, s: '', c, x, y: 0, w: 6, h: 3, rooms });
const rooms = [R1, R2, R3, R4].map(r => r.out());
rooms[0].x = 1;
rooms[1].x = 1;
rooms[2].x = 1;
rooms[3].x = 4;
rooms[3].y = 0;

const enemies = [
  {
    id: 'crab',
    name: 'Shore Crab',
    w: 1,
    h: 0.8,
    hp: 3,
    move: 'patrol',
    speed: 2,
    range: 3,
    sight: 6,
    attack: 'none',
    color: '#d9534f',
    scale: 1.3,
    clips: { idle: 'crab_walk', walk: 'crab_walk', hurt: 'crab_hurt', die: 'crab_die' },
    coins: 2,
    flinch: 0.3
  },
  {
    id: 'eel',
    name: 'Moray Eel',
    w: 1.4,
    h: 0.8,
    hp: 4,
    ai: 'brain',
    move: 'patrol',
    speed: 2.6,
    range: 4,
    sight: 8,
    leash: 12,
    alertTime: 0.4,
    attack: 'strike',
    pattern: 'strike, strike',
    meleeRange: 2.2,
    atkWind: 0.45,
    atkDur: 0.5,
    atkCool: 1.2,
    color: '#6c8e3a',
    scale: 1.35,
    clips: { idle: 'eel_idle', walk: 'eel_idle', warn: 'eel_warn', attack: 'eel_bite', hurt: 'eel_hurt', die: 'eel_die' },
    coins: 3,
    strike: [{ name: 'Bite', shape: 'rect', w: 1.4, h: 0.9, from: 0.15, to: 0.35, dmg: 1, kf: [{ t: 0, x: 1.1, y: 0 }] }]
  },
  {
    id: 'puffer',
    name: 'Pufferfish Guard',
    w: 0.9,
    h: 0.9,
    hp: 2,
    ai: 'brain',
    move: 'stand still',
    sight: 10,
    attack: 'shoot',
    pattern: 'shoot',
    atkRange: 9,
    keepAway: 3,
    atkWind: 0.6,
    atkCool: 1.8,
    atkSpeed: 8,
    atkSize: 0.3,
    atkAim: 'at the player',
    color: '#e8c04a',
    scale: 1.5,
    clips: { idle: 'puf_idle', warn: 'puf_warn', attack: 'puf_shoot', hurt: 'puf_hurt', die: 'puf_die' },
    coins: 3
  },
  {
    id: 'urchin',
    name: 'Sea Urchin',
    w: 1,
    h: 1,
    hp: 99,
    ai: 'hazard',
    immune: 'yes',
    touch: 'yes',
    damage: 1,
    knock: 5,
    dtype: 'poison',
    inflict: 'poison',
    inflictTime: 4,
    shape: 'circle',
    color: '#7b4fa8',
    scale: 1.35,
    clips: { idle: 'urchin' }
  }
];

const boss = {
  id: 'kingcrab',
  name: 'King Crab',
  hp: 40,
  w: 3,
  h: 2.2,
  wake: 14,
  wakeTime: 1.2,
  speed: 2.4,
  keep: 2.5,
  fly: 'no',
  touch: 'yes',
  damage: 1,
  invul: 0.15,
  stagger: 35,
  staggerTime: 1.6,
  staggerMult: 2,
  flag: 'kingcrab_down',
  clips: { passive: 'king_idle', awakened: 'king_idle', idle: 'king_idle', warn: 'king_warn', attack: 'king_hit', phase: 'king_phase', stun: 'king_stun', hurt: 'king_hurt', die: 'king_die' },
  patterns: [
    {
      id: 'slam',
      name: 'Claw slam',
      warn: 0.7,
      duration: 1,
      track: 'yes',
      hitboxes: [{ name: 'Claw', w: 2.2, h: 2.2, dmg: 1, from: 0.2, to: 0.7, kf: [{ t: 0, x: 2.6, y: 0 }] }]
    },
    {
      id: 'sweep',
      name: 'Claw sweep',
      warn: 0.6,
      duration: 1.2,
      hitboxes: [
        { name: 'Sweep', w: 1.6, h: 1, dmg: 1, from: 0.2, to: 1, kf: [{ t: 0.2, x: 1.8, y: 0.4 }, { t: 1, x: 4.8, y: 0.4 }] }
      ]
    },
    {
      id: 'stomp',
      name: 'Stomp',
      warn: 0.8,
      duration: 1,
      hitboxes: [{ name: 'Shockwave', w: 7, h: 0.7, dmg: 1, from: 0.4, to: 0.8, kf: [{ t: 0.4, x: 0, y: 0.7 }] }]
    }
  ],
  phases: [
    { below: 100, idle: 1, speed: 1, patterns: ['slam', 'sweep'] },
    { below: 60, idle: 0.7, speed: 1.2, enter: 0.8, patterns: ['slam', 'sweep', 'stomp'] },
    { below: 30, idle: 0.4, speed: 1.5, enter: 0.8, patterns: ['stomp', 'sweep', 'slam', 'sweep'] }
  ]
};

const project = {
  name: 'Tidebound (showcase)',
  areas: [
    area('wreck', 'The Wreck', '#c08a4a', 0, [rooms[0]]),
    area('reef', 'Urchin Reef', '#7b4fa8', 7, [rooms[1]]),
    area('lair', "King Crab's Lair", '#d9534f', 14, [rooms[2], rooms[3]])
  ],
  links: [
    ['wreck', 'reef'],
    ['reef', 'lair']
  ],
  mw: 60,
  mh: 24,
  player: { maxHp: 6, jumpHeight: 3.2, run: 8.5, camLookAhead: 2 },
  moves: [
    { id: 'dash', label: 'Dash', type: 'dash', key: 'Shift', requires: 'dash', speed: 22, duration: 0.2, cooldown: 0.5, uses: 1, where: 'any' },
    { id: 'doublejump', label: 'Double jump', type: 'impulse', key: 'Jump', requires: 'doublejump', where: 'air', dir: 'up', speed: 15, uses: 1, cooldown: 0.1 }
  ],
  attacks: [
    {
      id: 'slash',
      label: 'Slash',
      key: 'KeyX',
      duration: 0.28,
      cooldown: 0.12,
      damage: 1,
      hitboxes: [{ name: 'Blade', w: 1.7, h: 1.5, from: 0.05, to: 0.2, kf: [{ t: 0, x: 1.2, y: -0.75 }] }]
    }
  ],
  enemies,
  bosses: [boss],
  events: [
    { id: 'learn_dash', name: 'Learned dash', once: 'yes', trigger: { type: 'ability', ability: 'dash' }, conds: [], actions: [{ type: 'message', text: 'You learned DASH. Jump, then press Shift.' }] },
    { id: 'learn_dj', name: 'Learned double jump', once: 'yes', trigger: { type: 'ability', ability: 'doublejump' }, conds: [], actions: [{ type: 'message', text: 'You learned DOUBLE JUMP.' }] },
    { id: 'learn_wj', name: 'Learned wall jump', once: 'yes', trigger: { type: 'ability', ability: 'wallJump' }, conds: [], actions: [{ type: 'message', text: 'You learned WALL JUMP.' }] },
    {
      id: 'win',
      name: 'King Crab falls',
      once: 'yes',
      trigger: { type: 'boss', boss: 'kingcrab' },
      conds: [],
      actions: [
        { type: 'shake', amount: 0.6 },
        { type: 'heal', n: 0 },
        { type: 'dialogue', text: 'The King Crab sinks into the dark.\nThe tide is calm again.\nThanks for playing!', speaker: 'Tidebound' }
      ]
    }
  ],
  sprite: {
    w: 1.9,
    h: 1.9,
    anims: {
      idle: { clip: 'p_idle' },
      run: { clip: 'p_run' },
      jump: { clip: 'p_jump' },
      fall: { clip: 'p_fall' },
      dash: { clip: 'p_dash' },
      wall: { clip: 'p_wall' },
      attack: { clip: 'p_attack' },
      hurt: { clip: 'p_hurt' }
    }
  },
  anims: MV.Anim.list(clips),
  sheets,
  tileSkins: {
    '#': { sheet: 'tiles', mode: 'auto16', col: 0, row: 0, frames: 1, fps: 8, join: 'solid' },
    '=': { sheet: 'tiles', mode: 'single', col: 4, row: 0, frames: 1, fps: 8, join: 'same' },
    o: { sheet: 'tiles', mode: 'single', col: 5, row: 0, frames: 1, fps: 8, join: 'same' }
  },
  ui: {
    titleText: 'TIDEBOUND',
    subtitle: 'A showcase made with Metroidvania Engine',
    menuBg: { sheet: 'title', col: 0, row: 0, frames: 1, fps: 8, loop: true },
    menuLogo: { sheet: 'logo', col: 0, row: 0, frames: 1, fps: 8, loop: true },
    heartFull: { sheet: 'items', col: 2, row: 1, frames: 1, fps: 8, loop: true },
    heartEmpty: { sheet: 'items', col: 3, row: 1, frames: 1, fps: 8, loop: true },
    coinIcon: { sheet: 'items', col: 4, row: 1, frames: 1, fps: 8, loop: true }
  }
};
// pickups give abilities by id; wall jump is built in, dash and double jump come from the moves above
fs.writeFileSync(path.join(__dirname, 'tidebound.json'), JSON.stringify(project));
console.log('wrote examples/tidebound.json');
