# Draws every picture of the Tidebound example (sprite sheets, tiles, decorations, backgrounds, UI) with Pillow.
# No outside art is used: everything is drawn here, so the example can be rebuilt and changed freely.
#   python3 examples/tidebound-art.py
import math, os, random
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tidebound-art')
os.makedirs(OUT, exist_ok=True)
T = (0, 0, 0, 0)


def hexc(h, a=255):
    h = h.lstrip('#')
    if len(h) == 3:
        h = ''.join(c * 2 for c in h)
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(4))


def R(d, x0, y0, x1, y1, c):
    d.rectangle([x0, y0, x1, y1], fill=c)


def P(d, x, y, c):
    d.point((x, y), fill=c)


def sheet(cols, rows, tw, th):
    im = Image.new('RGBA', (cols * tw, rows * th), T)
    return im


def cell(im, col, row, tw, th):
    """a fresh transparent cell image to draw into, pasted back with put()"""
    return Image.new('RGBA', (tw, th), T)


def put(im, c, col, row, tw, th):
    im.paste(c, (col * tw, row * th))


def flash(img, amt=0.75):
    """white hurt flash"""
    px = img.load()
    for y in range(img.height):
        for x in range(img.width):
            r, g, b, a = px[x, y]
            if a:
                px[x, y] = (int(r + (255 - r) * amt), int(g + (255 - g) * amt), int(b + (255 - b) * amt), a)
    return img


def grey(img, amt=0.8):
    px = img.load()
    for y in range(img.height):
        for x in range(img.width):
            r, g, b, a = px[x, y]
            if a:
                v = int((r + g + b) / 3 * 0.6)
                px[x, y] = (int(r + (v - r) * amt), int(g + (v - g) * amt), int(b + (v - b) * amt), a)
    return img


def outline(img, col=(15, 18, 30, 255)):
    """1px dark outline around the drawing, which keeps small sprites readable on any background"""
    src = img.copy()
    sp = src.load()
    dp = img.load()
    for y in range(img.height):
        for x in range(img.width):
            if sp[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < img.width and 0 <= ny < img.height and sp[nx, ny][3] > 200:
                        dp[x, y] = col
                        break
    return img


# ------------------------------------------------------------------ the hero (16x16 cells, facing right)
SKIN, CAP, COAT, COAT2, PANTS, BOOT, SCARF, STEEL = (hexc(c) for c in ('#f2c79a', '#eef2f5', '#2f6fb0', '#4b8fd0', '#2b3a67', '#3b2a20', '#d9534f', '#d9e6f2'))


def hero(bob=0, lf=0, rf=0, arm=0, sword=None, lean=0, scarf=0, tuck=False, wall=False):
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    b = bob
    # legs
    if tuck:
        R(d, 6, 11 + b, 8, 12 + b, PANTS)
        R(d, 8, 12 + b, 10, 13 + b, PANTS)
        R(d, 6, 13 + b, 7, 13 + b, BOOT)
        R(d, 9, 14 + b, 10, 14 + b, BOOT)
    else:
        R(d, 6 + lf, 12 + b, 7 + lf, 14, PANTS)
        R(d, 8 + rf, 12 + b, 9 + rf, 14, PANTS)
        R(d, 6 + lf, 15, 8 + lf, 15, BOOT)
        R(d, 8 + rf, 15, 10 + rf, 15, BOOT)
    # coat + belt
    R(d, 5 + lean, 7 + b, 10 + lean, 11 + b, COAT)
    R(d, 5 + lean, 11 + b, 10 + lean, 11 + b, hexc('#1f4f86'))
    P(d, 8 + lean, 8 + b, COAT2)
    P(d, 8 + lean, 10 + b, COAT2)
    # scarf with a tail that waves
    R(d, 5 + lean, 6 + b, 10 + lean, 6 + b, SCARF)
    R(d, 3 + lean, 6 + b + scarf, 5 + lean, 7 + b + scarf, SCARF)
    P(d, 2 + lean, 7 + b + scarf, SCARF)
    # head, cap, eye
    R(d, 6 + lean, 3 + b, 10 + lean, 5 + b, SKIN)
    R(d, 5 + lean, 1 + b, 10 + lean, 2 + b, CAP)
    R(d, 6 + lean, 3 + b, 10 + lean, 3 + b, CAP)
    P(d, 5 + lean, 3 + b, CAP)
    P(d, 9 + lean, 4 + b, hexc('#1b1b2b'))
    P(d, 10 + lean, 5 + b, hexc('#d99a78'))
    # arm
    if wall:
        R(d, 9 + lean, 3 + b, 10 + lean, 6 + b, COAT)
        P(d, 10 + lean, 2 + b, SKIN)
    elif arm == 2:  # raised
        R(d, 9 + lean, 4 + b, 10 + lean, 8 + b, COAT)
        P(d, 10 + lean, 3 + b, SKIN)
    else:
        R(d, 8 + lean, 8 + b + arm, 10 + lean, 9 + b + arm, COAT2)
        P(d, 11 + lean, 9 + b + arm, SKIN)
    # sword
    if sword is not None:
        sx, sy, dx, dy = sword
        for i in range(6):
            P(d, sx + dx * i, sy + dy * i, STEEL)
        P(d, sx - dx, sy - dy, hexc('#b98b3e'))
    return outline(im)


def slash_arc(frame):
    """a white swoosh drawn in front of the hero"""
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    if frame == 1:
        d.arc([6, -1, 18, 12], 280, 360, fill=hexc('#ffffff'), width=2)
    if frame == 2:
        d.arc([7, 2, 19, 14], 300, 405, fill=hexc('#ffffff'), width=2)
        d.arc([8, 3, 18, 13], 320, 400, fill=hexc('#9fd8ff'), width=1)
    if frame == 3:
        d.arc([8, 4, 20, 16], 340, 430, fill=hexc('#9fd8ff'), width=1)
    return im


def make_player():
    S = sheet(8, 9, 16, 16)
    rows = {
        # idle (4)
        0: [dict(bob=0, scarf=0), dict(bob=0, scarf=1), dict(bob=1, scarf=1), dict(bob=0, scarf=0)],
        # run (6)
        1: [
            dict(lf=-1, rf=1, lean=1, scarf=-1, bob=1),
            dict(lf=0, rf=0, lean=1, scarf=-1, bob=0),
            dict(lf=1, rf=-1, lean=1, scarf=0, bob=1),
            dict(lf=1, rf=-1, lean=1, scarf=0, bob=1),
            dict(lf=0, rf=0, lean=1, scarf=-1, bob=0),
            dict(lf=-1, rf=1, lean=1, scarf=-1, bob=1),
        ],
        2: [dict(tuck=True, arm=2, scarf=-1, bob=-1)],  # jump
        3: [dict(lf=-1, rf=1, arm=-1, scarf=-1, bob=0)],  # fall
        4: [dict(lean=2, lf=-1, rf=2, arm=0, scarf=-1, bob=1), dict(lean=2, lf=-1, rf=2, arm=0, scarf=-2, bob=1)],  # dash
        5: [dict(wall=True, bob=0, lean=-1)],  # wall
        # attack (4): wind-up, slash x2, recover
        6: [
            dict(arm=1, sword=(11, 9, 1, -1), lean=0),
            dict(arm=0, sword=(12, 6, 1, 0), lean=1),
            dict(arm=0, sword=(12, 9, 1, 1), lean=1),
            dict(arm=0, sword=(11, 10, 1, 1), lean=0),
        ],
        7: [dict(bob=0, lean=-1, scarf=1, arm=1)],  # hurt
    }
    for r, frames in rows.items():
        for c, kw in enumerate(frames):
            im = hero(**kw)
            if r == 6:
                im = Image.alpha_composite(im, slash_arc(c))
            if r == 7:
                im = flash(im, 0.5)
            put(S, im, c, r, 16, 16)
    S.save(os.path.join(OUT, 'player.png'))


# ------------------------------------------------------------------ enemies
def make_crab():
    S = sheet(5, 1, 16, 16)
    RED, DK, LT = hexc('#d9534f'), hexc('#a63a38'), hexc('#f0897f')
    for c in range(5):
        im = Image.new('RGBA', (16, 16), T)
        d = ImageDraw.Draw(im)
        k = c % 2
        # legs
        for i, x in enumerate((3, 5, 7, 9, 11)):
            if i % 2 == k:
                R(d, x, 13, x, 14, DK)
            else:
                R(d, x, 12, x, 13, DK)
        # body
        d.ellipse([3, 6, 12, 13], fill=RED)
        d.arc([3, 6, 12, 13], 190, 350, fill=LT)
        R(d, 5, 9, 10, 9, DK)
        # eyes on stalks
        R(d, 5, 4, 5, 6, DK)
        R(d, 10, 4, 10, 6, DK)
        P(d, 5, 3, hexc('#ffffff'))
        P(d, 10, 3, hexc('#ffffff'))
        # claws
        up = 0 if k else 1
        d.ellipse([0, 4 + up, 3, 8 + up], fill=RED)
        d.ellipse([12, 4 + up, 15, 8 + up], fill=RED)
        P(d, 1, 5 + up, T)
        P(d, 14, 5 + up, T)
        R(d, 2, 8 + up, 3, 9, DK)
        R(d, 12, 8 + up, 13, 9, DK)
        im = outline(im)
        if c == 2:
            im = flash(im)
        if c == 3:  # defeated: upside down and grey
            im = grey(im.transpose(Image.FLIP_TOP_BOTTOM))
        if c == 4:
            im = grey(im.transpose(Image.FLIP_TOP_BOTTOM), 1.0)
            px = im.load()
            for y in range(16):
                for x in range(16):
                    if px[x, y][3] and (x + y) % 2:
                        px[x, y] = (0, 0, 0, 0)
        put(S, im, c, 0, 16, 16)
    S.save(os.path.join(OUT, 'crab.png'))


def eel_frame(phase, mouth=0, lunge=0, red=False):
    im = Image.new('RGBA', (32, 16), T)
    d = ImageDraw.Draw(im)
    G, DG, BE = hexc('#6c8e3a'), hexc('#46621f'), hexc('#c9d27a')
    pts = []
    for i in range(22):
        x = 2 + i + lunge
        y = 9 + math.sin((i * 0.45) + phase) * (2.0 - i * 0.04)
        pts.append((x, y))
    for (x, y) in pts:
        thick = 2 + (1.5 if 8 < pts.index((x, y)) < 18 else 0.5)
        d.ellipse([x - 1, y - thick, x + 2, y + thick], fill=G)
    for (x, y) in pts[3:19:2]:
        P(d, int(x), int(y - 3), DG)  # back spots
        P(d, int(x), int(y + 2), BE)
    # head
    hx, hy = pts[-1]
    d.ellipse([hx - 3, hy - 4, hx + 6, hy + 4], fill=G)
    jaw = 2 + mouth
    R(d, int(hx) + 2, int(hy) + 1, int(hx) + 8, int(hy) + 1 + (jaw if mouth else 0), hexc('#7a1f2a') if mouth else DG)
    if mouth:
        for tx in (int(hx) + 3, int(hx) + 5, int(hx) + 7):
            P(d, tx, int(hy) + 1, hexc('#ffffff'))
            P(d, tx, int(hy) + 1 + jaw, hexc('#ffffff'))
    P(d, int(hx) + 1, int(hy) - 2, hexc('#ff3b3b') if red else hexc('#ffe36b'))
    return outline(im)


def make_eel():
    S = sheet(6, 1, 32, 16)
    frames = [eel_frame(0), eel_frame(1.6), eel_frame(0.8, mouth=1, red=True), eel_frame(2.4, mouth=3, lunge=3, red=True)]
    frames.append(flash(eel_frame(0.5)))
    frames.append(grey(eel_frame(0).transpose(Image.FLIP_TOP_BOTTOM), 1.0))
    for i, f in enumerate(frames):
        put(S, f, i, 0, 32, 16)
    S.save(os.path.join(OUT, 'eel.png'))


def make_puffer():
    S = sheet(5, 1, 16, 16)
    Y, DY, BE = hexc('#e8c04a'), hexc('#b8902a'), hexc('#fff1b0')
    for c in range(5):
        im = Image.new('RGBA', (16, 16), T)
        d = ImageDraw.Draw(im)
        big = {0: 0, 1: 1, 2: 3, 3: 0, 4: 0}[c]
        if c == 1:
            big = 1
        r = 4 + big
        cx, cy = 8, 8
        if c in (0, 3, 4):
            pass
        # tail
        d.polygon([(cx - r - 4, cy - 3 + (c % 2)), (cx - r + 1, cy), (cx - r - 4, cy + 3 - (c % 2))], fill=DY)
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=Y)
        d.pieslice([cx - r + 1, cy - r + 1, cx + r - 1, cy + r - 1], 30, 150, fill=BE)
        if c == 2:  # fully puffed with spikes
            for a in range(0, 360, 40):
                x1 = cx + math.cos(math.radians(a)) * r
                y1 = cy + math.sin(math.radians(a)) * r
                x2 = cx + math.cos(math.radians(a)) * (r + 2)
                y2 = cy + math.sin(math.radians(a)) * (r + 2)
                d.line([(x1, y1), (x2, y2)], fill=DY)
        R(d, cx + 1, cy - 2, cx + 2, cy - 1, hexc('#ffffff'))
        P(d, cx + 2, cy - 1, hexc('#1b1b2b'))
        R(d, cx + r - 2, cy + 2, cx + r, cy + 2, hexc('#a33'))
        im = outline(im)
        if c == 3:
            im = flash(im)
        if c == 4:
            im = grey(im.transpose(Image.FLIP_TOP_BOTTOM), 1.0)
        put(S, im, c, 0, 16, 16)
    S.save(os.path.join(OUT, 'puffer.png'))


def make_urchin():
    S = sheet(2, 1, 16, 16)
    for c in range(2):
        im = Image.new('RGBA', (16, 16), T)
        d = ImageDraw.Draw(im)
        L = 7 if c else 6
        for a in range(0, 360, 20):
            x1 = 8 + math.cos(math.radians(a)) * 3
            y1 = 8 + math.sin(math.radians(a)) * 3
            x2 = 8 + math.cos(math.radians(a)) * (L + (1 if a % 40 == 0 else 0))
            y2 = 8 + math.sin(math.radians(a)) * (L + (1 if a % 40 == 0 else 0))
            d.line([(x1, y1), (x2, y2)], fill=hexc('#3d2466'))
        d.ellipse([4, 4, 11, 11], fill=hexc('#7b4fa8'))
        d.ellipse([5, 5, 8, 8], fill=hexc('#a77bd6'))
        P(d, 9, 9, hexc('#b8ff7a') if c else hexc('#7bd63c'))  # a poison glint
        put(S, outline(im, (20, 10, 40, 255)), c, 0, 16, 16)
    S.save(os.path.join(OUT, 'urchin.png'))


# ------------------------------------------------------------------ the boss: King Crab (64x48 cells, facing the player: symmetric)
def king(claw_l=0, claw_r=0, bob=0, eyes='n', crown_tilt=0, droop=0):
    im = Image.new('RGBA', (64, 48), T)
    d = ImageDraw.Draw(im)
    RED, DK, LT, GOLD = hexc('#c8423a'), hexc('#8e2a2a'), hexc('#ee7b6c'), hexc('#f2c94c')
    b = bob
    # legs
    for i, x in enumerate((10, 16, 22, 36, 42, 48)):
        off = (i % 2) * 2
        d.line([(x + 4, 36 + b), (x + (-4 if x < 32 else 8), 44 - off)], fill=DK, width=2)
        d.line([(x + (-4 if x < 32 else 8), 44 - off), (x + (-6 if x < 32 else 10), 47)], fill=DK, width=2)
    # big claws (arm + pincer), cl/cr = raise amount
    for side, raise_ in ((-1, claw_l), (1, claw_r)):
        bx = 32 + side * 13
        ax = 32 + side * 21
        ay = 26 + b - raise_ + droop
        d.line([(bx, 30 + b), (ax, ay)], fill=DK, width=5)
        d.line([(bx, 30 + b), (ax, ay)], fill=RED, width=3)
        # pincer: two half circles
        px_, py_ = ax + side * 3, ay - 6
        d.ellipse([px_ - 9, py_ - 8, px_ + 9, py_ + 8], fill=RED, outline=DK)
        d.polygon([(px_ - 2, py_ - 1), (px_ + side * 12, py_ - 4), (px_ + side * 6, py_ + 3)], fill=T)
        d.line([(px_ + side * 1, py_ - 1), (px_ + side * 10, py_ - 3)], fill=DK, width=1)
        d.arc([px_ - 7, py_ - 6, px_ + 7, py_ + 6], 200, 340, fill=LT)
    # shell
    d.ellipse([12, 14 + b, 52, 42 + b], fill=RED, outline=DK)
    d.pieslice([15, 17 + b, 49, 40 + b], 200, 340, fill=LT)
    for x in (22, 30, 38):
        d.line([(x, 28 + b), (x + 2, 36 + b)], fill=DK)
    # eye stalks
    ec = hexc('#ffffff')
    for x in (24, 40):
        d.line([(x, 17 + b), (x, 9 + b + droop)], fill=DK, width=2)
        d.ellipse([x - 3, 4 + b + droop, x + 3, 10 + b + droop], fill=ec, outline=DK)
        if eyes == 'n':
            d.ellipse([x - 1, 6 + b + droop, x + 1, 9 + b + droop], fill=hexc('#1b1b2b'))
        elif eyes == 'angry':
            d.ellipse([x - 1, 6 + b + droop, x + 1, 9 + b + droop], fill=hexc('#d11'))
            d.line([(x - 4, 3 + b), (x + 4, 6 + b)] if x < 32 else [(x + 4, 3 + b), (x - 4, 6 + b)], fill=DK, width=2)
        elif eyes == 'dizzy':
            d.line([(x - 2, 6 + b), (x + 2, 9 + b)], fill=hexc('#1b1b2b'))
            d.line([(x + 2, 6 + b), (x - 2, 9 + b)], fill=hexc('#1b1b2b'))
    # mouth, crown
    d.arc([26, 30 + b, 38, 38 + b], 20, 160, fill=DK, width=2)
    cx0 = 24 + crown_tilt
    d.polygon([(cx0, 14 + b), (cx0 + 2, 6 + b), (cx0 + 7, 11 + b), (cx0 + 8, 3 + b), (cx0 + 13, 11 + b), (cx0 + 16, 6 + b), (cx0 + 16, 14 + b)], fill=GOLD, outline=hexc('#8a6a12'))
    P(d, cx0 + 8, 9 + b, hexc('#4ad0ff'))
    return outline(im)


def make_boss():
    S = sheet(8, 1, 64, 48)
    fr = [
        king(0, 0, 0),  # idle 1
        king(2, 2, 1),  # idle 2
        king(0, 12, 0, 'angry'),  # warn: right claw lifted
        king(0, -4, 1, 'angry'),  # attack: slammed down
        king(0, 0, 3, 'dizzy', 2, 3),  # stun
        flash(king(0, 0, 1, 'angry'), 0.7),  # hurt
        grey(king(0, 0, 4, 'dizzy', 3, 5), 0.9),  # die
        king(10, 10, 0, 'angry'),  # phase: both claws up
    ]
    for i, f in enumerate(fr):
        put(S, f, i, 0, 64, 48)
    S.save(os.path.join(OUT, 'kingcrab.png'))


# ------------------------------------------------------------------ pickups, lantern, hearts, coin
def orb(col, glow, glyph, f):
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    r = 5 + (1 if f else 0)
    for i in range(3, 0, -1):
        d.ellipse([8 - r - i, 8 - r - i, 8 + r + i, 8 + r + i], fill=glow[:3] + (28 * (4 - i),))
    d.ellipse([8 - r, 8 - r, 8 + r, 8 + r], fill=col, outline=hexc('#102a3c'))
    d.ellipse([5, 5, 8, 8], fill=hexc('#ffffff', 190))
    for (x, y) in glyph:
        P(d, x, y, hexc('#102a3c'))
    return im


def make_items():
    S = sheet(8, 3, 16, 16)
    dash = [(5, 8), (6, 8), (7, 8), (8, 8), (9, 8), (10, 8), (9, 7), (9, 9), (10, 8), (8, 6), (8, 10)]
    dj = [(8, 5), (7, 6), (9, 6), (6, 7), (10, 7), (8, 6), (8, 7), (8, 8), (8, 10), (7, 11), (9, 11), (6, 10), (10, 10)]
    wj = [(6, 5), (6, 6), (6, 7), (6, 8), (6, 9), (6, 10), (7, 10), (8, 9), (9, 8), (10, 7), (10, 6), (9, 6), (9, 7), (10, 5)]
    for i, (col, glow, g) in enumerate(((hexc('#46d9e6'), hexc('#46d9e6'), dash), (hexc('#f2d34c'), hexc('#f2d34c'), dj), (hexc('#7de65a'), hexc('#7de65a'), wj))):
        for f in range(2):
            put(S, orb(col, glow, g, f), i * 2 + f, 0, 16, 16)
    # lantern: off / lit a / lit b
    for f in range(3):
        im = Image.new('RGBA', (16, 16), T)
        d = ImageDraw.Draw(im)
        R(d, 7, 1, 8, 3, hexc('#5a4a3a'))
        R(d, 5, 4, 10, 5, hexc('#5a4a3a'))
        R(d, 5, 12, 10, 13, hexc('#5a4a3a'))
        R(d, 5, 6, 10, 11, hexc('#2a3a4a') if f == 0 else hexc('#ffd66b'))
        if f:
            R(d, 6, 7 + (f - 1), 9, 10, hexc('#fff3b0'))
            for i in range(3, 0, -1):
                d.ellipse([8 - 5 - i * 2, 8 - 5 - i * 2 + 2, 8 + 5 + i * 2, 8 + 5 + i * 2 + 2], fill=(255, 214, 107, 14 * (4 - i)))
        R(d, 5, 6, 5, 11, hexc('#5a4a3a'))
        R(d, 10, 6, 10, 11, hexc('#5a4a3a'))
        R(d, 7, 14, 8, 15, hexc('#5a4a3a'))
        put(S, outline(im), 6 + f, 0, 16, 16) if f < 2 else put(S, outline(im), 0, 1, 16, 16)
    # platform: a wooden raft 16x16 stretched by the game
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    R(d, 0, 4, 15, 10, hexc('#8a5a34'))
    R(d, 0, 4, 15, 5, hexc('#b07a48'))
    for x in (3, 7, 11):
        R(d, x, 5, x, 10, hexc('#5a3a20'))
    R(d, 0, 10, 15, 11, hexc('#4a2e18'))
    put(S, im, 1, 1, 16, 16)
    # hearts: full, lost
    for i, c in enumerate((hexc('#e24b4a'), hexc('#3a3f4d'))):
        im = Image.new('RGBA', (16, 16), T)
        d = ImageDraw.Draw(im)
        d.ellipse([1, 2, 8, 9], fill=c)
        d.ellipse([7, 2, 14, 9], fill=c)
        d.polygon([(1, 7), (14, 7), (8, 14)], fill=c)
        if i == 0:
            R(d, 3, 4, 4, 5, hexc('#ff9c9a'))
        put(S, outline(im), 2 + i, 1, 16, 16)
    # coin / shell
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    d.ellipse([3, 3, 12, 12], fill=hexc('#f2c94c'), outline=hexc('#8a6a12'))
    R(d, 7, 5, 8, 10, hexc('#8a6a12'))
    put(S, im, 4, 1, 16, 16)
    S.save(os.path.join(OUT, 'items.png'))


# ------------------------------------------------------------------ tiles (16x16)
def noise_tile(base, rnd, spots, n=10):
    im = Image.new('RGBA', (16, 16), base)
    d = ImageDraw.Draw(im)
    for _ in range(n):
        x, y = rnd.randint(0, 15), rnd.randint(0, 15)
        d.point((x, y), fill=rnd.choice(spots))
    return im


def make_tiles():
    S = sheet(8, 6, 16, 16)
    rnd = random.Random(7)
    BASE, DK, MID, LT, MOSS, MOSS2 = hexc('#3c4a5e'), hexc('#27323f'), hexc('#4d5f77'), hexc('#6b809c'), hexc('#3f8f6a'), hexc('#6bcf9a')
    # a seeded base the 16 neighbours variants all share, so joined tiles flow together
    def rock(m):
        up, right, down, left = m & 1, m & 2, m & 4, m & 8
        im = Image.new('RGBA', (16, 16), BASE)
        d = ImageDraw.Draw(im)
        rr = random.Random(99)
        for _ in range(26):
            x, y = rr.randint(0, 15), rr.randint(0, 15)
            d.point((x, y), fill=rr.choice((MID, DK, MID)))
        # brick cracks
        d.line([(0, 8), (15, 8)], fill=DK)
        d.line([(5, 0), (5, 7)], fill=DK)
        d.line([(11, 9), (11, 15)], fill=DK)
        # outlines where the neighbour is empty
        if not up:
            R(d, 0, 0, 15, 1, MOSS)
            R(d, 0, 2, 15, 2, MOSS2 if False else MOSS)
            for x in range(0, 16, 3):
                P(d, x, 3, MOSS)
                P(d, (x + 1) % 16, 0, MOSS2)
        if not down:
            R(d, 0, 14, 15, 15, DK)
        if not left:
            R(d, 0, 0, 1, 15, DK)
            R(d, 1, 2, 1, 14, MID)
        if not right:
            R(d, 14, 0, 15, 15, DK)
        if not up and not left:
            P(d, 0, 0, DK)
        if not up:
            R(d, 0, 0, 15, 0, MOSS2)
        return im
    for m in range(16):
        put(S, rock(m), m % 4, m // 4, 16, 16)
    # (cols 4..7, rows 0..3 free) one-way plank at (4,0)
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    R(d, 0, 0, 15, 5, hexc('#9a6a3e'))
    R(d, 0, 0, 15, 1, hexc('#c08a52'))
    R(d, 0, 5, 15, 6, hexc('#5a3a20'))
    for x in (4, 10):
        R(d, x, 2, x, 4, hexc('#6a4526'))
    P(d, 2, 3, hexc('#c8c8c8'))
    P(d, 13, 3, hexc('#c8c8c8'))
    put(S, im, 4, 0, 16, 16)
    # back wall planks at (5,0): the inside of the ship
    im = Image.new('RGBA', (16, 16), hexc('#4a3424'))
    d = ImageDraw.Draw(im)
    rr = random.Random(5)
    for y in (0, 5, 10):
        R(d, 0, y, 15, y, hexc('#2e2016'))
    for x, y0 in ((4, 0), (11, 6), (7, 11)):
        R(d, x, y0, x, y0 + 4, hexc('#2e2016'))
    for _ in range(14):
        P(d, rr.randint(0, 15), rr.randint(0, 15), hexc('#5c4330'))
    put(S, im, 5, 0, 16, 16)
    S.save(os.path.join(OUT, 'tiles.png'))


# ------------------------------------------------------------------ decorations (16px cells; placed as room art)
def make_deco():
    S = sheet(10, 4, 16, 16)

    def weed(h, seed, col, col2):
        im = Image.new('RGBA', (16, 16 * h), T)
        d = ImageDraw.Draw(im)
        rr = random.Random(seed)
        for k in range(3):
            x0 = 3 + k * 5
            pts = []
            for y in range(16 * h - 1, 2, -1):
                pts.append((x0 + math.sin(y * 0.3 + k) * 2, y))
            d.line(pts, fill=col, width=2)
            d.line([(a + 1, b) for a, b in pts[::2]], fill=col2, width=1)
        return im

    put(S, weed(2, 1, hexc('#2f8f5f'), hexc('#6bcf9a')).crop((0, 0, 16, 16)), 0, 0, 16, 16)
    put(S, weed(2, 1, hexc('#2f8f5f'), hexc('#6bcf9a')).crop((0, 16, 16, 32)), 0, 1, 16, 16)
    put(S, weed(2, 2, hexc('#3f6fbf'), hexc('#7fb0ff')).crop((0, 0, 16, 16)), 1, 0, 16, 16)
    put(S, weed(2, 2, hexc('#3f6fbf'), hexc('#7fb0ff')).crop((0, 16, 16, 32)), 1, 1, 16, 16)

    def coral(col, col2, seed):
        im = Image.new('RGBA', (32, 32), T)
        d = ImageDraw.Draw(im)
        rr = random.Random(seed)
        for x in (6, 12, 18, 24):
            h = rr.randint(10, 26)
            d.line([(x, 31), (x + rr.randint(-3, 3), 31 - h)], fill=col, width=3)
            tx = x + rr.randint(-3, 3)
            d.ellipse([tx - 2, 31 - h - 2, tx + 2, 31 - h + 2], fill=col2)
            if h > 16:
                bx = x + 4
                d.line([(x, 31 - h // 2), (bx, 31 - h // 2 - 7)], fill=col, width=2)
                d.ellipse([bx - 1, 31 - h // 2 - 9, bx + 2, 31 - h // 2 - 6], fill=col2)
        return outline(im, (20, 10, 40, 255))

    c1 = coral(hexc('#9a4fc8'), hexc('#d9a0ff'), 3)
    c2 = coral(hexc('#e8774a'), hexc('#ffc08a'), 4)
    S.paste(c1, (2 * 16, 0))
    S.paste(c2, (4 * 16, 0))
    # barrel, crate
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([3, 2, 12, 14], 3, fill=hexc('#8a5a34'))
    for y in (5, 11):
        R(d, 3, y, 12, y, hexc('#3a3a3a'))
    R(d, 5, 3, 5, 13, hexc('#a8723e'))
    put(S, outline(im), 6, 0, 16, 16)
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    R(d, 2, 3, 13, 14, hexc('#9a6a3e'))
    R(d, 2, 3, 13, 4, hexc('#c08a52'))
    d.line([(2, 3), (13, 14)], fill=hexc('#5a3a20'))
    d.line([(13, 3), (2, 14)], fill=hexc('#5a3a20'))
    R(d, 2, 13, 13, 14, hexc('#5a3a20'))
    put(S, outline(im), 7, 0, 16, 16)
    # anchor 2x2
    im = Image.new('RGBA', (32, 32), T)
    d = ImageDraw.Draw(im)
    iron = hexc('#5b6672')
    d.line([(16, 4), (16, 26)], fill=iron, width=3)
    d.ellipse([12, 1, 20, 8], outline=iron, width=2)
    d.line([(9, 9), (23, 9)], fill=iron, width=2)
    d.arc([5, 10, 27, 30], 20, 160, fill=iron, width=3)
    d.polygon([(5, 22), (9, 20), (8, 26)], fill=iron)
    d.polygon([(27, 22), (23, 20), (24, 26)], fill=iron)
    S.paste(outline(im), (0, 32))
    # chain 1x2 (hangs)
    im = Image.new('RGBA', (16, 32), T)
    d = ImageDraw.Draw(im)
    for y in range(0, 32, 5):
        d.ellipse([6, y, 10, y + 6], outline=hexc('#7b8794'), width=1)
    S.paste(im, (2 * 16, 32))
    # ship wheel 2x2
    im = Image.new('RGBA', (32, 32), T)
    d = ImageDraw.Draw(im)
    wood = hexc('#8a5a34')
    d.ellipse([4, 4, 27, 27], outline=wood, width=3)
    for a in range(0, 360, 45):
        d.line([(16, 16), (16 + math.cos(math.radians(a)) * 14, 16 + math.sin(math.radians(a)) * 14)], fill=wood, width=2)
    d.ellipse([12, 12, 20, 20], fill=hexc('#c08a52'))
    S.paste(outline(im), (3 * 16, 32))
    # glow anemone 1x1
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    for a in range(200, 341, 20):
        d.line([(8, 14), (8 + math.cos(math.radians(a)) * 6, 14 + math.sin(math.radians(a)) * 9)], fill=hexc('#7ff0ff'), width=1)
        P(d, int(8 + math.cos(math.radians(a)) * 6), int(14 + math.sin(math.radians(a)) * 9), hexc('#ffffff'))
    R(d, 5, 13, 11, 15, hexc('#2a8fa0'))
    put(S, im, 5, 2, 16, 16)
    # stalagmite 1x2
    im = Image.new('RGBA', (16, 32), T)
    d = ImageDraw.Draw(im)
    d.polygon([(1, 31), (7, 4), (9, 4), (15, 31)], fill=hexc('#323f52'), outline=hexc('#1c2430'))
    d.line([(7, 6), (5, 30)], fill=hexc('#4d5f77'))
    S.paste(im, (6 * 16, 32))
    # crab-claw statue 2x2
    im = Image.new('RGBA', (32, 32), T)
    d = ImageDraw.Draw(im)
    st = hexc('#59405a')
    d.rectangle([8, 24, 24, 31], fill=hexc('#3a2a3b'))
    d.polygon([(11, 24), (13, 8), (19, 8), (21, 24)], fill=st)
    d.ellipse([6, 0, 26, 14], fill=st)
    d.polygon([(16, 3), (24, 6), (16, 11)], fill=T)
    d.line([(14, 9), (23, 6)], fill=hexc('#3a2a3b'))
    S.paste(outline(im, (20, 10, 30, 255)), (8 * 16, 32))
    # sign board 1x1
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    R(d, 7, 8, 8, 15, hexc('#5a3a20'))
    R(d, 2, 2, 13, 9, hexc('#b07a48'))
    R(d, 2, 2, 13, 3, hexc('#d09a62'))
    for y in (5, 7):
        R(d, 4, y, 11, y, hexc('#5a3a20'))
    put(S, outline(im), 7, 2, 16, 16)
    # bones / shell 1x1
    im = Image.new('RGBA', (16, 16), T)
    d = ImageDraw.Draw(im)
    d.pieslice([2, 6, 13, 18], 180, 360, fill=hexc('#f0d8d0'))
    for a in (200, 230, 260, 290, 320):
        d.line([(7.5, 15), (7.5 + math.cos(math.radians(a)) * 6, 15 + math.sin(math.radians(a)) * 8)], fill=hexc('#d6b8b0'))
    put(S, outline(im), 5, 3, 16, 16)
    S.save(os.path.join(OUT, 'deco.png'))


# ------------------------------------------------------------------ backgrounds (320x180 pictures, scaled up by the game)
W, H = 320, 180


def grad(top, bot, w=W, h=H):
    im = Image.new('RGBA', (w, h))
    px = im.load()
    for y in range(h):
        c = mix(top, bot, y / (h - 1))
        for x in range(w):
            px[x, y] = c
    return im


def rays(im, col, n, rnd, strength=26):
    ov = Image.new('RGBA', im.size, T)
    d = ImageDraw.Draw(ov)
    for _ in range(n):
        x = rnd.randint(-20, im.width)
        w = rnd.randint(8, 28)
        d.polygon([(x, 0), (x + w, 0), (x + w + 50, im.height), (x + 30, im.height)], fill=col[:3] + (strength,))
    ov = ov.filter(ImageFilter.GaussianBlur(3))
    return Image.alpha_composite(im, ov)


def far_layer(top, bot, ray, seed, extra=None):
    rnd = random.Random(seed)
    im = grad(hexc(top), hexc(bot))
    im = rays(im, hexc(ray), 7, rnd)
    if extra:
        extra(im, rnd)
    return im


def silhouette(col, seed, kind, alpha=255, base=H, h0=70, w=W):
    im = Image.new('RGBA', (w, H), T)
    d = ImageDraw.Draw(im)
    rnd = random.Random(seed)
    c = hexc(col, alpha)
    if kind == 'ship':  # broken ship ribs and masts
        for x in range(10, w, 55):
            hh = rnd.randint(50, 110)
            d.polygon([(x, base), (x + 4, base - hh), (x + 10, base - hh + 6), (x + 14, base)], fill=c)
            if rnd.random() < 0.5:
                d.line([(x + 6, base - hh + 10), (x + 40, base - hh + 30)], fill=c, width=2)
        d.rectangle([0, base - 18, w, base], fill=c)
        d.polygon([(w * 0.55, base - 18), (w * 0.62, base - 70), (w * 0.9, base - 40), (w * 0.95, base - 18)], fill=c)
    elif kind == 'coral':
        x = 0
        while x < w:
            hh = rnd.randint(25, 95)
            ww = rnd.randint(10, 26)
            d.rounded_rectangle([x, base - hh, x + ww, base], 5, fill=c)
            if rnd.random() < 0.6:
                d.rounded_rectangle([x + ww - 4, base - hh * 0.6, x + ww + 12, base - hh * 0.6 + 8], 3, fill=c)
            x += ww + rnd.randint(-4, 12)
    elif kind == 'rock':
        pts = [(0, base)]
        x = 0
        while x < w:
            x += rnd.randint(14, 34)
            pts.append((x, base - rnd.randint(20, 110)))
            x += rnd.randint(4, 16)
            pts.append((x, base - rnd.randint(0, 30)))
        pts.append((w, base))
        d.polygon(pts, fill=c)
    elif kind == 'weed':
        for x in range(4, w, 11):
            hh = rnd.randint(35, 100)
            pts = [(x + math.sin(y * 0.1 + x) * 4, base - y) for y in range(0, hh, 2)]
            d.line(pts, fill=c, width=3)
    elif kind == 'claws':  # giant claws and pillars for the lair
        for x in range(12, w, 70):
            hh = rnd.randint(80, 140)
            d.rectangle([x, base - hh, x + 18, base], fill=c)
            d.ellipse([x - 14, base - hh - 20, x + 32, base - hh + 18], fill=c)
            d.polygon([(x + 9, base - hh - 14), (x + 38, base - hh - 2), (x + 9, base - hh + 8)], fill=T)
    return im


def bubble_tile(seed, col=(190, 225, 255), n=26):
    sz = 128
    im = Image.new('RGBA', (sz, sz), T)
    d = ImageDraw.Draw(im)
    rnd = random.Random(seed)
    for _ in range(n):
        x, y, r = rnd.randint(0, sz - 1), rnd.randint(0, sz - 1), rnd.choice((1, 1, 2, 2, 3))
        for ox in (-sz, 0, sz):
            for oy in (-sz, 0, sz):
                d.ellipse([x + ox - r, y + oy - r, x + ox + r, y + oy + r], outline=col + (150,))
                P(d, x + ox - r // 2, y + oy - r // 2, col + (230,))
    return im


def make_backgrounds():
    def ship_extra(im, rnd):
        # a far away wreck in the haze
        im.alpha_composite(silhouette('#16405a', 11, 'ship', 150, base=H - 4, w=W), (0, 0))

    far = {
        'wreck': far_layer('#1c5a7a', '#0c2b40', '#9fe8ff', 1, ship_extra),
        'reef': far_layer('#1a5a66', '#0b2a3a', '#b8f0e0', 2),
        'shaft': far_layer('#0c2236', '#050d17', '#4a8fd0', 3),
        'lair': far_layer('#2a1530', '#0b0710', '#c84a6a', 4),
    }
    mid = {
        'wreck': silhouette('#14425f', 21, 'ship', 240),
        'reef': silhouette('#2e2a6b', 22, 'coral', 220),
        'shaft': silhouette('#0f2a44', 23, 'rock', 230),
        'lair': silhouette('#3a1d44', 24, 'claws', 230),
    }
    near = {
        'wreck': silhouette('#08243a', 31, 'weed', 255, h0=60),
        'reef': silhouette('#13204a', 32, 'weed', 255),
        'shaft': silhouette('#071a2e', 33, 'rock', 255),
        'lair': silhouette('#1b0d22', 34, 'rock', 255),
    }
    for k in far:
        far[k].save(os.path.join(OUT, 'bg-%s-far.png' % k))
        mid[k].save(os.path.join(OUT, 'bg-%s-mid.png' % k))
        near[k].save(os.path.join(OUT, 'bg-%s-near.png' % k))
    bubble_tile(1).save(os.path.join(OUT, 'bg-bubbles.png'))
    bubble_tile(2, (255, 200, 210), 14).save(os.path.join(OUT, 'bg-embers.png'))


# ------------------------------------------------------------------ title screen
def make_title():
    im = grad(hexc('#10405e'), hexc('#06121e'), 480, 270)
    rnd = random.Random(8)
    im = rays(im, hexc('#9fe8ff'), 9, rnd, 30)
    # a sinking ship silhouette and a diver
    sil = silhouette('#07202f', 9, 'ship', 255, base=268, w=320).resize((480, 270), Image.NEAREST)
    im = Image.alpha_composite(im, sil)
    im = Image.alpha_composite(im, silhouette('#041018', 12, 'weed', 255, base=180, w=320).resize((480, 270), Image.NEAREST))
    im.save(os.path.join(OUT, 'title.png'))
    # logo
    lw, lh = 360, 90
    logo = Image.new('RGBA', (lw, lh), T)
    d = ImageDraw.Draw(logo)
    try:
        f = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 46)
        f2 = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 14)
    except Exception:
        f = f2 = ImageFont.load_default()
    for dx, dy in ((3, 3), (2, 2)):
        d.text((lw // 2 + dx, 34 + dy), 'TIDEBOUND', font=f, fill=hexc('#06121e'), anchor='mm')
    d.text((lw // 2, 34), 'TIDEBOUND', font=f, fill=hexc('#e8fbff'), anchor='mm')
    d.text((lw // 2, 80), 'A METROIDVANIA ENGINE SHOWCASE', font=f2, fill=hexc('#5dcaa5'), anchor='mm')
    logo.save(os.path.join(OUT, 'logo.png'))


if __name__ == '__main__':
    make_player(); make_crab(); make_eel(); make_puffer(); make_urchin(); make_boss(); make_items(); make_tiles(); make_deco(); make_backgrounds(); make_title()
    print('wrote', len(os.listdir(OUT)), 'pictures to', OUT)
