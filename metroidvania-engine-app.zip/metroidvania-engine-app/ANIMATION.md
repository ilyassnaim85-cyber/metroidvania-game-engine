# Animation Studio and the animation API

Reusable 2D sprite animation clips. Make them in the editor (the **Animations** tab), save them with the project, share them as
JSON files, and play them from game code with `engine/animation.js`.

## Using the Animation Studio

1. Open the **Animations** tab and click **New clip**.
2. **Import a sprite sheet** (PNG, GIF, WebP or JPEG; an Aseprite sheet export works). Set **Frame width / height** to the size of
   one frame. Sheets are shared with the rest of the project (rooms, bosses, the player sprite).
3. **Add frames in playback order.** Click a cell in the sheet to add that frame to the end of the clip. Drag over several cells to add
   them in reading order (left to right, then down); empty cells are skipped unless you turn that off. You can mix frames from
   different sheets in one clip. "New frame length" sets the length of frames you add.
4. **Reorder on the timeline.** Each frame is a box whose width follows its length. Drag a frame to move it, or use Move left / Move
   right. Delete (button or key) removes the selected frame, Duplicate copies it.
5. **Per-frame settings.** Select a frame to set its **Length (ms)** and an **Event marker**, a name that fires when that frame
   starts (for example `footstep` or `hit`). A flag on the timeline shows frames with events. "Same length for all frames" copies the
   selected frame's length to every frame.
6. **Playback**: **Loop** repeats forever. **Play once** stops on the last frame. **Ping pong** plays forward then backward, without
   repeating the end frames (frames 1 2 3 4 play 1 2 3 4 3 2 1 2 3 ...), forever. **Default speed** is stored with the clip.
7. **Pivot**: the point the clip is placed, scaled and flipped around. Type X/Y (0 to 1 across the frame, bottom centre is 0.5, 1) or
   drag the marker in the preview, or use a preset.
8. **Preview**: Play/Pause, Restart, Step back / forward (one frame), and a Preview speed slider (0.1x to 4x). Preview speed is not
   saved. The red line on the timeline shows the playhead and fired events are listed beside the preview.

Clips are saved with the project, are included in undo and redo (Ctrl+Z / Ctrl+Y), and are part of the project JSON.

### Sharing clips (JSON)
- **Export clip** writes one clip. **Export library** writes every clip. Both include the sprite sheet images, so the file is
  self-contained and can be imported into another project.
- **Import...** reads a clip file, a library file, or a whole project file. Sheets that already exist (same image) are reused; ids and
  clip names that clash are renamed ("Run" becomes "Run 2"); frames whose sheet is missing from the file are dropped.

## JSON format

Clip file (`mv-animation-clip`) and library file (`mv-animation-library`):

```json
{
  "type": "mv-animation-library",
  "version": 1,
  "clips": [
    {
      "id": "run",
      "name": "Run",
      "mode": "pingpong",
      "speed": 1,
      "pivot": { "x": 0.5, "y": 1 },
      "frames": [
        { "sheet": "s1", "col": 0, "row": 0, "dur": 80, "event": "" },
        { "sheet": "s1", "col": 1, "row": 0, "dur": 80, "event": "footstep" }
      ]
    }
  ],
  "sheets": [
    { "id": "s1", "name": "hero.png", "url": "data:image/png;base64,....", "tw": 16, "th": 24 }
  ]
}
```
A clip file has `"clip": { ... }` instead of `"clips": [ ... ]`.

- `mode`: `loop`, `once` or `pingpong`. `speed`: 0.1 to 4. `pivot`: fractions of the frame size.
- A frame is the cell (`col`, `row`) of sheet `sheet`, `dur` is **milliseconds** (10 to 10000), `event` is an optional name.
- A sheet is a PNG/GIF/WebP/JPEG as a `data:` URL plus the frame size `tw` x `th` in pixels. The source rectangle of a frame is
  `(col*tw, row*th, tw, th)`.
- Limits: 100 clips, 256 frames per clip, 60 sheets per file. Invalid values are clamped when a file is read.

## Runtime API (`engine/animation.js`)

No dependencies. In a page: `<script src="engine/animation.js"></script>` gives `MV.Anim`. In Node: `require('./engine/animation.js')`.
**Frame lengths in clip data are milliseconds; every time you pass to or get from the API is seconds.**

### Load a library and play a clip

```js
const lib = new MV.Anim.Library(jsonObject);      // a clip file, a library file, or a project file
await lib.ready;                                   // sprite sheet images have loaded
const hero = lib.player('Run', { onEvent: (name, e) => console.log(name, e.time) });

function frame(dt, ctx, x, y) {                    // dt in seconds
  hero.update(dt);                                 // advances time, fires events
  hero.draw(ctx, null, x, y, { scale: 3, flipX: facingLeft });   // (x, y) is where the pivot goes
}
hero.play('Idle');                                 // switch clips by name or id (restarts)
hero.play('Run', { restart: false });              // no-op if Run is already playing
```

### Player (`MV.Anim.createPlayer(clip, options)`)
| Member | Meaning |
| --- | --- |
| `clip` | the clip being played |
| `t` | clip time in seconds |
| `speed` | playback speed multiplier (multiplies the clip's own `speed`) |
| `paused`, `done` | `done` becomes true when a "once" clip has finished |
| `onEvent(name, info)` | called for each event marker crossed; `info = { name, frame, time }` |
| `update(dt)` | advance by `dt` seconds |
| `play(clipOrNameOrId, { restart })`, `reset()` | switch or restart |
| `sample()` | the current `{ index, frame, time, cycle, done }` |
| `draw(ctx, sheets, x, y, options)` | draw the current frame (see below) |

Options for `createPlayer`: `onEvent`, `library` (so `play('name')` works).

### Functions
- `MV.Anim.sample(clip, t)` returns the frame showing at time `t` (seconds of clip time): `{ index, frame, time, cycle, done }`.
  `index` is the frame's position in `clip.frames`, `time` is the time inside the current cycle, `done` is true once a "once" clip ended.
- `MV.Anim.events(clip, t0, t1)` returns the events whose frame starts in `(t0, t1]`, in order, as `{ name, frame, time }`.
  Use `t0 = -1e-9` to include an event on the first frame at time 0.
- `MV.Anim.draw(ctx, clip, sample, sheets, x, y, options)` draws a sample. `sheets` is a function `id => { img, tw, th }` or an object
  keyed by sheet id. Options: `scale` (default 1), `flipX`, `flipY`, `alpha`, `smooth` (default off, for crisp pixels). Returns `false`
  if the image is not loaded yet. Flipping mirrors around the pivot.
- `MV.Anim.compile(clip)` precomputes the playback order if you sample the same clip many times.
- `MV.Anim.clean(clip)`, `MV.Anim.list(clips)`: validate and clamp data you build by hand.
- `MV.Anim.exportClip(project, idOrName)`, `exportLibrary(project)`, `parse(json)`, `importInto(project, json)`: the JSON functions
  the editor uses. `project` is any object with `sheets` and `anims` arrays.
- `MV.Anim.loadImages(sheets)` returns `{ map, ready }`: images by sheet id.

### Without the library (any engine or language)
The data is plain JSON, so other engines can read it. To sample a clip at time `t`: build the play order (`loop` and `once`: frames in
order; `pingpong`: frames in order, then back from the second-to-last to the second); the cycle length is the sum of the order's `dur`
values; for `loop` and `pingpong` use `t mod cycle`; for `once` clamp `t` to the cycle and the last frame is final. Pick the frame whose
start (running sum of `dur`) is at or before the time. Draw the rectangle `(col*tw, row*th, tw, th)` of the sheet with the pivot at your
position.

## Compatibility
Projects without animations load unchanged (an empty list). The player sprite, boss and move animations are separate and keep working.
