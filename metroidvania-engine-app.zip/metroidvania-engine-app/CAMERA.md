# Camera system

The camera has two layers. Keep them apart when you read the code.

| Layer | File | Job |
|---|---|---|
| Solver | `engine/camera.js` (`MV.Camera`) | Smooth follow, dead zone, look-ahead, peek, ledge hint, room bounds, profiles. It knows nothing about zoom, effects or input. |
| Rig | `engine/camera_rig.js` (`MV.CameraRig`) | Wraps the solver. Adds modes, targets and framing, lock-on, zoom, tilt, shake, recoil, fades, transitions, overrides, rails, cutscenes, manual pan, free camera and player settings. It never draws gameplay and never reads gameplay state except through `bind()`. |

`engine/game.js` owns one rig (`G.cam`), feeds it once per frame and draws with `rig.view()`. Gameplay code never touches the rig directly; it uses `MV.Game.camera`.

```js
const cam = MV.Game.camera;
cam.zoomTo(1.4, { time: .6 });
cam.shake({ amount: .3, time: .4 });
```

Every call is a no-op when no game is running, so scripts can call it safely.

## Data-driven settings

* **Profiles** (Player > Camera) are sets of settings picked by a room, a Camera zone or `cam.set(id)`. The new fields are in `MV.data.camExtra` (data/config.js): `view`, `zoom`, `zoomSpeed`, `rot`, `edge`, `softPad`, `manualPan`, `panRange`, `bossFrame`, `framePad`, `frameMin`, `doorFx`, `doorTime`, `roomFade`.
* **Player settings** (`MV.data.camUser`) are what an options menu changes: sensitivity, stick dead zone, invert X/Y, mouse, zoom multiplier, smoothing, shake strength, flashes, reduce motion. They are saved in the browser (localStorage key `mv.camera.settings`), not in the map.
* **Keys** (`MV.data.camKeys`): pan `J I K L`, free camera `WASD` or arrows, zoom `+` and `-`, reset `Backspace`. Gamepad: right stick pans, triggers zoom, right-stick click resets. Mouse: wheel zooms, middle-button drag pans (only while panning is on).

## Modes

`cam.mode(name)` returns the mode now in use, or `false` with `cam.status().unsupported` explaining why.

| Mode | What it does |
|---|---|
| `follow` | The profile decides (default). |
| `side` | Side-scrolling, Hollow Knight style: holds the height of your last floor. |
| `topdown` | Leans the way you move on both axes. |
| `fixed` | Does not move. |
| `free` | You steer it (see Free camera). |
| `isometric`, `firstperson` | **Not supported.** The renderer is a flat 2D tile view. `mode()` returns false and says so. |

Add your own with `MV.CameraRig.registerMode(name, { label, p, look2d, cin })`.

## API

**Targets and framing**
* `target(spec, { blend })`: follow something other than the player. `spec` is `{x, y}`, an entity, an entity uid, a function returning a point, or `'player'`.
* `addTarget(spec, weight)` returns an id; `removeTarget(idOrSpec)`; `clearTargets()`.
* `frame(on, { pad, min, max, zoomIn })`: keep the player and all added targets in view, zooming out as needed (never past `min`).
* `bossFrame(on, { pad, min })`: same, with every awake boss.
* `lockOn(spec | { type: 'enemy', range }, { weight, maxDist, release: 'manual', frame })`, `unlock()`, `lockNext(dir)`.

A target that disappears (dead, room left) is dropped and the camera glides back to the player.

**Manual control**
* `manualPan(on)`, `pan(dx, dy)` (tiles), `free(on, { speed, bounds, lockInput })`.
* `settings(patch)` reads or changes player settings; `resetSettings()`.

**Effects** (all frame-rate independent, all clamped)
* `shake(0.4)` (old call) or `shake({ amount, time, freq, roll, dir, curve, power, id })`; `stopShake(id)`.
* `recoil(dx, dy, strength)`: a kick that springs back.
* `zoomTo(z, { time, ease, hold, returnTime })`, `zoomReset(time)`, `zoomPunch(amount, time)` (amount 0.1 is about 10%).
* `rotateTo(deg, opts)`, `rotatePunch(deg, time)`.
* `fade(color, to, time)`, `fadeOut(time, color)`, `fadeIn(time)`, `flash(color, time, alpha)`.
* `transition('fade' | 'wipe' | 'iris', time, onMid, { color })`: `onMid` runs once, at the covered halfway point. A profile with `doorFx` uses this for doors.

Easing names: `linear easeIn easeOut easeInOut smooth smoother sine overshoot bounce`, a CSS-style `[x1, y1, x2, y2]` bezier, or your own function. Register a name with `MV.CameraRig` instances' `curves.register(name, fn)`.

**Overrides** (temporary, stackable)
* `override({ id, priority, mode, target, zoom, rot, offset, profile, p, bounds, frame, lockInput, blend, ttl, scope, onEnd })` returns an id. Higher priority wins on conflicts; equal priority, the newest wins. Overrides blend in and out over `blend` seconds. `ttl` ends it by itself; `scope: 'room'` ends it on room change.
* `endOverride(id, blend)`, `overrides()`.

**Rails and cutscenes**
* `rail([{x, y, zoom?, rot?}, ...], { time | speed, ease, loop, smooth, hold, lockInput, onDone })`, `stopRail(id)`.
* `cutscene([{ pan, dur, ease, zoom, rot, shake, recoil, fade, flash, lock, unlock, call, wait, parallel }, ...], { lockInput, onDone })`, `skipCutscene()`, `endCutscene()`. While input is locked the player stands still and keys are ignored.

**Queries**: `status()`, `toScreen(wx, wy, cw, ch, z)`, `toWorld(sx, sy, cw, ch, z)`, `rig()` (the rig itself, for tools).

## Events tab

The Events tab has camera actions that need no code: change profile, zoom, tilt, fade or flash, look at a spot for a while, shake.

## Robustness rules

* `update` clamps `dt` (so a stall never throws the view), and every number goes through a finite check; NaN or Infinity never reach the canvas.
* A room change calls `sceneChange()`: room-scoped overrides end, effects clear, the view snaps to the new room, dead targets are dropped.
* A window or resolution change calls `resize()` so the view snaps instead of gliding.
* Zoom out is limited so the view never shows past the room while room limits are on.
* Reduce motion turns off shake, tilt and zoom effects, and `flashes: false` removes flashes.
* Rooms with darkness ignore tilt (the light mask is axis-aligned); zoom works there.

## Assumptions and limits

* Isometric and first-person need a different renderer and are not supported.
* Backgrounds and foreground background layers are drawn at normal scale while zoomed; only the tile world and entities zoom and tilt.
* The HUD is never zoomed or tilted.
* Mouse drag uses the middle button so it never fights the game's clicks.
