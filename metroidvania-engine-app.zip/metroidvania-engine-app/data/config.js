// Designer-editable game data. No engine code changes needed to tune these values.
window.MV = window.MV || {};
MV.data = {
  version: 1,
  // Fixed body size (tiles). Movement tuning lives in playerSchema below.
  player: { w: 0.7, h: 1.5 },
  // Editable movement tuning: def = default, min/max = allowed range. The editor builds its
  // "Player movement" form from this list, and values outside the range are clamped.
  playerSchema: {
    w: {
      group: 'Body',
      label: 'Player width',
      unit: 'tiles',
      def: 0.7,
      min: 0.3,
      max: 3,
      step: 0.05,
      help: 'How wide the player is for walls, enemies and hits. Your sprite is drawn separately.'
    },
    h: {
      group: 'Body',
      label: 'Player height',
      unit: 'tiles',
      def: 1.5,
      min: 0.5,
      max: 4,
      step: 0.05,
      help: 'How tall the player is. Low ceilings, crawl gaps and the camera height use this.'
    },
    run: {
      group: 'Movement',
      label: 'Max run speed',
      unit: 'tiles/s',
      def: 8,
      min: 1,
      max: 20,
      step: 0.5,
      help: 'Top horizontal speed.'
    },
    accel: {
      group: 'Movement',
      label: 'Acceleration',
      unit: 'tiles/s²',
      def: 80,
      min: 5,
      max: 400,
      step: 5,
      help: 'How fast you speed up on the ground.'
    },
    decel: {
      group: 'Movement',
      label: 'Deceleration',
      unit: 'tiles/s²',
      def: 90,
      min: 5,
      max: 400,
      step: 5,
      help: 'How fast you slow down when you let go.'
    },
    airControl: {
      group: 'Movement',
      label: 'Air control',
      unit: '0 to 1',
      def: 0.7,
      min: 0,
      max: 1,
      step: 0.05,
      help: '0 = no steering in the air, 1 = same as the ground.'
    },
    jumpHeight: {
      group: 'Jump',
      label: 'Jump height',
      unit: 'tiles',
      def: 3,
      min: 0.5,
      max: 8,
      step: 0.1,
      help: 'Height of a full jump. Speed is worked out from gravity.'
    },
    airTime: {
      group: 'Jump',
      label: 'Air time of a full jump',
      unit: 's',
      def: 0,
      min: 0,
      max: 3,
      step: 0.05,
      help: 'How many seconds a full jump lasts, up and back down to the same height. 0 = off (Gravity decides). When set, Gravity is worked out from Jump height and this time, so a short air time feels snappy and a long one floaty.'
    },
    gravity: {
      group: 'Jump',
      label: 'Gravity',
      unit: 'tiles/s²',
      def: 55,
      min: 10,
      max: 150,
      step: 1,
      help: 'Higher feels snappier. Ignored while Air time is set.'
    },
    maxFall: {
      group: 'Jump',
      label: 'Max fall speed',
      unit: 'tiles/s',
      def: 28,
      min: 5,
      max: 80,
      step: 1,
      help: 'Terminal velocity when falling.'
    },
    jumpCut: {
      group: 'Jump',
      label: 'Short hop cut',
      unit: '0.1 to 1',
      def: 0.5,
      min: 0.1,
      max: 1,
      step: 0.05,
      help: 'Upward speed kept when you release jump early. 1 = no short hop.'
    },
    coyote: {
      group: 'Jump',
      label: 'Coyote time',
      unit: 's',
      def: 0.1,
      min: 0,
      max: 0.4,
      step: 0.01,
      help: 'Grace time to jump after leaving a ledge.'
    },
    buffer: {
      group: 'Jump',
      label: 'Jump buffer',
      unit: 's',
      def: 0.12,
      min: 0,
      max: 0.4,
      step: 0.01,
      help: 'A jump pressed this early before landing still counts.'
    },
    attackTime: {
      group: 'Attack',
      hide: true,
      label: 'Swing time',
      unit: 's',
      def: 0.18,
      min: 0.05,
      max: 1,
      step: 0.01,
      help: 'How long the attack hits.'
    },
    attackCooldown: {
      group: 'Attack',
      hide: true,
      label: 'Attack cooldown',
      unit: 's',
      def: 0.1,
      min: 0,
      max: 1,
      step: 0.01,
      help: 'Pause after a swing before the next one.'
    },
    attackReach: {
      group: 'Attack',
      hide: true,
      label: 'Attack reach',
      unit: 'tiles',
      def: 1.3,
      min: 0.5,
      max: 4,
      step: 0.1,
      help: 'How far in front of you the attack reaches.'
    },
    maxHp: {
      group: 'Health',
      label: 'Health',
      unit: 'hits',
      def: 5,
      min: 1,
      max: 30,
      step: 1,
      help: 'How many hits you can take before you die. Interactive checkpoints heal you fully.'
    },
    invTime: {
      group: 'Health',
      label: 'Invisibility time',
      unit: 's',
      def: 1,
      min: 0,
      max: 5,
      step: 0.05,
      help: 'After a hit you cannot be hurt for this long, and the player blinks. 0 = no protection.'
    },
    oxygen: {
      group: 'Water',
      label: 'Air under water',
      unit: 's',
      def: 0,
      min: 0,
      max: 300,
      step: 1,
      help: 'How long you can stay with your head under water before you start to drown. 0 = unlimited air (no drowning). A bar shows above you when the air is going. Pick up the ability "waterBreath" and you never run out.'
    },
    airRefill: {
      group: 'Water',
      label: 'Air refill speed',
      unit: 'x',
      def: 4,
      min: 0.5,
      max: 20,
      step: 0.5,
      help: 'How fast the air comes back when your head is above water or inside an Air pocket, compared with how fast it runs out.'
    },
    drownEvery: {
      group: 'Water',
      label: 'Drowning damage every',
      unit: 's',
      def: 2,
      min: 0.2,
      max: 10,
      step: 0.1,
      help: 'Once the air has run out you lose health this often until you reach air.'
    },
    drownDmg: {
      group: 'Water',
      label: 'Drowning damage',
      unit: 'hits',
      def: 1,
      min: 1,
      max: 30,
      step: 1,
      help: 'Health lost each time.'
    },
    knockback: {
      group: 'Damage',
      hide: true,
      label: 'Knockback',
      unit: 'tiles/s',
      def: 6,
      min: 0,
      max: 20,
      step: 0.5,
      help: 'How hard enemies and bosses push you away when they hit you.'
    },
    stun: {
      group: 'Damage',
      hide: true,
      label: 'Stun time',
      unit: 's',
      def: 0.2,
      min: 0,
      max: 1,
      step: 0.05,
      help: 'You cannot steer for this long after a hit while the knockback plays.'
    },
    contactDamage: {
      group: 'Damage',
      hide: true,
      label: 'Enemy and boss damage',
      unit: 'hits',
      def: 1,
      min: 0,
      max: 30,
      step: 1,
      help: 'Health lost when an enemy, a boss or a boss attack hits you.'
    },
    hazardDamage: {
      group: 'Damage',
      hide: true,
      label: 'Hazard damage',
      unit: 'hits',
      def: 1,
      min: 0,
      max: 30,
      step: 1,
      help: 'Health lost on spikes and hazards. After a hazard hit you are put back at the last checkpoint you touched in this room (the ones that are not interactive), or where you came into the room.'
    },
    energyMax: {
      group: 'Energy',
      label: 'Energy (mana, soul, focus) maximum',
      unit: 'points',
      def: 0,
      min: 0,
      max: 200,
      step: 1,
      help: 'A second bar next to health that moves and attacks can spend. 0 = no energy bar at all. Give a move or attack a Cost in the Moves and Attacks tabs.'
    },
    energyRegen: {
      group: 'Energy',
      label: 'Energy regrows by itself',
      unit: 'points/s',
      def: 0,
      min: 0,
      max: 50,
      step: 0.5,
      help: 'How fast the bar fills when you are not spending. 0 = it only fills from hits you land, pickups and events.'
    },
    energyDelay: {
      group: 'Energy',
      label: 'Regrow pause after spending',
      unit: 's',
      def: 1,
      min: 0,
      max: 10,
      step: 0.1,
      help: 'After you spend energy it waits this long before it starts regrowing.'
    },
    energyPerHit: {
      group: 'Energy',
      label: 'Energy gained per hit you land',
      unit: 'points',
      def: 0,
      min: 0,
      max: 50,
      step: 0.5,
      help: 'Every time one of your attacks or moves hits something you gain this much. This is how a soul or focus loop is made: hit enemies, fill the bar, spend it on a heal or a spell.'
    },
    charmSlots: {
      group: 'Charms',
      label: 'Charm notches at the start',
      unit: 'notches',
      def: 0,
      min: 0,
      max: 20,
      step: 1,
      help: 'How many notches your equipped charms can use up together. Items with the use "Charm" (Items tab) cost notches. More notches come from upgrade pickups.'
    },
    respawnHp: {
      group: 'Death',
      label: 'Health after you die',
      unit: '% of max',
      def: 100,
      min: 1,
      max: 100,
      step: 1,
      help: '100 = you come back with full health.'
    },
    respawnEnergy: {
      group: 'Death',
      label: 'Energy after you die',
      unit: '% of max',
      def: 100,
      min: 0,
      max: 100,
      step: 1,
      help: 'How much of the energy bar you keep when you respawn. 0 = you come back empty.'
    },
    coinsLost: {
      group: 'Death',
      label: 'Coins lost when you die',
      unit: '%',
      def: 0,
      min: 0,
      max: 100,
      step: 5,
      help: 'The share of your coins you drop where you died.'
    },
    coinsRecover: {
      group: 'Death',
      label: 'Dropped coins can be picked up again',
      unit: '0 or 1',
      def: 1,
      min: 0,
      max: 1,
      step: 1,
      help: '1 = a glowing bag stays where you died (in that room) and gives the coins back when you touch it. 0 = they are gone. Only matters when Coins lost is above 0.'
    },
    deathScreen: {
      group: 'Death',
      label: 'You died screen',
      unit: 's',
      def: 0,
      min: 0,
      max: 6,
      step: 0.1,
      help: 'After the death animation the screen fades to black and says YOU DIED for this long, then you respawn. 0 = no screen, you respawn at once.'
    },
    camDelay: {
      group: 'Camera',
      label: 'Follow delay',
      unit: 's',
      def: 0,
      min: 0,
      max: 1.5,
      step: 0.05,
      help: 'After you leave the dead zone the camera waits this long before it starts following. 0 = no delay.'
    },
    camDeadX: {
      group: 'Camera',
      label: 'Dead zone, sideways',
      unit: 'tiles',
      def: 0,
      min: 0,
      max: 8,
      step: 0.25,
      help: 'You can move this far left or right of the screen centre before the camera moves.'
    },
    camDeadY: {
      group: 'Camera',
      label: 'Dead zone, up and down',
      unit: 'tiles',
      def: 0,
      min: 0,
      max: 5,
      step: 0.25,
      help: 'Same, vertically. A taller zone stops the camera bobbing on every jump.'
    },
    camSmoothX: {
      group: 'Camera',
      label: 'Horizontal smoothing',
      unit: '0.02 to 1',
      def: 0.1,
      min: 0.02,
      max: 1,
      step: 0.01,
      help: '0.02 = very lazy, 1 = locked to you. A room can override this in Level Settings.'
    },
    camSmoothY: {
      group: 'Camera',
      label: 'Vertical smoothing',
      unit: '0.02 to 1',
      def: 0.08,
      min: 0.02,
      max: 1,
      step: 0.01,
      help: 'Same, vertically.'
    },
    camLookAhead: {
      group: 'Camera',
      label: 'Look ahead',
      unit: 'tiles',
      def: 2,
      min: 0,
      max: 8,
      step: 0.25,
      help: 'The view leans this far toward the way you are facing, so you see more of what is coming.'
    },
    camLookSpeed: {
      group: 'Camera',
      label: 'Look-ahead speed',
      unit: '0.01 to 1',
      def: 0.04,
      min: 0.01,
      max: 1,
      step: 0.01,
      help: 'How quickly the view swings to the other side when you turn around.'
    },
    camFallLook: {
      group: 'Camera',
      label: 'Look down when falling',
      unit: 'tiles',
      def: 2.5,
      min: 0,
      max: 6,
      step: 0.25,
      help: 'How far the view slides down while you fall. It grows smoothly with your fall speed: nothing below "Speed where it starts", the full amount at "Speed for the full amount".'
    },
    camRiseLook: {
      group: 'Camera',
      label: 'Look up when rising',
      unit: 'tiles',
      def: 0,
      min: 0,
      max: 6,
      step: 0.25,
      help: 'The same for rising (jumps, springs, launches): the view slides up with your upward speed.'
    },
    camVelStart: {
      group: 'Camera',
      label: 'Speed where it starts',
      unit: 'tiles/s',
      def: 12,
      min: 0,
      max: 60,
      step: 0.5,
      help: 'Vertical speed below which the rise and fall look does nothing.'
    },
    camVelMax: {
      group: 'Camera',
      label: 'Speed for the full amount',
      unit: 'tiles/s',
      def: 28,
      min: 2,
      max: 80,
      step: 0.5,
      help: 'Vertical speed at which the full look amount is reached. In between it is smooth (eased).'
    },
    camVelSmooth: {
      group: 'Camera',
      label: 'Vertical smoothing at top speed',
      unit: '0 to 1',
      def: 0,
      min: 0,
      max: 1,
      step: 0.01,
      help: 'The vertical smoothing used when you move at the full speed above, so the camera catches up faster in a long fall. In between it is blended with the normal vertical smoothing. 0 = do not change it.'
    },
    camLookDelay: {
      group: 'Camera',
      label: 'Direction bias delay',
      unit: 's',
      def: 0.15,
      min: 0,
      max: 1,
      step: 0.01,
      help: 'You must move the other way this long before the look-ahead swings to the other side. Stops the view shaking when you tap back and forth.'
    },
    camLookRamp: {
      group: 'Camera',
      label: 'Bias grows with speed',
      unit: '0 to 1',
      def: 0,
      min: 0,
      max: 1,
      step: 0.05,
      help: '0 = the look-ahead is always the full amount. 1 = it is zero when you stand still and full at run speed.'
    },
    camPeek: {
      group: 'Camera',
      label: 'Look up and down (hold the key)',
      unit: 'tiles',
      def: 4,
      min: 0,
      max: 8,
      step: 0.25,
      help: 'While you stand still, holding Up or Down for a moment slides the view that far up or down so you can see above or below you. 0 = off.'
    },
    camPeekDelay: {
      group: 'Camera',
      label: 'Look up and down delay',
      unit: 's',
      def: 0.5,
      min: 0,
      max: 2,
      step: 0.05,
      help: 'How long Up or Down must be held before the view moves.'
    },
    camLedgeLook: {
      group: 'Camera',
      label: 'Ledge hint: look down',
      unit: 'tiles',
      def: 2.5,
      min: 0,
      max: 8,
      step: 0.25,
      help: 'When you stand at the edge of a drop (the way you face or push) the view slides down this far, to show the player that they can fall down here. 0 = off.'
    },
    camLedgeDelay: {
      group: 'Camera',
      label: 'Ledge hint: wait',
      unit: 's',
      def: 0.5,
      min: 0,
      max: 3,
      step: 0.05,
      help: 'How long you must stand still at the edge before the view slides down.'
    },
    camLedgeDepth: {
      group: 'Camera',
      label: 'Ledge hint: smallest drop',
      unit: 'tiles',
      def: 3,
      min: 1,
      max: 20,
      step: 1,
      help: 'Drops shorter than this are not ledges. The hint also appears over a pit with no floor at all.'
    },
    camLedgeReach: {
      group: 'Camera',
      label: 'Ledge hint: reach',
      unit: 'tiles',
      def: 0.3,
      min: 0,
      max: 2,
      step: 0.05,
      help: 'How far past the edge of your body the engine looks for the drop.'
    },
    camPosX: {
      group: 'Camera',
      label: 'Player position on screen, sideways',
      unit: '% of width',
      def: 0,
      min: -45,
      max: 45,
      step: 1,
      help: 'Where the player stands on the screen. 0 = the middle, 20 = a fifth of the screen to the right of the middle, -20 = to the left. Near a room edge the view stops at the edge, so the player may walk past this spot there.'
    },
    camPosY: {
      group: 'Camera',
      label: 'Player position on screen, up and down',
      unit: '% of height',
      def: 8,
      min: -45,
      max: 45,
      step: 1,
      help: 'Where the player stands on the screen. 0 = the middle, 25 = a quarter of the screen below the middle (you see more of the sky), -25 = above the middle (you see more of the ground).'
    },
    camOffsetY: {
      group: 'Camera',
      label: 'Vertical offset',
      unit: 'tiles',
      def: 0,
      min: -4,
      max: 4,
      step: 0.25,
      help: 'Older setting in tiles; Player position on screen does the same in percent. Positive moves the view down (you appear higher on the screen), negative moves it up.'
    }
  },
  // Moves: any movement is a row of numbers. type: impulse (one push, e.g. jumps), dash (timed velocity),
  // hold (while a key is held, e.g. glide or jetpack) or swim (in water tiles). requires = ability id that must be
  // unlocked ('' = always). Abilities for these moves are created automatically from `requires`.
  moveFields: {
    id: { t: 'text', def: '', label: 'Id', help: 'Short name, no spaces. Must be unique.' },
    label: { t: 'text', def: '', label: 'Name', help: 'Shown in messages.' },
    type: {
      t: 'select',
      def: 'dash',
      o: ['dash', 'sequence', 'scripted', 'impulse', 'hold', 'surface', 'ledge', 'swim', 'grapple', 'bash', 'throw'],
      legacy: ['roll', 'path'],
      names: {
        sequence: 'Multi-step move (leap, hang, slam...)',
        scripted: 'Scripted move (a JavaScript function drives it)',
        surface: 'Wall or ceiling (cling, climb, run)',
        ledge: 'Ledge grab and climb (hang, pull up)',
        dash: 'Timed move (dash, roll, leap, slide...)',
        impulse: 'Instant push (jump)',
        hold: 'While held (glide, jetpack)',
        swim: 'Swimming',
        roll: 'Roll (old)',
        grapple: 'Grapple hook (pull to it, or swing from it)',
        bash: 'Bash (launch off a Bash orb)',
        throw: 'Throw an item, then teleport to it',
        path: 'Path (old)'
      },
      label: 'Type',
      help: 'Timed move: plays for its duration. Push it along a direction at a speed, or draw its route and speed curve in the timeline. Instant push: one push, like a jump. While held: works while the key is down. Swimming: how you move in water.'
    },
    key: {
      t: 'key',
      def: 'Shift',
      label: 'Key',
      help: 'Click, then press the key you want. Jump = the jump keys, None = automatic (swim).'
    },
    with: {
      t: 'key',
      def: 'None',
      label: 'Also hold',
      help: 'A second key that must be held while you press Key, for example Down + Shift for a down dash. None = no second key.'
    },
    priority: {
      t: 'number',
      def: 0,
      min: -9,
      max: 9,
      step: 1,
      label: 'Order on a shared key',
      help: 'When two moves use the same key (a double jump and a glide on Jump, say), the one with the HIGHER number gets the press first. The other one only works when the first cannot (used up, wrong place, no energy), or after you let go and press again. A move with more keys (Down + Jump) always goes before a plain Jump.'
    },
    requires: { t: 'text', def: '', label: 'Unlocked by', help: 'Ability id from a pickup. Empty = always available.' },
    where: {
      t: 'select',
      def: 'any',
      o: ['any', 'ground', 'air', 'water'],
      label: 'Usable',
      help: 'Where the move can start.'
    },
    dir: {
      t: 'select',
      def: 'forward',
      o: ['forward', 'up', 'down', 'input', 'fixed'],
      label: 'Direction',
      help: 'input = the 8 directions you hold, fixed = use Angle.'
    },
    angle: {
      t: 'number',
      def: 0,
      min: -180,
      max: 180,
      step: 5,
      label: 'Angle',
      help: 'Degrees for Direction fixed. 0 = forward, 90 = up.'
    },
    speed: {
      t: 'number',
      def: 20,
      min: 0,
      max: 80,
      step: 0.5,
      label: 'Speed (tiles/s)',
      help: 'Velocity. Hold: max fall speed (0 = unchanged). Swim: top speed.'
    },
    script: {
      t: 'text',
      def: '',
      label: 'Script function',
      help: 'The name of a function a script offers with fn("name", me => ...). It runs every frame while the move plays and steers the player. Duration is the longest it can last; me.end() stops it sooner. See SCRIPTING.md.'
    },
    duration: { t: 'number', def: 0.15, min: 0, max: 3, step: 0.01, label: 'Duration (s)', help: 'Dash length.' },
    accel: {
      t: 'number',
      def: 0,
      min: -300,
      max: 300,
      step: 5,
      label: 'Acceleration',
      help: 'Dash: speeds up or slows along the direction. Hold: upward lift. Swim: steering acceleration. Grapple swing: how hard Left and Right push the swing.'
    },
    gravity: {
      t: 'number',
      def: 0,
      min: 0,
      max: 3,
      step: 0.05,
      label: 'Gravity x',
      help: 'Gravity multiplier during the move. 0 = none. Grapple swing: how heavy the swing is (0 = normal gravity).'
    },
    cooldown: {
      t: 'number',
      def: 0.5,
      min: 0,
      max: 10,
      step: 0.05,
      label: 'Cooldown (s)',
      help: 'Wait before it can be used again.'
    },
    uses: {
      t: 'number',
      def: 0,
      min: 0,
      max: 9,
      step: 1,
      label: 'Uses per air time',
      help: '0 = unlimited. Refills when you land or swim.'
    },
    keep: {
      t: 'number',
      def: 0,
      min: 0,
      max: 1,
      step: 0.05,
      label: 'Keep speed',
      help: 'Impulse: momentum kept on the other axis. Dash: share of dash speed kept after it ends.'
    },
    stop: {
      t: 'select',
      def: 'no',
      o: ['no', 'yes'],
      label: 'Stop when blocked',
      help: 'End a dash early when it hits a wall, floor or ceiling.'
    },
    surface: {
      t: 'select',
      def: 'wall',
      o: ['wall', 'ceiling'],
      label: 'Sticks to',
      help: 'Wall or ceiling move: works only while the player touches a wall (beside the body) or a ceiling (above it), the key is held and the player is in the air.'
    },
    mode: {
      t: 'select',
      def: 'climb',
      o: ['stick', 'climb', 'run'],
      label: 'Behaviour',
      help: 'Stick: hang still. Climb: Up and Down (wall) or Left and Right (ceiling) move you at Speed. Run: you go up the wall (or along the ceiling the way you face) by yourself at Speed.'
    },
    damage: {
      t: 'number',
      def: 1,
      min: 0,
      max: 99,
      step: 1,
      label: 'Attack box damage',
      help: "Health taken from what this move's attack boxes hit. Only used when the move has attack boxes."
    },
    squash: {
      t: 'number',
      def: 1,
      min: 0.2,
      max: 1,
      step: 0.05,
      label: 'Body height while it plays (x)',
      help: 'How tall the player is while a timed move plays (1 = normal, 0.5 = half). A low body fits under low gaps. If something is overhead when the move ends, the player stays low until there is room.'
    },
    reach: {
      t: 'number',
      def: 10,
      min: 1,
      max: 40,
      step: 0.5,
      label: 'Hook reach (tiles)',
      help: 'Grapple: how far the hook can fly before it gives up. Bash: how close a Bash orb must be. Throw: how far the item can fly.'
    },
    life: {
      t: 'number',
      def: 6,
      min: 0,
      max: 60,
      step: 0.5,
      label: 'Item stays (s)',
      help: 'Throw: how long the thrown item stays before it fades away (it blinks in the last second and a half). The move cools down when it fades. 0 = it stays until you teleport to it.'
    },
    hook: {
      t: 'number',
      def: 45,
      min: 5,
      max: 120,
      step: 1,
      label: 'Hook speed (tiles/s)',
      help: 'Grapple: how fast the hook flies out.'
    },
    pull: {
      t: 'number',
      def: 24,
      min: 2,
      max: 80,
      step: 0.5,
      label: 'Pull speed (tiles/s)',
      help: 'Grapple: how fast you are pulled to the hook. The speed curve changes it over time. Press Jump to let go.'
    },
    aim: {
      t: 'number',
      def: 0.6,
      min: 0.1,
      max: 3,
      step: 0.05,
      label: 'Aim time (s)',
      help: 'Bash: how long the world slows while you aim with the direction keys. Let go of the key (or wait) to launch.'
    },
    only: {
      t: 'select',
      def: 'any',
      o: ['any', 'sticky only'],
      names: { any: 'Any wall or ceiling, and Sticky surfaces', 'sticky only': 'Sticky surfaces only' },
      label: 'Works on',
      help: 'Wall or ceiling move: where it works. Sticky surfaces is an entity you place in a room.'
    },
    cost: {
      t: 'number',
      def: 0,
      min: 0,
      max: 200,
      step: 1,
      label: 'Energy cost',
      help: 'Energy spent when the move starts. You cannot use it with less energy than this. While held (Hold moves): spent each time the Charge time is complete. Needs Energy set in Settings. 0 = free.'
    },
    drain: {
      t: 'number',
      def: 0,
      min: 0,
      max: 100,
      step: 0.5,
      label: 'Energy used per second',
      help: 'While held: energy used every second after the Charge time, so a jetpack or a shield runs dry. The move stops when the bar is empty. 0 = none.'
    },
    recharge: {
      t: 'select',
      def: 'no',
      o: ['no', 'yes'],
      label: 'Charge again while held',
      help: 'While held: Yes = when the Charge time is complete the effects run and the charge starts over while you keep holding the key (a heal you can repeat). No = it works once for as long as you hold.'
    },
    windup: {
      t: 'number',
      def: 0,
      min: 0,
      max: 10,
      step: 0.05,
      label: 'Charge time (s)',
      help: 'While held: you must hold the key this long before it starts working (on the ground or in the air). A bar fills above the player while it charges. Let go and the charge is lost. 0 = works at once.'
    },
    loop: {
      t: 'select',
      def: 'no',
      o: ['no', 'yes'],
      label: 'Repeat the hitbox animation',
      help: 'Wall or ceiling move: its Duration is how long the hitbox animation (body hitbox keyframes, invincible periods and attack boxes) plays while you cling. Yes = it starts again when it ends.'
    },
    fuel: {
      t: 'number',
      def: 0,
      min: 0,
      max: 30,
      step: 0.1,
      label: 'Time it works (s)',
      help: 'While held: how long it can be used in one air time (flying too). Wall or ceiling: how long you can cling. Ledge: how long you can hang. Grapple swing: how long you can swing. It fills up again when you land. 0 = no limit.'
    },
    side: {
      t: 'number',
      def: 1,
      min: 0,
      max: 1,
      step: 0.05,
      label: 'Left/right speed while held (x)',
      help: 'While held: how fast you can steer sideways while it is on (1 = as fast as running, 0 = straight up or down).'
    },
    slide: {
      t: 'number',
      def: 0,
      min: 0,
      max: 30,
      step: 0.5,
      label: 'Slide down speed (tiles/s)',
      help: 'Wall move: how fast you slide down while clinging (Stick, or Climb with no key held). Ledge: how fast you sag while hanging. 0 = hang still.'
    },
    kick: {
      t: 'number',
      def: 7,
      min: 0,
      max: 30,
      step: 0.5,
      label: 'Jump-off push (tiles/s)',
      help: 'Wall or ledge move: how hard Jump (held away from the wall) throws you off.'
    },
    repeat: {
      t: 'number',
      def: 1,
      min: 1,
      max: 9,
      step: 1,
      label: 'Repeat all steps (times)',
      help: 'Multi-step move: play the whole list of steps this many times in a row (a spin attack, a bouncing hop).'
    },
    on: {
      t: 'select',
      def: 'air',
      o: ['air', 'air and ground', 'ground'],
      names: {
        air: 'In the air only (glide, jetpack)',
        'air and ground': 'In the air and on the ground',
        ground: 'On the ground only (sprint, crouch, morph)'
      },
      label: 'Works',
      help: 'While held: where it works. On the ground only is for sprinting, crouching, crawling or turning into a ball: nothing runs out, it works for as long as you hold the key.'
    },
    runs: {
      t: 'number',
      def: 0,
      min: 0,
      max: 40,
      step: 0.5,
      label: 'Run speed while held (tiles/s)',
      help: 'While held: your top left/right speed while the key is down (a sprint is higher than your normal run, a crawl is lower). 0 = unchanged.'
    },
    sqw: {
      t: 'number',
      def: 1,
      min: 0.2,
      max: 1,
      step: 0.05,
      label: 'Body width while held (x)',
      help: 'While held: how wide the player is (1 = normal). A ball is both low and narrow.'
    },
    nojump: {
      t: 'select',
      def: 'no',
      o: ['no', 'yes'],
      label: 'Blocks jumping and attacks',
      help: 'While held: Yes = you cannot jump or attack while it is on (a morph ball).'
    },
    state: {
      t: 'select',
      def: 'auto',
      o: ['auto', 'crouch', 'sprint', 'morph', 'fly', 'burrow', 'phase'],
      names: {
        auto: 'Normal animations (burrow and phase play theirs by themselves)',
        crouch: 'Crouch animation',
        sprint: 'Sprint animation',
        morph: 'Morph animation',
        fly: 'Fly animation',
        burrow: 'Burrow animation',
        phase: 'Phase animation'
      },
      label: 'Plays animation',
      help: 'While held: which Sprite and animations entry the player shows while it is on (set them in the Sprite tab).'
    },
    anchor: {
      t: 'select',
      def: 'walls and points',
      o: ['walls and points', 'grapple points only', 'walls only'],
      label: 'Hook sticks to',
      help: 'Grapple: what the hook can grab. Grapple points are an entity you place in a room.'
    },
    how: {
      t: 'select',
      def: 'pull',
      o: ['pull', 'swing'],
      names: { pull: 'Pulls you straight to the hook', swing: 'Rope: you swing from the hook like a pendulum' },
      label: 'Grapple works as',
      help: 'Pull: you are reeled in to the hook. Swing: the rope stays as long as it was when it caught, you swing on it with gravity, Left and Right pump the swing, Up and Down shorten and lengthen the rope, and Jump lets go with the speed you have.'
    },
    grab: {
      t: 'number',
      def: 0.5,
      min: 0.1,
      max: 1.5,
      step: 0.05,
      label: 'Grab reach (tiles)',
      help: 'Ledge: how far below the edge of a ledge your head can be and you still catch it.'
    },
    climb: {
      t: 'number',
      def: 0.35,
      min: 0.05,
      max: 2,
      step: 0.05,
      label: 'Climb time (s)',
      help: 'Ledge: how long pulling yourself up takes. You cannot be steered while you do it.'
    },
    fly: {
      t: 'number',
      def: 0,
      min: 0,
      max: 40,
      step: 0.5,
      label: 'Fly speed (tiles/s)',
      help: 'While held: above 0 you fly. Up and Down move you at this speed (nothing pulls you down), and Run speed while held sets how fast you go sideways. Let go of Up and Down and you hover. Use it for flying, hovering, levitating, swimming through the air or digging through soft ground.'
    },
    phase: {
      t: 'select',
      def: 'no',
      o: ['no', 'walls', 'soil', 'ghost'],
      names: {
        no: 'No: solid ground and walls block you',
        walls: 'Through every wall, floor and ceiling',
        soil: 'Through soft ground only (burrow)',
        ghost: 'Through Phase walls only (a ghost or shadow form)'
      },
      label: 'Passes through',
      help: 'Ghost through solid tiles while the move plays (or the key is held). Soft ground and Phase wall are tiles in the Tiles palette: pick which kind this move can pass, and give the move an ability (Unlocked by) so only players who earned it can. When the move ends inside something solid you pop out at the nearest free spot.'
    }
  },
  moves: [], // a new project has no moves: you build them from scratch in the Moves and abilities tab
  camera: { follow: 0.12, shakeDecay: 3 },
  // requires: ability ids that must already be unlocked before this one can be gained
  abilities: {
    wallJump: { label: 'Wall jump', slide: 3, kickX: 9, kickY: 17, kickTime: 0.18, requires: [] },
    waterBreath: { label: 'Underwater breathing', requires: [] }
  },
  // t: text | number | select. d: default value shown in the editor.
  entities: {
    checkpoint: { label: 'Checkpoint', color: '#5dcaa5', w: 1, h: 1, props: {} },
    checkpointkey: {
      label: 'Checkpoint (press key)',
      color: '#3fb58c',
      w: 1,
      h: 1,
      props: { key: { t: 'key', d: 'E' } }
    },
    pickup: {
      label: 'Pickup',
      color: '#ef9f27',
      w: 0.6,
      h: 0.6,
      props: {
        kind: { t: 'select', o: ['ability', 'flag', 'item', 'weapon', 'upgrade', 'energy'], d: 'ability' },
        give: { t: 'text', d: 'dash' },
        amount: { t: 'number', d: 1 }
      }
    },
    door: {
      label: 'Locked door',
      color: '#a67c52',
      w: 1,
      h: 2,
      props: { requires: { t: 'text', d: 'flag:switch1' }, idle: { t: 'clip', d: '' }, open: { t: 'clip', d: '' } }
    },
    switch: {
      label: 'Switch',
      color: '#d85a30',
      w: 0.6,
      h: 0.8,
      props: { flag: { t: 'text', d: 'switch1' }, off: { t: 'clip', d: '' }, on: { t: 'clip', d: '' } }
    },
    enemy: {
      label: 'Enemy',
      color: '#e24b4a',
      w: 0.8,
      h: 0.8,
      props: {
        kind: { t: 'enemy', d: '' },
        hp: { t: 'number', d: 2 },
        speed: { t: 'number', d: 2 },
        range: { t: 'number', d: 3 }
      }
    },
    breakable: {
      label: 'Breakable wall',
      color: '#888780',
      w: 1,
      h: 1,
      props: {
        width: { t: 'number', d: 1 },
        height: { t: 'number', d: 1 },
        needs: { t: 'text', d: '' },
        hp: { t: 'number', d: 1 },
        idle: { t: 'clip', d: '' },
        hit: { t: 'clip', d: '' },
        broken: { t: 'clip', d: '' }
      }
    },
    collapse: {
      label: 'Collapsing ground',
      color: '#8a6a45',
      w: 3,
      h: 1,
      props: {
        width: { t: 'number', d: 3 },
        height: { t: 'number', d: 1 },
        delay: { t: 'number', d: 0.6 },
        respawn: { t: 'number', d: 4 },
        idle: { t: 'clip', d: '' },
        shake: { t: 'clip', d: '' },
        fall: { t: 'clip', d: '' }
      }
    },
    spring: {
      label: 'Bounce pad',
      color: '#e8c34a',
      w: 1,
      h: 0.4,
      props: {
        width: { t: 'number', d: 1 },
        power: { t: 'number', d: 6 },
        idle: { t: 'clip', d: '' },
        bounce: { t: 'clip', d: '' }
      }
    },
    conveyor: {
      label: 'Conveyor belt',
      color: '#58708a',
      w: 3,
      h: 1,
      props: { width: { t: 'number', d: 3 }, speed: { t: 'number', d: 3 } }
    },
    secret: {
      label: 'Secret wall',
      color: '#5b6b7a',
      w: 1,
      h: 1,
      props: { width: { t: 'number', d: 1 }, height: { t: 'number', d: 1 } }
    },
    sign: { label: 'Sign', color: '#b08d57', w: 0.8, h: 1.2, props: { text: { t: 'text', d: 'Hello' } } },
    signkey: {
      label: 'Sign (press key)',
      color: '#9a7a45',
      w: 0.8,
      h: 1.2,
      props: { text: { t: 'text', d: 'Hello' }, key: { t: 'key', d: 'E' } }
    },
    ladder: {
      label: 'Ladder',
      color: '#a67c52',
      w: 1,
      h: 3,
      props: { height: { t: 'number', d: 3 }, speed: { t: 'number', d: 4 } }
    },
    dashpad: {
      label: 'Dash pad',
      color: '#4ad0e8',
      w: 1,
      h: 0.3,
      props: {
        width: { t: 'number', d: 1 },
        dir: { t: 'select', o: ['right', 'left', 'up', 'down'], d: 'right' },
        speed: { t: 'number', d: 18 },
        duration: { t: 'number', d: 0.25 }
      }
    },
    stickwall: {
      label: 'Climb wall (up or down)',
      color: '#7a5a9a',
      w: 1,
      h: 3,
      props: {
        width: { t: 'number', d: 1 },
        height: { t: 'number', d: 3 },
        dir: { t: 'select', o: ['up', 'down'], d: 'up' },
        speed: { t: 'number', d: 4 }
      }
    },
    sticky: {
      label: 'Sticky surface',
      color: '#9acd32',
      w: 1,
      h: 3,
      props: { width: { t: 'number', d: 1 }, height: { t: 'number', d: 3 } }
    },
    platform: {
      label: 'Moving platform',
      color: '#7f77dd',
      w: 3,
      h: 0.4,
      props: {
        dx: { t: 'number', d: 4 },
        dy: { t: 'number', d: 0 },
        speed: { t: 'number', d: 2 },
        solid: { t: 'select', o: ['no', 'yes'], d: 'no' }
      }
    }
  }
};
// Bosses: entity type for placing one in a room, and the editable boss fields (the editor builds its form from these).
MV.data.entities.boss = {
  label: 'Boss',
  color: '#7f77dd',
  w: 2.5,
  h: 3,
  props: { boss: { t: 'boss', d: '' }, arena: { t: 'text', d: '' } }
}; // arena: "x0,y0,x1,y1" in tiles, stamped when the boss is placed from the Bosses tab; the boss never leaves it. Empty = worked out from the spawn and the boss's arena size
MV.data.bossFields = {
  name: { t: 'text', def: 'New boss', label: 'Name' },
  hp: { t: 'number', def: 30, min: 1, max: 999, step: 1, label: 'Health (hits to defeat)' },
  w: { t: 'number', def: 2.5, min: 0.5, max: 12, step: 0.1, label: 'Body width (tiles)' },
  h: { t: 'number', def: 3, min: 0.5, max: 12, step: 0.1, label: 'Body height (tiles)' },
  wakeTime: { t: 'number', def: 1, min: 0, max: 10, step: 0.1, label: 'Wake-up time without an animation (s)' },
  wake: { t: 'number', def: 12, min: 2, max: 60, step: 1, label: 'Wakes when you are within (tiles)' },
  shape: {
    t: 'select',
    def: 'rect',
    o: ['rect', 'circle', 'polygon'],
    label: 'Body shape (what your attacks must touch)'
  },
  select: {
    t: 'select',
    def: 'order',
    o: ['order', 'rules'],
    label: 'Picks attacks',
    names: { order: 'In order (pattern 1, 2, 3...)', rules: 'By rules (distance, health, cooldown, weight)' }
  },
  ai: {
    t: 'select',
    def: 'built-in',
    o: ['built-in', 'script'],
    label: 'AI',
    names: {
      'built-in': 'Built-in (walks toward you, picks patterns)',
      script: 'Script (a JavaScript function decides everything; it can start your patterns)'
    }
  },
  brain: { t: 'text', def: '', label: 'AI script function (when AI = Script)' },
  speed: { t: 'number', def: 0, min: 0, max: 20, step: 0.5, label: 'Walks toward you at (tiles/s, 0 = stays)' },
  keep: { t: 'number', def: 3, min: 0, max: 30, step: 0.5, label: 'Walks until it is this close (tiles)' },
  fly: {
    t: 'select',
    def: 'yes',
    o: ['yes', 'no'],
    label: 'Floats (no = falls to the floor)',
    names: { yes: 'Floats', no: 'Stands on the floor' }
  },
  leash: {
    t: 'number',
    def: 0,
    min: 0,
    max: 200,
    step: 1,
    label: 'Never goes farther than this from its spot (tiles, 0 = anywhere in the room)'
  },
  weakOnly: { t: 'select', def: 'no', o: ['no', 'yes'], label: 'Only weak spots take damage' },
  touch: { t: 'select', def: 'yes', o: ['yes', 'no'], label: 'Hurts when touched' },
  damage: { t: 'number', def: 1, min: 0, max: 30, step: 1, label: 'Touch damage (hits)' },
  knock: { t: 'number', def: 6, min: 0, max: 20, step: 0.5, label: 'Pushes you back (tiles/s)' },
  stun: { t: 'number', def: 0.2, min: 0, max: 1, step: 0.05, label: 'You cannot steer for (s)' },
  invul: { t: 'number', def: 0.25, min: 0.05, max: 3, step: 0.05, label: 'Safe time after a hit (s)' },
  stagger: { t: 'number', def: 0, min: 0, max: 100, step: 5, label: 'Stunned after losing this much health (%)' },
  staggerTime: { t: 'number', def: 2, min: 0.2, max: 15, step: 0.1, label: 'Stun lasts (s)' },
  staggerMult: { t: 'number', def: 1.5, min: 0.1, max: 10, step: 0.1, label: 'Damage taken while stunned (x)' },
  stunSnd: { t: 'sound', def: '', label: 'Sound: gets stunned' },
  restart: { t: 'select', def: 'yes', o: ['yes', 'no'], label: 'Starts over when you die (full health, asleep)' },
  wakeSnd: { t: 'sound', def: '', label: 'Sound: wakes up' },
  hurtSnd: { t: 'sound', def: '', label: 'Sound: takes a hit' },
  phaseSnd: { t: 'sound', def: '', label: 'Sound: changes phase' },
  dieSnd: { t: 'sound', def: '', label: 'Sound: defeated' },
  reward: { t: 'text', def: '', label: 'Ability given when defeated' },
  flag: { t: 'text', def: '', label: 'Flag set when defeated (blank = boss_<id>)' }
};
// Hazards (spikes and the like) are an entity now, so the Tiles palette can stay terrain only. Old ^ tiles still work.
MV.data.entities.hazard = {
  label: 'Hazard (spikes)',
  color: '#d85a30',
  w: 1,
  h: 0.5,
  props: { width: { t: 'number', d: 1 }, height: { t: 'number', d: 0.5 } }
};
// More level-design entities (no enemies here: enemies, hazards and bosses are not offered in the Entities list).
MV.data.entities.current = {
  label: 'Water current',
  color: '#4aa3c8',
  w: 4,
  h: 3,
  props: {
    width: { t: 'number', d: 4 },
    height: { t: 'number', d: 3 },
    dir: { t: 'select', o: ['right', 'left', 'up', 'down'], d: 'right' },
    power: { t: 'number', d: 5 }
  }
};
MV.data.entities.lowgrav = {
  label: 'Low gravity zone',
  color: '#9a8fe0',
  w: 4,
  h: 4,
  props: { width: { t: 'number', d: 4 }, height: { t: 'number', d: 4 }, gravity: { t: 'number', d: 0.3 } }
};
MV.data.entities.msgzone = {
  label: 'Message zone',
  color: '#d6a54a',
  w: 3,
  h: 3,
  props: {
    width: { t: 'number', d: 3 },
    height: { t: 'number', d: 3 },
    text: { t: 'text', d: 'Hello' },
    once: { t: 'select', o: ['no', 'yes'], d: 'no' },
    stop: { t: 'select', o: ['no', 'yes'], d: 'no' },
    hold: { t: 'number', d: 2 }
  }
};
MV.data.entities.teleporter = {
  label: 'Portal or teleporter (pairs by channel)',
  color: '#c36ad8',
  w: 1,
  h: 2,
  props: {
    channel: { t: 'text', d: 'A' },
    launch: { t: 'number', d: 0 },
    angle: { t: 'number', d: 90 },
    keep: { t: 'select', o: ['no', 'yes'], d: 'no' }
  }
};
MV.data.entities.blink = {
  label: 'Blinking platform',
  color: '#e8a0b8',
  w: 3,
  h: 1,
  props: {
    width: { t: 'number', d: 3 },
    height: { t: 'number', d: 1 },
    on: { t: 'number', d: 2 },
    off: { t: 'number', d: 1.5 },
    offset: { t: 'number', d: 0 }
  }
};
MV.data.entities.icezone = {
  label: 'Ice (slippery)',
  color: '#bfe8f5',
  w: 4,
  h: 1,
  props: { width: { t: 'number', d: 4 }, height: { t: 'number', d: 1 }, slip: { t: 'number', d: 0.02 } }
};
MV.data.entities.mudzone = {
  label: 'Mud (slow)',
  color: '#7a5a3a',
  w: 4,
  h: 1,
  props: { width: { t: 'number', d: 4 }, height: { t: 'number', d: 1 }, slow: { t: 'number', d: 0.45 } }
};
MV.data.entities.chest = {
  label: 'Chest',
  color: '#d9a441',
  w: 1,
  h: 0.8,
  props: {
    closed: { t: 'clip', d: '' },
    open: { t: 'clip', d: '' },
    reward: { t: 'select', o: ['coins', 'key', 'flag', 'ability', 'weapon', 'item', 'upgrade', 'energy'], d: 'coins' },
    amount: { t: 'number', d: 5 },
    give: { t: 'text', d: '' },
    name: { t: 'text', d: '' },
    message: { t: 'text', d: '' },
    key: { t: 'key', d: 'E' }
  }
};
MV.data.entities.npc = {
  label: 'Character (talk)',
  color: '#6fb7d9',
  w: 0.8,
  h: 1.6,
  props: {
    name: { t: 'text', d: 'Villager' },
    passing: { t: 'longtext', d: 'Nice weather today.' },
    range: { t: 'number', d: 4 },
    dialogue: {
      t: 'longtext',
      d: 'Hello there, traveller.\n>Hi! Can you tell me about this place?\nBe careful in the deep.'
    },
    after: { t: 'longtext', d: '' },
    key: { t: 'key', d: 'E' }
  }
};
MV.data.entities.orb = {
  label: 'Refill orb (dash and jumps)',
  color: '#7bf0d0',
  w: 0.7,
  h: 0.7,
  props: { respawn: { t: 'number', d: 2 } }
};
MV.data.entities.animsprite = {
  label: 'Animated sprite',
  color: '#e0a3ff',
  w: 1,
  h: 1,
  props: {
    clip: { t: 'clip', d: '' },
    width: { t: 'number', d: 2 },
    flip: { t: 'select', o: ['no', 'yes'], d: 'no' },
    layer: { t: 'select', o: ['behind player', 'in front of player'], d: 'behind player' },
    when: {
      t: 'select',
      o: [
        'always',
        'room start',
        'player touches',
        'player stands in it',
        'breakable wall hit',
        'breakable wall broken',
        'collapsing ground shakes',
        'switch toggled',
        'chest opened',
        'flag set'
      ],
      d: 'always'
    },
    near: { t: 'number', d: 6 },
    flag: { t: 'text', d: '' },
    idle: { t: 'select', o: ['hidden', 'first frame'], d: 'hidden' },
    finish: { t: 'select', o: ['hide', 'hold last frame'], d: 'hide' }
  }
};
// A light zone you place in a room: a dark area, like a secret room, that lights up while the player is inside it. Its shape is a circle or a polygon whose corners you drag, like a lamp (saved in props.pts). "dark" is how dark it is from outside (0 to 1), "fade" the seconds the change takes, "stay" keeps it lit once you have been in, and "invert" also darkens everything OUTSIDE the shape while you are inside it.
MV.data.entities.lightzone = {
  label: 'Light zone',
  color: '#f2d36b',
  w: 0.6,
  h: 0.6,
  props: {
    shape: { t: 'select', o: ['circle', 'polygon'], d: 'polygon' },
    radius: { t: 'number', d: 2.5 },
    sides: { t: 'number', d: 4 },
    dark: { t: 'number', d: 1 },
    color: { t: 'text', d: '#04060b' },
    fade: { t: 'number', d: 0.4 },
    stay: { t: 'select', o: ['no', 'yes'], d: 'no' },
    invert: { t: 'select', o: ['no', 'yes'], d: 'no' }
  }
};
MV.data.entities.grapplepoint = { label: 'Grapple point', color: '#e8c34a', w: 0.8, h: 0.8, props: {} };
MV.data.entities.bashpoint = {
  label: 'Bash orb',
  color: '#ff7a3d',
  w: 0.9,
  h: 0.9,
  props: { respawn: { t: 'number', d: 1.5 } }
};
MV.data.entities.spawn = { label: 'Player start', color: '#7bd06f', w: 1, h: 1, props: {} };
// A light you place in a room. Dark rooms (Level Settings > Lighting) show it; radius is in tiles, level 0 to 1.
MV.data.entities.light = {
  label: 'Light',
  color: '#ffe08a',
  w: 0.6,
  h: 0.6,
  props: { radius: { t: 'number', d: 5 }, level: { t: 'number', d: 1 } }
};
// A lamp you place in a room: a light with a shape (circle, or a polygon whose corners you drag), a radius, a level and a colour. Its corners are saved in props.pts.
MV.data.entities.lamp = {
  label: 'Lamp',
  color: '#ffd699',
  w: 0.6,
  h: 0.6,
  props: {
    shape: { t: 'select', o: ['circle', 'polygon'], d: 'circle' },
    radius: { t: 'number', d: 5 },
    level: { t: 'number', d: 1 },
    color: { t: 'text', d: '#ffd699' },
    sides: { t: 'number', d: 5 },
    soft: { t: 'number', d: 0.9 },
    flicker: { t: 'number', d: 0 },
    shadows: { t: 'select', o: ['yes', 'no'], d: 'yes' }
  }
};
// A darkness zone you place in a room: shade over a circle or polygon area (corners are dragged like a lamp's, saved in props.pts). It is not a light: walls do not cut it, and lamps inside it still shine.
MV.data.entities.darkness = {
  label: 'Darkness',
  color: '#04060b',
  w: 0.6,
  h: 0.6,
  props: {
    shape: { t: 'select', o: ['circle', 'polygon'], d: 'circle' },
    radius: { t: 'number', d: 5 },
    amount: { t: 'number', d: 1 },
    color: { t: 'text', d: '#04060b' },
    sides: { t: 'number', d: 5 },
    soft: { t: 'number', d: 0.5 },
    walls: { t: 'select', o: ['yes', 'no'], d: 'yes' },
    oval: { t: 'number', d: 0 },
    bleed: { t: 'number', d: 0.2 }
  }
};

// Skins: which entities can wear an animation, and which state plays which property. The first state is the resting one. Light, lamp, darkness and the touch checkpoint have none.
// Sign, signkey and ladder take one still sprite (a "sprite" property) instead of an animation. Tiled types repeat the picture once per tile of their width and height.
MV.data.skins = {
  door: { idle: 'idle', open: 'open' },
  switch: { off: 'off', on: 'on' },
  breakable: { idle: 'idle', hit: 'hit', broken: 'broken' },
  collapse: { idle: 'idle', shake: 'shake', fall: 'fall' },
  chest: { closed: 'closed', open: 'open' },
  spring: { idle: 'idle', bounce: 'bounce' },
  checkpointkey: { idle: 'idle', active: 'active' },
  pickup: { idle: 'idle', collected: 'collected' },
  conveyor: { idle: 'idle' },
  secret: { idle: 'idle', revealed: 'revealed' },
  dashpad: { idle: 'idle', fire: 'fire' },
  stickwall: { idle: 'idle', climb: 'climb' },
  platform: { idle: 'idle' },
  current: { idle: 'idle' },
  lowgrav: { idle: 'idle' },
  icezone: { idle: 'idle' },
  mudzone: { idle: 'idle' },
  msgzone: { idle: 'idle', triggered: 'triggered' },
  teleporter: { idle: 'idle', used: 'used' },
  blink: { idle: 'clipOn', gone: 'clipOff' },
  npc: { idle: 'idle', talk: 'talk' },
  orb: { idle: 'idle', used: 'used' }
};
MV.data.skinTiled = [
  'breakable',
  'collapse',
  'conveyor',
  'secret',
  'stickwall',
  'current',
  'lowgrav',
  'msgzone',
  'blink',
  'icezone',
  'mudzone',
  'ladder'
];
MV.data.spriteOnly = ['sign', 'signkey', 'ladder'];
// Zipline or rail: a line from this spot to a spot dx, dy tiles away. Touch it (or press a key) and you ride it. Hang below it like a zipline, or stand on it like a rail.
MV.data.entities.rail = {
  label: 'Zipline or rail',
  color: '#c9b37a',
  w: 0.6,
  h: 0.6,
  props: {
    dx: { t: 'number', d: 10 },
    dy: { t: 'number', d: 3 },
    speed: { t: 'number', d: 9 },
    accel: { t: 'number', d: 14 },
    mode: { t: 'select', o: ['ride to the end', 'steer with Left and Right'], d: 'ride to the end' },
    hang: { t: 'select', o: ['hang below', 'stand on top'], d: 'hang below' },
    grab: { t: 'select', o: ['touch it', 'press a key'], d: 'touch it' },
    key: { t: 'key', d: 'E' }
  }
};
// Cannon: touch it and you are loaded into the barrel. Its angle (0 = right, 90 = up) can be fixed, swing back and forth, or follow Left and Right. It fires after a delay or when you press its key.
MV.data.entities.cannon = {
  label: 'Cannon (barrel)',
  color: '#8a8f98',
  w: 1.4,
  h: 1.4,
  props: {
    angle: { t: 'number', d: 60 },
    aim: { t: 'select', o: ['fixed', 'swings back and forth', 'Left and Right'], d: 'fixed' },
    sweep: { t: 'number', d: 40 },
    turn: { t: 'number', d: 90 },
    power: { t: 'number', d: 24 },
    fire: { t: 'select', o: ['after a delay', 'press a key'], d: 'after a delay' },
    delay: { t: 'number', d: 0.8 },
    key: { t: 'key', d: 'E' },
    flight: { t: 'number', d: 0.5 },
    reload: { t: 'number', d: 1 }
  }
};
// Mount: stand near it and press its key to ride it (press again to get off). While you ride, its speed, jump, gravity and body size replace yours.
MV.data.entities.mount = {
  label: 'Mount (creature or vehicle)',
  color: '#d99a5b',
  w: 1.6,
  h: 1.2,
  props: {
    name: { t: 'text', d: 'Mount' },
    kind: { t: 'select', o: ['walks', 'flies', 'swims'], d: 'walks' },
    key: { t: 'key', d: 'E' },
    needs: { t: 'text', d: '' },
    speed: { t: 'number', d: 8 },
    jump: { t: 'number', d: 3 },
    gravity: { t: 'number', d: 1 },
    width: { t: 'number', d: 1.6 },
    height: { t: 'number', d: 1.2 },
    seat: { t: 'number', d: 0.5 }
  }
};
// Air pocket: a zone where you breathe (your air fills up again fast), for rooms under water.
MV.data.entities.airpocket = {
  label: 'Air pocket (refills air)',
  color: '#9fe3ff',
  w: 3,
  h: 2,
  props: { width: { t: 'number', d: 3 }, height: { t: 'number', d: 2 } }
};
Object.assign(MV.data.skins, {
  cannon: { idle: 'idle', fire: 'fire' },
  mount: { idle: 'idle', move: 'move' },
  airpocket: { idle: 'idle' },
  bashpoint: { idle: 'idle', used: 'used', bashed: 'bashed' },
  grapplepoint: { idle: 'idle', hooked: 'hooked' },
  rail: { idle: 'idle', ride: 'ride' }
});
MV.data.skinTiled.push('airpocket');
(() => {
  const E = MV.data.entities,
    K = MV.data.skins;
  for (const t in K)
    if (E[t])
      for (const st in K[t]) {
        const pr = K[t][st];
        if (!E[t].props[pr]) E[t].props[pr] = { t: 'clip', d: '' };
      }
  MV.data.spriteOnly.forEach(t => {
    if (E[t] && !E[t].props.sprite) E[t].props.sprite = { t: 'sprite', d: '' };
  });
})();

// Camera profiles: a profile is a few camera settings that replace the Default ones (Player > Camera) while it is used.
// A room picks one (Level Settings > Camera), a Camera zone swaps to one while you stand in it, and MV.Game.camera.set(id) swaps by script.
// modeX / modeY: follow (smooth, dead zone, look ahead), centered (locked on the player), locked (the view stays still, at lockX / lockY or the middle of the room).
// bounds: room (the view stays inside the room), extended (pad tiles of extra room around it), none (no limit at all).
// biasSrc: what decides which way the look-ahead leans: facing, velocity (the way you move) or input (the keys you hold).
MV.data.camPresets = [
  { id: 'default', name: 'Hollow Knight style (default)', p: { modeY: 'grounded', groundBand: 4 } },
  {
    id: 'plain',
    name: 'Plain smooth follow',
    p: {
      modeY: 'follow',
      camSmoothX: 0.12,
      camSmoothY: 0.12,
      camLookAhead: 0,
      camLookDelay: 0,
      camFallLook: 0,
      camPeek: 0,
      camLedgeLook: 0,
      camPosY: 0
    }
  },
  { id: 'vcenter', name: 'Vertically centered', p: { modeY: 'centered' } },
  { id: 'vlock', name: 'Vertically locked', p: { modeY: 'locked' } },
  { id: 'hlock', name: 'Horizontally locked', p: { modeX: 'locked' } },
  { id: 'locked', name: 'Fully locked', p: { modeX: 'locked', modeY: 'locked' } },
  { id: 'free', name: 'No bounds', p: { bounds: 'none' } },
  {
    id: 'knight',
    name: 'Hollow Knight style',
    p: {
      modeY: 'grounded',
      groundBand: 4,
      camSmoothX: 0.1,
      camSmoothY: 0.08,
      camLookAhead: 2,
      camLookSpeed: 0.04,
      camLookDelay: 0.15,
      camFallLook: 2.5,
      camVelStart: 12,
      camVelMax: 30,
      camPeek: 4,
      camPeekDelay: 0.5,
      camLedgeLook: 2.5,
      camLedgeDelay: 0.5,
      camPosY: 8
    }
  }
];
MV.data.camExtra = {
  modeX: {
    t: 'select',
    o: ['follow', 'centered', 'locked'],
    def: 'follow',
    label: 'Sideways',
    names: { follow: 'Follow (smooth)', centered: 'Centered on the player', locked: 'Locked (does not move)' }
  },
  modeY: {
    t: 'select',
    o: ['follow', 'grounded', 'centered', 'locked'],
    def: 'follow',
    label: 'Up and down',
    names: {
      grounded: 'Follow when you land (Hollow Knight style)',
      follow: 'Follow (smooth)',
      centered: 'Centered on the player',
      locked: 'Locked (does not move)'
    }
  },
  groundBand: {
    t: 'number',
    def: 4,
    min: 0.5,
    max: 12,
    step: 0.5,
    label: 'Grounded: free band (tiles)',
    help: 'Follow when you land: the view keeps the height of your last floor while you jump around inside this band. It follows at once if you fall or rise farther than this.'
  },
  lockX: {
    t: 'number',
    def: null,
    min: 0,
    max: 10000,
    step: 0.5,
    label: 'Locked at x (tile)',
    help: 'Where the middle of the view sits when sideways is Locked. Empty = the middle of the room.'
  },
  lockY: {
    t: 'number',
    def: null,
    min: 0,
    max: 10000,
    step: 0.5,
    label: 'Locked at y (tile)',
    help: 'Where the middle of the view sits when up and down is Locked. Empty = the middle of the room.'
  },
  bounds: {
    t: 'select',
    o: ['room', 'extended', 'none'],
    def: 'room',
    label: 'Room limits',
    names: {
      room: 'Stay inside the room',
      extended: 'Allow some extra room around it',
      none: 'No limit (the view can leave the room)'
    }
  },
  pad: {
    t: 'number',
    def: 0,
    min: 0,
    max: 200,
    step: 0.5,
    label: 'Extra room (tiles)',
    help: 'Room limits "extra room": how many tiles past each edge of the room the view may go.'
  },
  biasSrc: {
    t: 'select',
    o: ['facing', 'velocity', 'input'],
    def: 'facing',
    label: 'Direction bias follows',
    names: { facing: 'The way you face', velocity: 'The way you move', input: 'The keys you hold' }
  },
  view: {
    t: 'select',
    o: ['follow', 'side', 'topdown', 'fixed', 'free'],
    def: 'follow',
    label: 'Camera mode',
    names: {
      follow: 'Follow (uses the settings above)',
      side: 'Side-scrolling (Hollow Knight style)',
      topdown: 'Top-down (leans both ways)',
      fixed: 'Fixed (does not move)',
      free: 'Free camera (you steer it)'
    }
  },
  zoom: {
    t: 'number',
    def: 1,
    min: 0.4,
    max: 3,
    step: 0.05,
    label: 'Zoom',
    help: '1 = normal. Above 1 zooms in, below 1 shows more of the room. The view never zooms out past the room when room limits are on.'
  },
  zoomSpeed: {
    t: 'number',
    def: 4,
    min: 0.5,
    max: 20,
    step: 0.5,
    label: 'Zoom speed',
    help: 'How fast the zoom settles on a new value.'
  },
  rot: {
    t: 'number',
    def: 0,
    min: -30,
    max: 30,
    step: 1,
    label: 'Tilt (degrees)',
    help: 'A fixed tilt of the view. Rooms with darkness ignore rotation.'
  },
  edge: {
    t: 'number',
    def: 0,
    min: 0,
    max: 6,
    step: 0.25,
    label: 'Screen-edge margin (tiles)',
    help: 'The player never gets closer than this to the edge of the screen.'
  },
  softPad: {
    t: 'number',
    def: 0,
    min: 0,
    max: 8,
    step: 0.25,
    label: 'Soft room limits (tiles)',
    help: 'The view can drift this far past the room edge and eases back, instead of stopping hard.'
  },
  manualPan: {
    t: 'select',
    o: ['no', 'yes'],
    def: 'no',
    label: 'Player can look around',
    names: { no: 'No', yes: 'Yes (pan keys, right stick, mouse drag)' }
  },
  panRange: {
    t: 'number',
    def: 6,
    min: 0,
    max: 40,
    step: 0.5,
    label: 'Look-around range (tiles)',
    help: 'How far manual panning may move the view from the player.'
  },
  bossFrame: {
    t: 'select',
    o: ['no', 'yes'],
    def: 'no',
    label: 'Frame the boss',
    names: { no: 'No', yes: 'Yes (zoom to fit the player and an awake boss)' }
  },
  framePad: {
    t: 'number',
    def: 3,
    min: 0,
    max: 20,
    step: 0.5,
    label: 'Framing padding (tiles)',
    help: 'Empty space kept around the framed targets.'
  },
  frameMin: {
    t: 'number',
    def: 0.6,
    min: 0.3,
    max: 1,
    step: 0.05,
    label: 'Framing: farthest zoom out',
    help: 'Framing never zooms out past this.'
  },
  doorFx: {
    t: 'select',
    o: ['none', 'fade', 'wipe', 'iris'],
    def: 'none',
    label: 'Door transition',
    names: {
      none: 'None (instant, like Hollow Knight)',
      fade: 'Fade through black',
      wipe: 'Wipe',
      iris: 'Iris (circle closes on the player)'
    }
  },
  doorTime: {
    t: 'number',
    def: 0.5,
    min: 0.1,
    max: 3,
    step: 0.05,
    label: 'Door transition time (s)',
    help: 'How long a door transition takes in total.'
  },
  roomFade: {
    t: 'number',
    def: 0,
    min: 0,
    max: 3,
    step: 0.1,
    label: 'Fade in on entering a room (s)',
    help: '0 = no fade.'
  }
};
// What a player may change in an options menu (MV.Game.camera.settings({...})). Saved in the browser, not in the map.
MV.data.camUser = {
  sensitivity: { t: 'number', def: 1, min: 0.2, max: 3, label: 'Camera sensitivity' },
  deadzone: { t: 'number', def: 0.15, min: 0, max: 0.8, label: 'Stick dead zone' },
  invertX: { t: 'bool', def: false, label: 'Invert horizontal' },
  invertY: { t: 'bool', def: false, label: 'Invert vertical' },
  mouse: { t: 'bool', def: true, label: 'Mouse wheel and drag' },
  zoom: { t: 'number', def: 1, min: 0.5, max: 1.5, label: 'Zoom multiplier' },
  smoothing: { t: 'number', def: 0.5, min: 0, max: 1, label: 'Smoothing (0 snappy, 1 floaty)' },
  shake: { t: 'number', def: 1, min: 0, max: 1, label: 'Screen shake strength' },
  flashes: { t: 'bool', def: true, label: 'Allow flashes' },
  reduceMotion: { t: 'bool', def: false, label: 'Reduce motion (no shake, tilt or zoom effects)' }
};
// Keys used by the camera while panning or in free mode (KeyboardEvent.code). Gamepad: the right stick.
MV.data.camKeys = {
  panLeft: ['KeyJ'],
  panRight: ['KeyL'],
  panUp: ['KeyI'],
  panDown: ['KeyK'],
  freeLeft: ['KeyA', 'ArrowLeft'],
  freeRight: ['KeyD', 'ArrowRight'],
  freeUp: ['KeyW', 'ArrowUp'],
  freeDown: ['KeyS', 'ArrowDown'],
  zoomIn: ['Equal', 'NumpadAdd'],
  zoomOut: ['Minus', 'NumpadSubtract'],
  reset: ['Backspace']
};
// Camera zone: while the player's middle is inside the box, the camera uses the profile you pick (empty = the room's own) and can limit the view to the box or break the room limits.
MV.data.entities.camzone = {
  label: 'Camera zone',
  color: '#5ab0e8',
  w: 4,
  h: 3,
  props: {
    width: { t: 'number', d: 4 },
    height: { t: 'number', d: 3 },
    profile: { t: 'camprofile', d: '' },
    bounds: { t: 'select', o: ['keep', 'limit view to this box', 'break room limits'], d: 'limit view to this box' },
    blend: { t: 'number', d: 0.8 }
  }
};

// Event zone: an invisible box. Walking into or out of it can start an event (Events tab > trigger "walks into an Event zone", with the same zone name).
MV.data.entities.evzone = {
  label: 'Event zone (starts events)',
  color: '#e86ab0',
  w: 3,
  h: 3,
  props: { width: { t: 'number', d: 3 }, height: { t: 'number', d: 3 }, tag: { t: 'text', d: 'zone1' } }
};

// One-line explanations shown above an entity's settings in the room editor.
MV.data.entityHelp = {
  evzone:
    'An invisible box that does nothing on its own. Name it (Zone name), then in the Events tab add an event whose trigger is "walks into an Event zone" with the same name. Use it to start a cutscene, close a door behind the player, spawn something or change the world when the player enters or leaves the box.',
  camzone:
    'An invisible box that changes the camera while the player is inside it: a different camera profile (Player > Camera > Camera profiles), optionally limiting the view to the box or breaking the room limits. The smallest box around the player wins; "blend" is how many seconds the change takes.',
  bashpoint:
    'An orb the Bash move launches you from. Hold the Bash key near it, aim with the direction keys and let go. It recharges after "respawn" seconds. Give it animations: waiting, used and bashed.',
  grapplepoint:
    'A hook spot for the Grapple move. Without any, a grapple only sticks to walls (or set the move to "grapple points only"). Animations: waiting and hooked.',
  rail: 'A line from this spot to a spot dx, dy tiles away. Touch it (or press a key) and you ride it. Animations: waiting and while riding (drawn at the start of the line).',
  cannon: 'Touch it to be loaded into the barrel, then it fires you at its angle.',
  mount: 'A creature or vehicle you ride with its key. Its speed, jump, gravity and size replace yours while you ride.',
  platform: 'A platform that moves dx, dy tiles and back. Solid = yes makes it block you from the sides and below.',
  collapse: 'Ground that shakes when you stand on it and falls after the delay.',
  secret: 'A hidden area that is revealed when you touch it.',
  msgzone: 'Shows a message when the player walks into the box.',
  teleporter: 'Two teleporters with the same channel send you to each other.',
  orb: 'Touch it to refill your dash and air jumps.'
};
