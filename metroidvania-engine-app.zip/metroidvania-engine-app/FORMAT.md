# Project file format

A project is one JSON file (the editor's **Save** and **Export**). Everything you build in the editor is in it, so a game, a converter or a test can read it without the editor. The editor reads it back the same way, and cleans what it does not understand (unknown values become defaults, lists are capped).

Check a file from the command line (no editor needed):

```
node tools/validate.js my-project.json          # report, exit code 1 on errors
node tools/validate.js my-project.json --json   # the same, as JSON
```

The same checks run in the editor: the World editor's problem panel (rooms and transitions), the Events tab (events) and the Audio tab (sounds).

## Top level

| key | what it holds |
|---|---|
| `name` | project name |
| `areas` | list of areas, each with `rooms` (see below) |
| `links` | `[areaId, areaId]` pairs: the lines between areas on the world map |
| `mw`, `mh` | size of the world map |
| `player` | movement and settings numbers (`run`, `gravity`, `jumpHeight`, `oxygen`, `camLookAhead`...). Names and ranges: `MV.data.playerSchema` in `data/config.js` |
| `moves` | the player's moves (see Moves) |
| `attacks` | the player's attacks and their hit boxes |
| `body` | the player's body hitbox timeline |
| `controls` | key bindings |
| `sprite` | which animation plays for each player state |
| `anims`, `sheets` | animation clips and the sprite sheets they use |
| `items`, `inv` | inventory items and the inventory screen design |
| `bosses` | boss definitions |
| `events` | the Events list (see Events) |
| `enemies[].move` / `.brain` | an enemy with `move: "script"` is moved by the script function named in `brain` |
| `bosses[].ai` / `.brain` | a boss with `ai: "script"` is run by the script function named in `brain` |
| `moves[]` with `type: "scripted"` | a move driven by the script function named in `script` |
| `scripts` | JavaScript scripts: `[{ id, name, on, code }]` (see SCRIPTING.md) |
| `sounds`, `sfx`, `vol` | the sound library, the player's own sounds and the volumes (see Audio) |
| `camProfiles` | your own camera profiles (the built-in ones are in `MV.data.camPresets`); fields include `view`, `zoom`, `zoomSpeed`, `rot`, `edge`, `softPad`, `manualPan`, `panRange`, `bossFrame`, `framePad`, `frameMin`, `doorFx`, `doorTime`, `roomFade` (see CAMERA.md) |
| `dialog` | the conversation box design |
| `templates`, `pins` | room templates and map pins (editor only; a game can ignore them) |

## Areas and rooms

`areas[i] = { id, n, c, x, y, w, h, rooms: [...] }`. A room:

```
{ id, n,                 // id (unique in the project) and name
  x, y, w, h,            // where it sits on its area map (editor only)
  gw, gh,                // size in tiles
  grid: [ "....", ... ], // gh strings of gw characters, one per tile row (see tiles)
  ent: [ { id, type, x, y, props } ],   // entities (see below)
  tr:  [ { x, y, a, r } ],              // transitions: the D tile at x,y leads to area a, room r
  bg:  { color, layers: [ { sheet, mode, parallax, front, alpha, blur, fog, fogColor, fogDir, ... } ] },
  light: { ... },        // room lighting
  cam: { profile, follow },             // camera profile for the room
  music: "soundId",      // music that plays in the room ("" = none)
  art: [...], table: [...] }            // sprites placed in the room (art) and its sprite table
```

Large grids may be stored packed: `grid` is then `{ "z": 1, "d": [ [rowString, repeatCount], ... ] }`, and a long run of one tile in a row is written `` `c12; `` (tile `c`, 12 times). `tools/validate.js` shows how to read both.

Tiles (one character each): `#` wall, `=` one-way platform, `/` `\` slopes, `[` `]` `{` `}` gentle slopes, `~` water, `D` transition, `s` soft ground (burrow), `g` shade wall, `i` ice, `m` mud, `>` `<` conveyor, `u` bounce, `y` glass, `o` back wall, `x` invisible wall, `.` empty. The full list with colours is in `engine/tiles.js`.

## Entities

`{ id, type, x, y, props }`. `x`, `y` is the tile the entity is placed on (for wide or tall entities `y` is the bottom row). Types and their `props` are described in `MV.data.entities` (`data/config.js`): checkpoint, pickup, door, switch, chest, npc, sign, breakable, collapse, spring, conveyor, ladder, platform, rail, cannon, mount, teleporter, camzone, evzone, lightzone, lamp, darkness, grapplepoint, bashpoint, and more. Enemies and bosses are placed with their own entity types.

## Enemies

`enemies` is a list of enemy types (`MV.Enemies.FIELDS` lists every number with its range). An Enemy entity chooses one with `props.kind` (empty = the old simple enemy with `hp`, `speed`, `range`). `clips` maps a state (`idle`, `walk`, `warn`, `attack`, `hurt`, `die`) to an animation id, `snds` maps `hurtSnd`, `dieSnd`, `atkSnd` to sound ids.

Phase 4 adds to an enemy type: `shape` (rect, circle, polygon), `pts` (3 to 16 corners, -1..1 of the body box), `weak` (up to 6 boxes `{name,x,y,w,h,mult}`), `weakOnly`, `touch`, and for `attack: "strike"` a `strike` list of hitboxes (`shape, w, h, r, pts, from, to, kf, dmg`) on a timeline of `atkDur` seconds.

Bosses gain the same `shape/pts/weak/weakOnly`, plus `damage, knock, stun, invul, restart, wakeSnd, hurtSnd, phaseSnd, dieSnd`; each pattern `warn` and `snd`; each hitbox `shape, r, pts, dmg`; each phase `enter`. Old projects load unchanged (warn 0, enter 0, damage 1).

Animation frames: `{sheet, col, row, dur, event}` plus optional `x, y, w, h` (a free pixel rectangle of any size). Bosses: `clips` maps `passive, awakened, idle, attack, warn, phase, stun, hurt, die` to animation ids; patterns have `clip` and `inv`; hitboxes have `clip`; `stagger` (% of max health), `staggerTime`, `staggerMult`, `stunSnd`. The old `sprite.anims` still loads and is used only where no clip is set.

## Moves

`{ id, label, type, key, with, more, requires, where, ... }`. `type` is one of `dash` (timed move), `sequence` (multi-step), `impulse`, `hold`, `surface`, `ledge`, `swim`, `grapple`, `bash`, `throw`. Every other field, with its range and meaning, is in `MV.data.moveFields`. Moves and attacks also have `cost` (energy to start; for a hold move: energy per completed charge), hold moves have `drain` (energy per second), `recharge` and effects with `on: 'charged'`; effects can `do: 'energy'`. Items with `use: 'charm'` have `notches`, `grant` (an ability id) and `mods` (`[{ key, add }]`). Player tuning has the groups Energy, Charms and Death (see `playerSchema`). A move or attack may have `effects: [ { on, do, value, snd } ]` (`on`: start, hit, land, wall, end; `do`: bounce, refill, slow, teleport, knock, heal, endmove, sound).

## Events

```
{ id, name, on: true, once: "yes"|"no",
  trigger: { type, ...params },       // when
  conds:   [ { type, ...params } ],   // only if (all must be true)
  actions: [ { type, ...params } ] }  // then (in order)
```

The trigger, condition and action types and their parameters are listed in `MV.Events.SCHEMA` (`engine/events.js`). Flags are plain strings in the save state (`flags`); the engine writes `talked:<npc>`, `chest:<id>`, `boss_<id>`, `ev:<eventId>` (an event that ran once) and `evoff:<eventId>` (an event switched off).

## Audio

```
sounds: [ { id, name, src, vol, rate, vary, loop, music, syn } ]
sfx:    { jump, land, step, hurt, die, pickup, checkpoint, chest, splash, talk, door, switch }  // each is a sound id
vol:    { master, music, sfx }                                                                   // 0 to 1
```

`src` is an audio file inside the project as a data URL (`data:audio/wav;base64,...`). `syn` is present on sounds made with the sound maker (so they can be edited again).

## Save state (a playthrough, not the project)

`MV.Progress.fresh()` shows the shape: `{ v, abilities, flags, collected, opened, cp, weapons, weapon, items, stats, equipped, lostCoins }`. `stats` holds permanent upgrades (`maxHp`, `energyMax`, `charmSlots`: the amount added), `equipped` the charm item ids being worn, `lostCoins` the bag dropped at a death (`{ a, r, x, y, n }`) or null.

## Stability

New versions are meant to read files from older ones (missing keys get defaults), and new features add keys rather than change old ones. If you build a game on this format, read what you need by key and ignore the rest.
