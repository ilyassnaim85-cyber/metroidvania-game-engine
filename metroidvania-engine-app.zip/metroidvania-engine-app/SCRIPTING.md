# Scripting (JavaScript)

Scripts are plain JavaScript saved inside the project (Scripts tab). They react to game events and use a small `game` object. They run only while the game is playing.

## Quick start

1. Open the **Scripts** tab and press **+ New script**.
2. Write code. The status line under the box tells you at once if it does not compile.
3. Press Play in the World tab. Messages from `log(...)` and errors show in the Scripts tab console.

```js
on('room', ({ room }) => game.say('You entered ' + room));

on('boss', ({ id }) => {
  game.give('key_gold', 1);
  game.camera.shake({ amount: 0.4, time: 0.5 });
});

// a function the Events tab can call with the action "Run a script function"
fn('openGate', () => game.flag('gate_open', true));
```

## What a script can use

* `on(hook, function)` listen to a game event (hooks below). `on('roomenter', ...)` style names work as aliases.
* `fn(name, function)` offer a function. The Events action **Run a script function** calls it by name, with an optional text argument.
* `game` the API below. `log(...)` writes to the console.

### Hooks

`start`, `update(dt)`, `room`, `roomleave`, `key`, `death`, `hurt`, `flag`, `flagoff`, `item`, `ability`, `boss`, `bosswake`, `bossphase`, `enemy`, `zone`, `zoneleave`, `npc`, `var`. The editor lists what each one passes. Aliases: `roomenter` is `room`, `enemydefeat` is `enemy`, `bossdefeat` is `boss`.

An optional filter picks one thing: `on('flag', { flag: 'gate_open' }, fn)`.

### The `game` object

| Group | Calls |
|---|---|
| Player | `hp(v?)`, `maxHp()`, `heal(n)`, `hurt(n)`, `energy()`, `addEnergy(n)`, `coins(v?)`, `upgrade(stat, n)`, `player.x`, `player.y` |
| Progress | `flag(name, on?)`, `variable(name, value?)` |
| Items | `give(id, n)`, `take(id, n)`, `itemCount(id)`, `giveWeapon(id)`, `ability(id, on)` |
| Talk | `say(text)`, `dialogue(text, who, done)` |
| World | `room()`, `goRoom(id, x, y)`, `entities(type?)`, `entity(uid)`, `spawn(type, x, y, props)`, `event(id)` |
| Entities | each has `x y w h hp props boss`, and `moveTo(x, y)`, `damage(n)`, `remove()` |
| Effects | `sound(id)`, `music(id)`, `shake(a)`, `camera` (see CAMERA.md) |
| Timers | `after(sec, fn)`, `every(sec, fn)`, `cancel(id)`; `{ room: true }` ends a timer when the room changes |
| Other | `save()`, `isDown(key)`, `random()`, `tune()` |

Everything goes through the same code the Events tab uses, so a script and an event do the same thing.


## Scripted enemies, bosses and moves

Write the behaviour as a function with `fn('name', me => { ... })`. The function runs **every frame**; `me` is what it can read and do. Then point at it by name:

| What | Setting | Where |
|---|---|---|
| Enemy | **Moves = Script**, **AI script function** | Enemies tab |
| Boss | **AI = Script**, **AI script function** | Bosses tab |
| Player move | **Type = Scripted move**, **Script function** | Player settings > Moves and abilities |

Names can be up to 24 characters. The checker warns when a name has no `fn(...)`.

### Enemy brain

```js
fn('hunter', me => {
  me.dir = me.dx >= 0 ? 1 : -1;          // face and walk toward the player
  me.vx = me.sees ? me.dir * 4 : 0;
  if (me.sees && me.onGround && me.dist < 3) me.jump(9);
});
```

Read: `dt t dx dy dist sees x y w h hp maxHp onGround bumpX home player mem`. `dx` and `dy` point at the player. `mem` is an object that is yours for this enemy.
Set: `vx`, `vy`, `dir`. Do: `fly(true or false)` (no gravity while true), `jump(power)`, `shoot(vx, vy, { size, damage, color })`, `hitbox(x, y, w, h, damage)` (hurts the player this frame), `sound(id)`, `die()`.
The enemy's own settings still apply (health, contact damage, flinch, drops, and its built-in attack if you pick one).

### Boss brain

The boss still has patterns made in the Bosses tab. The script decides when to use them, and can also do its own attacks.

```js
fn('kraken', me => {
  me.turn(me.dx);                                    // face the player
  if (me.dist > 4) me.walk(me.dx, 3);               // walk toward them
  else if (me.ready('slam')) me.attack('slam');     // start an authored pattern
  else me.hitbox(me.x + me.facing * 1.5, me.y - 1, 2, 2, 1);   // or hurt the player in a box (world position)
  if (me.hpPercent < 50 && me.t > (me.mem.next || 0)) {   // your own timer: me.t is seconds, me.mem is yours
    me.mem.next = me.t + 5;
    me.shoot(me.facing * 8, 0, { size: 0.6 });
  }
});
```

Runs while the boss is idle (not in a pattern, stunned or changing phase). Read: `dt t dx dy dist x y w h hp maxHp hpPercent phase onGround facing patterns player mem`, `ready(patternId)`.
Do: `turn(dir)`, `walk(dir, speed)`, `move(vx, vy)` (floating bosses can move up and down), `moveTo(x, y)`, `jump(power)` (standing bosses), `attack(patternId)`, `hitbox(x, y, w, h, damage)`, `shoot(vx, vy, opts)`, `invulnerable(sec)`, `sound(id)`, `shake(amount)`.
Every move goes through the same walls, room edges, arena and leash as the built-in AI, so a script cannot push a boss out of its arena. `x` and `y` are the boss's feet (centre, bottom).

### Scripted player move

```js
fn('zip', me => {                        // runs every frame while the move plays
  me.vx = me.facing * 18;                // fast forward
  me.vy = 0;                             // no falling
  me.hitbox(1, 0, 1.5, 1.5, 2);          // hurt enemies one tile in front
  me.invulnerable(0.1);
  if (me.t > 0.2 || me.bumpX) me.end();  // stop early
});
```

Make a move in the Moves list, set **Type** to *Scripted move*, **Script function** to `zip`, a **Key**, and **Duration** (the longest it can last, up to 3 s). Cost, cooldown, uses, unlock ability and the other usual settings work.
Read: `dt t left duration dirX dirY x y vx vy facing onGround bumpX bumpY mem`, `held(key)`. Set: `vx`, `vy`, `facing`. Do: `gravity(multiplier)` (adds normal gravity), `hitbox(forward, down, w, h, damage)`, `invulnerable(sec)`, `sound(id)`, `shake(amount)`, `end(keepSpeed)`.
Attack boxes you draw on the move still work as well.

## Changing settings from a script

For the current play only; nothing is written to the project, and every value is held inside the same range the editor allows.

```js
game.player.tune('jumpHeight');          // read a movement setting (names as in Player settings)
game.player.tune('jumpHeight', 6);       // change it
game.player.tune('jumpHeight', null);    // put it back
game.player.setVelocity(0, -12);  game.player.invulnerable(1);

const e = game.entities('enemy')[0];
e.get('speed');  e.set('speed', 6);      // names as in the Enemies tab (numbers and choices only)
const b = game.entities('boss')[0];
b.set('damage', 3);                      // names as in the Bosses tab
```
`set` returns false for an unknown name or a bad value. An enemy's settings change only for that one enemy; a boss's settings change only for that boss.

## Safety and limits

* A script that throws is reported (name, hook and message) and the game keeps running. A handler that fails five times in a row is switched off for that play.
* Scripts cannot see `window`, `document`, `MV`, `localStorage`, `fetch` and similar names. **This hides them; it is not a security wall.** Only open projects whose scripts you trust. The editor asks before opening a project file that has scripts.
* **An endless loop (`while (true) {}`) freezes the game.** Use `on('update', ...)` or `game.every(...)`. The checker warns about it.
* Limits: 40 scripts per project, 60,000 characters each. A brain function that throws is reported once and its enemy simply stops moving that frame; five failures in a row switch it off for that play.
* Brain functions run every frame for every enemy that uses them. Keep them short.
* The World check panel and `tools/validate.js` report scripts that do not compile, unknown hooks, and events that call a function no script defines.

## For developers

`engine/script.js` (`MV.Script`: hooks, `clean`, `syntax`, `validate`, `Runtime`), `engine/game/13-script-api.js` (the `game` object), `editor/scripts_ui.js` (`scUI`). From the page: `MV.Game.script.errors()`, `.logs()`, `.clear()`, `.call(name, arg)`, `.functions()`. The project field is `scripts` (see FORMAT.md).
