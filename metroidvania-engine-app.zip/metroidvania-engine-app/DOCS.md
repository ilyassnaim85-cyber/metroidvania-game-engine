# Metroidvania Engine

A level editor plus a playtest runtime. The editor's JSON export (Ctrl+S) is the data contract
you can load from your own game (for example the SFML one); the JS runtime is for testing it.

## Project layout
- `index.html`  editor UI (world map, rooms map, room tile editor, sprites, entities, playtest launcher)
- `main.js`, `preload.js`  Electron shell (Save / Save as / Import, Undo / Redo menu items)
- `data/config.js`  designer-editable data: player tuning, abilities, entity types and their properties
- `engine/light.js`     room darkness and lights (room light level, player light, Light entities); also usable on its own
- `engine/animation.js` reusable sprite animation clips: validate, sample, play, draw, JSON import/export (see ANIMATION.md)
- `engine/boss.js`      boss data validation, keyframed hitbox patterns, and the boss fight logic
- `engine/moves.js`     validates the move list and registers each move's unlock ability
- `engine/sprite.js`    player sprite and animation frames, shared by the game and the editor preview
- `engine/tuning.js`    validates player tuning (clamps to the ranges in `playerSchema`)
- `engine/background.js`  room background drawing, shared by the editor and the runtime
- `engine/progress.js`  abilities, flags, collected items, opened doors, checkpoint; save/load with validation
- `engine/camera.js`    smooth follow, room-bound clamp, shake, per-room config
- `engine/game.js`      room loading, player controller, collision, entities, transitions, respawn, debug overlay

## Tabs and theme
Two tabs under the toolbar: **World editor** (everything below) and **Player settings** (the movement and attack
tuning on its own page, with "Reset to defaults" and a "Test in room" button). Switching tabs pauses a running
playtest and resumes it when you come back. The app is always dark mode.

## Projects and the start screen
The app opens on a start screen with **New project** (a name and a starting point: an empty world with one start
area, or the sea game map with 13 areas) and **Existing projects** (Open, Delete, and Open project file...). The toolbar
Projects button returns there. Each project keeps its own map and its own saved game (checkpoints, unlocked
abilities). The map you had before projects existed is kept as "My game (from the earlier version)". The project name
in the toolbar can be edited. Save (Ctrl+S) writes the project to a .json file: the first time it asks where, then it
overwrites that file; opening a project file remembers its path. Outside Electron, Save downloads the file. File menu:
New project (Ctrl+N), Open project file (Ctrl+O), Save, Save as, Close project. Projects are stored inside the app, so
Save to a file when you want a backup or want to move a project to another computer.

## Zoom and pan
The world map, the rooms map, the room editor and the boss arena all zoom and pan. Each has a bar above it: **-**, the zoom
percentage, **+**, **Fit** and **Reset view**.
- **Mouse wheel** zooms in and out around the pointer. **Shift + wheel** scrolls sideways. The scroll bars also work.
- **Pan** by holding **Space** and dragging, by dragging with the **middle mouse button**, or (on the two maps) by dragging the empty
  background.
- **Fit** zooms to the content: the areas or rooms on the maps (not the empty rest of a big map), the whole room or arena otherwise.
- **Reset view** returns to the default view: the whole map, room or arena at 100%, shrunk to fit when it is bigger than the window,
  scrolled to the start. The default is also what you see when you first open something.
- Keys (when you are not typing in a box): **+** and **-** zoom, **0** resets the view, **F** fits.
- Each room, each area's rooms map and each boss arena remembers its own zoom while the editor is open. Zoom is 10% to 800%, and
  stops earlier on huge rooms so the picture stays within what the browser can draw. Zoom is not saved in the project.

- **Big rooms:** press the Map button above the room for a minimap. Click or drag it to jump; it closes when you click the room or press Esc. Arrow keys pan (Shift = fast). The readout next to the zoom buttons shows the tile under the mouse, and Go to centres the view on a tile you type, like 500, 320.

## Lighting
Rooms can be dark. In a room, **Level Settings > Lighting** has:
- **Room light level**: 1 = fully lit (no darkness, the default, so existing rooms are unchanged), 0 = pitch black.
- **Player light radius** (tiles) and **Player light level** (0 to 1): the light the player carries, set separately for each room.
- **Preview lighting in the editor**: shows the darkness and the Light entities on the room (dimmed so you can still see the tiles).
  The player's own light only shows in a playtest.

Place **Light** entities from the **Entities** section to light areas. Each has a **radius** (tiles) and a **level** (0 to 1). A dashed
circle in the editor shows its radius. Lights are brightest in the middle and fade smoothly to nothing at the radius; overlapping
lights add up. Light entities are not drawn in the game, only their light. Values are clamped (radius 0 to 40 tiles, levels 0 to 1).
### How light looks
- **Walls block light.** Solid tiles (walls and slopes) cast real shadows, so a lamp on one side of a pillar leaves the other side dark. A lamp placed inside a wall shines out of it. Each lamp has **Walls block the light** (Yes by default); the player's light and the old Light item also cast shadows.
- The fade is smooth (no ring or hard step), the edges of shadows are soft, and coloured lamps add a glow on top of the scene.
- **Darkness shades the scene** instead of covering it: the picture is multiplied by a light map, so tiles, platforms and sprites stay readable in the shade (full darkness is a deep blue-grey, not flat black).
- **Flicker** (0 to 1) on a lamp makes its light waver, like a torch. 0 is steady.
- Rooms with a lot of big lights cost more to draw. If a room feels slow, use fewer or smaller lamps, or turn Walls block the light off for the far ones.

### Darkness
**Darkness** is a separate item from the lamp. In the room editor open **Entities** and drag the **Darkness (shade)** chip into the room. It shades a circle or polygon area, and you edit its shape exactly like a lamp (drag the middle to move, drag corners or the edge handle to reshape, Sides for a polygon).
- **Darkness amount** (0 to 1): how deep the shade is. **Shade colour**: the colour of full darkness (default deep blue-grey; pick black for true black).
- **Edge softness** (0 hard, 1 soft).
- Darkness fills the **room it is in and stops at the face of the walls** (the wall tiles themselves are not shaded; no blur past a wall; nothing leaks into the next room or behind the wall). It spreads through open space connected to the item, inside its radius or shape, so make the radius big enough to cover the room. Set **Walls stop the darkness** to No to let it go through walls.
- **Wall bleed** (0 to 1, default 0.2): how far the darkness soaks into a normal wall and fades out. 0 = blocked at the wall face, 1 = reaches the far side. It scales with the wall's thickness.
- **Shade wall** (Tiles palette): a solid wall that darkness passes through. Every other wall stops the darkness; a Shade wall lets it flow into the next room. It blocks the player and light like a normal wall.
- Lamps and the player's light still shine inside a darkness zone, because light is cut out of all the shade.
- The room's own **Room light level** (Level Settings > Lighting) is still the base darkness for the whole room.

### Slopes and light
Light and darkness follow a slope's diagonal: a lamp is blocked by the solid half under the slope, and a darkness zone shades only the open triangle above it. Fill the tiles under a slope with walls so the solid side reads correctly.

### Lamps
A **Lamp** is a light you can shape and colour. In the room editor open **Entities** and drag the **Lamp** chip into the room (or pick Lamp in the list and click the room).
- **Select** a lamp by clicking its middle (with the Entities section open). Drag the middle to move it.
- **Circle**: drag the square handle on its edge to change the radius, or type **Radius (tiles)**.
- **Polygon**: choose **Shape > Polygon**, set **Sides** (3 to 16), then drag any corner to make any shape you want. **Regular shape** resets the corners. Changing Sides also resets them.
- **Colour**: use the colour picker, or the **R, G, B** boxes (0 to 255). The light tints what it lights, even in a fully lit room.
- **Edge softness** (0 to 1, default 0.5): a lamp or darkness zone only affects the inside of its circle or polygon, never outside it. 0 = full strength right up to a sharp edge, 1 = fades out from the middle. The dashed outline in the editor is exactly where the effect stops.
- **Light level** 0 to 1 is how strongly the lamp lights its area (0 = off, 1 = full). A lamp only ever adds light: to make something darker, use a **Darkness** item (below).
- In code: `MV.Light.fromEntities(ents)` returns lamps with `shape`, `pts` and `color`; `MV.Light.draw` and `levelAt` accept them. The older **Light** entity still works (circle, no colour).

`engine/light.js` has `MV.Light.levelAt(ambient, lights, x, y)` if game code needs to know how bright a spot is.

## Level editor sections
In a room the Level Editing header has four sections, each with its own tools: **Tiles** (Wall, Platform, Slope up-right, Slope up-left,
Water, Transition, Erase: terrain and layout only), **Entities** (pick a type, such as Enemy, Pickup, Hazard, Checkpoint, Locked door,
Switch, Breakable wall, Moving platform or Boss, then click the room), **Sprites** (your sprite table, Open all sprites, Erase sprite) and
**Bosses** (drag a boss with its arena onto the room). Opening a section selects the right tool, so a click on the room always does what
the section says. Maps made earlier that contain the old Enemy, Boss, Hazard and Pickup tiles still load, draw and play; use Erase to
remove them.

## Editor layout
Top toolbar: Save, Undo, Redo, save status, breadcrumb (World > Area > Room) and Import / Export JSON.
Room size goes up to 10000 x 10000 tiles (the editor draws only the visible part; rooms over 1,000,000 tiles are saved run-length packed). Entities are chosen from a button grid.
Left column: Sprites panel (room sprite table, sprite library) above Level Settings (map size, room size,
camera, collision view, transitions, entities, playtest setup). Right column: Level Editing header (modes
or tile tools, transition and entity pickers, Play) above the main canvas. Below 900 px wide the columns stack.

## Player movement settings
Defaults, units and allowed ranges live in `data/config.js > playerSchema`; the movement code lives in
`engine/game.js`. The Player settings tab is built from that schema: max run speed,
acceleration, deceleration, air control, jump height (tiles), gravity, max fall speed, short-hop cut, coyote time,
jump buffer, attack swing time, attack cooldown and attack reach. Your changes are stored with the map
(`player` in the JSON, only values that differ from the defaults), are clamped to the allowed range, and take
effect in any playtest (a paused playtest picks them up when you return to it). "Reset to defaults" clears them. Add a new setting by adding an entry to
`playerSchema` and using it in `engine/game.js`.

## Level background
Level Settings > Background (per room): a color, an optional image, how it fits (Cover room, Stretch, Tile)
and how much it scrolls with the camera (0 fixed on screen, 1 moves with the room). Import an image there or pick
a sheet you already imported. It shows in the editor canvas and in playtests. Removing the image from the
sprite library clears it from rooms that used it.

## Animation Studio
The **Animations** tab makes reusable sprite animation clips (frames in playback order, a timeline with per-frame length and event
markers, Loop / Play once / Ping pong, a pivot and a preview). Clips are saved with the project and are part of undo and redo. They
can be exported and imported as JSON with their sprite sheets. Full guide, JSON format and the runtime API are in **ANIMATION.md**.

## Bosses
The **Bosses** tab (top) makes a boss together with its arena. **New boss** starts with two example patterns, a claw
swipe and a thrown rock. Make as many as you like.
- **Arena**: paint the fight room with the tile tools (wall, platform, hazard, slopes, water), set the Boss spawn, and
  set the arena size.
- **Patterns**: a pattern is a timeline. Pick a pattern, move the time slider, then drag a hitbox (or the boss itself) to
  where it should be at that moment. Each drag makes a keyframe and the hitbox moves between keyframes, so a thrown
  hitbox is just two keyframes far apart. The timeline under the arena shows the keyframes as diamonds: click one to
  select it, drag to change its time, Delete keyframe to remove it. Play previews the pattern. Positions are measured
  from the boss's feet and mirrored when the boss faces left.
- **Hitbox settings**: size, "Hurts from / until" (when it can hurt you), "Moves with the boss" (for swings) or flies on
  its own (for projectiles), and **Look**: a sprite animation drawn on the hitbox, such as a thrown rock. Without one it
  shows as a red box. The "Boss movement" row moves the body (jumps, charges). Each pattern has a boss animation name.
- **Three animation states**: Passive plays in a loop while the boss has not seen you. Awakened plays once when you come close (turn Loop off); the boss cannot attack or be hurt until it ends, and a hit on a sleeping boss only wakes it. Normal plays during the fight between attacks. Each pattern's animation plays during that pattern. Anything empty uses Normal. A small preview plays the selected animation, and under the keyframe timeline a strip shows the boss and hitbox frames lined up with the time axis.
- **Boss animations and phases**: give each state an animation like the player's (states come from the patterns'
  animation names, plus Idle). Phases switch the pattern set, the pause between patterns and the speed when health drops
  to a percentage. With no phases the boss cycles through all patterns.
- **In the game**: the boss wakes when you come within its wake distance, runs its patterns, and anything touching a
  hitbox sends you back to your checkpoint, like other hazards. Your attack hurts it, a health bar shows at the top, and
  when it is defeated it sets the flag `boss_<id>` (or your own flag), can give an ability, and stays defeated.
- **Placing a boss in a level**: in the level editor use the **Bosses** section next to Tiles and Sprites. Drag a boss
  card onto the room (or click the card, then click the room). The arena is stamped into the room around the drop point,
  the room grows if the arena is bigger, and the boss is added. The arena is a copy, so repaint it by dragging again; the
  boss itself (health, patterns, animations) stays linked, so changes apply to every room that uses it.

## Moves (any movement)
**Two keys:** every move has Key and Also hold. Click Press a key and press the key you want, or pick from the list.
Down dash is Shift with Down held; Upper dash is Shift with Up held. Any pair works, for example O held and P pressed.
When a key press matches several moves, the one with a second key wins, so Shift alone still gives a normal dash.
**Animation:** dash and impulse moves have an Animation section: pick a sprite sheet, the first column and row, the
number of frames and the speed. The strip under it shows each frame across the move's duration (a 0.16 s dash with
4 frames shows 4 cells). "Fit all frames into the duration" spreads the frames over the dash exactly; turn it off to use
your own frames-per-second. The player plays it for the length of the move. Hold and swim moves use the Fall and Swim
animations in the Player sprite panel.
Player settings > Moves. A move is a row of numbers: type (impulse = one push, dash = timed velocity, hold = while a
key is held, swim = in water), key, where it can start (any, ground, air, water), direction (forward, up, down, input,
or a fixed angle), speed, acceleration, gravity multiplier, duration, cooldown, uses per air time, momentum kept and
stop-when-blocked. "Unlocked by" is an ability id that a pickup gives; empty means always available. There are no ready-made moves (see 3.4.0 below); you build each one with New move, duplicate, edit or delete. Values
are clamped to their allowed range. Water tiles (`~`, Water in the room tools) enable swimming. Wall jump and wall slide
are built in and unlocked by the ability id `wallJump`.

## Player sprite and animations
Player settings, right column: a live preview of the player with an animation editor below it. Each state (idle, run,
jump, fall, dash, wall, attack, swim) can have its own animation: pick or import a sprite sheet (Aseprite PNG), set the
frame size, the first column and row, the number of frames, the speed and loop. States without one use Idle. The game
draws the animation, flipped when facing left. Without any sprite the game draws a box. Draw size is set in tiles.

## Comments
Areas and rooms have a comment: "Edit name and size" mode (or the Area comment / Room comment boxes in Level Settings).
Boxes with a comment show a pencil and the comment on hover.

## Level background (4 layers)
Level Settings > Background: a color plus a far, middle and near layer, and a front layer that always draws over the player. Each layer has an image, a fit (cover, stretch,
tile), a camera scroll (0 fixed on screen, 1 moves with the room, above 1 faster for depth) and a choice to draw behind
the game or in front of the player. Older single-image backgrounds become the far layer.

## Sprites in the level editor
In a room, the Level Editing header has Tiles and Sprites tabs. Sprites shows this room's sprite table, Open all sprites
(import PNGs, right-click drag to pick sprites) and Remove chosen sprite.

## Save, undo and redo
- The map is still auto-saved inside the app after every change.
- Save (Ctrl+S) writes a JSON file: the first time it asks where, then it overwrites that file. Importing a file
  makes Save overwrite it. Save as: Ctrl+Shift+S. Outside Electron, Save downloads the JSON.
- Undo (Ctrl+Z) and Redo (Ctrl+Y or Ctrl+Shift+Z) cover map edits: moves, connections, sizes, tiles, sprites,
  entities, transitions, imports. Rapid edits within half a second merge into one step. 100 steps are kept.
  Inside a text field, Ctrl+Z undoes the text instead. History resets when the app restarts.

## Workflows
- **Tune an ability**: edit its numbers in `data/config.js` (dash speed, wall-jump kick, double-jump count...).
  `requires` lists abilities that must be unlocked first.
- **Add an entity type**: add an entry in `data/config.js > entities` with a color, size and `props`
  (`t`: text | number | select). The editor builds its property form automatically. Behaviour for the built-in
  types lives in `engine/game.js`; a brand-new behaviour still needs a small handler there.
- **Place entities**: Entity tool + type in the room editor. Edit properties in "Entities in this room".
- **Gate routes**: a Locked door's `requires` is an ability id or `flag:name`. A Switch sets/clears its flag.
  A Pickup with kind `ability` unlocks that ability (if prerequisites are met); kind `flag` sets a flag.
- **Checkpoints**: touching one stores the respawn point (in any room). Dying respawns there.
- **Slopes / one-way / water**: tiles `/` and `\` (slopes), `=` (one-way), `~` (water). Hazards (spikes) are an entity: Entities section, type Hazard (width and height are editable). Turn on
  "Show collision shapes" in the room editor or playtest to inspect them.
- **Camera**: per room, Follow or Fixed plus smoothing (0.02 slow, 1 instant). Leave Smoothing empty to use Player settings > Camera; a number there overrides both directions for that room.
- **Playtest any room**: choose abilities and flags under Playtest, then Play this room. "Use my saved game"
  plays with, and writes to, the real save; otherwise the session is temporary.

## More entities
Pick these from the entity chips in the room editor. Each one has its own properties.
- **Low gravity zone** (`lowgrav`): width, height, gravity (default 0.3 of normal). The player floats inside it.
- **Message zone** (`msgzone`): width, height, text, once. Shows the text while the player stands inside.
- **Teleporter** (`teleporter`): channel. Two teleporters with the same channel are a pair.
- **Ice** (`icezone`): width, height, slip (default 0.02, lower is more slippery). Works on the tile row it covers or the tile above it.
- **Mud** (`mudzone`): width, height, slow (default 0.45 of normal speed).
- **Chest** (`chest`): reward (coins, key, flag, ability), amount, give, name, message, key. The message shown on opening can be customised.
- **Refill orb** (`orb`): respawn seconds. Refills dash and jumps.
- **Character** (`npc`): name, passing (a line said as you walk by), range, dialogue, after, key. In dialogue, a line starting with `>` is the player speaking; other lines are the character. The talk box uses the sprite chosen in the Player settings dialogue section.
- **Animated sprite** (`animsprite`): clip, width, flip, layer, when, near, flag, idle, finish. `when` picks the trigger: always, room start, player touches, player stands in it, breakable wall hit, breakable wall broken, collapsing ground shakes, switch toggled, chest opened, flag set. Wall, ground, switch and chest triggers listen to the nearest matching entity within `near` tiles, so place the sprite next to it. `idle` is what shows before it plays (hidden or first frame) and `finish` is what is left after a one-shot (hide or hold last frame).

## Light zone
Entities > Light zone is a lamp-like shape (circle or polygon with draggable corners). From outside it is dark, like a secret room; while you stand inside its shape it lights up (fade seconds), and it goes dark again when you leave unless "stay lit" is yes. With "Darken the outside while you are inside" on, entering also darkens everything outside the shape, so the shape is a pool of light. Its shade stops at walls and has the same soft wall shading as a Darkness zone. It does not change the room's own lighting.

## Animated entities
Locked door, Switch, Breakable wall, Collapsing ground, Chest and Bounce pad can wear animations from the Animations tab. Select the entity on the room and pick a clip for each state in its properties (door: idle, open. switch: off, on. breakable: idle, hit, broken. collapsing: idle, shake, fall. chest: closed, open. bounce pad: idle, bounce). An empty slot falls back to the idle clip, then to the built-in look. The sprite is scaled to fit inside the entity's footprint, anchored at the bottom centre. Breakable walls and collapsing ground repeat it once per tile. For reacting to events on something other than these six, use the Animated sprite entity.

## Room layers
In the room editor press **Layers** (next to the Map button). Tiles, Scenery (sprites and background) and Gameplay objects (entities, bosses, lamps, transitions) each have a Shown/Hidden toggle and a Locked toggle. Hide a layer to see the others clearly; lock one so you cannot change it by accident while working on another. This only affects the editor, never the game.

## Tiles and tile tools
- **Blocks:** Wall, Shade wall, Half block, Platform (one-way), Glass (solid, light passes), Invisible wall.
- **Slopes:** steep 45 degree slopes, and gentle slopes made of two tiles (the Gentle 1 and 2 pieces go side by side).
- **Surfaces:** Ice, Mud, Belt left and right, Bounce.
- **Special:** Back wall (scenery). Ladders, breakable walls and crumbling ground are entities, not tiles.
- **Tools:** Pencil (with Brush size and Mirror left-right), Line, Rectangle, Outline, Ellipse, Ellipse outline, **Ramp**, Fill, Replace all, Pick tile (or hold Alt), Select (move, copy, cut, paste, flip, fill, delete), and **Frame room**.
- **Ramp:** drag from one end of the slope to the other. A shallow drag makes gentle slopes, a steeper one makes 45 degree slopes. Fill under ramps fills the empty tiles below it with walls.

## Compatibility
Existing maps load unchanged. Old `e`, `B` and `*` tiles still act as enemy, boss and coin. Rooms gain `ent`
and `cam` fields; exported JSON stays backwards compatible.

## Not built yet
Grapple and swimming, map screen and icons, dialogue/events, boss phases and attack patterns,
audio and particles, world validation (unreachable rooms, softlocks), versioned backups and crash recovery.


## Camera settings
Player settings > **Camera** shapes how the view follows the player in every room:
- **Follow delay** (s): after you leave the dead zone the camera waits this long before it starts following, then eases in. 0 = no delay.
- **Dead zone, sideways / up and down** (tiles): you can move this far from the centre of the screen before the camera moves at all. A tall dead zone stops the view bobbing on every jump.
- **Horizontal / Vertical smoothing**: 0.02 = very lazy, 1 = locked to you. Set them apart, for example lazy vertical and quick horizontal.
- **Look ahead** (tiles) and **Look-ahead speed**: the view leans toward the way you face and swings over when you turn.
- **Look down when falling** (tiles): extra view below you during fast falls.
- **Vertical offset** (tiles): positive moves the view down (you appear higher on screen), negative moves it up.

With everything at its default the camera is the same as before. Settings are saved with the project like the other player settings. In code, `MV.Camera.update(dt, tx, ty, vw, vh, roomW, roomH, roomCam, snap, player, tuning)` takes the player's `{ face, vx, vy }` and the resolved tuning.

## Player attacks
Player settings > Attacks: an attack is a timeline of moving hitboxes (keyframes from the middle of the player's feet, x forward, y up is negative), a speed curve (multiplier of the forward speed over time) and an animation. Saved in the project as `attacks`. See README 3.1.0.

## Moves and attacks on a timeline
A move or attack has `hit` / `hitboxes` (moving hitboxes), `curve` (speed multiplier over time) and `path` (the player's own movement: keyframes `{t, x, y}` in tiles from where it started, x forward, y up is negative). Move types: impulse, dash, roll, grapple, path, hold, swim. The Grapple point entity (`grapplepoint`) is something a grapple hook can stick to. See README 3.2.0.


## Version 3.3.0: Moves and abilities, test room, clips, basic view
- **Moves and abilities** tab: Core movement is the first list item; other moves follow.
- **Test movement**: floating test room using the real game physics, live-updating; falling in a gap restarts at the spawn.
- **Animation clips**: in Sprite and animations, each state can use an Animation Studio clip instead of a sheet (the sheet fields hide when a clip is set; Clear removes both).
- **Basic / Advanced**: stored in the browser (`mv_pview`), default Basic. Advanced shows the timeline and all fields.


## Version 3.4.0: hitbox, attack boxes and building from scratch
- **Body hitbox** (Player settings > Hitbox): the shape of the part of the player that gets hurt. Rectangle (follows the player size unless you set it), circle or polygon, with an offset. Walking and tile collisions still use the plain body size from Settings.
- **Timeline Body hitbox row**: periods in which the body hitbox is off (`body.off`: list of from/until seconds). While off, hurtP ignores all damage, including hazards and boss attacks. A fall out of the room still resets you.
- **Attack boxes** (the old "hitboxes"): `shape` is `rect`, `circle` (`r`) or `polygon` (`pts`, corners in tiles from the middle). The game tests the real shape against enemies, breakables and bosses.
- **Moves**: types `dash` (shown as Timed move), `impulse`, `hold`, `swim`; `roll`, `grapple` and `path` are still understood in old saves. `squash` (body height) works for any timed move. `iframes` was replaced by `body.off`; old data is converted when loaded.
- New projects have `moves: []` and `attacks: []`. The preset buttons are gone.


## Version 3.5.0: Controls
- `S.controls = { keys: {Left,Right,Up,Down,Jump: [codes]}, pad: {Jump, Interact: button 0-11 or -1, 'm:<moveId>' / 'a:<attackId>': button} }`, validated by `engine/controls.js` (`MV.Controls`). Logical key names in moves and attacks (Jump, Up, Down, Left, Right) resolve through it.
- Gamepad: the game polls `navigator.getGamepads()` every frame. Button presses become virtual key codes `Pad:<name>` that go through the same path as keyboard keys. Left stick (threshold 0.5) and D-pad buttons 12 to 15 steer.
- `MV.Controls.conflicts(ctl, moves, attacks)` returns the warning texts shown in the tab.


## Version 3.6.0: more moves
- `body.kf` (list of `{t,w,h,x,y}`): the body hitbox gets this size and offset at time t, gliding between keyframes (`MV.Attacks.bodyKf`, `bodyWorld(..., ov)`).
- Move type `sequence`: `steps` is a list of `{name,dur,vx,vy,gravity,steer,until}`; `until` is time, land, wall, ceiling or release. Its duration is the sum of the step lengths.
- Move type `surface`: `surface` (wall or ceiling) and `mode` (stick, climb, run), active while the key is held, in the air, touching it.
- On timed moves, impulses and attacks: `chainTo` (`m:id` or `a:id`) and `chainWin`; `charge`, `chargeMult`, `chargeLock`; `shots` (`at, shape, w, h, r, speed, angle, ox, oy, gravity, life, damage, pierce`); `effects` (`on`: start, hit, land, wall, end; `do`: bounce, refill, slow, teleport, knock, heal, endmove; `value`).


## Version 3.11.0: Hitbox tab removed

Player settings no longer has a Hitbox tab. In a move's or attack's Hitbox section the Editing menu switches between that move's hitbox through time and the normal hitbox (shape and size, all the time).

## Version 3.10.3: gravity with a route

A move with a route (two or more points in Path and speed) now also obeys Gravity x: the player falls on top of the route and lands on the floor. Direction, Angle, Speed and Acceleration are replaced by the route.

## Version 3.10.2: routes and Stop when blocked

A move or attack with a route of two or more points (Path and speed section) moves along the route; Direction, Angle, Speed, Acceleration and Gravity are not used then (the speed curve, Duration, Keep speed and Stop when blocked are). With fewer than two points the plain settings apply. Stop when blocked ends the movement when a wall is in the way or the player hits a ceiling; the floor does not count.

## Version 3.10.1: test room fix

The Movement test room: clear ground for 10 tiles to the right of the start (breakable wall at x 22, short gap at 24 to 27, enemy near 29, spikes at 33 and 34, breakable wall at 35, wide gap 36 to 46). If a hazard (spikes or a fall) hurts you, you go back to the last safe spot and a message in the test room says so.

## Version 3.10.0: sprite tools

World editor > Sprites. Choose a sprite in the table, then pick a tool:

- Place: one click, one sprite. Pencil: drag to place along the path. Line, Rectangle, Outline, Ellipse, Ellipse outline: drag a shape; with **Fit to sprite size** on, sprites are spaced by their own width and height (a rectangle of 2x1 sprites steps 2 tiles across).
- Pick sprite (or hold Alt with any tool): click a sprite in the room to choose it as the brush.
- Select: drag over sprites to select them (any sprite touching the box). Drag inside the selection to move it. Copy / Cut / Paste (click the room to place), Delete, Flip left-right and Flip up-down (mirror the layout inside the selection). Ctrl+C, Ctrl+X, Ctrl+V, Delete and Esc work too.
- Erase sprite: drag to erase every sprite you pass over.
- Replace: a sprite placed on a tile where another one starts replaces it (off: they stack). Mirror left-right: also places the sprite on the other side of the room.

## Version 3.9.0: moves and attacks rebuilt around the hitbox

Player settings > Moves and abilities (and Attacks): pick a move or attack, then use the section buttons above its settings.

- **Move** or **Attack**: the plain settings (key, unlock, speed, duration, cooldown, damage...).
- **Hitbox**: the player hitbox through time. Drag the slider (or click the strip), drag the green box to move it, drag a corner square to resize it. Typing a width, height or offset also makes a keyframe at the current time. Click a diamond to select a keyframe and drag it to change its time. Invincible periods are from/to seconds; nothing can hurt the player during them. The shape (rectangle, circle, polygon) and normal size: choose "The normal hitbox" in the Editing menu above the picture.
- **Attack boxes** (Advanced): what hurts enemies, moving and changing shape through time.
- **Path and speed** (Advanced): where the player goes during the move or attack, and the speed curve.
- **Shots and effects** (Advanced): combos, charging, shots, effects on start/hit/land/wall/end.
- **Animation** (Advanced): the picture shown while it plays.

In Test movement and the playtest the player picture is drawn to match the hitbox (it moves and stretches with the keyframes). In the Hitbox editor only the hitbox moves.

## Version 3.8.0: hitbox you move on the screen

Player settings > Hitbox. "Edit the hitbox for" chooses the normal body (always) or one move or attack.

For a move or attack:
- The time slider (and the strip under the picture) sets the time. Drag the green box to move it, drag a white corner square to resize it. This writes a keyframe (size and place) at that time; the first keyframe also adds one at time 0 with the plain hitbox so it glides from there.
- Click a diamond on the strip to select a keyframe, drag it to change its time; Delete keyframe removes it.
- Invincible periods: from and to in seconds. Drag the orange bars (or their ends) or type the numbers. The timeline is as long as the move or attack lasts, so raise the duration if you need later times.
- Play previews the movement.

In the Hitbox tab only the hitbox moves; in Test movement and the playtest the player picture matches it (moves and stretches with it).

## Version 3.7.0: clearer Moves and Attacks
Basic view shows Usable. New moves and attacks get numbered names. "Unlocked by" and pickup/chest "give" use a shared ability picker (ids are letters, digits, `_` and `-`). Deleting all moves or attacks asks for confirmation.

## Version 3.12.0: attack periods, shapes, key combos
Attack boxes have "Hurts from" and "Hurts until" in seconds; typing a time beyond the move or attack length extends the length (multi-step moves keep the length of their steps; moves max 3 s, attacks max 5 s). Circle and Polygon are available in Basic and Advanced. "Add key" in a move or attack adds keys to `more` (max 5): all must be held together with Key and Also hold, and the most specific combo is chosen when several match.

## Version 3.13.0: grapple, bash, throw
Pick the move Type: Grapple (Hook reach, Hook speed, Pull speed, Hook sticks to), Bash (Hook reach = how close the orb must be, Aim time, Speed, Duration) or Throw (Direction, Speed, Hook reach = how far the item flies, Gravity x for an arc; press the key again to teleport to it, and the item lands in the nearest free spot). Place Grapple points, Bash orbs and Sticky surfaces from the Entities list of the World editor.

## Version 3.14.0: multi-step, While held, Wall or ceiling
Multi-step moves: `repeat` (1 to 9) plays the list of steps several times; each step has `accel` (tiles/s each second), `aim` (forward or input) and `until` can be `jump`. While held: `fuel` (seconds per air time, 0 = unlimited) and `side` (0 to 1, sideways speed). Wall or ceiling: `slide` (tiles/s while clinging), `fuel` (stamina, refilled by landing, not by jumping off) and `kick` (jump-off push).

## Version 3.15.0: charge time, wall hitbox animation
`windup` (While held): seconds the key must be held before the move starts; the charge is lost when you let go. Wall or ceiling moves accept `body` (keyframes, off periods), `hit` (attack boxes), `duration` and `loop`; the animation clock starts when you grab the surface and stops when you let go.

## Version 3.16.0: Wall or ceiling path and speed
Surface moves accept `path` (route, relative to the grab point, x toward the wall) and `curve` (speed multiplier over the clinging clock). With a route the player follows it for `duration` seconds (or forever with `loop` yes); without one, the curve scales the climb or run speed. Jump still lets go.

## Version 3.17.0: weapons
`weapon` on an attack (letters, digits, - and _). Progress state gains `weapons` (owned ids) and `weapon` (the one in hand). Pickup kind `weapon` and Chest reward `weapon` call giveWeapon, which also equips it. Tab cycles through owned weapons in the order the attacks list first mentions them. An attack whose weapon is not in hand does not start (chained attacks still follow their parent).

## Version 3.18.0: inventory
`S.items` is a list of `{id, name, desc, max, use, amount}` (use: none or heal). Progress state keeps `items` as `{id: count}`. Pickup kind `item` and Chest reward `item` add `amount` of an item with `MV.Inventory.add`. `Progress.has` (and so "Unlocked by") counts items you carry. The inventory screen opens with I and pauses the game; Up/Down choose, Enter uses or equips, I or Esc closes.

## Version 3.18.1: throw item
Throw moves have `life` (seconds the item stays, 0 = forever). Teleporting searches in a 4 by 3 tile area around the item for the nearest spot where the body fits. When the item fades the move's cooldown starts.

## Version 3.18.2: Bash launch
At the end of the launch phase a Bash move multiplies your velocity by `keep` and, when `keep` is above 0, holds that sideways speed for 0.12 + 0.3 x keep seconds (the wall-kick mechanism) before normal control returns.

## Version 3.18.3: keys held
Test-room overlay listing the held key codes, to tell a keyboard that cannot send three keys at once apart from a game problem.

## Version 3.19.0: wall jump off by default
The playtest ability list starts with Wall jump unticked and the Movement test room grants every ability except wallJump. Pickups (give wallJump) still unlock the slide (`slide`) and kick (`kickX`, `kickY`, `kickTime`).

## Version 3.20.0: inventory design
`S.inv` holds the design: `title`, `key`, `tabs` (`{id, name, kind: items|weapons|abilities, icon}`), `layout`, `cols`, `slot`, `w`, `h`, `opacity`, `dim`, `slota`, `radius`, `bwidth`, `font`, `detail`, colours (`panel`, `border`, `text`, `muted`, `accent`, `slotc`), the panel picture (`sheet`, `slice`, `scale`) and `meta` (`w:<weapon id>` and `a:<ability id>` entries with name, desc, icon). Items gain `tab` and `icon`. `MV.Inventory.draw` renders both the game screen and the editor preview.

## Version 3.21.0: more movement
Move fields added to `MV.data.moveFields`: `on` (air|air and ground|ground), `runs`, `sqw`, `nojump`, `state`, `fly`, `phase` (no|walls|soil) for `hold`; `how` (pull|swing), `grab`, `climb` and type `ledge`. Engine: `HF` (hold effects) is built every frame in `sim()`; `p.hq/hwid/hst` are the held body height, width and animation state; `p.gh` is the ghost mode read by `tl()` (soft ground `s` is solid unless `p.gh`); `p.lg` ledge state, `p.rl` rail state, `p.cn` cannon state, `p.ride` mount state. Entities: `rail`, `cannon`, `mount`, `airpocket`. Tuning: `oxygen`, `airRefill`, `drownEvery`, `drownDmg`; ability `waterBreath`. Sprite states added: crouch, sprint, morph, ledge, pullup, swing, zip, cannon, burrow, ride, drown, phase, fly.

## Version 3.22.0: camera
`engine/camera.js` takes a config from `camCfg()` in game.js: `{id, blend, p (profile settings merged over the player tuning), follow, box, brk}` and a player snapshot from `camPl()`: `{face, vx, vy, on, up, dn, dir, ledge}`. Profiles live in `world.camProfiles` (`MV.Camera.cleanProfiles`), built-ins in `MV.data.camPresets`, extra fields in `MV.data.camExtra`. Rooms store `room.cam = {profile, follow}`. Entity `camzone` (props `profile`, `bounds`, `blend`). `ledgeNear()` is the drop check. Script API: `MV.Game.camera.set/reset/get/list`.

## Version 3.23.0: Phase 1
`engine/events.js` (`MV.Events`: schema, `clean`, `validate`, `Runner`), `engine/audio.js` (`MV.Audio`: library, slots, music, `sync` for the editor, `setup` for a playtest, `log`), `engine/background.js` (layers, blur, fog). Editor screens: `editor/events_ui.js` (`evUI`), `editor/audio_ui.js` (`auUI`). The World check merges `MV.Events.validate` and `MV.Audio.validate` (see `wValRun`). Event API: `MV.Game.events.log/run/list/running`. JavaScript scripting: see `SCRIPTING.md` (`engine/script.js`, `editor/scripts_ui.js`). The editor script is split into `editor/app-NN.js`; keep their order in `index.html`. Checks: `tools/validate.js`, `tests/unit.js`, `tests/browser.js`, format in `FORMAT.md`.

## Version 3.24.0: Phase 2
`engine/game.js`: `G.mp` is the energy, `afford/spend/gain` handle it, `bonus()` adds `st.stats` and equipped charms to `G.tune` every frame (so editor changes show at once), `die()` applies the Death rules (and the `G.dscr` death screen), hold moves use `p.hw` (charge) and `p.hd` (charge done). `engine/inventory.js`: `use: 'charm'`, `MODS`. `engine/progress.js`: `stats`, `equipped`, `lostCoins`. `engine/world.js`: progression checks in `validate`. Editor: `tplUI` (templates) in `editor/app-02.js`. Test hooks in `MV.Game`: `energy`, `energyMax`, `maxHp`, `coins`, `charms`, `hurt`, `dying`, `attackList`.

## Version 3.25.0: Phase 3
`engine/enemies.js`: `MV.Actor.hit` (shared damage rule) and `MV.Enemies` (`FIELDS` with their groups, `CLIPS`, `SNDS`, `clean1`, `resolve`, `find`). Project field: `enemies` (a list, up to 40). `engine/game.js`: `G.ed` (resolved types, re-read every frame so editor changes show at once), `enemyTick` (behaviour, attack states `wind` and `dash`, hit reaction, contact), `eMove` (box physics against blocks, half blocks and platforms), `enemyDie` (drops, event, death animation), `enemyDraw`, `G.es` (shots fired by enemies). `hurtP` takes an override `{ k, s }` for knockback and stun. Editor: `editor/enemies_ui.js` (`enUI`). Entities: `enemy` has the prop `kind`. Test hooks: `MV.Game.enemyShots()`.

## Version 3.26.0: Phase 4
`MV.Attacks.shapeHit(a,b)` (shape against shape; `outline`), `MV.Enemies.bodyShape/weakWorld/strikeWorld/ptsOf/weakOf`, enemy fields `shape`, `pts`, `weak`, `weakOnly`, `touch`, `strike`, attack kind `strike`. Boss: `MV.Boss.hbShape`, `reset`; boss fields `shape, pts, weak, weakOnly, damage, knock, stun, invul, restart, wakeSnd, hurtSnd, phaseSnd, dieSnd`; pattern `warn`, `snd`; hitbox `shape, r, pts, dmg`; phase `enter`. Boss env for `MV.Boss.tick`: `hurt({d,k,s})`, `bodyS(shape)`, `snd(id)`.

## Version 3.27.0
`MV.Anim`: frames may carry `x, y, w, h` (a free rectangle); `MV.Anim.rectOf(frame, sheet)` and `customRect(frame)`. `MV.Boss`: `CLIPS`, `clipNow`, boss field `clips` ({state: clip id}), `stagger, staggerTime, staggerMult, stunSnd`; pattern `clip`, `inv` (list of {from,to}); hitbox `clip`; env hooks `anims`, `die(e, def)`. Camera presets: `default` is Hollow Knight style, `plain` is the old follow.

## Version 3.28.0
Camera system: see CAMERA.md. Game code calls `MV.Game.camera.*`; profiles gain the fields in `MV.data.camExtra`; player options are in `MV.data.camUser`.

## Version 3.29.0
Boss AI: `MV.Boss.tick(e, dt, env)` now needs `env.room {gw, gh}` and `env.blocked(cx, by, w, h)` for collision (both optional; without them the boss is not contained). `env.rand()` is optional. New boss fields: `select`, `speed`, `keep`, `fly`, `leash`. New pattern fields: `min`, `max`, `at`, `hpBelow`, `hpAbove`, `cd`, `weight`, `track`, `reach`.

## Version 3.37.0
`MV.UI` (engine/ui.js): `FIELDS`, `def()`, `clean(o)`, `hud(ctx, w, h, ui, state)`, `messages`, `bossBar`, `death`. The project has a `ui` object (cleaned with `MV.UI.clean`). `MV.Boss.hud(ctx, G, w, ui)` takes the settings as a fourth argument. Items: new `use` values `energy`, `upgrade`, `script`; new item fields `stat`, `fn`, `keep`. Boss fields `dropItem`, `dropAmount`, `dropCoins`; `env.drop(def)` in the boss env. Pickup prop `again`. Script hook `use`.

## Version 3.38.0
`MV.UI`: field type `sprite` (a cleaned `MV.Attacks.anim` or null); `hud(...)` and `bossBar(...)` take `getSheet, time` as extra arguments; new `menu(ctx, w, h, ui, { kind: 'title'|'pause', title, subtitle, items: [{ id, label }], sel }, getSheet, time)` returns the button boxes; `hitAt(boxes, x, y)`, `point(canvas, event)` and `spr(...)`. `MV.Game.start` takes `quit` (a function: shows a Quit to title button in the pause menu); `MV.Game.pauseOpen()` and `MV.Game.size()` are new.

## Version 3.39.0
`MV.UI`: `options(ctx, w, h, ui, { kind, rows, sel }, getSheet, time)`, `optRows(ui, vol, canFull)`, `stepVal(v, dir)`, `sliderAt(box, x)`, `spr9(...)` (nine-slice); HUD items take `icon`. `MV.Audio.getVol()`. `MV.Game.start` takes `fullscreen` (true shows Full screen in the options), `vol` (volumes to start with) and `onVol(vol)` (called when the player changes them).

## Version 3.40.0

UI tab additions: a Fonts box (your own font files, saved in the project as `fonts`), a Minimap group (`mapShow` and related keys), and a Controls page in Options. Progress now stores `seen` (rooms visited).

## Version 3.41.0

Editor theme moved into `editor/theme.css` (Unity-style dark look, inspector on the right).

## Version 3.41.1

The tab pages (Enemies, Scripts, Events, Audio) scroll inside the window again; the rule is at the end of `editor/theme.css`.

## Version 3.42.0

Enemy types: `ai` (loop, brain, hazard), `pattern`, `patMode`, `alertTime`, `loseTime`, `leash`, `meleeRange`, `keepAway`, `immune`. `MV.Enemies.attacks(type)` lists the attacks a type can use.

## Version 3.43.0

Project keys: `tileSkins` (`{ "#": { sheet, mode: "single" | "auto16", col, row, frames, fps, join: "same" | "solid" } }`, cleaned by `MV.Tiles.cleanSkins`) and `stamps` (`[{ id, name, w, h, rows }]`, `MV.Tiles.cleanStamps`). `MV.Tiles.draw(ctx, ch, px, py, s, { skins, sheet, time, tx, ty, at })` paints a picture when the tile has one. Editor: `editor/tileart_ui.js`.

Status effects and damage types: `engine/status.js` (`MV.Status.mult`, `add`, `step`, `speedMul`, `list`). The player keeps `G.status`, enemies and bosses keep `e.sts`. Test hooks: `MV.Game.status()`, `addStatus(id, seconds)`, `tune()`, `shopOpen()`, `mapOpen()`.

Entity props: Locked door `consume`, `needMsg`; Switch `mode`; Hazard `inflict`, `inflictTime`; Checkpoint (press key) `rest`; Character `shop`.

## Version 3.44.0

Transition entries in `room.tr` take optional keys: `fx` (`none | fade | wipe | iris | slide | dissolve`), `fxTime` (0.1 to 3 s), `mode` (`press`), `key` (`down`; default Up) and `ride` (0.5 to 10 s). Cleaned in the editor by `okTr`. At runtime `doorGo(tg, from, e)` picks the doorway's effect, else the camera profile's `doorFx`; `simDoors` handles press doors and rides (`G.go`, `G.dprompt`). Camera transitions gained `slide` and `dissolve`. Test hook: `MV.Game.door()`.

## Version 3.44.1

Level editor tool `M` (sub-tab Enemies, `#enmt`, `#enmp`) places `enemy` (props.kind = enemy type id) and `hazard` entities; it belongs to the `objects` layer. Enemies tab: strike hitboxes drag in the preview (`dragSetup`), Play updates the slider and timeline through `PLIVE`.

## Version 3.44.2

`examples/tidebound-build.js` writes `examples/tidebound.json` (a hand-built project in the format of FORMAT.md; its `Room` helper shows how rooms, pits and doorways are written). `tests/showcase.js` exports it with `tools/export.js` and plays it in Chromium (dash gap, double jump wall, wall jump shaft, lift, boss). The exported player falls back to the default player sprite when a project has no `sprite`.

## Version 3.44.3

`examples/tidebound-art.py` draws the example's pictures into `examples/tidebound-art/`; `tidebound-build.js` embeds them as sheets (data URLs), builds Studio clips (`clip()`), room decorations (`Room.deco`, stored in `room.art`), layered backgrounds (`backdrop()`), tile pictures (`tileSkins`) and UI pictures. `engine/game/12-api.js` sets `MV.PlayerSprite.clips` from `world.anims` when a game starts.
